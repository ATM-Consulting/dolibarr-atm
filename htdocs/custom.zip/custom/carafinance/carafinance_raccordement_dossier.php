<?php
/* Copyright (C) 2007-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *  \file       carafinance_document.php
 *  \ingroup    carafinance
 *  \brief      Tab for documents linked to carafinance
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/carafinance/class/carafinance.class.php');
dol_include_once('/carafinance/lib/carafinance_carafinance.lib.php');

// Load translation files required by the page
$langs->loadLangs(array("carafinance@carafinance", "companies", "other", "mails"));


$action = GETPOST('action', 'aZ09');
$confirm = GETPOST('confirm');
$id = (GETPOST('socid', 'int') ? GETPOST('socid', 'int') : GETPOST('id', 'int'));
$ref = GETPOST('ref', 'alpha');

// Get parameters
$sortfield = GETPOST("sortfield", 'alpha');
$sortorder = GETPOST("sortorder", 'alpha');
$page = GETPOST("page", 'int');
if (empty($page) || $page == -1) { $page = 0; }     // If $page is not defined, or '' or -1
$offset = $conf->liste_limit * $page;
$pageprev = $page - 1;
$pagenext = $page + 1;
if (!$sortorder) $sortorder = "ASC";
if (!$sortfield) $sortfield = "name";
//if (! $sortfield) $sortfield="position_name";

// Initialize technical objects
$object = new carafinance($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->carafinance->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('carafinancedocument', 'globalcard')); // Note that conf->hooks_modules contains array
// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once  // Must be include, not include_once. Include fetch and fetch_thirdparty but not fetch_optionals

//if ($id > 0 || ! empty($ref)) $upload_dir = $conf->carafinance->multidir_output[$object->entity?$object->entity:$conf->entity] . "/carafinance/" . dol_sanitizeFileName($object->id);
if ($id > 0 || !empty($ref)) $upload_dir = $conf->carafinance->multidir_output[$object->entity ? $object->entity : $conf->entity]."/carafinance/".dol_sanitizeFileName($object->ref);

// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$result = restrictedArea($user, 'carafinance', $object->id);

$permissiontoadd = $user->rights->carafinance->carafinance->write; // Used by the include of actions_addupdatedelete.inc.php



/*
 * Actions
 */
$idiso = GETPOST('idiso', 'int');
$idces = GETPOST('idces', 'int');
$idrep = GETPOST('idrep', 'int');
$idtoit = GETPOST('idtoit', 'int');
$save = GETPOST('save', 'alpha');
if ($idiso){
	$object->link($idiso,1);
}
if ($idces){
	$object->link($idces,2);
}
if ($idrep){
	$object->link($idrep,3);
}
if ($idtoit){
	$object->link($idtoit,4);
}
if ($save){
	header("Location: ".dol_buildpath('/carafinance/carafinance_card.php', 1).'?id='.$object->id);
	exit;
}

/*
 * View
 */

$form = new Form($db);

$title = $langs->trans("carafinance").' - '.$langs->trans("Files");
$help_url = '';
//$help_url='EN:Module_Third_Parties|FR:Module_Tiers|ES:Empresas';
llxHeader('', $title, $help_url);

if ($object->id)
{
	/*
	 * Show tabs
	 */
	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
    print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="update">';
	print '<input type="hidden" name="id" value="'.$object->id.'">';
	print '<table>
	<tr><td colspan=2>Saisie des identifiants des produits pour les relier à l\'afaire</td></tr>
	<tr><td>ISO</td><td><input type="text" name="idiso"></td></tr>
	<tr><td>CES</td><td><input type="text" name="idces"></td></tr>
	<tr><td>REP</td><td><input type="text" name="idrep"></td></tr>
	<tr><td>TOITURE</td><td><input type="text" name="idtoit"></td></tr>
	<tr><td><div class="center"><input type="submit" class="button" name="save" value="'.$langs->trans("Save").'"></td><td></td></tr>
	</table>';


}

// End of page
llxFooter();
$db->close();
