<?php
// LMK
/**
 * Class carafinancePaiement. Classe qui gère les paiements 
 */
class carafinancePaiement  extends CommonObject
{

	/**
	 * @var string ID pour identifier un objet géré
	 */
	public $element = 'packdetdet';

	/**
	 * @var string Nom de la table sans préfixe où l'objet est stocké
	 */
	public $table_element = 'carafinance_paiement';
	public $table_objectelement = 'carafinance_carafinance';

	public function __construct($db)
	{
		$this->db = $db;
	}
    
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>1, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'type_paiement' => array('type'=>'integer', 'label'=>'Moyen de paiement', 'enabled'=>1, 'position'=>40, 'notnull'=>1, 'visible'=>1, 'index'=>1, 'arrayofkeyval'=>array( '1'=>'Carte bancaire','2'=>'Chèque','3'=>'Espèce','4'=>'Ordre de prélèvement','5'=>'Virement bancaire','6'=>'CMA'),),
		'numero_cheque' => array('type'=>'varchar(255)', 'label'=>'Numéro du chèque', 'enabled'=>1, 'position'=>41, 'notnull'=>-1, 'visible'=>-2,),
		'banque_cheque' => array('type'=>'varchar(255)', 'label'=>'Banque du chèque', 'enabled'=>1, 'position'=>42, 'notnull'=>-1, 'visible'=>-2,),
		'note_cheque' => array('type'=>'text', 'label'=>'Notes pour le chèque', 'enabled'=>1, 'position'=>43, 'notnull'=>-1, 'visible'=>-2,),
		'amount' => array('type'=>'price', 'label'=>'Amount', 'enabled'=>1, 'position'=>10, 'notnull'=>0, 'visible'=>1, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'date_creation' => array('type'=>'datetime', 'label'=>'Date', 'enabled'=>1, 'position'=>2, 'notnull'=>1, 'visible'=>-2,),
		'date_prevue' => array('type'=>'datetime', 'label'=>'DatePrevue', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>-2,),
		'date_encaissement' => array('type'=>'datetime', 'label'=>'DateEncaissement', 'enabled'=>1, 'position'=>20, 'notnull'=>0, 'visible'=>-2,),
		'statut' => array('type'=>'integer', 'label'=>'Status', 'enabled'=>1, 'position'=>4, 'notnull'=>1, 'visible'=>1, 'index'=>1),
		'fk_carafinance' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>3, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
	);
    
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 10, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		$sql = 'SELECT ';
		$sql .= $this->getFieldList();
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as p';
		$sql .= ' WHERE fk_carafinance = '.$id;

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i < min($limit, $num))
			{
			    $obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}
    
	function reste($id){
		$sql = 'SELECT SUM(amount) AS impaye';
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element;
		$sql .= ' WHERE fk_carafinance = '.$id;
		$sql .= ' AND statut = 0';
		$resql = $this->db->query($sql);
		if ($resql)
		{
			$num_rows = $this->db->num_rows($resql);
            $obj = $this->db->fetch_object($resql);
			$this->db->free($resql);
            return ($num_rows) ? $obj->impaye : -1;
		}
	}
	
	function paye($id){
		$sql = 'SELECT SUM(amount) AS paye';
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element;
		$sql .= ' WHERE fk_carafinance = '.$id;
		$sql .= ' AND statut = 1';
		$resql = $this->db->query($sql);
		if ($resql)
		{
			$num_rows = $this->db->num_rows($resql);
            $obj = $this->db->fetch_object($resql);
			$this->db->free($resql);
            return ($num_rows) ? $obj->paye : -1;
		}
	}
    
	/*Ajouter un paiement*/
	public function insert()
    {
		$resql = $this->db->query($sql);
        // Traitement des dates pour l'insertion
        $this->date_creation=date('Y-m-d H:i:s');
        (!$this->date_prevue) ? $this->date_prevue = 'null' : $this->date_prevue = "'$this->date_prevue'";
        (!$this->date_encaissement) ? $this->date_encaissement = 'null' : $this->date_encaissement = "'$this->date_encaissement'";
		$sql= 'INSERT INTO '.MAIN_DB_PREFIX.$this->table_element.' (type_paiement, numero_cheque, banque_cheque, note_cheque, amount, date_creation, date_prevue, date_encaissement, statut, fk_carafinance)';
		$sql .=' VALUES ('.$this->type_paiement.',"'.$this->numero_cheque.'","'.$this->banque_cheque.'","'.$this->note_cheque.'",'.$this->amount.',"'.$this->date_creation.'",'.$this->date_prevue.','.$this->date_encaissement.','.$this->statut.','.$this->fk_carafinance.')';
		$resql = $this->db->query($sql);
		if (!$resql) { $error++; $this->error = $this->db->lasterror(); 
			setEventMessages('Erreur requete', $this->error, 'errors');
		} else setEventMessages('Le nouveau paiement a été ajouté !','', 'mesgs');
	}    
    
    /*Supprimer un paiement*/
	public function delete(){
		//on supprime le paiement lié à l'affaire
		$error=0;
		$sql ='DELETE FROM '.MAIN_DB_PREFIX.$this->table_element;
		$sql .= ' WHERE rowid='.$this->rowid.' AND fk_carafinance='.$this->fk_carafinance;
		$resql = $this->db->query($sql);
		if (!$resql){
			setEventMessages('Erreur suppression objet', $this->error, 'errors');
			$error++;
		} else setEventMessages('Le paiement a été supprimé !','', 'mesgs');
	}
    
    /*Mettre à jour un paiement - Encaisser un paiement*/
	public function update(){
		//On met à jour le paiement lié à l'affaire
        // Formatage des dates pour l'insertion
        (!$this->date_prevue) ? $this->date_prevue = 'null' : $this->date_prevue;
        (!$this->date_encaissement) ? $this->date_encaissement = 'null' : $this->date_encaissement ;
		$sql ='UPDATE '.MAIN_DB_PREFIX.$this->table_element;
        $sql .= ' SET type_paiement = "'.$this->type_paiement.'", numero_cheque = "'.$this->numero_cheque.'", banque_cheque = "'.$this->banque_cheque.'", note_cheque = "'.$this->note_cheque.'", amount= "'.$this->amount.'", date_prevue = "'.$this->date_prevue.'", date_encaissement = "'.$this->date_encaissement.'", statut = "'.$this->statut.'"';
		$sql .= ' WHERE rowid='.$this->rowid.' AND fk_carafinance='.$this->fk_carafinance;
		$resql = $this->db->query($sql);
		if (!$resql){
			setEventMessages('Erreur mise à jour objet', $this->error, 'errors');
			$error++;
		} else setEventMessages('Le paiement a été mis à jour !','', 'mesgs');
	}
}
?>