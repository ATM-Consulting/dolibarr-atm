<?php
/* Copyright (C) 2007-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       carafinance_list.php
 *		\ingroup    carafinance
 *		\brief      List page for carafinance
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB', '1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER', '1');					// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC', '1');					// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN', '1');					// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION', '1');			// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION', '1');			// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK', '1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL', '1');					// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK', '1');					// Do not check style html tag into posted data
//if (! defined('NOIPCHECK'))                define('NOIPCHECK', '1');						// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU', '1');					// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML', '1');					// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX', '1');       		  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN", '1');						// If this page is public (can be called outside logged session)
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT', 'auto');			// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN', '1');		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("XFRAMEOPTIONS_ALLOWALL"))   define('XFRAMEOPTIONS_ALLOWALL', '1');			// Do not add the HTTP header 'X-Frame-Options: SAMEORIGIN' but 'X-Frame-Options: ALLOWALL'

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';

// load carafinance libraries
require_once __DIR__.'/class/carafinancecom.class.php';

// for other modules
//dol_include_once('/othermodule/class/otherobject.class.php');

// Load translation files required by the page
$langs->loadLangs(array("carafinance@carafinance", "other"));

$action     = GETPOST('action', 'aZ09') ?GETPOST('action', 'aZ09') : 'view'; // The action 'add', 'create', 'edit', 'update', 'view', ...
$massaction = GETPOST('massaction', 'alpha'); // The bulk action (combo box choice into lists)
$show_files = GETPOST('show_files', 'int'); // Show files area generated by bulk actions ?
$confirm    = GETPOST('confirm', 'alpha'); // Result of a confirmation
$cancel     = GETPOST('cancel', 'alpha'); // We click on a Cancel button
$toselect   = GETPOST('toselect', 'array'); // Array of ids of elements selected into a list
$contextpage = GETPOST('contextpage', 'aZ') ? GETPOST('contextpage', 'aZ') : 'carafinancelist'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha'); // Go back to a dedicated page
$optioncss  = GETPOST('optioncss', 'aZ'); // Option for the css output (always '' except when 'print')

$id = GETPOST('id', 'int');

// Load variable for pagination
$limit = GETPOST('limit', 'int') ? GETPOST('limit', 'int') : $conf->liste_limit;
$sortfield = GETPOST('sortfield', 'alpha');
$sortorder = GETPOST('sortorder', 'alpha');
if($_SESSION['list_finance']['page'] && GETPOST('page', 'int')=="")
	$page = $_SESSION['list_finance']['page'];
else{
	$page = GETPOST('page', 'int');
	$_SESSION['list_finance']['page']=$page;
}
if (empty($page) || $page == -1 || GETPOST('button_search', 'alpha') || GETPOST('button_removefilter', 'alpha') || (empty($toselect) && $massaction === '0')) { $page = 0; }     // If $page is not defined, or '' or -1 or if we click on clear filters or if we select empty mass action
$offset = $limit * $page;
$pageprev = $page - 1;
$pagenext = $page + 1;

// Initialize technical objects
$object = new carafinance($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->carafinance->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('carafinancelist')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);
//$extrafields->fetch_name_optionals_label($object->table_element_line);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Default sort order (if not yet defined by previous GETPOST)
if (!$sortfield) $sortfield = "w.".key($object->fields); // Set here default search field. By default 1st field in definition.
if (!$sortorder) $sortorder = "ASC";

// Security check
if (empty($conf->carafinance->enabled)) accessforbidden('Module not enabled');
$socid = 0;
if ($user->socid > 0)	// Protection if external user
{
	//$socid = $user->socid;
	accessforbidden();
}
//$result = restrictedArea($user, 'carafinance', $id, '');

// Initialize array of search criterias
$search_all=trim(GETPOST("search_all", 'alpha'));
$search=array();
foreach($object->fields as $key => $val)
{
	if (!$_SESSION['list_finance']['search'.$key] || GETPOST('search_'.$key, 'alpha') !== '') {
		$search[$key]=GETPOST('search_'.$key, 'alpha');
		$_SESSION['list_finance']['search'.$key]=$search[$key];
	}
	else $search[$key]=$_SESSION['list_finance']['search'.$key];
}
if(!$_SESSION['list_finance']['search_ville'] || GETPOST('search_ville', 'alpha') !== ''){
	$search['ville']=GETPOST('search_ville', 'alpha');
	$_SESSION['list_finance']['search_ville']=$search['ville'];
}
else $search['ville']=$_SESSION['list_finance']['search_ville'];

if(!$_SESSION['list_finance']['search_phone'] || GETPOST('search_phone', 'alpha') !== '' ){
	$search['phone']=GETPOST('search_phone', 'alpha');
	$_SESSION['list_finance']['search_phone']=$search['phone'];
}
else $search['phone']=$_SESSION['list_finance']['search_phone'];

if(!$_SESSION['list_finance']['search_address'] || GETPOST('search_address', 'alpha') !== ''){
	$search['address']=GETPOST('search_address', 'alpha');
	$_SESSION['list_finance']['search_address']=$search['address'];
}
else $search['address']=$_SESSION['list_finance']['search_address'];
if(!$_SESSION['list_finance']['search_status'] || GETPOST('search_status') !== ''){
	$search['status']=GETPOST('search_status');
	$_SESSION['list_finance']['search_status']=$search['status'];
}
else $search['status']=$_SESSION['list_finance']['search_status'];

// List of fields to search into when doing a "search in all"
$fieldstosearchall = array();
$_SESSION['list_finance']['sortfield']=$sortfield;
$_SESSION['list_finance']['sortorder']=$sortorder;

foreach($object->fields as $key => $val)
{
	if ($val['searchall']) $fieldstosearchall['w.'.$key]=$val['label'];
}

// Definition of fields for list
$arrayfields=array();
$tab=$object->get_fields_supp();
$object->fields=array_merge($object->fields, $tab);
foreach($object->fields as $key => $val)
{
	// If $val['visible']==0, then we never show the field
	if (!empty($val['visible'])) $arrayfields['w.'.$key] = array('label'=>$val['label'], 'checked'=>(($val['visible'] < 0) ? 0 : 1), 'enabled'=>($val['enabled'] && ($val['visible'] != 3)), 'position'=>$val['position']);
}
// Extra fields
if (is_array($extrafields->attributes[$object->table_element]['label']) && count($extrafields->attributes[$object->table_element]['label']) > 0)
{
	foreach($extrafields->attributes[$object->table_element]['label'] as $key => $val)
	{
		if (!empty($extrafields->attributes[$object->table_element]['list'][$key])) {
			$arrayfields["ef.".$key] = array(
				'label'=>$extrafields->attributes[$object->table_element]['label'][$key],
				'checked'=>(($extrafields->attributes[$object->table_element]['list'][$key]<0)?0:1),
				'position'=>$extrafields->attributes[$object->table_element]['pos'][$key],
				'enabled'=>(abs($extrafields->attributes[$object->table_element]['list'][$key])!=3 && $extrafields->attributes[$object->table_element]['perms'][$key])
			);
		}
	}
}
$object->fields = dol_sort_array($object->fields, 'position');
$arrayfields = dol_sort_array($arrayfields, 'position');

$permissiontoread = $user->rights->carafinance->carafinance->read;
$permissiontoadd = $user->rights->carafinance->carafinance->write;
$permissiontodelete = $user->rights->carafinance->carafinance->delete;


/*
 * Actions
 */

if (GETPOST('cancel', 'alpha')) { $action = 'list'; $massaction = ''; }
if (!GETPOST('confirmmassaction', 'alpha') && $massaction != 'presend' && $massaction != 'confirm_presend') { $massaction = ''; }

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook))
{
	// Selection of new fields
	include DOL_DOCUMENT_ROOT.'/core/actions_changeselectedfields.inc.php';

	// Purge search criteria
	if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')) // All tests are required to be compatible with all browsers
	{
		foreach ($object->fields as $key => $val)
		{
			$search[$key] = '';
		}
		$toselect = '';
		$search_array_options = array();
		unset($_POST['search_search_fk_soc']);
		unset($_SESSION['list_finance']);
	}
	if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')
		|| GETPOST('button_search_x', 'alpha') || GETPOST('button_search.x', 'alpha') || GETPOST('button_search', 'alpha'))
	{
		$massaction = ''; // Protection to avoid mass action if we force a new search during a mass action confirmation
		
	}

	// Mass actions
	$objectclass = 'carafinance';
	$objectlabel = 'carafinance';
	$uploaddir = $conf->carafinance->dir_output;
	include DOL_DOCUMENT_ROOT.'/core/actions_massactions.inc.php';
}



/*
 * View
 */

$form = new Form($db);

$now = dol_now();

//$help_url="EN:Module_carafinance|FR:Module_carafinance_FR|ES:Módulo_carafinance";
$help_url = '';
$title = $langs->trans('ListOf', $langs->transnoentitiesnoconv("Renov Direction"));


// Build and execute select
// --------------------------------------------------------------------

$sql = 'SELECT ';
$sql_fields= 'distinct (w.rowid),w.fk_soc,s.nom, w.ref, w.entity, w.date_creation,w.description, w.tms, w.fk_user_creat, w.fk_user_modif, w.status, w.date_commercial, 
w.date_signature, w.date_expedition,w.amount,w.date_pv,w.date_bc,w.fk_usercomm,w.pack,w.mod_financement, w.model_pdf, w.date_depot,w.alerte_dossier_finance,
w.numero_dossier,w.date_cmafinancement,w.date_modification_etat, w.date_previsite,w.date_enfabrication, w.date_invalide, w.date_incomplet,w.date_termine, w.fk_user_pos,w.facture_poseur, w.facture_commercial,
w.mod_favorable,w.date_favorable,w.date_standby,w.description_pertinente,w.suivi_financement,poseur_amount,status_poseur,commercial_amount, status_commercial,source,
cpv.rowid as ville, concat(COALESCE(s.phone,""),";",COALESCE(s.fax,""),";",COALESCE(s.url,"")) as phone, s.address,';

$sql.=$sql_fields;

$sql = preg_replace('/,\s*$/', '', $sql);
$sql .= " FROM ".MAIN_DB_PREFIX."carafinance_carafinance as w";
$sql.=" left join ".MAIN_DB_PREFIX."societe s on s.rowid=w.fk_soc";
$sql.=' left join '.MAIN_DB_PREFIX.'societe_extrafields se on fk_object=s.rowid';
$sql.=' left join '.MAIN_DB_PREFIX.'cara_cpville cpv on cpv.rowid=se.ville';
$sql.=" left join ".MAIN_DB_PREFIX."carafinance_carafinancedet fidet on fidet.fk_carafinance=w.rowid";

if ($object->ismultientitymanaged == 1) $sql .= " WHERE w.entity IN (".getEntity($object->element).")";
else $sql .= " WHERE 1 = 1";
foreach ($search as $key => $val)
{
	
	if ($key == 'status' && ($search[$key] == -1 || $search[$key] == '') ) continue;
	if ($key == 'ville' && $search[$key] == -1) continue;
	if($key == 'status' && is_array( $search[$key])){
		$tabrecherche='(';
		foreach ($search[$key] as $keystatus){
			$tabrecherche.=$keystatus.',';
		}
		$tabrecherche=trim($tabrecherche,',');
		$sql.=' and  (w.status IN '.$tabrecherche.' ) )'; 
		continue;
	}
	if($key=='ville' && ($search[$key] != -1 && $search[$key] != '')) {
		$sql.=' and  (cpv.rowid = "'.$search['ville'].'" )'; 
		continue;
	}
	if($key=='phone' && $search[$key] != "") {
		$sql.=' and  (replace(s.phone," ","") like "%'.$search['phone'].'%" or replace(s.fax," ","") like "%'.$search['phone'].'%" or replace(s.url," ","") like "%'.$search['phone'].'%" )'; 
		continue;
	}
	if($key=='address' && $search[$key] != "") {
		$sql.=' and  (s.address like "%'.$search['address'].'%" )'; 
		continue;
	}
	if($key=='status' && $search[$key] != "-1") {
		$sql.=' and  (w.status ='.$search['status'].' )'; 
		continue;
	}
	if($key=='fk_soc' && $search[$key] != "") {
		$sql.=' and  (w.fk_soc in ('.$search[$key].') )'; 
		continue;
	}
	if($key=='fk_usercomm' && $search[$key] != "" && $search[$key] != "-1") {
		$sql.=' and  (w.fk_usercomm in ('.$search[$key].') )'; 
		continue;
	}
	if($key=='description' && $search[$key] != "-1") {
		$sql.=' and  (w.description like "%'.$search['description'].'%" )'; 
		continue;
	}
	$mode_search = 1;
	if (strpos($object->fields[$key]['type'], 'integer:') === 0) {
		if ($search[$key] == '-1') $search[$key] = '';
		$mode_search = 2;
	}
	if ($search[$key] != '' && $search[$key] !=-1 ) $sql .= natural_search($key, $search[$key], (($key == 'status') ? 2 : $mode_search));

}
$searchlibvialoupe=GETPOST('search_search_fk_soc');
if($searchlibvialoupe && ($search['fk_soc']=="")) {
	$searchlibvialoupe=trim($searchlibvialoupe);
	$sql.=' and  (s.nom like "%'.$searchlibvialoupe.'%" )'; 
}
$sql .= $db->order($sortfield, $sortorder);
//print $sql;
// Count total nb of records
$nbtotalofrecords = '';
if (empty($conf->global->MAIN_DISABLE_FULL_SCANLIST))
{
	$resql = $db->query($sql);
	$nbtotalofrecords = $db->num_rows($resql);
	if (($page * $limit) > $nbtotalofrecords)	// if total of record found is smaller than page * limit, goto and load page 0
	{
		$page = 0;
		$offset = 0;
	}
}
// if total of record found is smaller than limit, no need to do paging and to restart another select with limits set.
if (is_numeric($nbtotalofrecords) && ($limit > $nbtotalofrecords || empty($limit)))
{
	$num = $nbtotalofrecords;
}
else
{
	if ($limit) $sql .= $db->plimit($limit + 1, $offset);

	$resql = $db->query($sql);
	if (!$resql)
	{
		dol_print_error($db);
		exit;
	}

	$num = $db->num_rows($resql);
}

// Direct jump if only one record found
if ($num == 1 && !empty($conf->global->MAIN_SEARCH_DIRECT_OPEN_IF_ONLY_ONE) && $search_all && !$page)
{
	$obj = $db->fetch_object($resql);
	$id = $obj->rowid;
	header("Location: ".dol_buildpath('/carafinance/carafinance_card.php', 1).'?id='.$id);
	exit;
}


// Output page
// --------------------------------------------------------------------

llxHeader('', $title, $help_url);

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});
</script>';

$arrayofselected = is_array($toselect) ? $toselect : array();

$param = '';
if (!empty($contextpage) && $contextpage != $_SERVER["PHP_SELF"]) $param .= '&contextpage='.urlencode($contextpage);
if ($limit > 0 && $limit != $conf->liste_limit) $param .= '&limit='.urlencode($limit);
foreach ($search as $key => $val)
{
    if (is_array($search[$key]) && count($search[$key])) foreach ($search[$key] as $skey) $param .= '&search_'.$key.'[]='.urlencode($skey);
    else $param .= '&search_'.$key.'='.urlencode($search[$key]);
}
if ($optioncss != '')     $param .= '&optioncss='.urlencode($optioncss);
// Add $param from extra fields
include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_param.tpl.php';

// List of mass actions available
$arrayofmassactions = array(
    //'validate'=>$langs->trans("Validate"),
    //'generate_doc'=>$langs->trans("ReGeneratePDF"),
    //'builddoc'=>$langs->trans("PDFMerge"),
    //'presend'=>$langs->trans("SendByMail"),
);
if ($permissiontodelete) $arrayofmassactions['predelete'] = '<span class="fa fa-trash paddingrightonly"></span>'.$langs->trans("Delete");
if (GETPOST('nomassaction', 'int') || in_array($massaction, array('presend', 'predelete'))) $arrayofmassactions = array();
$massactionbutton = $form->selectMassAction('', $arrayofmassactions);

print '<form method="POST" id="searchFormList" action="'.$_SERVER["PHP_SELF"].'">'."\n";
if ($optioncss != '') print '<input type="hidden" name="optioncss" value="'.$optioncss.'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="formfilteraction" id="formfilteraction" value="list">';
print '<input type="hidden" name="action" value="list">';
print '<input type="hidden" name="sortfield" value="'.$sortfield.'">';
print '<input type="hidden" name="sortorder" value="'.$sortorder.'">';
print '<input type="hidden" name="page" value="'.$page.'">';
print '<input type="hidden" name="contextpage" value="'.$contextpage.'">';

$newcardbutton = dolGetButtonTitle($langs->trans('New'), '', 'fa fa-plus-circle', dol_buildpath('/carafinance/carafinance_card.php', 1).'?action=create&backtopage='.urlencode($_SERVER['PHP_SELF']), '', $permissiontoadd);

print_barre_liste($title, $page, $_SERVER["PHP_SELF"], $param, $sortfield, $sortorder, $massactionbutton, $num, $nbtotalofrecords, 'title_companies', 0, $newcardbutton, '', $limit);

// Add code for pre mass action (confirmation or email presend form)
$topicmail = "SendcarafinanceRef";
$modelmail = "carafinance";
$objecttmp = new carafinance($db);
$trackid = 'xxxx'.$object->id;
include DOL_DOCUMENT_ROOT.'/core/tpl/massactions_pre.tpl.php';

if ($search_all)
{
	foreach ($fieldstosearchall as $key => $val) $fieldstosearchall[$key] = $langs->trans($val);
	print '<div class="divsearchfieldfilter">'.$langs->trans("FilterOnInto", $search_all).join(', ', $fieldstosearchall).'</div>';
}

$moreforfilter = '';
/*$moreforfilter.='<div class="divsearchfield">';
$moreforfilter.= $langs->trans('MyFilter') . ': <input type="text" name="search_myfield" value="'.dol_escape_htmltag($search_myfield).'">';
$moreforfilter.= '</div>';*/

$parameters = array();
$reshook = $hookmanager->executeHooks('printFieldPreListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
if (empty($reshook)) $moreforfilter .= $hookmanager->resPrint;
else $moreforfilter = $hookmanager->resPrint;

if (!empty($moreforfilter))
{
	print '<div class="liste_titre liste_titre_bydiv centpercent">';
	print $moreforfilter;
	print '</div>';
}

$varpage = empty($contextpage) ? $_SERVER["PHP_SELF"] : $contextpage;
$selectedfields = $form->multiSelectArrayWithCheckbox('selectedfields', $arrayfields, $varpage); // This also change content of $arrayfields
$selectedfields .= (count($arrayofmassactions) ? $form->showCheckAddButtons('checkforselect', 1) : '');

print '<div class="div-table-responsive">'; // You can use div-table-responsive-no-min if you dont need reserved height for your table
print '<table class="tagtable liste'.($moreforfilter ? " listwithfilterbefore" : "").'">'."\n";


// Fields title search
// --------------------------------------------------------------------
print '<tr class="liste_titre">';
$tabnottoaffiche=array('date_commercial','date_signature', 'date_expedition','date_pv','date_bc','date_depot','date_cmafinancement','date_previsite','date_enfabrication','date_invalide','date_incomplet','date_termine','date_favorable','ville','phone','date_finstandby','date_standby','date_fincontratexp');

foreach ($object->fields as $key => $val)
{
	$cssforfield = (empty($val['css']) ? '' : $val['css']);
	if ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '').'center';
	if (in_array($key, $tabnottoaffiche)) continue;
	elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'center';
	elseif (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
	elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $val['label'] != 'TechnicalID') $cssforfield .= ($cssforfield ? ' ' : '').'right';
	elseif (in_array($key, array('fk_soc','status'))) $cssforfield .= ($cssforfield ? ' ' : '').'right nowrap';
	if (!empty($arrayfields['w.'.$key]['checked']))
	{
		print '<td class="liste_titre'.($cssforfield ? ' '.$cssforfield : '').'">';
		if (is_array($val['arrayofkeyval']) && $key=='status'){
			$statuslist = $object->fields['status']['arrayofkeyval'];
			$arrayselected = GETPOST('search_status', 'array');
			$out=$form->multiselectarray('search_status', $statuslist, $arrayselected, null, null, null, null, "90%");
			$out.='<button type="submit" class="liste_titre button_search" name="button_search_x" value="x"><span class="fa fa-search"></span></button>';
			$out .=  '<button type="submit" class="liste_titre button_removefilter" name="button_removefilter_x" value="x"><span class="fa fa-remove"></span></button>';
			print $out;
		}
		elseif (is_array($val['arrayofkeyval'])) print $form->selectarray('search_'.$key, $val['arrayofkeyval'], $search[$key], $val['notnull'], 0, 0, '', 1, 0, 0, '', 'maxwidth100');
		elseif (strpos($val['type'], 'integer:') === 0) {
			$out=$object->showInputField($val, $key, $search[$key], 'onchange="this.form.submit();"', '', 'search_', 'maxwidth150', 1);
			//loupe à côté du champ rechercher
			if($key=='fk_soc'){	
				$out .=  '<button type="submit" class="liste_titre button_search" name="button_search_x" value="x"><span class="fa fa-search"></span></button>';
				$out .=  '<button type="submit" class="liste_titre button_removefilter" name="button_removefilter_x" value="x"><span class="fa fa-remove"></span></button>';
			}
			print $out;
		}
		elseif (! preg_match('/^(date|timestamp)/', $val['type'])) print '<input type="text" class="flat maxwidth75" name="search_'.$key.'" value="'.dol_escape_htmltag($search[$key]).'">';
		print '</td>';
	}
}
// Extra fields
include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_input.tpl.php';

// Fields from hook
$parameters = array('arrayfields'=>$arrayfields);
$reshook = $hookmanager->executeHooks('printFieldListOption', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;
// Action column
print '<td class="liste_titre maxwidthsearch">';
$searchpicto = $form->showFilterButtons();
print $searchpicto;
print '</td>';
print '</tr>'."\n";


// Fields title label
// --------------------------------------------------------------------
print '<tr class="liste_titre">';
foreach ($object->fields as $key => $val)
{
	$cssforfield = (empty($val['css']) ? '' : $val['css']);
	if (in_array($key, $tabnottoaffiche)) continue;
	if ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '').'center';
	elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'center';
	elseif (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
	elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $val['label'] != 'TechnicalID') $cssforfield .= ($cssforfield ? ' ' : '').'right';
	if (!empty($arrayfields['w.'.$key]['checked']))
	{
		print getTitleFieldOfList($arrayfields['w.'.$key]['label'], 0, $_SERVER['PHP_SELF'], 'w.'.$key, '', $param, ($cssforfield ? 'class="'.$cssforfield.'"' : ''), $sortfield, $sortorder, ($cssforfield ? $cssforfield.' ' : ''))."\n";
	}
}
print '<td>Toiture</td><td>CES</td><td>REP</td><td>ISO</td><td>Menuiserie</td>';
// Extra fields
include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_title.tpl.php';
// Hook fields
$parameters = array('arrayfields'=>$arrayfields, 'param'=>$param, 'sortfield'=>$sortfield, 'sortorder'=>$sortorder);
$reshook = $hookmanager->executeHooks('printFieldListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;
// Action column
print getTitleFieldOfList($selectedfields, 0, $_SERVER["PHP_SELF"], '', '', '', '', $sortfield, $sortorder, 'center maxwidthsearch ')."\n";
print '</tr>'."\n";


// Detect if we need a fetch on each output line
$needToFetchEachLine = 0;
if (is_array($extrafields->attributes[$object->table_element]['computed']) && count($extrafields->attributes[$object->table_element]['computed']) > 0)
{
	foreach ($extrafields->attributes[$object->table_element]['computed'] as $key => $val)
	{
		if (preg_match('/\$object/', $val)) $needToFetchEachLine++; // There is at least one compute field that use $object
	}
}


// Loop on record
// --------------------------------------------------------------------
$i = 0;
$totalarray = array();
while ($i < ($limit ? min($num, $limit) : $num))
{
	$obj = $db->fetch_object($resql);
	if (empty($obj)) break; // Should not happen

	// Store properties in $object
	$object->setVarsFromFetchObj($obj);

	// Show here line of result
	print '<tr class="oddeven">';
	foreach ($object->fields as $key => $val)
	{
		if (in_array($key,$tabnottoaffiche)) continue;
		$cssforfield = (empty($val['css']) ? '' : $val['css']);
	    if (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'center';
	    elseif ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '').'center nowrap';

	    if (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
		elseif ($key == 'ref') $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
		if (in_array($key, array('planification','ville','phone','suivi_financement'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';

	    if (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $key != 'status') $cssforfield .= ($cssforfield ? ' ' : '').'right';
		
	    if (!empty($arrayfields['w.'.$key]['checked']))
		{
			print '<td'.($cssforfield ? ' class="'.$cssforfield.'"' : '').'>';
			if ($key == 'status') {
				print $object->getLibStatut(5);
				// if($obj->alerte_dossier_finance==1)
				// 	print '&nbsp;<img src="img/alerte.gif" width=25 valign="bottom">';
			}
			elseif ($key == 'suivi_financement') {
				print $object->getLibStatutFin(5);
				if($object->status==$object::STATUS_FABRICATION && $object->suivi_financement==$object::STATUSFIN_FAVORABLE)
					print '&nbsp;<img src="img/alerte.gif" width=25 valign="bottom">';
			}
			elseif($key=='ref'){
				$url=dol_buildpath('carafinance/carafinancecom_card.php?id='.$obj->rowid.'',1);
				print '<a href="'.$url.'">'.$obj->ref.'</a>';

			}
			elseif($key=='poseur'){
				//$poseur=$object->getPoseurToit();
				print $object->poseur;

			}
			elseif($key=='mod_favorable' && $object->$key > 0){
				$out='<span class="badge  badge-statusrenov2 badge-status">';
				
				$out.='<a title="<div class=&quot;centpercent&quot;>
				<b>Date Favorable :</b> '.dol_print_date($object->date_favorable,'%d/%m/%Y').'</div>" class="classfortooltip refurl">';
				$out.='Favorable</span></a>';
				print $out;

			}
			elseif($key=='phone'){
				$tab_phone=explode(';',$object->$key);
				$tel='';
				foreach($tab_phone as $phone){
					$tel = preg_replace('/(\d{4})(\d{2})(\d{2})(\d{2})/','\1 \2 \3 \4',$phone);
					print $tel.'<br>';
				}
			}
			elseif($key=='date_modification_etat'){
				if($object->$key){
					$datec=new DateTime();
					$datec=dol_print_date($object->date_modification_etat,'%d/%m/%Y');
				}
				else $datec="";
				if($object->date_commercial)
					$datecommercial=dol_print_date($object->date_commercial,'%d/%m/%Y');
				else $datecommercial="";
				if($object->date_signature){
					$datesignature=dol_print_date($object->date_signature,'%d/%m/%Y');
				}
				else $datesignature="";
				if($object->date_expedition){
					$dateexpedition=dol_print_date($object->date_expedition,'%d/%m/%Y');
				}
				else $dateexpedition="";
				if($object->date_pv){
					$datepv=dol_print_date($object->date_pv,'%d/%m/%Y');
				}
				else $datepv="";
				// if($object->date_bc){
				// 	$datebc=dol_print_date($object->date_bc,'%d/%m/%Y');
				// }
				// else $datebc="";
				if($object->date_depot){
					$datedepot=dol_print_date($object->date_depot,'%d/%m/%Y');
				}
				else $datedepot="";
				if($object->date_cmafinancement){
					$datecmafinancement=dol_print_date($object->date_cmafinancement,'%d/%m/%Y');
				}
				else $datecmafinancement="";
				if($object->date_previsite){
					$dateprevisite=dol_print_date($object->date_previsite,'%d/%m/%Y');
				}
				else $dateprevisite="";
				if($object->date_enfabrication){
					$dateenfabrication=dol_print_date($object->date_enfabrication,'%d/%m/%Y');
				}
				else $dateenfabrication="";
				if($object->date_invalide){
					$dateinvalide=dol_print_date($object->date_invalide,'%d/%m/%Y');
				}
				else $dateinvalide="";
				if($object->date_incomplet){
					$dateincomplet=dol_print_date($object->date_incomplet,'%d/%m/%Y');
				}
				else $dateincomplet="";
				if($object->date_termine){
					$datetermine=dol_print_date($object->date_termine,'%d/%m/%Y');
				}
				else $datetermine="";
				if($object->date_standby){
					$datestandby=dol_print_date($object->date_standby,'%d/%m/%Y');
				}
				else $datestandby="";
				if($object->date_fincontratexp){
					$datefincontratexp=dol_print_date($object->date_fincontratexp,'%d/%m/%Y');
				}
				else $datefincontratexp="";
				if($object->date_finstandby){
					$datefinstandby=dol_print_date($object->date_finstandby,'%d/%m/%Y');
				}
				else $datefinstandby="";
				
				
				
				$out='<a  title="<div class=&quot;centpercent&quot;>
				<b>Acceptation/Annulation:</b> '.$datecommercial.'<br>
				<b>StandBY:</b> '.$datestandby.'<br>
				<b>Refusé</b> '.$datesignature.'<br>
				<b>En Etude</b>:'.$dateexpedition.' <br>
				<b>En Cours : </b>'.$datepv.'<br>
				<b>Paye:</b> '.$datedepot.' <br>
				<b>CMA/Fianancement :</b> '.$datecmafinancement.' <br>
				<b>Previsite :</b> '.$dateprevisite.' <br>
				<b>En Fab :</b> '.$dateenfabrication.' <br>
				<b>Invalide :</b> '.$dateinvalide.' <br>
				<b>Incomplet :</b> '.$dateincomplet.' <br>
				<b>Envoi contrat financement :</b> '.$datefincontratexp.' <br>
				<b>Standby financement :</b> '.$datefinstandby.' <br>
				<b>Pose :</b> '.$datetermine.'  </div>" class="classfortooltip refurl">'.$datec.'</a>';
				print $out;
			}
			elseif($key=='fk_soc'){
				$tab_phone=explode(';',$object->phone);
				foreach($tab_phone as $phone){
					$tel .= preg_replace('/(\d{4})(\d{2})(\d{2})(\d{2})/','\1 \2 \3 \4',$phone).'<br>';
				}
				$out='<a href="/societe/card.php?socid='.$object->fk_soc.'" title="<div class=&quot;centpercent&quot;>
					<b>ville: </b>'.$object->showOutputField($object->fields['ville'], 'ville', $obj->ville, '').'<br>
					<b>Adresse: </b>'.$obj->address.'<br>
					<b>Telephone: </b>'.$tel.'
					<b>Numéro Autorisation: </b>'.$object->numero_dossier.'<br>
					</div>" class="classfortooltip refurl"><img src="/theme/eldy/img/object_company.png" alt="" class="paddingright classfortooltip valignmiddle">'.$obj->nom.'</a>';
				print $out;
			}
			else print $object->showOutputField($val, $key, $object->$key, '');
			print '</td>';
			if (!$i) $totalarray['nbfield']++;
			if (!empty($val['isameasure']))
			{
				if (!$i) $totalarray['pos'][$totalarray['nbfield']] = 'w.'.$key;
				$totalarray['val']['w.'.$key] += $object->$key;
			}
		}
	}
	$tab_lines=array();
	$line=new carafinanceline($db);
	$tab_lines=$line->fetch($obj->rowid);
	for($j=0;$j<5;$j++){
		unset($objcible);
		foreach($tab_lines as $key=>$val){
			if($val['fk_type']==4 && $j==0){
				include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaratoit/class/deviscaratoit.class.php',1);
				$objcible=new Deviscaratoit($db);
				$objcible->fetch($val['fk_prod']);
				$url=dol_buildpath('deviscaratoit/card.php?id='.$val['fk_prod'],1);
				print '<td>'.$objcible->libStatutPlanif(5,$url).'</td>';
			}
			elseif($val['fk_type']==1 && $j==3){
				include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaraiso/class/deviscaraiso.class.php',1);
				$objcible=new Deviscaraiso($db);
				$objcible->fetch($val['fk_prod']);
				$url=dol_buildpath('deviscaraiso/card.php?id='.$val['fk_prod'],1);
				print '<td>'.$objcible->libStatutPlanif(5,$url).'</td>';
			}
			elseif($val['fk_type']==2 && $j==1){
				include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaraces/class/deviscaraces.class.php',1);
				$objcible=new Deviscaraces($db);
				$objcible->fetch($val['fk_prod']);
				$url=dol_buildpath('deviscaraces/card.php?id='.$val['fk_prod'],1);
				print '<td>'.$objcible->libStatutPlanif(5,$url).'</td>';
			}
			elseif($val['fk_type']==3 && $j==2){
				include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscararep/class/deviscararep.class.php',1);
				$objcible=new Deviscararep($db);
				$objcible->fetch($val['fk_prod']);
				$url=dol_buildpath('deviscararep/card.php?id='.$val['fk_prod'],1);
				print '<td>'.$objcible->libStatutPlanif(5,$url).'</td>';
			}
			elseif($val['fk_type']==5 && $j==4){
				include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaramen/class/men.class.php',1);
				$objcible=new men($db);
				$objcible->fetch($val['fk_prod']);
				$url=dol_buildpath('deviscaramen/men_card.php?id='.$val['fk_prod'],1);
				print '<td>'.$objcible->libStatutPlanif(5,$url).'</td>';
			}
			
		}
		if(!isset($objcible))
				print '<td>&nbsp;</td>';
	}
	// Extra fields
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_print_fields.tpl.php';
	// Fields from hook
	$parameters = array('arrayfields'=>$arrayfields, 'object'=>$object, 'obj'=>$obj, 'i'=>$i, 'totalarray'=>&$totalarray);
	$reshook = $hookmanager->executeHooks('printFieldListValue', $parameters, $object); // Note that $action and $object may have been modified by hook
	print $hookmanager->resPrint;
	// Action column
	print '<td class="nowrap center">';
	if ($massactionbutton || $massaction)   // If we are in select mode (massactionbutton defined) or if we have already selected and sent an action ($massaction) defined
	{
		$selected = 0;
		if (in_array($object->id, $arrayofselected)) $selected = 1;
		print '<input id="cb'.$object->id.'" class="flat checkforselect" type="checkbox" name="toselect[]" value="'.$object->id.'"'.($selected ? ' checked="checked"' : '').'>';
	}
	print '</td>';
	if (!$i) $totalarray['nbfield']++;

	print '</tr>'."\n";

	$i++;
}

// Show total line
include DOL_DOCUMENT_ROOT.'/core/tpl/list_print_total.tpl.php';

// If no record found
if ($num == 0)
{
	$colspan = 1;
	foreach ($arrayfields as $key => $val) { if (!empty($val['checked'])) $colspan++; }
	print '<tr><td colspan="'.$colspan.'" class="opacitymedium">'.$langs->trans("NoRecordFound").'</td></tr>';
}


$db->free($resql);

$parameters = array('arrayfields'=>$arrayfields, 'sql'=>$sql);
$reshook = $hookmanager->executeHooks('printFieldListFooter', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;

print '</table>'."\n";
print '</div>'."\n";

print '</form>'."\n";

if (in_array('builddoc', $arrayofmassactions) && ($nbtotalofrecords === '' || $nbtotalofrecords))
{
	$hidegeneratedfilelistifempty = 1;
	if ($massaction == 'builddoc' || $action == 'remove_file' || $show_files) $hidegeneratedfilelistifempty = 0;

	require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
	$formfile = new FormFile($db);

	// Show list of available documents
	$urlsource = $_SERVER['PHP_SELF'].'?sortfield='.$sortfield.'&sortorder='.$sortorder;
	$urlsource .= str_replace('&amp;', '&', $param);

	$filedir = $diroutputmassaction;
	$genallowed = $permissiontoread;
	$delallowed = $permissiontoadd;

	print $formfile->showdocuments('massfilesarea_carafinance', '', $filedir, $urlsource, 0, $delallowed, '', 1, 1, 0, 48, 1, $param, $title, '', '', '', null, $hidegeneratedfilelistifempty);
}

// End of page
llxFooter();
$db->close();
