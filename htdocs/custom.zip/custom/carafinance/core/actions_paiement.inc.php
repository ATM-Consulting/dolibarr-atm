<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

/*LMK*/

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}

// Action pour ajouter un enregistrement (paiement)
if ($action == 'createP' && !empty($permissiontoadd))
{
    $paiementline=new carafinancePaiement($db);
	$nb_fois = GETPOST('nb_fois'); // Définition du nombre de mensualités - Mantis 0000398
    $paiementline->type_paiement = GETPOST('type_paiement');
    $paiementline->fk_carafinance = GETPOST('id');
	// Traitement de la première fois
    if($paiementline->type_paiement==2) { // S'il s'agit d'un chèque, on collecte les autres infos chèque
        $paiementline->numero_cheque = GETPOST('numero_cheque');
        $paiementline->banque_cheque = GETPOST('banque_cheque');
        $paiementline->note_cheque = GETPOST('note_cheque');
    } else { // Sinon on les efface
        $paiementline->numero_cheque = '';
        $paiementline->banque_cheque = '';
        $paiementline->note_cheque = '';
    }
    $paiementline->amount = str_replace(',','.',GETPOST('amount')); // Mantis 0000373 saisie des montants avec les 2 formats '.' et ','
    $paiementline->statut = GETPOST('statut');
    // On traite selon s'il s'agit d'un encaissement ou d'un paiement différé
    if(GETPOST('statut')) {
        if(GETPOST('date_encaissement')) $paiementline->date_encaissement = GETPOST('date_encaissementyear').'/'.GETPOST('date_encaissementmonth').'/'.GETPOST('date_encaissementday');
    } elseif(GETPOST('date_prevue')) $paiementline->date_prevue = GETPOST('date_prevueyear').'/'.GETPOST('date_prevuemonth').'/'.GETPOST('date_prevueday');
    $paiementline->insert();
	// Traitement des autres mensualités - Mantis 0000398
	if($nb_fois > 1) {
		$paiementline->numero_cheque = ''; // On efface le numéro de chèque
		if(GETPOST('statut')) {
			$jour = GETPOST('date_encaissementday');
			$mois = GETPOST('date_encaissementmonth');
			$annee = GETPOST('date_encaissementyear');
		} else {
			$jour = GETPOST('date_prevueday');
			$mois = GETPOST('date_prevuemonth');
			$annee = GETPOST('date_prevueyear');
		}
		for($i=2;$i<=$nb_fois;$i++) {
			// Traitement des dates
			$mois++;
			if($mois > 12) {
				$annee++;
				$mois = 1;
			}
			$date_time = mktime( 0, 0, 0, $mois, 1, $annee );
			$dernier_jour = date("t",$date_time); // Définition du dernier jour du mois
			($dernier_jour > $jour) ? $temp_jour = $jour : $temp_jour = $dernier_jour; // On définit un jour valide
			$paiementline->statut = 0; // On met le statut des règlements en prévu
			$paiementline->date_prevue = $annee.'/'.$mois.'/'.$temp_jour;
			$paiementline->date_encaissement = '';
			$paiementline->insert(); // On enregistre le règlement
		}
	}
}

// Action pour supprimer un paiement
if($action=='delP'){
    $paiementline=new carafinancePaiement($db);
    $paiementline->rowid = GETPOST('rowid');
    $paiementline->fk_carafinance = GETPOST('id');
    $paiementline->delete();
}

//Action pour mettre à jour un paiement 
if($action=='updateP') {
    $paiementline=new carafinancePaiement($db);
    $paiementline->rowid = GETPOST('rowid');
    $paiementline->type_paiement = GETPOST('type_paiement');
    if($paiementline->type_paiement==2) { // S'il s'agit d'un chèque, on collecte les autres infos chèque
        $paiementline->numero_cheque = GETPOST('numero_cheque');
        $paiementline->banque_cheque = GETPOST('banque_cheque');
        $paiementline->note_cheque = GETPOST('note_cheque');
    } else { // Sinon on les efface
        $paiementline->numero_cheque = '';
        $paiementline->banque_cheque = '';
        $paiementline->note_cheque = '';
    }
    $paiementline->amount = str_replace(',','.',GETPOST('amount')); // Mantis 0000373 saisie des montants avec les 2 formats '.' et ','
    $paiementline->statut = GETPOST('statut');
    // On traite selon s'il s'agit d'un encaissement ou d'un paiement différé
    if(GETPOST('statut')) {
        if(GETPOST('date_encaissement')) $paiementline->date_encaissement = GETPOST('date_encaissementyear').'/'.GETPOST('date_encaissementmonth').'/'.GETPOST('date_encaissementday');
    } elseif(GETPOST('date_prevue')) $paiementline->date_prevue = GETPOST('date_prevueyear').'/'.GETPOST('date_prevuemonth').'/'.GETPOST('date_prevueday');
    $paiementline->fk_carafinance = GETPOST('id');
    $paiementline->update();
}
