<?
if($action=='ask_deleteline'){

    
    $objectline=new carafinanceline($db);
    $objectline->getLine(GETPOST('lineid','integer)'));

    // en fonction du type on crée le produit et on fait le lien.
    
    if($objectline->fk_type==1){//ISO
        $obj= new Deviscaraiso($db);
        $obj->id=$objectline->fk_prod;
        $lineid=$obj->delete($user);
        
    }
    elseif($objectline->fk_type==2){//CES
         $obj= new deviscaraces($db);
        $obj->id=$objectline->fk_prod;
        $lineid=$obj->delete($user);
    }
    elseif($objectline->fk_type==3){//REP
        $obj= new deviscararep($db);
        $obj->id=$objectline->fk_prod;
        $lineid=$obj->delete($user);
    }
    elseif($objectline->fk_type==4){//toit
        $obj= new deviscaratoit($db);
        $obj->id=$objectline->fk_prod;
        $lineid=$obj->delete($user);
    }
    elseif($objectline->fk_type==7){//ISO TOITURE
        $obj= new Deviscaraisotoit($db);
        $obj->id=$objectline->fk_prod;
        $lineid=$obj->delete($user);
    }
    $objectline->delete();
}

?>