<?
if($action=='updateline'){

    
    $objectline=new carafinanceline($db);
    $objectline->getLine(GETPOST('lineid','integer)'));

    // en fonction du type on crée le produit et on fait le lien.
    
    $objectline->description=GETPOST('product_desc');
    $objectline->update($user);
    
}

?>