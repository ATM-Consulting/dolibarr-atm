<?
if($action=='addline'){
    $objectline=new carafinanceLine($db);
    $objectline->fk_type=GETPOST('fk_type');
    $objectline->description=GETPOST ('dp_desc');
    $objectline->fk_carafinance=$object->id;

    //si ligne toiture déjà présente planification en ATF
    if($objectline->check_toitureinlist()>0){
        $planif=Deviscaratoit::STATUSPLANIF_PACK;
        $date='date_pack';
        $fk_usercomm=112;
    }
    else{
        $planif=Deviscaratoit::STATUSPLANIF_ATTENTE; //j'ai pris la classe toiture par défaut= constantes autres classes.
        $date='date_atraiter';
        $fk_usercomm=$object->fk_usercomm;
    }

    // en fonction du type on crée le produit et on fait le lien.
    
    if($objectline->fk_type==1){//ISO
        //include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaraiso/class/deviscaraiso.class.php',1);
        $obj= new Deviscaraiso($db);
        $obj->fk_soc=$object->fk_soc;
        $obj->fk_usercomm=$fk_usercomm;
        $obj->label=1;
        $obj->planification=$planif;
        $obj->status=Deviscaraiso::STATUS_DRAFT; //statut brouillon
        $obj->date_creation=$object->date_creation;
        $obj->date_accepte_mpr=$object->date_creation;
        $obj->status_mpr=1;
        $obj->status_edf2=1;
        $obj->description="Création Devis ISO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id='.$object->id,1).">RENO</a>" ;
        $lineid=$obj->create($user);
        
    }
    elseif($objectline->fk_type==2){//CES
        $obj= new deviscaraces($db);
        $obj->fk_soc=$object->fk_soc;
        $obj->fk_usercomm=$fk_usercomm;
        $obj->label=2;
        $obj->planification=$planif;
        $obj->status=Deviscaraces::STATUS_DRAFT; //statut brouillon
        $obj->date_creation=$object->date_creation;
        $obj->date_accepte_mpr=$object->date_creation;
        $obj->status_mpr=1;
        $obj->status_edf2=1;
        $obj->description="Création Devis CES via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id='.$object->id,1).">RENO</a>" ;
        $lineid=$obj->create($user);
    }
    elseif($objectline->fk_type==3){//REP
        $obj= new deviscararep($db);
        $obj->fk_soc=$object->fk_soc;
        $obj->fk_usercomm=$fk_usercomm;
        $obj->label=3;
        $obj->planification=$planif;
        $obj->status_ctm=1;
        $obj->status=Deviscararep::STATUS_DRAFT;; //statut brouillon
        $obj->date_creation=$object->date_creation;
        $obj->description="Création Devis REP via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id='.$object->id,1).">RENO</a>" ;
        $lineid=$obj->create($user);
    }
    elseif($objectline->fk_type==4){//toit
        $obj= new deviscaratoit($db);
        $obj->fk_soc=$object->fk_soc;
        $obj->fk_usercomm=$object->fk_usercomm;
        if($object->suivi_financement==carafinance::STATUSFIN_ACCEPTE) //si financement accepté: toiture en a traiter
            $obj->planification=Deviscaratoit::STATUSPLANIF_ATTENTE;
        else
            $obj->planification=Deviscaratoit::STATUSPLANIF_PACK;
        $obj->date_planif=$obj->$date=$db->idate(dol_now());
        $obj->status=Deviscaratoit::STATUS_DRAFT;; //statut brouillon
        $obj->label=4;
        $obj->date_creation=$object->date_creation;
        $obj->date_accepte_mpr=$object->date_creation;
        $obj->status_mpr=1;
        $obj->status_edf2=1;
        $obj->description="Création Devis TOIT via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id='.$object->id,1).">RENO</a>" ;
        $lineid=$obj->create($user);
        $objectline->update_planif_autresobjets();
    }
    elseif($objectline->fk_type==5){//Menuiseries
        $obj= new men($db);
        $obj->fk_soc=$object->fk_soc;
        $obj->fk_usercomm=$fk_usercomm;
        $obj->planification=$planif;
        $obj->status=men::STATUS_DRAFT;; //statut brouillon
        $obj->label=5;
        $obj->date_creation=$object->date_creation;
        $obj->description="<a href=".dol_buildpath('carafinance/carafinance_card.php?id='.$object->id,1).">Création Devis Menuiserie via tableau RENO</a>" ;
        $lineid=$obj->create($user);
    }
    elseif($objectline->fk_type==6){//PPV
        $obj= new ppv($db);
        $obj->fk_soc=$object->fk_soc;
        $obj->fk_usercomm=$fk_usercomm;
        $obj->planification=$planif;
        $obj->status=ppv::STATUS_DRAFT; //statut brouillon
        $obj->label=6;
        $obj->date_creation=$object->date_creation;
        $obj->description="<a href=".dol_buildpath('carafinance/carafinance_card.php?id='.$object->id,1).">Création Devis PV via tableau RENO</a>" ;
        $lineid=$obj->create($user);
    }

    
    $objectline->fk_prod=$lineid;
    $objectline->insert();
}

?>