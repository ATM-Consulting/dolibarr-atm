<?php
// LMK Pied de tableau carafinance_list_finance.php
// Move fields of totalizable into the common array pos and val
if (is_array($totalarray['totalizable'])) {
	foreach($totalarray['totalizable'] as $keytotalizable => $valtotalizable) {
		$totalarray['pos'][$valtotalizable['pos']] = $keytotalizable;
		$totalarray['val'][$keytotalizable] = $valtotalizable['total'];
	}
}
// Show total line
if (isset($totalarray['pos']))
{
	print '<tr class="liste_total">';
	$i=0;
	while ($i < $totalarray['nbfield'])
	{
		$i++;
		if($i==5)
		{
			print '<td class="right" style="color:green;">'.price($total_paye).'</td>';
		}
		else
		if($i==6)
		{
			print '<td class="right" style="color:blue;">'.price($total_reste).'</td>';
		}
		else
		if($i==7 && abs($total_impaye)>0) // Affiche le total impayé uniquement s'il existe
		{
			print '<td class="right" style="color:red;">'.price($total_impaye).'</td>';
		}
		else
		if (! empty($totalarray['pos'][$i]))  print '<td class="right">'.price($totalarray['val'][$totalarray['pos'][$i]]).'</td>';
		else
		{
			if ($i == 1)
			{
				if ($num < $limit) print '<td class="left">'.$langs->trans("Total").'</td>';
				else print '<td class="left">'.$langs->trans("Totalforthispage").'</td>';
			}
			else print '<td></td>';
		}
	}
	print '<td colspan=3>&nbsp;</td></tr>';
}
