<?php
// Move fields of totalizable into the common array pos and val
if (is_array($totalarray['totalizable'])) {
	foreach($totalarray['totalizable'] as $keytotalizable => $valtotalizable) {
		$totalarray['pos'][$valtotalizable['pos']] = $keytotalizable;
		$totalarray['val'][$keytotalizable] = $valtotalizable['total'];
	}
}
// Show total line
if (isset($totalarray['pos']))
{
	print '<tr class="liste_total"><td></td>';
	$i=0;
	while ($i < $totalarray['nbfield'])
	{
		$i++;
		if (! empty($totalarray['pos'][$i]))  print '<td class="right">'.price($totalarray['val'][$totalarray['pos'][$i]]).'</td>';
		else
		{
			if ($i == 1)
			{
				if ($num < $limit) print '<td class="left">'.$langs->trans("Total").'</td>';
				else print '<td class="left">'.$langs->trans("Totalforthispage").'</td>';
			} 
			// LMK Mantis 0000355 Affichage des quantités vendues et posées
			elseif ($i == 4) {
				print '<td align="right">'.number_format($tot_toiture_vendue,0,',',' ').'</td>';
			} elseif ($i == 5) {
				print '<td align="right">'.number_format($tot_toiture_posee,0,',',' ').'</td>';
			}
			// Fin LMK Mantis 0000355
			else print '<td></td>';
		}
	}
	print '<td colspan=4></td>';
	print '</tr>';
}
