<?php
/*LMK*/
// Vue règlement : doit être inclus à la fin du fichier commonfields_view.tpl.php en étant dans le même dossier et dans le fichier carafinance_card_finance.php
print '<script>
    function affichage_date(index) {
        if(index==1) {
           document.getElementById("affichage_maintenant").style.display = "block";
           document.getElementById("affichage_prevu").style.display = "none";
        } else {
           document.getElementById("affichage_maintenant").style.display = "none";
           document.getElementById("affichage_prevu").style.display = "block";
        }
    }
    function affichage_cheque(index) {
        if(index==2) {
           document.getElementById("view_cheque").style.display = "block";
        } else {
           document.getElementById("view_cheque").style.display = "none";
        }
    }
</script>';

$paiement=new carafinancePaiement($db);
$form = new Form($db);
// Définition des variables
$cancelurl = $_SERVER['PHP_SELF']."?id=".GETPOST('id'); // On definit la page retour = page de l'affaire en cours
$boutoncancel = '<input type="button" class="button" value="'.$langs->trans("Cancel").'" onclick="javascript:document.location.href=\''.$cancelurl.'\'">'; // Bouton annuler des formulaires
$types_paiement = ['Carte bancaire', 'Chèque', 'Espèce', 'Ordre de prélèvement', 'Virement bancaire']; // Liste des libellés de règlement
$max_fois = 180; // Nombre maxumum de mensualités - Mantis 0000398

// Affichage du formulaire pour l'ajout d'un règlement
if($action=='addP') {
    
    print '<tr><td>';
	print '<form action="'.$_SERVER['PHP_SELF'].'?id='.$id.'" method="POST">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	print '<input type="hidden" name="action" value="createP">';
                print '<table class="centpercent">';
                print '<tr align="center"><td bgcolor="#ddd" colspan="4">Ajouter un règlement</td></tr>';
                ($obj->statut) ? $selected0 = ' selected="selected"' : $selected1 = ' selected="selected"';
                print '<tr align="left">
                        <th>Montant</th>
                        <th>Date du règlement</th>
                        <th>Mode de règlement</th>
                        <th></th>
                      </tr>';
                print '<tr>
                        <td><input name="amount" id="amount" value="'.$obj->amount.'" style="width:50px;">
                          <select name="nb_fois" id="nb_fois">'; // Mantis 0000398
                for($i=1;$i<=$max_fois;$i++) {
                          print '<option value="'.$i.'">x '.$i.' fois</option>';
                }
                    print'</select>
						</td>
                        <td>
                        <select name="statut" id="statut" onChange="affichage_date(this.value)">
                          <option value="1">Règlement immédiat</option>
                          <option value="0">Règlement différé</option>
                        </select>
                        <div id="affichage_maintenant">'.$form->selectDate((empty($date_encaissement) ?-1 : $date_encaissement), "date_encaissement", '', '', '', 'add', 1, 1).'</div>
                         <div id="affichage_prevu">'.$form->selectDate((empty($date_prevue) ?-1 : $date_prevue), "date_prevue", '', '', '', 'add', 1, 0).'</div>
                        </td>
                        <td>
                        <select id="type_paiement" class="flat selectpaymenttypes" name="type_paiement" onChange="affichage_cheque(this.value)">
                        <option value="">Choisissez un mode</option>';
                        $type_paiement = $paiement->fields['type_paiement']['arrayofkeyval'];
                        foreach ($type_paiement as $key => $value) {
                            print '<option value="'.$key.'">'.$value.'</option>';
                        }
                print '</select>
                        <div id="view_cheque">
                        <br><input name="numero_cheque" id="numero_cheque" placeholder="Numéro du chèque">
                        <br><input name="banque_cheque" id="banque_cheque" placeholder="Banque émettrice">
                        <br><textarea name="note_cheque" cols="22" wrap="hard" id="note_cheque" placeholder="Notes concernant le chèque"></textarea>
                        </div>
                        </td>
                        <td><input type="submit" class="button" value="'.$langs->trans("Save").'">'.$boutoncancel.'</td>
                      </tr>';
                print '</table>';
    
	print '<hr>';
    
	print '</form>';
    
// On charge le javascript de la gestion de l'affichage des dates et des éléments de chèque
print '
<script>
  affichage_date(document.getElementById("statut").value);
  affichage_cheque(document.getElementById("type_paiement").value);
</script>';
}

// Affichage du bouton Ajouter si on n'est pas en mode ajout ou édit
if(!($action=='addP' || $action=='editP')) print '<tr><td><div class="center"><a style=" color: #00F;" href="'.$_SERVER['PHP_SELF'].'?id='.$id.'&action=addP" title="Ajouter un règlement">Ajouter un règlement</a></div></td></tr>'; 

// Affichage des lignes de règlement & Encaissement règlement & Edit ligne de règlement
$sql = 'SELECT ';
$sql .= 'p.rowid, p.type_paiement, p.numero_cheque, p.banque_cheque, p.note_cheque, p.amount, p.date_creation, p.date_prevue, p.date_encaissement, p.statut, p.fk_carafinance';
$sql .= ' FROM '.MAIN_DB_PREFIX.'carafinance_paiement as p';
$sql .= ' WHERE fk_carafinance = '.$id;
$resql = $db->query($sql);
if($resql)
{
    $num = $db->num_rows($resql);
    if($num){
        // Définition des variables pour les calculs des montants des règlements
        $total_encaisse = 0;
        $total_prevu = 0;
        print '<table class="centpercent">';
        //print '<tr><td>'.$backtopage.'</td></tr>';
        print '<tr bgcolor="#dfd"><td colspan="8" align="center"><strong>Liste des règlements</strong></td></tr>';
        print '<tr align="left">
                <th scope="col" width="50">Crée le</th>
                <th scope="col" align="center">Montant</th>
                <th scope="col">Date de règlement</th>
                <th scope="col">Mode de règlement</th>
                <th scope="col"></th>
                <th scope="col"></th>
              </tr>';
        // Parcours des enregistrements
        // --------------------------------------------------------------------
        $i = 0;
        while( $i < $num) {
            $obj = $db->fetch_object($resql);
            if (empty($obj)) break; // Ne devrait pas arriver
            // On enregistre les montants pour les calculs
            ($obj->statut) ? $total_encaisse += $obj->amount : $total_prevu += $obj->amount ;
            
            // Traitement pour l'affichage des dates
            is_null($obj->date_encaissement) ? $date_encaissement = '' : $date_encaissement = date("d/m/Y", strtotime($obj->date_encaissement));
            is_null($obj->date_prevue) ? $date_prevue = '' : $date_prevue = date("d/m/Y", strtotime($obj->date_prevue));
            
            if(($action!='editP' && $action!='setP') || $obj->rowid!=GETPOST('rowid')) { // Affichage ligne
                ($obj->statut) ? $statut ='Encaissé le '.$date_encaissement : $statut = 'Prévu le '.$date_prevue.' <a href="?id='.$obj->fk_carafinance.'&amp;action=setP&amp;rowid='.$obj->rowid.'"><span class="fas fa-credit-card marginleftonly" style=" color: #00F;" title="Encaisser ce règlement"></span></a>';
                // S'il s'agit d'un chèque
                $info_cheque="";
                $note = '';
                if($obj->type_paiement=='2') 
                {
                    if ($obj->numero_cheque!='') $info_cheque .= " - N° ".$obj->numero_cheque;
                    if ($obj->banque_cheque) $info_cheque .= " (".$obj->banque_cheque.")";
                    $note = '<a title="<div class=&quot;centpercent&quot;><strong>Notes (chèque) :</strong><br>'.nl2br ($obj->note_cheque).'</div>" class="classfortooltip refurl"><span class="fas fa-comment marginleftonly pictodelete" style=" color: #0C0;"></span></a>';
                }
                print '<tr>
                        <td>'.date("d/m/Y", strtotime($obj->date_creation)).'</td>
                        <td align="center">'.$obj->amount.' €</td>
                        <td>'.$statut.'</td>
                        <td>'.$paiement->fields['type_paiement']['arrayofkeyval'][$obj->type_paiement].$info_cheque.$note.'</td>
                        <td><a href="?id='.$obj->fk_carafinance.'&amp;action=editP&amp;rowid='.$obj->rowid.'"><span class="fas fa-pencil-alt marginleftonly" style=" color: #00F;" title="Modifier ce règlement"></span></a></td>
                        <td><a href="?id='.$obj->fk_carafinance.'&amp;action=delP&amp;rowid='.$obj->rowid.'"><span class="fas fa-trash marginleftonly pictodelete" style=" color: #C00;" title="Supprimer ce règlement"></span></a></td>
                      </tr>';
            } elseif($action=='setP') { // Encaissement règlement
                // Traitement pour l'affichage des dates
                $date_encaissement=strtotime($obj->date_encaissement);
                print '<tr><td colspan="7">';
                print '<form action="'.$_SERVER['PHP_SELF'].'?id='.$id.'" method="POST">';
                print '<input type="hidden" name="token" value="'.newToken().'">';
                print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
                print '<input type="hidden" name="action" value="updateP">';
                print '<input type="hidden" name="rowid" value="'.$obj->rowid.'">';
                print '<hr>';
                print '<table class="centpercent">';
                print '<tr align="center"><td bgcolor="#ddd" colspan="5">Encaisser ce règlement</td></tr>';
                ($obj->statut) ? $selected0 = ' selected="selected"' : $selected1 = ' selected="selected"';
                print '<tr align="left">
                        <td>Crée le</td>
                        <td>Montant</td>
                        <td>Règlement immédiat</td>
                        <td>Mode de règlement</td>
                        <td></td>
                      </tr>';
                print '<tr>
                        <td>'.date("d/m/Y", strtotime($obj->date_creation)).'</td>
                        <td><input type="hidden" name="amount" id="amount" value="'.$obj->amount.'"><strong>'.$obj->amount.' €</strong></td>
                        <td><input type="hidden" name="statut" id="statut" value="1">'
                        .$form->selectDate((empty($date_encaissement) ?-1 : ''), "date_encaissement", '', '', '', 'add', 1, 1).
                        '</td>
                        <td>
                        <select id="type_paiement" class="flat selectpaymenttypes" name="type_paiement" onChange="affichage_cheque(this.value)">';
                        $type_paiement = $paiement->fields['type_paiement']['arrayofkeyval'];
                        foreach ($type_paiement as $key => $value) {
                            ($key == $obj->type_paiement) ? $selected = ' selected="selected"' : $selected='' ;
                            print '<option value="'.$key.'"'.$selected.'>'.$value.'</option>';
                        }
                print '</select>
                        <div id="view_cheque">
                        <br><input name="numero_cheque" id="numero_cheque" value="'.$obj->numero_cheque.'" placeholder="Numéro du chèque">
                        <br><input name="banque_cheque" id="banque_cheque" value="'.$obj->banque_cheque.'" placeholder="Banque émettrice">
                        <br><textarea name="note_cheque" cols="22" wrap="hard" id="note_cheque" placeholder="Notes concernant le chèque">'.$obj->note_cheque.'</textarea>
                        </div>
                        </td>
                        <td><input type="submit" class="button" value="'.$langs->trans("Save").'">'.$boutoncancel.'</td>
                      </tr>';
                print '</table>';
                print '<hr>';
                //print '<tr><td colspan="8" align="center">&nbsp;</td></tr>';
                print '</form>';
                print '</td></tr>';
            } else { // Edit règlement
                // Traitement pour l'affichage des dates
                if(($obj->statut)) {
                    $date_encaissement=strtotime($obj->date_encaissement);
                    $date_prevue='';
                } else {
                    $date_encaissement='';
                    $date_prevue=strtotime($obj->date_prevue);
                }
                print '<tr><td colspan="7">';
                print '<form action="'.$_SERVER['PHP_SELF'].'?id='.$id.'" method="POST">';
                print '<input type="hidden" name="token" value="'.newToken().'">';
                print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
                print '<input type="hidden" name="action" value="updateP">';
                print '<input type="hidden" name="rowid" value="'.$obj->rowid.'">';
                print '<hr>';
                print '<table class="centpercent">';
                print '<tr align="center"><td bgcolor="#ddd" colspan="5">Modifier ce règlement</td></tr>';
                ($obj->statut) ? $selected0 = ' selected="selected"' : $selected1 = ' selected="selected"';
                print '<tr align="left">
                        <td>Crée le</td>
                        <td>Montant</td>
                        <td>
                        <select name="statut" id="statut" onChange="affichage_date(this.value)">
                          <option value="1"'.$selected0.'>Règlement immédiat</option>
                          <option value="0"'.$selected1.'>Règlement différé</option>
                        </select>
                        </td>
                        <td>Mode de règlement</td>
                        <td></td>
                      </tr>';
                print '<tr>
                        <td>'.date("d/m/Y", strtotime($obj->date_creation)).'</td>
                        <td><input name="amount" id="amount" value="'.$obj->amount.'" style="width:50px;"></td>
                        <td>
                        <div id="affichage_maintenant">'.$form->selectDate((empty($date_encaissement) ?-1 : $date_encaissement), "date_encaissement", '', '', '', 'add', 1, 1).'</div>
                         <div id="affichage_prevu">'.$form->selectDate((empty($date_prevue) ?-1 : $date_prevue), "date_prevue", '', '', '', 'add', 1, 0).'</div>
                        </td>
                        <td>
                        <select id="type_paiement" class="flat selectpaymenttypes" name="type_paiement" onChange="affichage_cheque(this.value)">';
                        $type_paiement = $paiement->fields['type_paiement']['arrayofkeyval'];
                        foreach ($type_paiement as $key => $value) {
                            ($key == $obj->type_paiement) ? $selected = ' selected="selected"' : $selected='' ;
                            print '<option value="'.$key.'"'.$selected.'>'.$value.'</option>';
                        }
                print '</select>
                        <div id="view_cheque">
                        <br><input name="numero_cheque" id="numero_cheque" value="'.$obj->numero_cheque.'" placeholder="Numéro du chèque">
                        <br><input name="banque_cheque" id="banque_cheque" value="'.$obj->banque_cheque.'" placeholder="Banque émettrice">
                        <br><textarea name="note_cheque" cols="22" wrap="hard" id="note_cheque" placeholder="Notes concernant le chèque">'.$obj->note_cheque.'</textarea>
                        </div>
                        </td>
                        <td><input type="submit" class="button" value="'.$langs->trans("Save").'">'.$boutoncancel.'</td>
                      </tr>';
                print '</table>';
                print '<hr>';
                //print '<tr><td colspan="8" align="center">&nbsp;</td></tr>';
                print '</form>';
                print '</td></tr>';
                // On charge le javascript de la gestion de l'affichage des dates
                print '
                <script>
                  affichage_date(document.getElementById("statut").value);
                  affichage_cheque(document.getElementById("type_paiement").value);
                </script>';
            }
            if ($action == 'editP' || $action == 'setP') { // S'il s'agit d'une édition ou d'un encaissement, on charge le javascript pour l'affichage des champs du chèque
                print '
                <script>
                  affichage_cheque(document.getElementById("type_paiement").value);
                </script>';
            }
            $i++;
        }
        // Récap des règlements
        function affichage_argent ($chiffre) { return number_format($chiffre,0,',',' '); }
        $reste = $object->amount - $total_encaisse - $total_prevu;
        ($reste<>0) ? $reste = '<br>Montant sans règlement : <span style="color:red"><strong>'.affichage_argent($reste).' €</strong></span>' : $reste = '';
        print '<tr><td colspan="8" align="center">&nbsp;</td></tr>';
        print '<tr bgcolor="#dfd"><td colspan="8" align="center"><strong>Récapitulatif des règlements</strong></td></tr>';
        print '<tr><td colspan="8" align="center">Total à régler : <strong>'.affichage_argent($object->amount).'</strong> €<br>Encaissé : <span style="color:green"><strong>'.affichage_argent($total_encaisse).' €</strong></span><br>Reste à encaisser : <span style="color:#FF8C00"><strong>'.affichage_argent($total_prevu).' €</strong></span>'.$reste.'</td></tr>';
        print '</table>';
    }
}
/*/LMK*/
?>