<?php
//Si la date d’intervention est dépassée de 3j , et planification « planifiée » alors alerte. 
//Date en rouge ou planifié qui se met à clignoter.

$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';

require_once $path . "../../../master.inc.php";
require_once $path . "../../carafinance/class/carafinance.class.php";

// Global variables
$version = DOL_VERSION;
$error = 0;

/*
 * Main
 */

@set_time_limit(0);
print "***** " . $script_file . " (" . $version . ") pid=" . dol_getmypid() . " *****\n";
dol_syslog($script_file . " launched with arg " . join(',', $argv));


$now=new DateTime('now');




$sql = "SELECT rowid,date_depot,date_pv,suivi_financement ";
$sql .= " FROM " . MAIN_DB_PREFIX . "carafinance_carafinance";

$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);

//    print "Lines " . $num . "\n";

    $i = 0;
    $db->begin();
    while ($i < $num) {
        $obj = $db->fetch_object($resql);
        if($obj->date_depot!=''){
            $date_depot=new DateTime($obj->date_depot);
            $diff=$now->diff($date_depot);
            if ($diff->invert==1 && $diff->d > 3 && $obj->suivi_financement == Carafinance::STATUSFIN_ETUDE){
                $sql = 'update '. MAIN_DB_PREFIX . 'carafinance_carafinance'.$ext.' set alerte_dossier_finance = 1 where rowid='.$obj->rowid;
                print $sql.'<br>';
            }
            else 
                $sql = 'update '. MAIN_DB_PREFIX . 'carafinance_carafinance'.$ext.' set alerte_dossier_finance = 0 where rowid='.$obj->rowid;
            
            $resql2 = $db->query($sql);

            $date_pv=new DateTime($obj->date_pv);
            $diff=$now->diff($date_pv);
            if ($diff->invert==1 && $diff->d > 7 && $obj->suivi_financement == Carafinance::STATUSFIN_PV){
                $sql = 'update '. MAIN_DB_PREFIX . 'carafinance_carafinance'.$ext.' set alerte_date_pv = 1 where rowid='.$obj->rowid;
                print $sql.'<br>';
            }
            else 
                $sql = 'update '. MAIN_DB_PREFIX . 'carafinance_carafinance'.$ext.' set alerte_date_pv = 0 where rowid='.$obj->rowid;
            
            $resql2 = $db->query($sql);
        }
        $i ++;
    }
    $db->commit();
}

?>