<?
if($action=='updateline'){

    
    $objectline=new menLine($db);
    $objectline->getLine(GETPOST('lineid','integer)'));

    // en fonction du type on crée le produit et on fait le lien.
    
    $objectline->label=GETPOST('product_desc');
    $objectline->qty=GETPOST('qty');
    $objectline->hauteur=GETPOST('hauteur');
    $objectline->largeur=GETPOST('largeur');
    $objectline->amount=GETPOST('amount');
    $objectline->objectid=$object->id;

    $objectline->update($user);
    include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.
    
}

?>