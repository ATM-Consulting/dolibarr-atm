<?
if($action=='ask_deleteline'){

    
    $objectline=new menline($db);
    $objectline->getLine(GETPOST('lineid','integer)'));
    $objectline->objectid=$object->id;

    $objectline->delete();
    include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.
}

?>