<?
if($action=='addline'){
    
    $objectline=new menLine($db);
    $objectline->qty=GETPOST('qty');
    $objectline->label=GETPOST ('dp_desc');
    $objectline->hauteur=GETPOST ('hauteur');
    $objectline->largeur=GETPOST ('largeur');
    $objectline->amount=GETPOST ('amount');
    
    $objectline->objectid=$object->id;
    $objectline->fk_men=$object->id;
    
    $objectline->insert();

    include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.
}

?>