<?php

	require __DIR__.'/config.default.php';

