INSERT INTO `llx_cara_deviscarapos_libelle` (`rowid`, `label`, `type`) VALUES
(1, 'Numéro de série', 1),
(2, 'Type CES', 1),
(3, 'Villa', 1),
(4, 'Raccord\r\n', 1),
(5, 'Dépose', 1),
(6, 'Règlement', 1),
(7, 'ISO (m2)', 2),
(8, 'Accès', 2),
(9, 'sacs', 2),
(10, 'Paiement', 2),
(11, 'L M M J V S', 2),
(12, 'Periode pose', 2);
