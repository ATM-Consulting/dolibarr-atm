CREATE TABLE `llx_cara_deviscarapos_extrafields` (
  `rowid` int NOT NULL,
  `tms` timestamp NULL DEFAULT NULL,
  `fk_object` int NOT NULL,
  `import_key` varchar(14) DEFAULT NULL
) ENGINE=InnoDB;