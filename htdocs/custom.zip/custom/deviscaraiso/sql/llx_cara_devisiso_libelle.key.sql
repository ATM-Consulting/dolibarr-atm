ALTER TABLE `llx_cara_devicarasiso_libelle`
  ADD PRIMARY KEY (`rowid`);


ALTER TABLE `llx_cara_devicarasiso_libelle`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;