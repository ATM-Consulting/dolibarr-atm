
CREATE TABLE `llx_cara_devicarasiso_libelle` (
  `rowid` int NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `pu` double DEFAULT NULL
) ENGINE=InnoDB;
