CREATE TABLE `llx_cara_cpville` (
  `rowid` int NOT NULL,
  `cp` int NOT NULL,
  `ville` varchar(50) NOT NULL
) ENGINE=InnoDB ;