ALTER TABLE `llx_cara_deviscaraposdet`
  ADD PRIMARY KEY (`rowid`);

ALTER TABLE `llx_cara_deviscaraposdet`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;