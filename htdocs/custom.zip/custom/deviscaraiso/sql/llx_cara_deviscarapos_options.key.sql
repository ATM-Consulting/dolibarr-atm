ALTER TABLE `llx_cara_deviscarapos_options`
  ADD PRIMARY KEY (`rowid`);


ALTER TABLE `llx_cara_deviscarapos_options`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;