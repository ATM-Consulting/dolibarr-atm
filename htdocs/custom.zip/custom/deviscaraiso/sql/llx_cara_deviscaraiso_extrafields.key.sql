
ALTER TABLE `llx_cara_deviscaraiso_extrafields`
  ADD PRIMARY KEY (`rowid`),
  ADD KEY `idx_fk_object` (`fk_object`);


ALTER TABLE `llx_cara_deviscaraiso_extrafields`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT;
