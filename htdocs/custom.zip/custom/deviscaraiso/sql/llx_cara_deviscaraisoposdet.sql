CREATE TABLE `llx_cara_deviscaraposdet` (
  `rowid` int NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `options` int DEFAULT NULL,
  `fk_deviscarapos` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `qty` varchar(20) DEFAULT NULL,
  `fk_user_creat` int DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `fk_user_modif` int DEFAULT NULL
) ENGINE=InnoDB;
