ALTER TABLE `llx_cara_deviscarapos_extrafields`
  ADD PRIMARY KEY (`rowid`),
  ADD KEY `idx_fk_object` (`fk_object`);

ALTER TABLE `llx_cara_deviscarapos_extrafields`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT;