CREATE TABLE `llx_cara_deviscarapos_options` (
  `rowid` int NOT NULL,
  `fk_libelle` int NOT NULL,
  `ref` varchar(128) DEFAULT NULL
) ENGINE=InnoDB;