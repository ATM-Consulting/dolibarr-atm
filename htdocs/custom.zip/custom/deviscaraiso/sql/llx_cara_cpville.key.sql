ALTER TABLE `llx_cara_cpville`
  ADD PRIMARY KEY (`rowid`);


ALTER TABLE `llx_cara_cpville`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
