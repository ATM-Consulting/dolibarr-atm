ALTER TABLE `llx_cara_deviscarapos`
  ADD PRIMARY KEY (`rowid`);


ALTER TABLE `llx_cara_deviscarapos`
  MODIFY `rowid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;