-- Copyright (C) ---Put here your own copyright and developer email---
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


CREATE TABLE `llx_cara_deviscaraiso` (
  `rowid` int NOT NULL,
  `ref` varchar(128) NOT NULL,
  `entity` int NOT NULL,
  `label` smallint DEFAULT NULL,
  `s_type` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `qty` float DEFAULT NULL,
  `qtypose` float DEFAULT NULL,
  `nb_sacs` int DEFAULT NULL,
  `fk_soc` int NOT NULL,
  `description` text,
  `date_creation` datetime DEFAULT NULL,
  `date_validation` datetime DEFAULT NULL,
  `tms` timestamp NULL DEFAULT NULL,
  `fk_user_creat` int DEFAULT NULL,
  `fk_user_modif` int DEFAULT NULL,
  `fk_user_valid` int DEFAULT NULL,
  `model_pdf` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `status` int DEFAULT NULL,
  `planification` int DEFAULT NULL,
  `date_planif` datetime DEFAULT NULL,
  `date_pose` datetime DEFAULT NULL,
  `fk_usercomm` int DEFAULT NULL,
  `fk_user_pos` int DEFAULT NULL,
  `last_main_doc` varchar(256) DEFAULT NULL,
  `alerte_date_planif` tinyint(1) DEFAULT '0',
  `alerte_dossier_incomplet` tinyint DEFAULT '0',
  `mod_paiement` tinyint DEFAULT '0',
  `mod_paiement_quand` tinyint DEFAULT '0',
  `mod_paiement_qty` int DEFAULT '0',
  `acompte` float DEFAULT '0'
)  ENGINE=innodb;
