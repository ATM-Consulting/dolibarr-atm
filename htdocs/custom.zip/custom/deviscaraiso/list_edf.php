<?php
/* Copyright (C) 2007-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       htdocs/modulebuilder/template/myobject_list.php
 *		\ingroup    mymodule
 *		\brief      List page for myobject
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB', '1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER', '1');					// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC', '1');					// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN', '1');					// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION', '1');			// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION', '1');			// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK', '1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL', '1');					// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK', '1');					// Do not check style html tag into posted data
//if (! defined('NOIPCHECK'))                define('NOIPCHECK', '1');						// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU', '1');					// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML', '1');					// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX', '1');       		  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN", '1');						// If this page is public (can be called outside logged session)
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT', 'auto');			// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN', '1');		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("XFRAMEOPTIONS_ALLOWALL"))   define('XFRAMEOPTIONS_ALLOWALL', '1');			// Do not add the HTTP header 'X-Frame-Options: SAMEORIGIN' but 'X-Frame-Options: ALLOWALL'

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';

// load mymodule libraries
require_once __DIR__.'/class/deviscaraedf.class.php';
include_once DOL_DOCUMENT_ROOT . dol_buildpath("caradocuments/data/cara_document.class.php", 1);

// for other modules
//dol_include_once('/othermodule/class/otherobject.class.php');

// Load translation files required by the page
$langs->loadLangs(array("mymodule@mymodule", "other"));

$action     = GETPOST('action', 'aZ09') ?GETPOST('action', 'aZ09') : 'view'; // The action 'add', 'create', 'edit', 'update', 'view', ...
$massaction = GETPOST('massaction', 'alpha'); // The bulk action (combo box choice into lists)
$show_files = GETPOST('show_files', 'int'); // Show files area generated by bulk actions ?
$confirm    = GETPOST('confirm', 'alpha'); // Result of a confirmation
$cancel     = GETPOST('cancel', 'alpha'); // We click on a Cancel button
$toselect   = GETPOST('toselect', 'array'); // Array of ids of elements selected into a list
$contextpage = GETPOST('contextpage', 'aZ') ? GETPOST('contextpage', 'aZ') : 'deviscaraisolist'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha'); // Go back to a dedicated page
$optioncss  = GETPOST('optioncss', 'aZ'); // Option for the css output (always '' except when 'print')
$fromdatecreation=GETPOST('fromdate_creation');
$todatecreation=GETPOST('todate_creation');
$searchlibvialoupe=GETPOST('search_search_fk_soc');
$id = GETPOST('id', 'int');

// Load variable for pagination
$limit = GETPOST('limit', 'int') ? GETPOST('limit', 'int') : $conf->liste_limit;
$sortfield = GETPOST('sortfield', 'alpha');
$sortorder = GETPOST('sortorder', 'alpha');
if($_SESSION['list_devis']['page'] && GETPOST('page', 'int')=="")
	$page = $_SESSION['list_devis']['page'];
else{
	$page = GETPOST('page', 'int');
	$_SESSION['list_devis']['page']=$page;
}
if (empty($page) || $page == -1 || GETPOST('button_search', 'alpha') || GETPOST('button_removefilter', 'alpha') || (empty($toselect) && $massaction === '0')) { $page = 0; }     // If $page is not defined, or '' or -1 or if we click on clear filters or if we select empty mass action
$offset = $limit * $page;
$pageprev = $page - 1;
$pagenext = $page + 1;

// Initialize technical objects
$object = new Deviscaraiso($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->deviscaraiso->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('deviscaraisolist')); // Note that conf->hooks_modules contains array


// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);
//$extrafields->fetch_name_optionals_label($object->table_element_line);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Default sort order (if not yet defined by previous GETPOST)
if (!$sortfield) $sortfield = "".key($object->fields); // Set here default search field. By default 1st field in definition.
if (!$sortorder) $sortorder = "DESC";

// Security check
if (empty($conf->deviscaraiso->enabled)) accessforbidden('Module not enabled');
$socid = 0;
if ($user->socid > 0)	// Protection if external user
{
	//$socid = $user->socid;
	accessforbidden();
}

$arrayfields=array();
$tab=$object->get_fields_supp();
$object->fields=array_merge($object->fields, $tab);

// Initialize array of search criterias
$search_all=trim(GETPOST("search_all", 'alpha'));
$search=array();
foreach($object->fields as $key => $val)
{
	if(!$_SESSION['list_devis']['search'.$key] || GETPOST('search_'.$key, 'alpha') !== ''){
		$search[$key]=GETPOST('search_'.$key, 'alpha');
		$_SESSION['list_devis']['search'.$key]=$search[$key];
	}
	else $search[$key]=$_SESSION['list_devis']['search'.$key];
	
}

if(!$_SESSION['list_devis']['search_ville'] || GETPOST('search_ville', 'alpha') !== ''){
	$search['ville']=GETPOST('search_ville', 'alpha');
	$_SESSION['list_devis']['search_ville']=$search['ville'];
}
else $search['ville']=$_SESSION['list_devis']['search_ville'];

if(!$_SESSION['list_devis']['search_phone'] || GETPOST('search_phone', 'alpha') !== '' ){
	$search['phone']=GETPOST('search_phone', 'alpha');
	$_SESSION['list_devis']['search_phone']=$search['phone'];
}
else $search['phone']=$_SESSION['list_devis']['search_phone'];

if(!$_SESSION['list_devis']['search_address'] || GETPOST('search_address', 'alpha') !== ''){
	$search['address']=GETPOST('search_address', 'alpha');
	$_SESSION['list_devis']['search_address']=$search['address'];
}
else $search['address']=$_SESSION['list_devis']['search_address'];

//if (GETPOST('search_commerciaux', 'alpha') !== '') $search['commerciaux']=GETPOST('search_commerciaux', 'alpha');
// List of fields to search into when doing a "search in all"
$fieldstosearchall = array();
$_SESSION['list_devis']['sortfield']=$sortfield;
$_SESSION['list_devis']['sortorder']=$sortorder;
foreach($object->fields as $key => $val)
{
	if ($val['searchall']) $fieldstosearchall['t.'.$key]=$val['label'];
}

// Definition of fields for list

foreach($object->fields as $key => $val)
{
	// If $val['visible']==0, then we never show the field
	if (!empty($val['visible'])) $arrayfields[$key] = array('label'=>$val['label'], 'checked'=>(($val['visible'] < 0) ? 0 : 1), 'enabled'=>($val['enabled'] && ($val['visible'] != 3)), 'position'=>$val['position']);
}
// Extra fields
if (is_array($extrafields->attributes[$object->table_element]['label']) && count($extrafields->attributes[$object->table_element]['label']) > 0)
{
	foreach($extrafields->attributes[$object->table_element]['label'] as $key => $val)
	{
		if (!empty($extrafields->attributes[$object->table_element]['list'][$key])) {
			$arrayfields["ef.".$key] = array(
				'label'=>$extrafields->attributes[$object->table_element]['label'][$key],
				'checked'=>(($extrafields->attributes[$object->table_element]['list'][$key]<0)?0:1),
				'position'=>$extrafields->attributes[$object->table_element]['pos'][$key],
				'enabled'=>(abs($extrafields->attributes[$object->table_element]['list'][$key])!=3 && $extrafields->attributes[$object->table_element]['perms'][$key])
			);
		}
	}
}

$object->fields = dol_sort_array($object->fields, 'position');
$arrayfields = dol_sort_array($arrayfields, 'position');

$permissiontoread = $user->rights->deviscaraiso->deviscaraiso->read;
$permissiontoadd = $user->rights->deviscaraiso->deviscaraiso->write;
$permissiontodelete = $user->rights->deviscaraiso->deviscaraiso->delete;


/*
 * Actions
 */

if (GETPOST('cancel', 'alpha')) { $action = 'list'; $massaction = ''; }
if (!GETPOST('confirmmassaction', 'alpha') && $massaction != 'presend' && $massaction != 'confirm_presend') { $massaction = ''; }

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook))
{
	// Selection of new fields
	include DOL_DOCUMENT_ROOT.'/core/actions_changeselectedfields.inc.php';

	// Purge search criteria
	if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')) // All tests are required to be compatible with all browsers
	{
		foreach ($object->fields as $key => $val)
		{
			$search[$key] = '';
		}
		$toselect = '';
		$search_array_options = array();
		$fromdatecreation='';
		$todatecreation='';
		$searchlibvialoupe='';
	}
	if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')
		|| GETPOST('button_search_x', 'alpha') || GETPOST('button_search.x', 'alpha') || GETPOST('button_search', 'alpha'))
	{
		$massaction = ''; // Protection to avoid mass action if we force a new search during a mass action confirmation
		unset($_SESSION['list_devis']);
	}

	// Mass actions
	$objectclass = 'Deviscaraiso';
	$objectlabel = 'Devis Cara Isolation';
	$uploaddir = $conf->deviscaraiso->dir_output;
	include DOL_DOCUMENT_ROOT.'/core/actions_massactions.inc.php';
}



/*
 * View
 */

$form = new Form($db);

$now = dol_now();

//$help_url="EN:Module_MyObject|FR:Module_MyObject_FR|ES:Módulo_MyObject";
$help_url = '';
$title = $langs->trans('ListOf', $langs->transnoentitiesnoconv("Affaires liés à EDF"));


// Build and execute select
// --------------------------------------------------------------------
$sql_fields= 'w.fk_soc,s.nom, w.rowid, w.ref, w.label, w.qty,w.qtypose, w.date_creation, w.fk_user_creat, w.fk_user_modif,  w.planification, w.date_planif, 
w.fk_usercomm, w.amount, w.commentaire_edf, w.edf_nbparts,w.nb_sacs,
s.address,s_type, edf,fposeur, aff.ref as affaire,aff.rowid as affaireid,status_edf,
cpv.rowid as ville, concat(COALESCE(s.phone,""),";",COALESCE(s.fax,""),";",COALESCE(s.url,"")) as phone,s.address,
cara_type_client as preca,se.nbpart,se.edl,se.contratedf,w.status_edf2,numfac_edf,
w.date_cee_1,w.date_cee_2,w.date_cee_3,w.date_edf2_1,w.date_edf2_2,w.date_edf2_4,w.date_edf2_6,
w.date_edf_2,w.date_edf_3,w.date_edf_4,w.date_edf_5,w.date_edf_6,w.date_edf_7,w.date_edf_8,w.date_edf_17,w.date_edf_29,w.date_edf_9,w.date_edf_10,
w.date_planif_4,status_edfop,date_pose,
';
$sql = 'SELECT ';

$sql.=$sql_fields;
$sql.='"iso"';

$sql .= " FROM ".MAIN_DB_PREFIX."cara_deviscaraiso as w";
$sql.=" left join ".MAIN_DB_PREFIX."societe s on s.rowid=w.fk_soc";
$sql.=' left join '.MAIN_DB_PREFIX.'societe_extrafields se on fk_object=s.rowid';
$sql.=' left join '.MAIN_DB_PREFIX.'cara_cpville cpv on cpv.rowid=se.ville';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinancedet affdet on w.rowid=fk_prod and fk_type=1';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinance aff on affdet.fk_carafinance=aff.rowid';

if($search['status_edf2'] == "-2")
	$sql .= " WHERE 1 = 1 ";
else
	$sql .= " WHERE 1 = 1 and (status_edf2 >0 or status_edf >0  )  " ;
foreach ($search as $key => $val)
{
	
	if ($key == 'planification' && $search[$key] == -1) continue;
	if ($key == 'status' && ($search[$key] == -1 || $search[$key] == '') ) continue;

	if($key=='ville' && ($search[$key] != -1 && $search[$key] != '')) {
		$sql.=' and  (cpv.rowid = "'.$search['ville'].'" )'; 
		continue;
	}
	if($key=='status' && $search[$key] != "-1") {
		$sql.=' and  (w.status ='.$search['status'].' )'; 
		continue;
	}
	if($key=='status_edf2' && $search[$key] == "-2") {
		$sql.=' and  (w.status_edf2 is null or w.status_edf2=0 )'; 
		continue;
	}
	if($key=='description' && $search[$key] != "-1") {
		$sql.=' and  (w.description like "%'.$search['description'].'%" )'; 
		continue;
	}
	
	if($key=='edf' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (w.edf like "%'.$search['edf'].'%" )'; 
		continue;
	}
	if($key=='preca' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (se.cara_type_client = '.$search[$key].' )'; 
		continue;
	}
	$mode_search = 1;
	if (strpos($object->fields[$key]['type'], 'integer:') === 0) {
		if ($search[$key] == '-1') $search[$key] = '';
		$mode_search = 2;
	}
	if ($search[$key] != '' && $search[$key] !=-1  ) $sql .= natural_search('w.'.$key, $search[$key], (($key == 'status') ? 2 : $mode_search));

}

if($fromdatecreation != '' && $todatecreation != ''){	
	$fromdate= DateTime::createFromFormat('d/m/Y',$fromdatecreation);
	$todate= DateTime::createFromFormat('d/m/Y',$todatecreation);
	$sql.=' and  (w.date_creation between  "'.$fromdate->format("Y-m-d").'" and "'.$todate->format("Y-m-d").'")'; 
} 

if($searchlibvialoupe && ($search['fk_soc']=="")) {
	$searchlibvialoupe=trim($searchlibvialoupe);
	$sql.=' and  (s.nom like "%'.$searchlibvialoupe.'%" )'; 
}
if ($search_all) $sql .= natural_search(array_keys($fieldstosearchall), $search_all);
//$sql.= dolSqlDateFilter("t.field", $search_xxxday, $search_xxxmonth, $search_xxxyear);
// Add where from extra fields
include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_sql.tpl.php';
// Add where from hooks
$parameters = array();
$reshook = $hookmanager->executeHooks('printFieldListWhere', $parameters, $object); // Note that $action and $object may have been modified by hook
$sql .= $hookmanager->resPrint;
//print $sql;

// on rajoute la table devisisoces
$sql .= " UNION ";
$sql .= 'SELECT ';
include dol_buildpath('/deviscaraces/class/deviscaraces.class.php');
$object_ces=new Deviscaraces($db);
$ces_fields=$object_ces->fields;
$ces_fields=array_merge($ces_fields,$tabfiledssupp);
$ces_fields = dol_sort_array($ces_fields, 'position');



$sql.=$sql_fields;
$sql.='"ces"';
$sql = preg_replace('/,\s*$/', '', $sql);
$sql .= " FROM ".MAIN_DB_PREFIX."cara_deviscaraces as w";
$sql.=" left join ".MAIN_DB_PREFIX."societe s on s.rowid=w.fk_soc";
$sql.=' left join '.MAIN_DB_PREFIX.'societe_extrafields se on fk_object=s.rowid';
$sql.=' left join '.MAIN_DB_PREFIX.'cara_cpville cpv on cpv.rowid=se.ville';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinancedet affdet on w.rowid=fk_prod and fk_type=2';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinance aff on affdet.fk_carafinance=aff.rowid';
if($search['status_edf2'] == "-2")
	$sql .= " WHERE 1 = 1 ";
else
	$sql .= " WHERE 1 = 1 and (status_edf2 >0 or status_edf >0 )   " ;

foreach ($search as $key => $val)
{
	
	if ($key == 'planification' && $search[$key] == -1) continue;
	if ($key == 'status' && ($search[$key] == -1 ||$search[$key] == '') ) continue;
	if ($key == 'ville' && $search[$key] == -1) continue;
	if($key=='ville' && ($search[$key] != -1 && $search[$key] != '')) {
		$sql.=' and  (cpv.rowid = "'.$search['ville'].'" )'; 
		continue;
	}
	if($key=='phone' && $search[$key] != "") {
		$sql.=' and  (replace(s.phone," ","") like "%'.$search['phone'].'%" or replace(s.fax," ","") like "%'.$search['phone'].'%" or replace(s.url," ","") like "%'.$search['phone'].'%" )'; 
		continue;
	}
	if($key=='status' && $search[$key] != "-1") {
		$sql.=' and  (w.status ='.$search['status'].' )'; 
		continue;
	}
	if($key=='status_edf2' && $search[$key] == "-2") {
		$sql.=' and  (w.status_edf2 is null or w.status_edf2=0 )'; 
		continue;
	}
	if($key=='description' && $search[$key] != "-1") {
		$sql.=' and  (w.description like "%'.$search['description'].'%" )'; 
		continue;
	}
	
	if($key=='edf' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (w.edf like "%'.$search['edf'].'%" )'; 
		continue;
	}
	if($key=='preca' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (se.cara_type_client = '.$search[$key].' )'; 
		continue;
	}
	$mode_search = 1;
	if (strpos($object->fields[$key]['type'], 'integer:') === 0) {
		if ($search[$key] == '-1') $search[$key] = '';
		$mode_search = 2;
	}
	if ($search[$key] != '' && $search[$key] !=-1 ) $sql .= natural_search('w.'.$key, $search[$key], (($key == 'status') ? 2 : $mode_search));
	 
}
if($fromdatecreation != '' && $todatecreation != ''){	
	$fromdate= DateTime::createFromFormat('d/m/Y',$fromdatecreation);
	$todate= DateTime::createFromFormat('d/m/Y',$todatecreation);
	$sql.=' and  (w.date_creation between  "'.$fromdate->format("Y-m-d").'" and "'.$todate->format("Y-m-d").'")'; 
}

if($searchlibvialoupe && ($search['fk_soc']=="")) {
	$searchlibvialoupe=trim($searchlibvialoupe);
	$sql.=' and  (s.nom like "%'.$searchlibvialoupe.'%" )'; 
}
//on rajoute les toitures
$sql .= " UNION ";
$sql .= 'SELECT ';	
include dol_buildpath('/deviscaratoit/class/deviscaratoit.class.php');
$object_rep=new Deviscaratoit($db);
$rep_fields=$object_ces->fields;
$rep_fields=array_merge($ces_fields,$tabfiledssupp);
$rep_fields = dol_sort_array($ces_fields, 'position');


$sql.=$sql_fields;
$sql.='"toit"';
$sql = preg_replace('/,\s*$/', '', $sql);
$sql .= " FROM ".MAIN_DB_PREFIX."cara_deviscaratoit as w";
$sql.=" left join ".MAIN_DB_PREFIX."societe s on s.rowid=w.fk_soc";
$sql.=' left join '.MAIN_DB_PREFIX.'societe_extrafields se on fk_object=s.rowid';
$sql.=' left join '.MAIN_DB_PREFIX.'cara_cpville cpv on cpv.rowid=se.ville';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinancedet affdet on w.rowid=fk_prod and fk_type=4';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinance aff on affdet.fk_carafinance=aff.rowid';

if($search['status_edf2'] == "-2")
	$sql .= " WHERE 1 = 1 ";
else
	$sql .= " WHERE 1 = 1 and (status_edf2 >0 or status_edf >0 ) and status_edf not in(29) " ;

foreach ($search as $key => $val)
{
	
	if ($key == 'planification' && $search[$key] == -1) continue;
	if ($key == 'status' && ($search[$key] == -1 || $search[$key] == '') ) continue;
	
	if($key=='status' && $search[$key] != "-1") {
		$sql.=' and  (w.status ='.$search['status'].' )'; 
		continue;
	}
	if($key=='ville' && ($search[$key] != -1 && $search[$key] != '')) {
		$sql.=' and  (cpv.rowid = "'.$search['ville'].'" )'; 
		continue;
	}
	if($key=='status_edf2' && $search[$key] == "-2") {
		$sql.=' and  (w.status_edf2 is null or w.status_edf2=0 )'; 
		continue;
	}
	if($key=='description' && $search[$key] != "-1") {
		$sql.=' and  (w.description like "%'.$search['description'].'%" )'; 
		continue;
	}
	if($key=='af') {
		if($search[$key] != "-1" && $search[$key] != ''){
			$sql.=' and  (w.af like "%'.$search['af'].'%" )'; 
			continue;
		}
		elseif($search[$key] == "-1"){
			$sql.=' and  (w.af is null )'; 
			continue;
		}
	}
	if($key=='edf' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (w.edf like "%'.$search['edf'].'%" )'; 
		continue;
	}
	if($key=='preca' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (se.cara_type_client = '.$search[$key].' )'; 
		continue;
	}
	$mode_search = 1;
	if (strpos($object->fields[$key]['type'], 'integer:') === 0) {
		if ($search[$key] == '-1') $search[$key] = '';
		$mode_search = 2;
	}
	if ($search[$key] != '' && $search[$key] !=-1 ) $sql .= natural_search('w.'.$key, $search[$key], (($key == 'status') ? 2 : $mode_search));

}
if($fromdatecreation != '' && $todatecreation != ''){	
	$fromdate= DateTime::createFromFormat('d/m/Y',$fromdatecreation);
	$todate= DateTime::createFromFormat('d/m/Y',$todatecreation);
	$sql.=' and  (w.date_creation between  "'.$fromdate->format("Y-m-d").'" and "'.$todate->format("Y-m-d").'")'; 
}

if($searchlibvialoupe && ($search['fk_soc']=="")) {
	$searchlibvialoupe=trim($searchlibvialoupe);
	$sql.=' and  (s.nom like "%'.$searchlibvialoupe.'%" )'; 
}

//on rajoute les isolations de toitures
$sql .= " UNION ";
$sql .= 'SELECT ';	
include dol_buildpath('/deviscaraiso/class/deviscaraisotoit.class.php');
$object_isotoit=new Deviscaraisotoit($db);
$object_isotoit_fields=$object_isotoit->fields;
$object_isotoit_fields=array_merge($object_isotoit,$tabfiledssupp);
$object_isotoit_fields = dol_sort_array($object_isotoit, 'position');


$sql.=$sql_fields;
$sql.='"isotoit"';
$sql = preg_replace('/,\s*$/', '', $sql);
$sql .= " FROM ".MAIN_DB_PREFIX."cara_deviscaraisotoit as w";
$sql.=" left join ".MAIN_DB_PREFIX."societe s on s.rowid=w.fk_soc";
$sql.=' left join '.MAIN_DB_PREFIX.'societe_extrafields se on fk_object=s.rowid';
$sql.=' left join '.MAIN_DB_PREFIX.'cara_cpville cpv on cpv.rowid=se.ville';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinancedet affdet on w.rowid=fk_prod and fk_type=4';
$sql.=' left join '.MAIN_DB_PREFIX.'carafinance_carafinance aff on affdet.fk_carafinance=aff.rowid';

if($search['status_edf2'] == "-2")
	$sql .= " WHERE 1 = 1 ";
else
	$sql .= " WHERE 1 = 1 and (status_edf2 >0 or status_edf >0 )  " ;

foreach ($search as $key => $val)
{
	
	if ($key == 'planification' && $search[$key] == -1) continue;
	if ($key == 'status' && ($search[$key] == -1 || $search[$key] == '') ) continue;
	
	if($key=='status' && $search[$key] != "-1") {
		$sql.=' and  (w.status ='.$search['status'].' )'; 
		continue;
	}
	if($key=='ville' && ($search[$key] != -1 && $search[$key] != '')) {
		$sql.=' and  (cpv.rowid = "'.$search['ville'].'" )'; 
		continue;
	}
	if($key=='status_edf2' && $search[$key] == "-2") {
		$sql.=' and  (w.status_edf2 is null or w.status_edf2=0 )'; 
		continue;
	}
	if($key=='description' && $search[$key] != "-1") {
		$sql.=' and  (w.description like "%'.$search['description'].'%" )'; 
		continue;
	}
	if($key=='af') {
		if($search[$key] != "-1" && $search[$key] != ''){
			$sql.=' and  (w.af like "%'.$search['af'].'%" )'; 
			continue;
		}
		elseif($search[$key] == "-1"){
			$sql.=' and  (w.af is null )'; 
			continue;
		}
	}
	if($key=='edf' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (w.edf like "%'.$search['edf'].'%" )'; 
		continue;
	}
	if($key=='preca' && $search[$key] != "-1" && $search[$key] != '') {
		$sql.=' and  (se.cara_type_client = '.$search[$key].' )'; 
		continue;
	}
	$mode_search = 1;
	if (strpos($object->fields[$key]['type'], 'integer:') === 0) {
		if ($search[$key] == '-1') $search[$key] = '';
		$mode_search = 2;
	}
	if ($search[$key] != '' && $search[$key] !=-1 ) $sql .= natural_search('w.'.$key, $search[$key], (($key == 'status') ? 2 : $mode_search));

}
if($fromdatecreation != '' && $todatecreation != ''){	
	$fromdate= DateTime::createFromFormat('d/m/Y',$fromdatecreation);
	$todate= DateTime::createFromFormat('d/m/Y',$todatecreation);
	$sql.=' and  (w.date_creation between  "'.$fromdate->format("Y-m-d").'" and "'.$todate->format("Y-m-d").'")'; 
}

if($searchlibvialoupe && ($search['fk_soc']=="")) {
	$searchlibvialoupe=trim($searchlibvialoupe);
	$sql.=' and  (s.nom like "%'.$searchlibvialoupe.'%" )'; 
}
if($sortfield=='fk_soc') $sortfield='nom';
$sql .= $db->order($sortfield, $sortorder);
//print $sql;
// Count total nb of records
$nbtotalofrecords = '';
if (empty($conf->global->MAIN_DISABLE_FULL_SCANLIST))
{
	$resql = $db->query($sql);
	$nbtotalofrecords = $db->num_rows($resql);
	if (($page * $limit) > $nbtotalofrecords)	// if total of record found is smaller than page * limit, goto and load page 0
	{
		$page = 0;
		$offset = 0;
	}
}
// if total of record found is smaller than limit, no need to do paging and to restart another select with limits set.
if (is_numeric($nbtotalofrecords) && ($limit > $nbtotalofrecords || empty($limit)))
{
	$num = $nbtotalofrecords;
}
else
{
	if ($limit) $sql .= $db->plimit($limit + 1, $offset);

	$resql = $db->query($sql);
	if (!$resql)
	{
		dol_print_error($db);
		exit;
	}

	$num = $db->num_rows($resql);
}

// Direct jump if only one record found
if ($num == 1 && !empty($conf->global->MAIN_SEARCH_DIRECT_OPEN_IF_ONLY_ONE) && $search_all && !$page)
{
	$obj = $db->fetch_object($resql);
	$id = $obj->rowid;
	header("Location: ".dol_buildpath('/deviscaraiso/cardbis.php', 1).'?id='.$id);
	exit;
}


// Output page
// --------------------------------------------------------------------

llxHeader('', $title, $help_url);

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});
</script>';

$arrayofselected = is_array($toselect) ? $toselect : array();

$param = '';
if (!empty($contextpage) && $contextpage != $_SERVER["PHP_SELF"]) $param .= '&contextpage='.urlencode($contextpage);
if ($limit > 0 && $limit != $conf->liste_limit) $param .= '&limit='.urlencode($limit);
foreach ($search as $key => $val)
{
    if (is_array($search[$key]) && count($search[$key])) foreach ($search[$key] as $skey) $param .= '&search_'.$key.'[]='.urlencode($skey);
    else $param .= '&search_'.$key.'='.urlencode($search[$key]);
}
if ($optioncss != '')     $param .= '&optioncss='.urlencode($optioncss);
// Add $param from extra fields
include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_param.tpl.php';

// List of mass actions available
$arrayofmassactions = array(
    //'validate'=>$langs->trans("Validate"),
    //'generate_doc'=>$langs->trans("ReGeneratePDF"),
    //'builddoc'=>$langs->trans("PDFMerge"),
    //'presend'=>$langs->trans("SendByMail"),
);
if ($permissiontodelete) $arrayofmassactions['predelete'] = '<span class="fa fa-trash paddingrightonly"></span>'.$langs->trans("Delete");
if (GETPOST('nomassaction', 'int') || in_array($massaction, array('presend', 'predelete'))) $arrayofmassactions = array();
$massactionbutton = $form->selectMassAction('', $arrayofmassactions);

print '<form method="POST" id="searchFormList" action="'.$_SERVER["PHP_SELF"].'">'."\n";
if ($optioncss != '') print '<input type="hidden" name="optioncss" value="'.$optioncss.'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="formfilteraction" id="formfilteraction" value="list">';
print '<input type="hidden" name="action" value="list">';
print '<input type="hidden" name="sortfield" value="'.$sortfield.'">';
print '<input type="hidden" name="sortorder" value="'.$sortorder.'">';
print '<input type="hidden" name="page" value="'.$page.'">';
print '<input type="hidden" name="contextpage" value="'.$contextpage.'">';

$newcardbutton = dolGetButtonTitle($langs->trans('New'), '', 'fa fa-plus-circle', dol_buildpath('/deviscaraiso/card.php', 1).'?action=create&backtopage='.urlencode($_SERVER['PHP_SELF']), '', $permissiontoadd);

print_barre_liste($title, $page, $_SERVER["PHP_SELF"], $param, $sortfield, $sortorder, $massactionbutton, $num, $nbtotalofrecords, 'title_companies', 0, $newcardbutton, '', $limit);

// Add code for pre mass action (confirmation or email presend form)
$topicmail = "SendMyObjectRef";
$modelmail = "myobject";
$objecttmp = new Deviscaraiso($db);
$trackid = 'xxxx'.$object->id;
include DOL_DOCUMENT_ROOT.'/core/tpl/massactions_pre.tpl.php';

if ($search_all)
{
	foreach ($fieldstosearchall as $key => $val) $fieldstosearchall[$key] = $langs->trans($val);
	print '<div class="divsearchfieldfilter">'.$langs->trans("FilterOnInto", $search_all).join(', ', $fieldstosearchall).'</div>';
}

$moreforfilter = '';
/*$moreforfilter.='<div class="divsearchfield">';
$moreforfilter.= $langs->trans('MyFilter') . ': <input type="text" name="search_myfield" value="'.dol_escape_htmltag($search_myfield).'">';
$moreforfilter.= '</div>';*/

$parameters = array();
$reshook = $hookmanager->executeHooks('printFieldPreListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
if (empty($reshook)) $moreforfilter .= $hookmanager->resPrint;
else $moreforfilter = $hookmanager->resPrint;

if (!empty($moreforfilter))
{
	print '<div class="liste_titre liste_titre_bydiv centpercent">';
	print $moreforfilter;
	print '</div>';
}

$varpage = empty($contextpage) ? $_SERVER["PHP_SELF"] : $contextpage;
//$selectedfields = $form->multiSelectArrayWithCheckbox('selectedfields', $arrayfields, $varpage); // This also change content of $arrayfields
$selectedfields .= (count($arrayofmassactions) ? $form->showCheckAddButtons('checkforselect', 1) : '');

print '<div class="div-table-responsive">'; // You can use div-table-responsive-no-min if you dont need reserved height for your table
print '<table class="tagtable liste'.($moreforfilter ? " listwithfilterbefore" : "").'" >'."\n";


// Fields title search
// --------------------------------------------------------------------
print '<tr class="liste_titre">';
//$tabnottoaffiche=array('ville');
foreach ($object->fields as $key => $val)
{
	$cssforfield = (empty($val['css']) ? '' : $val['css']);
	if ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '').'center';
	if (in_array($key, $tabnottoaffiche)) continue;
	elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'center';
	elseif (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
	elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $val['label'] != 'TechnicalID') $cssforfield .= ($cssforfield ? ' ' : '').'right';
	elseif (in_array($key, array('fk_soc'))) $cssforfield .= ($cssforfield ? ' ' : '').'left nowrap';
	if (!empty($arrayfields[$key]['checked']))
	{
		print '<td class="liste_titre'.($cssforfield ? ' '.$cssforfield : '').'">';
		if (is_array($val['arrayofkeyval'])) 
			print $form->selectarray('search_'.$key, $val['arrayofkeyval'], $search[$key], $val['notnull'], 0, 0, '', 1, 0, 0, '', 'maxwidth75');
		elseif ($key=='date_creation') {
			print $langs->trans('From').' ';
			if($fromdate)
				$stampfromdate=$fromdate->getTimestamp();
			else
				$stampfromdate='';
			print $form->selectDate($stampfromdate, 'from'.$key, 0, 0, 1, "search_form", 1, 0);
			print $langs->trans('To').' ';
			if($todate)
				$stamptodate=$todate->getTimestamp();
			else
				$stamptodate='';
			print $form->selectDate($stamptodate, 'to'.$key, 0, 0, 1, "search_form", 1, 0);
			
		}
		
		elseif (strpos($val['type'], 'integer:') === 0) {
			$out=$object->showInputField($val, $key, $search[$key], 'onchange="this.form.submit();"', '', 'search_', 'maxwidth150', 1);
			//loupe à côté du champ rechercher
			if($key=='fk_soc'){	
				$out .=  '<button type="submit" class="liste_titre button_search" name="button_search_x" value="x"><span class="fa fa-search"></span></button>
				<button type="submit" class="liste_titre button_removefilter" name="button_removefilter_x" value="x"><span class="fa fa-remove"></span></button>';
			}
			print $out;
		}
		elseif (! preg_match('/^(date|timestamp)/', $val['type'])) 
			print '<input type="text" class="flat maxwidth75" name="search_'.$key.'" value="'.dol_escape_htmltag($search[$key]).'">';
		print '</td>';
	}

	
	
}

// Extra fields
include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_input.tpl.php';

// Fields from hook
$parameters = array('arrayfields'=>$arrayfields);
$reshook = $hookmanager->executeHooks('printFieldListOption', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;
// Action column
print '<td class="liste_titre maxwidthsearch">';
$searchpicto = $form->showFilterButtons();
print $searchpicto;
print '</td>';
print '</tr>'."\n";


// Fields title label
// --------------------------------------------------------------------
print '<tr class="liste_titre">';
foreach ($object->fields as $key => $val)
{
	$cssforfield = (empty($val['css']) ? '' : $val['css']);
	if (in_array($key, $tabnottoaffiche)) continue;
	if ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '').'center';
	elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'center';
	elseif (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
	elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $val['label'] != 'TechnicalID') $cssforfield .= ($cssforfield ? ' ' : '').'right';
	if (!empty($arrayfields[$key]['checked']))
	{
		print getTitleFieldOfList($arrayfields[$key]['label'], 0, $_SERVER['PHP_SELF'], $key, '', $param, ($cssforfield ? 'class="'.$cssforfield.'"' : ''), $sortfield, $sortorder, ($cssforfield ? $cssforfield.' ' : ''))."\n";
	}
	
}

include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_search_title.tpl.php';
// Hook fields
$parameters = array('arrayfields'=>$arrayfields, 'param'=>$param, 'sortfield'=>$sortfield, 'sortorder'=>$sortorder);
$reshook = $hookmanager->executeHooks('printFieldListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;
// Action column
print getTitleFieldOfList($selectedfields, 0, $_SERVER["PHP_SELF"], '', '', '', '', $sortfield, $sortorder, 'center maxwidthsearch ')."\n";
print '</tr>'."\n";


// Detect if we need a fetch on each output line
$needToFetchEachLine = 0;
if (is_array($extrafields->attributes[$object->table_element]['computed']) && count($extrafields->attributes[$object->table_element]['computed']) > 0)
{
	foreach ($extrafields->attributes[$object->table_element]['computed'] as $key => $val)
	{
		if (preg_match('/\$object/', $val)) $needToFetchEachLine++; // There is at least one compute field that use $object
	}
}


// Loop on record
// --------------------------------------------------------------------
$i = 0;
$totalarray = array();
$url_iso=dol_buildpath('/deviscaraiso/card.php', 1).'?id=';
$url_ces=dol_buildpath('/deviscaraces/card.php', 1).'?id=';
$url_rep=dol_buildpath('/deviscararep/card.php', 1).'?id=';
$url_toit=dol_buildpath('/deviscaratoit/cardbis.php', 1).'?id=';
$url_isotoit=dol_buildpath('/deviscaraiso/card_toit.php', 1).'?id=';

$url_majces=dol_buildpath('/deviscaraces/card.php', 1).'?id=';
$url_majiso=dol_buildpath('/deviscaraiso/card.php', 1).'?id=';
$url_majisotoit=dol_buildpath('/deviscaraiso/card_toit.php', 1).'?id=';
$url_majrep=dol_buildpath('/deviscararep/card.php', 1).'?id=';
$url_majtoit=dol_buildpath('/deviscaratoit/cardbis.php', 1).'?id=';
$url_finance=dol_buildpath('/carafinance/carafinance_card.php', 1).'?id=';
while ($i < ($limit ? min($num, $limit) : $num))
{
	$obj = $db->fetch_object($resql);
	if (empty($obj)) break; // Should not happen

	// Store properties in $object
	$object->setVarsFromFetchObj($obj);
	if ($obj->iso=='iso') {
		$object->type='iso';
		$object->typeid=1;
	
	}
	elseif($obj->iso=='ces'){
		$object->type='ces';
		$object->typeid=2;
	}
	elseif($obj->iso=='rep'){
		$object->type='rep';
		$object->typeid=3;
	}
	elseif($obj->iso=='toit'){
		$object->type='toit';
		$object->typeid=4;
	}
	elseif($obj->iso=='isotoit'){
		$object->type='isotoit';
		$object->typeid=7;
	}
	$tab_elts_fichepose=$object->get_elts_fichepose();
	// Show here line of result
	print '<tr class="oddeven">';
	$dateschgt='';
	foreach ($object->fields as $key2 => $val2){
		if( strstr($key2,'date_cee_') || strstr($key2,'date_edf2_') || strstr($key2,'date_edf_')){
			$dateschgt.='<b>'.$val2['label'].' : </b>'.($object->$key2?dol_print_date($object->$key2,'%d/%m/%Y'):'').'<br>';
		}
	}
	foreach ($object->fields as $key => $val)
	{
		$cssforfield = (empty($val['css']) ? '' : $val['css']);
		if (in_array($key, $tabnottoaffiche)) continue;
	    if (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'center';
	    elseif ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '').'center';

	    if (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
	    elseif (in_array($key,array('ref','fk_soc','affaire','date_pose'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';

		if (in_array($key, array('planification','ville','phone','status_edf'))) $cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
		

	    if (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $key != 'status') $cssforfield .= ($cssforfield ? ' ' : '').'right';

	    if (!empty($arrayfields[$key]['checked']))
		{
			
			print '<td'.($cssforfield ? ' class="'.$cssforfield.'"' : '').'>';
			if ($key == 'status') {
				
			}
			elseif ($key == 'status_edf') {
				$url=${'url_maj'.$object->type}.$object->id.'&action=edit';
				$out='<a  title="<div class=\'centpercent\'>
				<b><u>Dates Modification status</u></b><br>'.$dateschgt;
				$out.='<br></div>" class="classfortooltip refurl">*</a>';
				print $out;
				print $object->LibStatutPlanif(5,$url);
		
			}
			elseif ($key=='nb_sacs'){
				print $object->nb_sacs;
			}
			elseif ($key=='label'){
				if($object->$key==1){
					$popup='<b>S_Type: </b>'.$object->fields['s_type']['arrayofkeyval'][$object->s_type].'<br>';
					$popup.='<b>Quantité Posee: </b>'.round($object->qtypose,2).'<br>';
				}
				if($object->$key==2){
					$popup='<b>Quantite vendue: </b>'.$object->qty.'<br>';
					$popup.='<b>Numéro de série: </b>'.$object->numserie.'<br>';
				}
				if($object->$key==4){
					$popup='<b>Quantite vendue: </b>'.$object->qty.'<br>';
					$popup.='<b>Soustype toiture: </b>'.$object->soustypetoiture.'<br>';
				}
				print '<a title="<div class=&quot;centpercent&quot;>'.$popup.'</div>" href="'.${'url_'.$object->type}.$object->id.'" class="classfortooltip refurl" >'.$object->showOutputField($val, $key, $object->$key, '').'</a> ';
			}
			elseif ($key=='status_edf2' ){
				if($object->$key !='')
					$dateplanif=dol_print_date($object->$key,'%d/%m/%Y');
				$out='<a  title="<div class=\'centpercent\'>
				<b><u>Dates Modification status</u></b><br>'.$dateschgt;
				
				
				$out.='<br></div>" class="classfortooltip refurl">'.$object->showOutputField($val, $key, $object->$key, '').'</a>';
				print $out;
			}
			elseif($key=='date_pose' ){
				if($tab_elts_fichepose['date_pose']>0)
					print dol_print_date($tab_elts_fichepose['date_pose'],'%d/%m/%Y');//date par la fiche de pose
				elseif($object->date_planif_4>0)
					print dol_print_date($object->date_planif_4,'%d/%m/%Y'); //date par l'opéraion
			}
			elseif ($key=='affaire' ){
				if($object->$key !=''){
					print '<a href="'.$url_finance.$obj->affaireid.'" >'.$object->$key.'</a>';
				}
			}
			elseif($key=='qtypose'){
				print $object->showOutputField($val, $key, round($object->$key,2), '');
			}
			elseif($key=='fk_soc'){
				$tab_phone=explode(';',$object->phone);
				$tel='';
				foreach($tab_phone as $phone){
					$tel .= preg_replace('/(\d{4})(\d{2})(\d{2})(\d{2})/','\1 \2 \3 \4',$phone).'<br>';
				}
				$out='<a href="/societe/card.php?socid='.$object->fk_soc.'" title="<div class=&quot;centpercent&quot;>
				<b>Ville: </b>'.$object->showOutputField($object->fields['ville'], 'ville', $object->ville, '', '', '', 0).'<br>
				<b>Adresse: </b>'.$obj->address.'<br>
				<b>Telephone: </b>'.$tel.'
					
					</div>" class="classfortooltip refurl"><img src="/theme/eldy/img/object_company.png" alt="" class="paddingright classfortooltip valignmiddle">'.$obj->nom.'</a>';
				print $out;
			}
			elseif($key=='phone'){
				$tab_phone=explode(';',$object->phone);
				$tel='';
				foreach($tab_phone as $phone){
					$tel .= preg_replace('/(\d{4})(\d{2})(\d{2})(\d{2})/','\1 \2 \3 \4',$phone).'<br>';
				}
				print $tel;
			}
			else 
				print $object->showOutputField($val, $key, $object->$key, '');
			print '</td>';
			if (!$i) $totalarray['nbfield']++;
			if (!empty($val['isameasure']))
			{
				if (!$i) $totalarray['pos'][$totalarray['nbfield']] = $key;
				$totalarray['val'][$key] += $object->$key;
			}
		}
	}
	
	// Extra fields
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_list_print_fields.tpl.php';
	// Fields from hook
	$parameters = array('arrayfields'=>$arrayfields, 'object'=>$object, 'obj'=>$obj, 'i'=>$i, 'totalarray'=>&$totalarray);
	$reshook = $hookmanager->executeHooks('printFieldListValue', $parameters, $object); // Note that $action and $object may have been modified by hook
	print $hookmanager->resPrint;
	// Action column
	print '<td class="nowrap center">';
	if ($massactionbutton || $massaction)   // If we are in select mode (massactionbutton defined) or if we have already selected and sent an action ($massaction) defined
	{
		$selected = 0;
		if (in_array($object->id, $arrayofselected)) $selected = 1;
		print '<input id="cb'.$object->id.'" class="flat checkforselect" type="checkbox" name="toselect[]" value="'.$object->id.'"'.($selected ? ' checked="checked"' : '').'>';
	}
	print '</td>';
	if (!$i) $totalarray['nbfield']++;

	print '</tr>'."\n";

	$i++;
}

// Show total line
//include DOL_DOCUMENT_ROOT.'/core/tpl/list_print_total.tpl.php';
include dol_buildpath("deviscaraiso/core/tpl/list_print_total.tpl.php");
// If no record found
if ($num == 0)
{
	$colspan = 1;
	foreach ($arrayfields as $key => $val) { if (!empty($val['checked'])) $colspan++; }
	print '<tr><td colspan="'.$colspan.'" class="opacitymedium">'.$langs->trans("NoRecordFound").'</td></tr>';
}


$db->free($resql);

$parameters = array('arrayfields'=>$arrayfields, 'sql'=>$sql);
$reshook = $hookmanager->executeHooks('printFieldListFooter', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;

print '</table>'."\n";
print '</div>'."\n";

print '</form>'."\n";

if (in_array('builddoc', $arrayofmassactions) && ($nbtotalofrecords === '' || $nbtotalofrecords))
{
	$hidegeneratedfilelistifempty = 1;
	if ($massaction == 'builddoc' || $action == 'remove_file' || $show_files) $hidegeneratedfilelistifempty = 0;

	require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
	$formfile = new FormFile($db);

	// Show list of available documents
	$urlsource = $_SERVER['PHP_SELF'].'?sortfield='.$sortfield.'&sortorder='.$sortorder;
	$urlsource .= str_replace('&amp;', '&', $param);

	$filedir = $diroutputmassaction;
	$genallowed = $permissiontoread;
	$delallowed = $permissiontoadd;

	print $formfile->showdocuments('massfilesarea_deviscaraiso', '', $filedir, $urlsource, 0, $delallowed, '', 1, 1, 0, 48, 1, $param, $title, '', '', '', null, $hidegeneratedfilelistifempty);
}

// End of page
llxFooter();
$db->close();
