<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        htdocs/modulebuilder/template/class/myobject.class.php
 * \ingroup     mymodule
 * \brief       This file is a CRUD class file for MyObject (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

/**
 * Class for MyObject
 */
class Deviscaraiso extends CommonObject
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'deviscaraiso';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'cara_deviscaraiso';

	/**
	 * @var int  Does myobject support multicompany module ? 0=No test on entity, 1=Test with field entity, 2=Test with link by societe
	 */
	public $ismultientitymanaged = 0;

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 1;

	/**
	 * @var string String with name of icon for myobject. Must be the part after the 'object_' into object_myobject.png
	 */
	public $picto = 'myobject@mymodule';


	const STATUS_DRAFT = 0;
	const STATUS_VALIDATED = 1;
	//const STATUS_SIGNED = 2; //validé en bc
	const STATUS_DEVIS = 2; //validé en en bourillon de devis
	const STATUS_BC = 4; //validé en Devis
	const STATUS_CANCELED = 9;

	const STATUSPLANIF_ATTENTE = 1;
	const STATUSPLANIF_PLANIFIE = 2;
	const STATUSPLANIF_REPLANIFIE = 3;
	const STATUSPLANIF_POSE= 4;
	const STATUSPLANIF_IMPOSSIBLE = 5;
	const STATUSPLANIF_INCOMPLET = 6;
	const STATUSPLANIF_PAYE = 7;
	const STATUSPLANIF_DEROULE = 8;
	const STATUSPLANIF_CANCELED = 9;
	const STATUSPLANIF_PREVISITE = 10;
	const STATUSPLANIF_DALLEFAITE = 11;
	const STATUSPLANIF_FACTURE = 12;
	const STATUSPLANIF_PORTAIL = 13;
	const STATUSPLANIF_PAIEMENT = 14;
	const STATUSPLANIF_ALIVRE = 15;
	const STATUSPLANIF_LIVRE = 16;
	const STATUSPLANIF_PRIME = 17;
	const STATUSPLANIF_AFDALLE = 18;
	const STATUSPLANIF_CMA = 19;
	const STATUSPLANIF_ATRAITER = 20;
	const STATUSPLANIF_PACK = 28;
	const STATUSPLANIF_INJOIGNABLE = 30;
	const STATUSPLANIF_PRECHANTIER = 31;


	const STATUSCEE_SANS = 1;
	const STATUSCEE_CEE= 2;
	const STATUSCEE_PREVU = 3;

	const GROUP_COMMERCIAUX = 1;
	
	const STATUSMPROP_ENCOURS=1;
	const STATUSMPROP_POSE=2;
	const STATUSMPROP_ANNULE=3;
	const STATUSMPROP_ATF=4;

	/**
	 *  'type' if the field format ('integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter]]', 'varchar(x)', 'double(24,8)', 'real', 'price', 'text', 'html', 'date', 'datetime', 'timestamp', 'duration', 'mail', 'phone', 'url', 'password')
	 *         Note: Filter can be a string like "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.nature:is:NULL)"
	 *  'label' the translation key.
	 *  'enabled' is a condition when the field must be managed.
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 if you want to have a total on list for this field. Field type must be summable like integer or double(24,8).
	 *  'css' is the CSS style to use on field. For example: 'maxwidth200'
	 *  'help' is a string visible as a tooltip on field
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
	 *  'arraykeyval' to set list of value if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel")
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
     * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
     */
	public $fields = array(
		'date_creation' => array('type'=>'date', 'label'=>'Date BC', 'enabled'=>1, 'visible'=>1, 'notnull'=> 0, 'default'=>'', 'position'=>10),
	    'rowid'         => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'visible'=>-2, 'noteditable'=>1, 'notnull'=> 1, 'index'=>1, 'position'=>2, 'comment'=>'Id'),
		'ref'           => array('type'=>'varchar(128)', 'label'=>'Ref', 'enabled'=>1, 'visible'=>0, 'noteditable'=>null, 'default'=>'(PROV)', 'notnull'=> 1, 'showoncombobox'=>1, 'index'=>1, 'position'=>10, 'searchall'=>1, 'comment'=>'Reference of object'),
	    'entity'        => array('type'=>'integer', 'label'=>'Entity', 'enabled'=>1, 'visible'=>0, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>20),
		'label'         => array('type'=>'smallint', 'label'=>'Type', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>'0', 'index'=>1, 'position'=>30, 'arrayofkeyval'=>array(1=>'ISO', 2=>'CES',3=>'REP',4=>'Toiture','5'=>'Menuiserie','6'=>'PV')),
		's_type'         => array('type'=>'smallint', 'label'=>'S_Type', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>'0', 'index'=>1, 'position'=>46, 'arrayofkeyval'=>array(1=>'LV', 2=>'LR',3=>'DR',4=>"ISO A",5=>"ISO M",6=>'ISO-R',7=>'ISO-T')),
	    'amount'        => array('type'=>'price', 'label'=>'R à Charge', 'enabled'=>1, 'visible'=>0, 'default'=>'null', 'position'=>1005, 'searchall'=>0, 'isameasure'=>0, 'help'=>'Montant total'),
	    'qty'           => array('type'=>'varchar(50)', 'label'=>'Quantité vendue', 'enabled'=>1, 'visible'=>1, 'default'=>'', 'position'=>45, 'searchall'=>0, 'isameasure'=>1, 'help'=>'Help text for quantity', 'css'=>'maxwidth75imp'),
		'qtypose'           => array('type'=>'varchar(50)', 'label'=>'Quantité Posée', 'enabled'=>1, 'visible'=>0, 'default'=>'0', 'position'=>45, 'searchall'=>0, 'isameasure'=>1, 'help'=>'Quantités posé', 'css'=>'maxwidth75imp'),
		'nb_sacs'           => array('type'=>'varchar(50)', 'label'=>'Sacs', 'enabled'=>1, 'visible'=>0, 'default'=>'0', 'position'=>47, 'searchall'=>0, 'isameasure'=>0, 'help'=>'Help text for quantity', 'css'=>'maxwidth75imp'),
		'fk_soc' 		=> array('type'=>'integer:Societe:societe/class/societe.class.php:1:status=1 AND entity IN (__SHARED_ENTITIES__)', 'label'=>'ThirdParty', 'visible'=> 1, 'enabled'=>1, 'position'=>1, 'notnull'=>-1, 'index'=>1, 'help'=>'LinkToThirparty'),
		//'fk_project'    => array('type'=>'integer:Project:projet/class/project.class.php:1', 'label'=>'Project', 'enabled'=>1, 'visible'=>-1, 'position'=>52, 'notnull'=>-1, 'index'=>1),
		'description'   => array('type'=>'text', 'label'=>'Commentaire', 'enabled'=>1, 'visible'=>1, 'position'=>1006),
		//'note_public'   => array('type'=>'html', 'label'=>'NotePublic', 'enabled'=>1, 'visible'=>0, 'position'=>61),
		//'note_private'  => array('type'=>'html', 'label'=>'NotePrivate', 'enabled'=>1, 'visible'=>0, 'position'=>62),
		
		'tms'           => array('type'=>'timestamp', 'label'=>'DateModification', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0, 'position'=>501),
		'date_validation'    =>array('type'=>'datetime',     'label'=>'DateValidation',     'enabled'=>1, 'visible'=>-2, 'position'=>502),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 1, 'position'=>510, 'foreignkey'=>'user.rowid'),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'visible'=>-2, 'notnull'=>-1, 'position'=>511),
		//'fk_user_valid' => array('type'=>'integer:User:user/class/user.class.php',      'label'=>'UserValidation',        'enabled'=>1, 'visible'=>-1, 'position'=>512),
		//'import_key'    => array('type'=>'varchar(14)', 'label'=>'ImportId', 'enabled'=>1, 'visible'=>-2, 'notnull'=>-1, 'index'=>0, 'position'=>1000),
		'model_pdf' 	=> array('type'=>'varchar(255)', 'label'=>'Model pdf', 'enabled'=>1, 'visible'=>0, 'notnull'=>-1, 'position'=>1010),
		//'status'        => array('type'=>'smallint', 'label'=>'Statut devis', 'enabled'=>1, 'visible'=>2, 'notnull'=> 1, 'default'=>0, 'index'=>1, 'position'=>90, 'arrayofkeyval'=>array(0=>'Draft', 1=>'Validated',2=>'Devis',4=>'BC', 9=>'Canceled')),
		'status'        => array('type'=>'smallint', 'label'=>'Statut devis', 'enabled'=>1, 'visible'=>2, 'notnull'=> 1, 'default'=>2, 'index'=>1, 'position'=>1010, 'arrayofkeyval'=>array(2=>'Brouillon',4=>'Devis')),
		'comission_commercial'   => array('type'=>'varchar(50)', 'label'=>'Comission Commercial', 'enabled'=>1, 'visible'=>1, 'default'=>'0', 'position'=>99, 'searchall'=>0, 'isameasure'=>0, 'help'=>'Comission commercial', 'css'=>'maxwidth75imp'),
		'planification'        => array('type'=>'smallint', 'label'=>'Etat', 'enabled'=>1, 'visible'=>1, 'notnull'=> 0, 'default'=>1, 'index'=>1, 'position'=>100, 
																		'arrayofkeyval'=>array(-1=>'',1=>'A TRAITER', 2=>'PLANIFIE',3=>'RE PLANIFIE',4=>'POSE',9=>'ANNULE',5=>'IMPOSSIBLE',6=>'INCOMPLET',30=>'INJOIGNABLE',19=>'EN ATTENTE',17=>'PRIME',28=>'ATF',31=>'PRECHANTIER'),
																		'showonly'=>array(-1=>'',1=>'A TRAITER', 2=>'PLANIFIE',3=>'RE PLANIFIE',5=>'IMPOSSIBLE',6=>'INCOMPLET',30=>'INJOIGNABLE',19=>'EN ATTENTE')
																		),
		'date_planif' => array('type'=>'datetime', 'label'=>'Date planifié', 'enabled'=>1, 'visible'=>1, 'notnull'=> 0,  'position'=>1000),
		'date_pose' => array('type'=>'datetime', 'label'=>'Date Pose', 'enabled'=>0, 'visible'=>0, 'notnull'=> 0,  'position'=>1003),
		'fk_usercomm' 		=> array('type'=>'integer:User:user/class/user.class.php::statut:=:1', 'label'=>'Commercial ', 'enabled'=>1, 'visible'=>1,  'notnull'=> 0, 'position'=>1004, 'foreignkey'=>'user.rowid'),
		'fk_user_pos' 		=> array('type'=>'integer:User:user/class/user.class.php', 'label'=>'Poseur', 'enabled'=>1, 'visible'=>1,  'notnull'=> 0, 'position'=>1003, 'foreignkey'=>'user.rowid'),
		
		'alerte_date_planif'         => array('type'=>'boolean', 'label'=>'Alerte', 'enabled'=>1, 'visible'=>0, 'noteditable'=>1, 'notnull'=> -1, 'index'=>1, 'position'=>1005, 'comment'=>'Alerte planification'),
		'alerte_dossier_incomplet'   => array('type'=>'boolean', 'label'=>'Alerte', 'enabled'=>1, 'visible'=>0, 'noteditable'=>1, 'notnull'=> -1, 'index'=>1, 'position'=>1006, 'comment'=>'Alerte planification'),
		'mod_paiement'        => array('type'=>'smallint', 'label'=>'Modalites de paiement', 'enabled'=>1, 'visible'=>0, 'notnull'=> 1, 'default'=>0, 'index'=>1, 'position'=>1007, 'arrayofkeyval'=>array(1=>'Cheque', 2=>'Especes',3=>'Prelevents')),
		'mod_paiement_quand'        => array('type'=>'smallint', 'label'=>'Planification', 'enabled'=>1, 'visible'=>0, 'notnull'=> 1, 'default'=>0, 'index'=>1, 'position'=>1008, 'arrayofkeyval'=>array(1=>'A la signature', 2=>'A la pose')),
		'mod_paiement_qty'        => array('type'=>'int', 'label'=>'Quantité', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0, 'default'=>0, 'index'=>1, 'position'=>1009),
		'acompte'        => array('type'=>'int', 'label'=>'Acompte', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0, 'default'=>0, 'index'=>1, 'position'=>1009),
		'edf' 	=> array('type'=>'varchar(255)', 'label'=>'Numero EDF', 'enabled'=>1, 'visible'=>1, 'notnull'=>-1, 'position'=>110),
		'af' 	=> array('type'=>'varchar(50)', 'label'=>'AF', 'enabled'=>1, 'visible'=>1, 'notnull'=>-1, 'position'=>115),
		'fposeur' 	=> array('type'=>'varchar(50)', 'label'=>'Facture Poseur', 'enabled'=>1, 'visible'=>1, 'notnull'=>-1, 'position'=>117),
		'status_edf'    => array('type'=>'smallint', 'label'=>'Etat', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>100, 'arrayofkeyval'=>array(/*'1'=>'En Attente',*/0=>'',2=>'POSE', 3=>'A TRAITER',4=>'FACTURE',5=>'PORTAIL',6=>'EDF',7=>'PAYE',8=>'INCOMPLET',17=>'PRIME',29=>'SANS PRIME',9=>'ANNULE',10=>'IMPOSSIBLE')),
		'commentaire_edf'   => array('type'=>'text', 'label'=>'Commentaire(edf)', 'enabled'=>1, 'visible'=>3, 'position'=>1006),
		'edf_nbparts'	=> array('type'=>'varchar(50)', 'label'=>'Nombre de parts', 'enabled'=>0, 'visible'=>1, 'default'=>'0', 'position'=>45, 'searchall'=>0, 'isameasure'=>0, 'help'=>'Nombre de parts', 'css'=>'maxwidth75imp'),
		'edf_edl'       => array('type'=>'varchar(50)', 'label'=>'EDL', 'enabled'=>0, 'visible'=>1, 'default'=>'0', 'position'=>45, 'searchall'=>0, 'isameasure'=>1, 'help'=>'Nombre de parts', 'css'=>'maxwidth75imp'),
		'edf_contrat'   => array('type'=>'varchar(50)', 'label'=>'Contrat Edf', 'enabled'=>0, 'visible'=>1, 'default'=>'0', 'position'=>45, 'searchall'=>0, 'isameasure'=>0, 'help'=>'Nombre de parts', 'css'=>'maxwidth75imp'),
		'date_attente' => array('type'=>'date', 'label'=>'Date attente', 'enabled'=>1, 'visible'=>1, 'notnull'=> 0,  'position'=>1000),
		'alerte_date_attente'         => array('type'=>'boolean', 'label'=>'Alerte', 'enabled'=>1, 'visible'=>-2, 'noteditable'=>1, 'notnull'=> 0, 'index'=>1, 'position'=>1005, 'comment'=>'Alerte date attente'),
		'status_mpr'    => array('type'=>'smallint', 'label'=>'Etat', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>100, 'arrayofkeyval'=>array( 1=>'A TRAITER',5=>'DESIGNATION MANDAT',2=>'DEMANDE DEPOSEE',3=>"ACCORDE",4=>"REFUSE",6=>"OBSOLETE",7=>"FACTURE",8=>"PAYE",9=>"NON ELIGIBLE",'11'=>'ANNULE',12=>'EN PAIEMENT',14=>'DOC MANQUANT',15=>'DOC RECU',16=>'ATTENTE DE SOLDE',17=>'CMPT BLOQUE',18=>'ANOMALIE',19=>'CSP')),
		'commentaire_mpr'   => array('type'=>'text', 'label'=>'Commentaire (mpr)', 'enabled'=>1, 'visible'=>1, 'position'=>120),
		'commentaire_doc'   => array('type'=>'text', 'label'=>'Documents manquants', 'enabled'=>1, 'visible'=>1, 'position'=>121),
		'montant_estime_mpr'   => array('type'=>'price', 'label'=>'Montant Estimé (mpr)', 'enabled'=>1, 'visible'=>1, 'position'=>120),
		'numero_mpr' => array('type'=>'varchar(20)', 'label'=>'Numéro MPR', 'enabled'=>1, 'visible'=>1, 'notnull'=>0, 'position'=>117),
		'numfacture_mpr' =>  array('type'=>'varchar(20)', 'label'=>'Numero facture MPR', 'enabled'=>1, 'visible'=>1, 'notnull'=>0, 'position'=>117),
		'date_accepte_mpr'=>array('type'=>'date', 'label'=>'Date Accepte_mpr', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		//'status_edf2'    => array('type'=>'smallint', 'label'=>'PRé Etat', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>90, 'arrayofkeyval'=>array('-2'=>'VIDE',1=>"A SAISIR",4=>'PRE CHANTIER',2=>"DEVIS",6=>"DEJA PRIME")),
		'status_edf2'    => array('type'=>'smallint', 'label'=>'PRé Etat', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>90, 'arrayofkeyval'=>array('-2'=>'VIDE',' '=>'',1=>"A SAISIR",4=>'PRE CHANTIER',2=>"DEVIS",5=>'AH',3=>"OK",6=>"ANNULE")),//anciens
		'numfac_edf'   => array('type'=>'varchar(50)', 'label'=>'Fac Portail EDF', 'enabled'=>1, 'visible'=>1, 'default'=>'0', 'position'=>114, 'searchall'=>0, 'isameasure'=>0, 'help'=>'Numéro de facture sur le portail edf', 'css'=>'maxwidth75imp'),
		'appel_mpr'    => array('type'=>'smallint', 'label'=>'Appel Tel', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>110, 'arrayofkeyval'=>array( 1=>'NON',2=>'OUI',3=>'NRP',4=>"RAP",)),
		'status_cee'    => array('type'=>'smallint', 'label'=>'CEE', 'enabled'=>1, 'visible'=>0, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>100, 'arrayofkeyval'=>array( 1=>'SANS',2=>'CEE',3=>'PREVU')),
		'date_planif_1' => array('type'=>'date', 'label'=>'Date traitement', 'enabled'=>1, 'visible'=>1, 'notnull'=> 0,  'position'=>1000),
		'date_planif_2' => array('type'=>'datetime', 'label'=>'Date planifie (chg statut)', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_3' => array('type'=>'date', 'label'=>'Date a traiter', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_4' => array('type'=>'date', 'label'=>'Date Pose', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_5' => array('type'=>'date', 'label'=>'Date impossible', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_6' => array('type'=>'date', 'label'=>'Date incomplet', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_30' => array('type'=>'date', 'label'=>'Date INJOIGNABLE', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_9' => array('type'=>'date', 'label'=>'Date annule', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_19' => array('type'=>'date', 'label'=>'Date en attente', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_17' => array('type'=>'date', 'label'=>'Date prime', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_planif_28' => array('type'=>'date', 'label'=>'Date ATF', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),'date_cee_1' => array('type'=>'date', 'label'=>'Date cee SANS', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_cee_2' => array('type'=>'date', 'label'=>'Date cee CEE', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_cee_3' => array('type'=>'date', 'label'=>'Date cee PREVU', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_edf2_1' => array('type'=>'date', 'label'=>'Date pre-etat A SAISIR', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_edf2_2' => array('type'=>'date', 'label'=>'Date pre-etat DEVIS', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_edf2_4' => array('type'=>'date', 'label'=>'Date pre-etat PRE CHANTIER', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_edf2_6' => array('type'=>'date', 'label'=>'Date pre-etat DEJA PRIME', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'status_mprop'    => array('type'=>'smallint', 'label'=>'Statut OP', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>54, 'arrayofkeyval'=>array( ' '=>' ',1=>'EN COURS',2=>'POSE',3=>'ANNULE',4=>'ATF')),
		'status_edfop'    => array('type'=>'smallint', 'label'=>'Statut OP', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 1, 'default'=>1, 'index'=>1, 'position'=>54, 'arrayofkeyval'=>array( ' '=>' ',1=>'EN COURS',2=>'POSE',3=>'ANNULE',4=>'ATF')),
		'difficulte' => array('type'=>'smallint', 'label'=>'Difficulte', 'enabled'=>1, 'position'=>98, 'notnull'=>1, 'visible'=>3,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'FACILE', '2'=>'DIFFICILE','3'=>'IMPOSSIBLE')),
		'duree' => array('type'=>'smallint', 'label'=>'Durée', 'enabled'=>1, 'position'=>98, 'notnull'=>1, 'visible'=>3,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'1', '2'=>'2','3'=>'3','4'=>'4','5'=>'5')),
		'fk_devis'         => array('type'=>'integer', 'label'=>'ref devis commercial', 'enabled'=>1, 'visible'=>-2, 'noteditable'=>1, 'notnull'=> 1, 'index'=>1, 'position'=>2, 'comment'=>'Id'),
		'date_mpr_1' => array('type'=>'date', 'label'=>'Date a traiter', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_2' => array('type'=>'datetime', 'label'=>'Date demande déposee', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_3' => array('type'=>'date', 'label'=>'Date accordé', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_4' => array('type'=>'date', 'label'=>'Date refusé', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_5' => array('type'=>'date', 'label'=>'Date désignation mandat', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_6' => array('type'=>'date', 'label'=>'Date incomplet', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_7' => array('type'=>'date', 'label'=>'Date facture', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_8' => array('type'=>'date', 'label'=>'Date paye', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_9' => array('type'=>'date', 'label'=>'Date non eligible', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_11' => array('type'=>'date', 'label'=>'Date annule', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_12' => array('type'=>'date', 'label'=>'Date en paiement', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_14' => array('type'=>'date', 'label'=>'Date doc manquant', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_15' => array('type'=>'date', 'label'=>'Date doc reçu', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_16' => array('type'=>'date', 'label'=>'Date Attente solde', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
		'date_mpr_etat' => array('type'=>'date', 'label'=>'Date Attente solde', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 0,  'position'=>1000),
	);

	/**
	 * @var int ID
	 */
	public $rowid;

	/**
	 * @var string Ref
	 */
	public $ref;

	/**
	 * @var int Entity
	 */
	public $entity;

	/**
     * @var string label
     */
    public $label;

    /**
     * @var string amount
     */
	public $amount;

	/**
	 * @var int Status
	 */
	public $status;

	/**
     * @var integer|string date_creation
     */
	public $date_creation;

	/**
     * @var integer tms
     */
	public $tms;

	/**
     * @var int ID
     */
	public $fk_user_creat;

	/**
     * @var int ID
     */
	public $fk_user_modif;

	/**
     * @var string import_key
     */
	public $import_key;
	// END MODULEBUILDER PROPERTIES
    /**
     * @var int fk_soc
     */
    public $fk_soc;

    /**
     * @var int $s_type
     */
    public $s_type;
	// If this object has a subtable with lines

	/**
	 * @var int    Name of subtable line
	 */
	public $table_element_line = 'cara_deviscaraisodet';

	/**
	 * @var int    Field with ID of parent key if this field has a parent
	 */
	public $fk_element = 'fk_deviscaraiso';

	/**
	 * @var int    Name of subtable class that manage subtable lines
	 */
	public $class_element_line = 'DeviscaraisoLine';

	/**
	 * @var array	List of child tables. To test if we can delete object.
	 */
	//protected $childtables=array();

	/**
	 * @var array	List of child tables. To know object to delete on cascade.
	 */
	//protected $childtablesoncascade=array('mymodule_myobjectdet');

	/**
	 * @var DeviscaraisoLine[]     Array of subtable lines
	 */
	//public $lines = array();



	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $conf, $langs;

		$this->db = $db;

		if (empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && isset($this->fields['rowid'])) $this->fields['rowid']['visible'] = 0;
		if (empty($conf->multicompany->enabled) && isset($this->fields['entity'])) $this->fields['entity']['enabled'] = 0;

		// Example to show how to set values of fields definition dynamically
		/*if ($user->rights->mymodule->myobject->read) {
			$this->fields['myfield']['visible'] = 1;
			$this->fields['myfield']['noteditable'] = 0;
		}*/

		// Unset fields that are disabled
		foreach ($this->fields as $key => $val)
		{
			if (isset($val['enabled']) && empty($val['enabled']))
			{
				unset($this->fields[$key]);
			}
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs))
		{
			foreach($this->fields as $key => $val)
			{
				if (is_array($val['arrayofkeyval']))
				{
					foreach($val['arrayofkeyval'] as $key2 => $val2)
					{
						$this->fields[$key]['arrayofkeyval'][$key2]=$langs->trans($val2);
					}
				}
			}
		}
	}

	/**
	 * Create object into database
	 *
	 * @param  User $user      User that creates
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, Id of created object if OK
	 */
	public function create(User $user, $notrigger = false)
	{
		
		// //estce que le devis existe à la même date pour le meme client et pour le meme type
		// $now= new DateTime('now');
		// $sql=' SELECT rowid from '.MAIN_DB_PREFIX.'cara_deviscaraiso a ';
		
		// $sql .= ' where  fk_soc='.$this->fk_soc; 
		// $sql .= ' and a.date_creation like "'.$now->format('Y-m-d').'%"';
		
		// $resql = $this->db->query($sql);
		// if ($resql) {
		// 	$num = $this->db->num_rows($resql);
		// 	if ($num > 0){
		// 		setEventMessages("Devis déjà existant pour ce client pour aujourd'hui", "", 'errors');
		// 		return (-1);
		// 	}
		// }
		
		
		// select lignes de la table libelle
		$sql=' SELECT rowid,libelle,pu from '.MAIN_DB_PREFIX.'cara_devicarasiso_libelle order by rowid';
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
				$this->lines[$i] = new DeviscaraisoLine($this->db);
				if($this->surfaceiso && $obj->rowid==1) //-info venant de deviscara lors de la création auto du devis
					$this->lines[$i]->qty=$this->surfaceiso;
				$this->lines[$i]->label=$obj->libelle;
				$this->lines[$i]->options=$obj->rowid;
				$this->lines[$i]->amount=$obj->pu;
				$i++;
			}
		}
		if(!isset($this->planification))
			$this->planification=1; //planification par défaut.
		$this->ref=$this->getNextNumRef();
		return $this->createCommon($user, $notrigger);
		
	}

	/**
	 * Clone an object into another one
	 *
	 * @param  	User 	$user      	User that creates
	 * @param  	int 	$fromid     Id of object to clone
	 * @return 	mixed 				New object created, <0 if KO
	 */
	public function createFromClone(User $user, $fromid)
	{
		global $langs, $extrafields;
	    $error = 0;

	    dol_syslog(__METHOD__, LOG_DEBUG);

	    $object = new self($this->db);

	    $this->db->begin();

	    // Load source object
	    $result = $object->fetchCommon($fromid);
	    if ($result > 0 && !empty($object->table_element_line)) $object->fetchLines();

	    // get lines so they will be clone
	    //foreach($this->lines as $line)
	    //	$line->fetch_optionals();

	    // Reset some properties
	    unset($object->id);
	    unset($object->fk_user_creat);
	    unset($object->import_key);


	    // Clear fields
	    $object->ref = empty($this->fields['ref']['default']) ? "copy_of_".$object->ref : $this->fields['ref']['default'];
	    $object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf")." ".$object->label : $this->fields['label']['default'];
	    $object->status = self::STATUS_DRAFT;
	    // ...
	    // Clear extrafields that are unique
	    if (is_array($object->array_options) && count($object->array_options) > 0)
	    {
	    	$extrafields->fetch_name_optionals_label($this->table_element);
	    	foreach ($object->array_options as $key => $option)
	    	{
	    		$shortkey = preg_replace('/options_/', '', $key);
	    		if (!empty($extrafields->attributes[$this->element]['unique'][$shortkey]))
	    		{
	    			//var_dump($key); var_dump($clonedObj->array_options[$key]); exit;
	    			unset($object->array_options[$key]);
	    		}
	    	}
	    }

	    // Create clone
		$object->context['createfromclone'] = 'createfromclone';
	    $result = $object->createCommon($user);
	    if ($result < 0) {
	        $error++;
	        $this->error = $object->error;
	        $this->errors = $object->errors;
	    }

	    if (!$error)
	    {
	    	// copy internal contacts
	    	if ($this->copy_linked_contact($object, 'internal') < 0)
	    	{
	    		$error++;
	    	}
	    }

	    if (!$error)
	    {
	    	// copy external contacts if same company
	    	if (property_exists($this, 'socid') && $this->socid == $object->socid)
	    	{
	    		if ($this->copy_linked_contact($object, 'external') < 0)
	    			$error++;
	    	}
	    }

	    unset($object->context['createfromclone']);

	    // End
	    if (!$error) {
	        $this->db->commit();
	        return $object;
	    } else {
	        $this->db->rollback();
	        return -1;
	    }
	}

	/**
	 * Load object in memory from the database
	 *
	 * @param int    $id   Id object
	 * @param string $ref  Ref
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null)
	{
		$result = $this->fetchCommon($id, $ref);
		if ($result > 0 && !empty($this->table_element_line)) $this->fetchLines();
		return $result;
	}

	/**
	 * Load object lines in memory from the database
	 *
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchLines()
	{
		$this->lines = array();

		$result = $this->fetchLinesCommon();
		return $result;
	}


	/**
	 * Load list of objects in memory from the database.
	 *
	 * @param  string      $sortorder    Sort Order
	 * @param  string      $sortfield    Sort field
	 * @param  int         $limit        limit
	 * @param  int         $offset       Offset
	 * @param  array       $filter       Filter array. Example array('field'=>'valueforlike', 'customurl'=>...)
	 * @param  string      $filtermode   Filter mode (AND or OR)
	 * @return array|int                 int <0 if KO, array of pages if OK
	 */
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		global $conf;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$records = array();

		$sql = 'SELECT ';
		$sql .= $this->getFieldList();
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		if (isset($this->ismultientitymanaged) && $this->ismultientitymanaged == 1) $sql .= ' WHERE t.entity IN ('.getEntity($this->table_element).')';
		else $sql .= ' WHERE 1 = 1';
		// Manage filter
		$sqlwhere = array();
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				if ($key == 't.rowid') {
					$sqlwhere[] = $key.'='.$value;
				}
				elseif (strpos($key, 'date') !== false) {
					$sqlwhere[] = $key.' = \''.$this->db->idate($value).'\'';
				}
				elseif ($key == 'customsql') {
					$sqlwhere[] = $value;
				}
				else {
					$sqlwhere[] = $key.' LIKE \'%'.$this->db->escape($value).'%\'';
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= ' AND ('.implode(' '.$filtermode.' ', $sqlwhere).')';
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= ' '.$this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i < min($limit, $num))
			{
			    $obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 * Update object into database
	 *
	 * @param  User $user      User that modifies
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = false)
	{
		//maj planification avant update
		if($this->date_pose != '') $this->planification=3;
		
		//maj alerte avant update si besoin. Attentiion règle dans le script maj_depassement.php
		$now=new DateTime('now');
		$date_planif=new DateTime(dol_print_date($this->date_planif,"%Y%m%d %H:%m"));
		$diff=$now->diff($date_planif);
		if ($diff->invert==1 && $diff->d > 3 && $this->planification == $this::STATUSPLANIF_PLANIFIE)
			$this->alerte_date_planif=1;
		else
			$this->alerte_date_planif=0;

		return $this->updateCommon($user, $notrigger);
	}

	/**
	 * Delete object in database
	 *
	 * @param User $user       User that deletes
	 * @param bool $notrigger  false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function delete(User $user, $notrigger = false)
	{
		//delete lines from table_element_line
		$sql = 'DELETE FROM '.MAIN_DB_PREFIX.$this->table_element_line.' WHERE '.$this->fk_element .'='.$this->id;
		$resql = $this->db->query($sql);

		return $this->deleteCommon($user, $notrigger);
		//return $this->deleteCommon($user, $notrigger, 1);
	}

	/**
	 *  Delete a line of object in database
	 *
	 *	@param  User	$user       User that delete
	 *  @param	int		$idline		Id of line to delete
	 *  @param 	bool 	$notrigger  false=launch triggers after, true=disable triggers
	 *  @return int         		>0 if OK, <0 if KO
	 */
	public function deleteLine(User $user, $idline, $notrigger = false)
	{
		if ($this->status < 0)
		{
			$this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
			return -2;
		}

		return $this->deleteLineCommon($user, $idline, $notrigger);
	}


	/**
	 *	Validate object
	 *
	 *	@param		User	$user     		User making status change
	 *  @param		int		$notrigger		1=Does not execute triggers, 0= execute triggers
	 *	@return  	int						<=0 if OK, 0=Nothing done, >0 if KO
	 */
	public function validate($user, $notrigger = 0)
	{
		global $conf, $langs;

		require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

		$error = 0;

		// Protection
		if ($this->status == self::STATUS_VALIDATED)
		{
			dol_syslog(get_class($this)."::validate action abandonned: already validated", LOG_WARNING);
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->myobject->create))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->myobject->myobject_advance->validate))))
		 {
		 $this->error='NotEnoughPermissions';
		 dol_syslog(get_class($this)."::valid ".$this->error, LOG_ERR);
		 return -1;
		 }*/

		$now = dol_now();

		$this->db->begin();

		// Define new ref
		if (!$error && (preg_match('/^[\(]?PROV/i', $this->ref) || empty($this->ref))) // empty should not happened, but when it occurs, the test save life
		{
			$num = $this->getNextNumRef();
		}
		else
		{
			$num = $this->ref;
		}
		$this->newref = $num;

		// Validate
		$sql = "UPDATE ".MAIN_DB_PREFIX.$this->table_element;
		$sql .= " SET ref = '".$this->db->escape($num)."',";
		$sql .= " status = ".self::STATUS_VALIDATED.",";
		$sql .= " date_validation = '".$this->db->idate($now)."',";
		$sql .= " fk_user_valid = ".$user->id;
		$sql .= " WHERE rowid = ".$this->id;

		dol_syslog(get_class($this)."::validate()", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql)
		{
			dol_print_error($this->db);
			$this->error = $this->db->lasterror();
			$error++;
		}

		if (!$error && !$notrigger)
		{
			// Call trigger
			$result = $this->call_trigger('MYOBJECT_VALIDATE', $user);
			if ($result < 0) $error++;
			// End call triggers
		}

		if (!$error)
		{
			$this->oldref = $this->ref;

			// Rename directory if dir was a temporary ref
			if (preg_match('/^[\(]?PROV/i', $this->ref))
			{
				// Now we rename also files into index
				$sql = 'UPDATE '.MAIN_DB_PREFIX."ecm_files set filename = CONCAT('".$this->db->escape($this->newref)."', SUBSTR(filename, ".(strlen($this->ref) + 1).")), filepath = 'myobject/".$this->db->escape($this->newref)."'";
				$sql .= " WHERE filename LIKE '".$this->db->escape($this->ref)."%' AND filepath = 'myobject/".$this->db->escape($this->ref)."' and entity = ".$conf->entity;
				$resql = $this->db->query($sql);
				if (!$resql) { $error++; $this->error = $this->db->lasterror(); }

				// We rename directory ($this->ref = old ref, $num = new ref) in order not to lose the attachments
				$oldref = dol_sanitizeFileName($this->ref);
				$newref = dol_sanitizeFileName($num);
				$dirsource = $conf->mymodule->dir_output.'/myobject/'.$oldref;
				$dirdest = $conf->mymodule->dir_output.'/myobject/'.$newref;
				if (!$error && file_exists($dirsource))
				{
					dol_syslog(get_class($this)."::validate() rename dir ".$dirsource." into ".$dirdest);

					if (@rename($dirsource, $dirdest))
					{
						dol_syslog("Rename ok");
						// Rename docs starting with $oldref with $newref
						$listoffiles = dol_dir_list($conf->mymodule->dir_output.'/myobject/'.$newref, 'files', 1, '^'.preg_quote($oldref, '/'));
						foreach ($listoffiles as $fileentry)
						{
							$dirsource = $fileentry['name'];
							$dirdest = preg_replace('/^'.preg_quote($oldref, '/').'/', $newref, $dirsource);
							$dirsource = $fileentry['path'].'/'.$dirsource;
							$dirdest = $fileentry['path'].'/'.$dirdest;
							@rename($dirsource, $dirdest);
						}
					}
				}
			}
		}

		// Set new ref and current status
		if (!$error)
		{
			$this->ref = $num;
			$this->status = self::STATUS_VALIDATED;
		}

		if (!$error)
		{
			$this->db->commit();
			return 1;
		}
		else
		{
			$this->db->rollback();
			return -1;
		}
	}


	/**
	 *	Set draft status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, >0 if OK
	 */
	public function setDraft($user, $notrigger = 0)
	{
		// Protection
		if ($this->status <= self::STATUS_DRAFT)
		{
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->mymodule->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->mymodule->mymodule_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_DRAFT, $notrigger, 'MYOBJECT_UNVALIDATE');
	}

	/**
	 *	Set devis status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, >0 if OK
	 */
	public function setBc($user, $notrigger = 0)
	{
		return $this->setStatusCommon($user, self::STATUS_BC, $notrigger, 'MYOBJECT_UNVALIDATE');
	}
	/**
	 *	Set devis status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, >0 if OK
	 */
	public function setDevis($user, $notrigger = 0)
	{
		return $this->setStatusCommon($user, self::STATUS_DEVIS, $notrigger, 'MYOBJECT_UNVALIDATE');
	}

	/**
	 *	Set cancel status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, 0=Nothing done, >0 if OK
	 */
	public function cancel($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_VALIDATED)
		{
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->mymodule->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->mymodule->mymodule_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_CANCELED, $notrigger, 'MYOBJECT_CLOSE');
	}

	/**
	 *	Set back to validated status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, 0=Nothing done, >0 if OK
	 */
	public function reopen($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_CANCELED)
		{
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->mymodule->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->mymodule->mymodule_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_VALIDATED, $notrigger, 'MYOBJECT_REOPEN');
	}

    /**
     *  Return a link to the object card (with optionaly the picto)
     *
     *  @param  int     $withpicto                  Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
     *  @param  string  $option                     On what the link point to ('nolink', ...)
     *  @param  int     $notooltip                  1=Disable tooltip
     *  @param  string  $morecss                    Add more css on link
     *  @param  int     $save_lastsearch_value      -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
     *  @return	string                              String with URL
     */
    public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
    {
        global $conf, $langs, $hookmanager;

        if (!empty($conf->dol_no_mouse_hover)) $notooltip = 1; // Force disable tooltips

		$result = '';
		if ($this->type=='ces'){
			$url = dol_buildpath('/deviscaraces/card.php', 1).'?id='.$this->id;
			$label = '<u>'.$langs->trans("Devis CES").'</u>';
		}
		else{
			$url=dol_buildpath('/deviscaraiso/card.php', 1).'?id='.$this->id;
			$label = '<u>'.$langs->trans("Devis ISO").'</u>';
		}
        
        $label .= '<br>';
        $label .= '<b>'.$langs->trans('Ref').':</b> '.$this->ref;
        if (isset($this->status)) {
        	$label.= '<br><b>' . $langs->trans("Status").":</b> ".$this->getLibStatut(5);
        }

		
		

        if ($option != 'nolink')
        {
            // Add param to save lastsearch_values or not
            $add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
            if ($save_lastsearch_value == -1 && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) $add_save_lastsearch_values = 1;
            if ($add_save_lastsearch_values) $url .= '&save_lastsearch_values=1';
        }

        $linkclose = '';
        if (empty($notooltip))
        {
            if (!empty($conf->global->MAIN_OPTIMIZEFORTEXTBROWSER))
            {
                $label = $langs->trans("ShowMyObject");
                $linkclose .= ' alt="'.dol_escape_htmltag($label, 1).'"';
            }
            $linkclose .= ' title="'.dol_escape_htmltag($label, 1).'"';
            $linkclose .= ' class="classfortooltip'.($morecss ? ' '.$morecss : '').'"';
        }
        else $linkclose = ($morecss ? ' class="'.$morecss.'"' : '');

		$linkstart = '<a href="'.$url.'"';
		$linkstart .= $linkclose.'>';
		$linkend = '</a>';

		$result .= $linkstart;
		if ($withpicto) $result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="'.(($withpicto != 2) ? 'paddingright ' : '').'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
		if ($withpicto != 2) $result .= $this->ref;
		$result .= $linkend;
		//if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

		global $action, $hookmanager;
		$hookmanager->initHooks(array('myobjectdao'));
		$parameters = array('id'=>$this->id, 'getnomurl'=>$result);
		$reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) $result = $hookmanager->resPrint;
		else $result .= $hookmanager->resPrint;

		return $result;
    }

	/**
	 *  Return label of the status
	 *
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLibStatut($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

    // phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	/**
	 *  Return the status
	 *
	 *  @param	int		$status        Id status
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return string 			       Label of status
	 */
	public function LibStatut($status, $mode = 0)
	{
		// phpcs:enable
		if (empty($this->labelStatus) || empty($this->labelStatusShort))
		{
			global $langs;
			//$langs->load("mymodule");
			$this->labelStatus[self::STATUS_DRAFT] = $langs->trans('Draft');
			$this->labelStatus[self::STATUS_VALIDATED] = $langs->trans('Brouillon');
			//$this->labelStatus[self::STATUS_SIGNED] = $langs->trans('Signed');
			$this->labelStatus[self::STATUS_DEVIS] = $langs->trans('Brouillon');
			$this->labelStatus[self::STATUS_BC] = $langs->trans('Devis');
			$this->labelStatus[self::STATUS_CANCELED] = $langs->trans('Disabled');
			
		}

		$statusType = 'status'.$status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		if ($status == self::STATUS_CANCELED) $statusType = 'status6';

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
	}

	/**
	 *  Return the status
	 *
	 *  @param	int		$status        Id status
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return string 			       Label of status
	 */
	public function LibStatutPlanif( $mode = 5,$url)
	{
		// phpcs:enable
		$status=$this->planification;
		if (empty($this->labelStatusPlanif) || empty($this->labelStatusShortPlanif))
		{
			global $langs;
			//$langs->load("mymodule");
		
			$this->labelStatusPlanif[self::STATUSPLANIF_ATTENTE] = $langs->trans('A TRAITER');
			$this->labelStatusPlanif[self::STATUSPLANIF_PLANIFIE] = $langs->trans('PLANIFIE');
			$this->labelStatusPlanif[self::STATUSPLANIF_REPLANIFIE] = $langs->trans('RE PLANIFIE');
			$this->labelStatusPlanif[self::STATUSPLANIF_POSE] = $langs->trans('POSE');
			$this->labelStatusPlanif[self::STATUSPLANIF_IMPOSSIBLE] = $langs->trans('IMPOSSIBLE');
			$this->labelStatusPlanif[self::STATUSPLANIF_INCOMPLET] = $langs->trans('INCOMPLET');
			$this->labelStatusPlanif[self::STATUSPLANIF_PAYE] = $langs->trans('PAYE');
			$this->labelStatusPlanif[self::STATUSPLANIF_DEROULE] = $langs->trans('DEROULE');
			$this->labelStatusPlanif[self::STATUSPLANIF_CANCELED] = $langs->trans('ANNULE');
			$this->labelStatusPlanif[self::STATUSPLANIF_FACTURE] = $langs->trans('FATURE');
			$this->labelStatusPlanif[self::STATUSPLANIF_PORTAIL] = $langs->trans('EDF');
			$this->labelStatusPlanif[self::STATUSPLANIF_PAIEMENT] = $langs->trans('PAIEMENT');
			$this->labelStatusPlanif[self::STATUSPLANIF_DALLEFAITE] = $langs->trans('DALLE FAITE');
			$this->labelStatusPlanif[self::STATUSPLANIF_LIVRE] = $langs->trans('LIVRE');
			$this->labelStatusPlanif[self::STATUSPLANIF_ALIVRE] = $langs->trans('A LIVRER');
			$this->labelStatusPlanif[self::STATUSPLANIF_PRIME] = $langs->trans('PRIME');
			$this->labelStatusPlanif[self::STATUSPLANIF_AFDALLE] = $langs->trans('PLANIF DALLE');
			$this->labelStatusPlanif[self::STATUSPLANIF_PREVISITE] = $langs->trans('PRE-VISITE');
			$this->labelStatusPlanif[self::STATUSPLANIF_CMA] = $langs->trans('EN ATTENTE');
			$this->labelStatusPlanif[self::STATUSPLANIF_ATRAITER] = $langs->trans('A TRAITER'); 
			$this->labelStatusPlanif[self::STATUSPLANIF_PACK] = $langs->trans('ATF'); 
			$this->labelStatusPlanif[self::STATUSPLANIF_INJOIGNABLE] = $langs->trans('INJOIGNABLE');
			$this->labelStatusPlanif[self::STATUSPLANIF_PRECHANTIER] = $langs->trans('PRE-CHANTIER');

			$this->labelStatusShortPlanif[self::STATUSPLANIF_ATTENTE] = $langs->trans('A TRAITER');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PLANIFIE] = $langs->trans('PLANIFIE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_REPLANIFIE] = $langs->trans('RE PLANIFIE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_POSE] = $langs->trans('POSE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_IMPOSSIBLE] = $langs->trans('IMPOSSIBLE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_INCOMPLET] = $langs->trans('INCOMPLET');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PAYE] = $langs->trans('PAYE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_DEROULE] = $langs->trans('DEROULE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_CANCELED] = $langs->trans('ANNULE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_FACTURE] = $langs->trans('FACTURE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PORTAIL] = $langs->trans('EDF');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PAIEMENT] = $langs->trans('PAIEMENT');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_DALLEFAITE] = $langs->trans('DALLE FAITE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_LIVRE] = $langs->trans('LIVRE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_ALIVRE] = $langs->trans('A LIVRER');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PRIME] = $langs->trans('PRIME');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_AFDALLE] = $langs->trans('PLANIF DALLE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PREVISITE] = $langs->trans('PRE-VISITE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_CMA] = $langs->trans('EN ATTENTE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_ATRAITER] = $langs->trans('A TRAITER');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PACK] = $langs->trans('ATF'); 
			$this->labelStatusShortPlanif[self::STATUSPLANIF_INJOIGNABLE] = $langs->trans('INJOIGNABLE');
			$this->labelStatusShortPlanif[self::STATUSPLANIF_PRECHANTIER] = $langs->trans('PRE-CHANTIER');
		}

		$statusType = 'status'.$status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		//if ($status == self::STATUS_CANCELED) $statusType = 'status6';

		return dolGetStatus($this->labelStatusPlanif[$status], $this->labelStatusShortPlanif[$status], '', $statusType, $mode,$url);
	}
	/* function pour afficher un select avec uniquement les poseurs*/
	public function list_poseurs($selected){
		global $db;
		include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscaraiso/class/deviscarapos.class.php',1);
		$pose=new Deviscarapos($db);
		$list_poseur=$pose->list_poseurs($selected,1);
		return $list_poseur;

	}
	public function tab_list_poseur(){
		$sql = "SELECT a.rowid,a.lastname,a.firstname from ".MAIN_DB_PREFIX."user a, ".MAIN_DB_PREFIX."usergroup_user b";
		$sql.= " where a.rowid=b.fk_user";
		$sql.= " and fk_usergroup =3 "; //poseurs ISO
		$sql .= ' and a.statut=1';
		$sql.= " order by fk_usergroup";
		$resql = $this->db->query($sql);
		if ($resql)
		{	
			$num_rows = $this->db->num_rows($resql);
			$i = 0;
			$res[null]="";
			while ($i < $num_rows)
			{
				$obj = $this->db->fetch_object($resql);
				$res[$obj->rowid]=$obj->lastname." ".$obj->firstname;
				$i++;

			}
			
		}
		return $res;
	}
	
	/**
	 *	Load the info information in the object
	 *
	 *	@param  int		$id       Id of object
	 *	@return	void
	 */
	public function info($id)
	{
		$sql = 'SELECT rowid, date_creation as datec, tms as datem,';
		$sql .= ' fk_user_creat, fk_user_modif';
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		$sql .= ' WHERE t.rowid = '.$id;
		$result = $this->db->query($sql);
		if ($result)
		{
			if ($this->db->num_rows($result))
			{
				$obj = $this->db->fetch_object($result);
				$this->id = $obj->rowid;
				if ($obj->fk_user_author)
				{
					$cuser = new User($this->db);
					$cuser->fetch($obj->fk_user_author);
					$this->user_creation = $cuser;
				}

				if ($obj->fk_user_valid)
				{
					$vuser = new User($this->db);
					$vuser->fetch($obj->fk_user_valid);
					$this->user_validation = $vuser;
				}

				if ($obj->fk_user_cloture)
				{
					$cluser = new User($this->db);
					$cluser->fetch($obj->fk_user_cloture);
					$this->user_cloture = $cluser;
				}

				$this->date_creation     = $this->db->jdate($obj->datec);
				$this->date_modification = $this->db->jdate($obj->datem);
				$this->date_validation   = $this->db->jdate($obj->datev);
			}

			$this->db->free($result);
		}
		else
		{
			dol_print_error($this->db);
		}
	}

	/**
	 * Initialise object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return void
	 */
	public function initAsSpecimen()
	{
		$this->initAsSpecimenCommon();
	}

	/**
	 * 	Create an array of lines
	 *
	 * 	@return array|int		array of lines if OK, <0 if KO
	 */
	public function getLinesArray()
	{
	    $this->lines = array();

	    $objectline = new DeviscaraisoLine($this->db);
	    $result = $objectline->fetchAll('ASC', 'position', 0, 0, array('customsql'=>'fk_myobject = '.$this->id));

	    if (is_numeric($result))
	    {
	        $this->error = $this->error;
	        $this->errors = $this->errors;
	        return $result;
	    }
	    else
	    {
	        $this->lines = $result;
	        return $this->lines;
	    }
	}

	/**
	 *  Returns the reference to the following non used object depending on the active numbering module.
	 *
	 *  @return string      		Object free reference
	 */
	public function getNextNumRef()
	{
		global $langs, $conf;
		$langs->load("deviscaraiso@deviscaraiso");

		if (empty($conf->global->MYMODULE_MYOBJECT_ADDON)) {
			$conf->global->MYMODULE_MYOBJECT_ADDON = 'mod_deviscaraiso_standard';
		}

		if (!empty($conf->global->MYMODULE_MYOBJECT_ADDON))
		{
			$mybool = false;

			$file = $conf->global->MYMODULE_MYOBJECT_ADDON.".php";
			$classname = $conf->global->MYMODULE_MYOBJECT_ADDON;

			// Include file with class
			$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);
			foreach ($dirmodels as $reldir)
			{
				$dir = dol_buildpath($reldir."core/modules/deviscaraiso/");

				// Load file with numbering class (if found)
				$mybool |= @include_once $dir.$file;
			}

			if ($mybool === false)
			{
				dol_print_error('', "Failed to include file ".$file);
				return '';
			}

			$obj = new $classname();
			$numref = $obj->getNextValue($this);

			if ($numref != "")
			{
				return $numref;
			}
			else
			{
				$this->error = $obj->error;
				//dol_print_error($this->db,get_class($this)."::getNextNumRef ".$obj->error);
				return "";
			}
		}
		else
		{
			print $langs->trans("Error")." ".$langs->trans("Error_MYMODULE_MYOBJECT_ADDON_NotDefined");
			return "";
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 *  @param	    string		$modele			Force template to use ('' to not force)
	 *  @param		Translate	$outputlangs	objet lang a utiliser pour traduction
	 *  @param      int			$hidedetails    Hide details of lines
	 *  @param      int			$hidedesc       Hide description
	 *  @param      int			$hideref        Hide ref
	 *  @param      null|array  $moreparams     Array to provide more information
	 *  @return     int         				0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	{
		global $conf, $langs;

		$langs->load("mymodule@mymodule");

		$this->modele = 'einsteinsigniso';

        //$modelpath = "core/modules/propale/doc/";
        $modelpath = dol_buildpath("einsteinsigniso/core/modules/deviscaraiso/doc/",1);

		return $this->commonGenerateDocument($modelpath, $this->modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
	}

	/**
	 * Action executed by scheduler
	 * CAN BE A CRON TASK. In such a case, parameters come from the schedule job setup field 'Parameters'
	 *
	 * @return	int			0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
	 */
	//public function doScheduledJob($param1, $param2, ...)
	public function doScheduledJob()
	{
		global $conf, $langs;

		//$conf->global->SYSLOG_FILE = 'DOL_DATA_ROOT/dolibarr_mydedicatedlofile.log';

		$error = 0;
		$this->output = '';
		$this->error = '';

		dol_syslog(__METHOD__, LOG_DEBUG);

		$now = dol_now();

		$this->db->begin();

		// ...

		$this->db->commit();

		return $error;
	}
	
	
	/* to get total of lines*/
	public function gettotalttc(){
		$totalttc=0;
		foreach($this->lines as $line){
			$totalttc+=$line->amount*$line->qty;
		}
		if($totalttc>=0){
			$sql="UPDATE ".MAIN_DB_PREFIX.$this->table_element;
			$sql .= ' set amount='.price2num($totalttc).'';
			$sql .= ' where rowid='.$this->id.'';
			$res = $this->db->query($sql);
			if ($res === false) {
				setEventMessages("Erreur de mise à jour", $this->db->lasterror(), 'errors');
				header("Location: " . $_SERVER['PHP_SELF'].'?id='.$this->id);
				exit;
			}
		}
		return price($totalttc);
	}

	
	public function get_fields_supp(){
		global $user,$db;
		$list_villes=array(-1=>'');
		$sql='select rowid,ville from '.MAIN_DB_PREFIX.'cara_cpville';
		$sql .= ''; 
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $this->db->fetch_object($resql);
				$list_villes[$obj->rowid]=$obj->ville;
				$i++;
			}
		}
		$tab['ville']['type']="varchar(50)";
		$tab['ville']['label']="Ville";
		$tab['ville']['enabled']=1;
		$tab['ville']['visible']=1;
		$tab['ville']['position']="40";
		$tab['ville']['arrayofkeyval']=$list_villes;

		$tab['phone']['type']="varchar(50)";
		$tab['phone']['label']="Telephone";
		$tab['phone']['enabled']=1;
		$tab['phone']['visible']=1;
		$tab['phone']['position']="30";

		$tab['address']['type']="varchar(50)";
		$tab['address']['label']="Adresse";
		$tab['address']['enabled']=1;
		$tab['address']['visible']=0;
		$tab['address']['position']="120";
		
		$tab['carafinance']['type']="varchar(50)";
		$tab['carafinance']['label']="Affaire";
		$tab['carafinance']['enabled']=1;
		$tab['carafinance']['visible']=1;
		$tab['carafinance']['position']="1190";
		$user->conf->MAIN_SELECTEDFIELDS_deviscaraisolist.='ville,phone,address,carafinance';


		return($tab);
	}
	public function get_fields_supp_entete(){
		$list_preca=array(-1=>'');
		$sql='select rowid,libelle from '.MAIN_DB_PREFIX.'cara_typeclient';
		$sql .= ''; 
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $this->db->fetch_object($resql);
				$list_typeclient[$obj->rowid]=$obj->libelle;
				$i++;
			}
		}
		$tab['cara_typeclient']['type']="sellist";
		$tab['cara_typeclient']['label']="Precarité";
		$tab['cara_typeclient']['enabled']=1;
		$tab['cara_typeclient']['visible']=1;
		$tab['cara_typeclient']['position']="99";
		$tab['cara_typeclient']['notnull']="1";
		$tab['cara_typeclient']['arrayofkeyval']=$list_typeclient;

		$sql='select rowid,libelle from '.MAIN_DB_PREFIX.'cara_typeclient_ctm';
		$sql .= ''; 
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $this->db->fetch_object($resql);
				$list_typeclient_ctm[$obj->rowid]=$obj->libelle;
				$i++;
			}
		}
		$tab['cara_typeclient_ctm']['type']="sellist";
		$tab['cara_typeclient_ctm']['label']="Precarité CTM";
		$tab['cara_typeclient_ctm']['enabled']=1;
		$tab['cara_typeclient_ctm']['visible']=1;
		$tab['cara_typeclient_ctm']['position']="99";
		$tab['cara_typeclient_ctm']['notnull']="0";
		$tab['cara_typeclient_ctm']['arrayofkeyval']=$list_typeclient_ctm;
		return($tab);
	}

	public function  get_typeclient(){

		$sql='select cara_type_client from '.MAIN_DB_PREFIX.'societe_extrafields';
		$sql .= ' where fk_object='.$this->fk_soc; 
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $this->db->fetch_object($resql);
				return($obj->cara_type_client);
				$i++;
			}
		}
		else return(-1);
	}

	public function  get_libtypeclient(){

		$sql='select libelle,ref from '.MAIN_DB_PREFIX.'societe_extrafields a, '.MAIN_DB_PREFIX.'cara_typeclient b';
		$sql .= ' where fk_object='.$this->fk_soc; 
		$sql .= ' and a.cara_type_client=b.rowid';
		$resql = $this->db->query($sql);
		if($resql){
			$obj = $this->db->fetch_object($resql);
			return($obj->libelle);
		}
		else return ('');
	}

	public function update_cara_typeclient($cara_typeclient,$ext=''){
		$sql=' INSERT into '.MAIN_DB_PREFIX.'societe_extrafields';
		$sql .= '(fk_object,cara_type_client'.$ext.',ville) values ('.$this->fk_soc.','.$cara_typeclient.',"NULL") on duplicate key ';
		$sql .='update  ';
		$sql .= ' cara_type_client'.$ext.' ='.$cara_typeclient.' '; 
		$resql = $this->db->query($sql);
		return ($resql);
	}

	/* retourne le montant de la précarité en fonction de la précarité du tiers (extrafields) */
	public function get_amount_preca(){
		$id_preca=$this->get_typeclient();
		if($id_preca==1 || $id_preca==2)
			return('-14');
		if($id_preca==3)
			return('-16');
		if($id_preca==4)//professionnels
			return('-12');

	}

	function get_info_commonfileds_edit(){
		$sql=' select nom from '.MAIN_DB_PREFIX.'societe';
		$sql .= ' where rowid='.$this->fk_soc;
		$resql = $this->db->query($sql);
		if($resql){
			$obj = $this->db->fetch_object($resql);
			$tab['nom']=$obj->nom;
			//return($obj->nom);
		}
		$sql=' select lastname, firstname from '.MAIN_DB_PREFIX.'user';
		$sql .= ' where rowid='.$this->fk_usercomm;
		$resql = $this->db->query($sql);
		if($resql){
			$obj = $this->db->fetch_object($resql);
			$tab['commercial']=$obj->lastname.' '.$obj->firstname;
		}
		return($tab);

	}
	public function getidfichpose(){
		$sql='select rowid from '.MAIN_DB_PREFIX.'cara_deviscarapos a';
		$sql .= ' where fk_devisiso = '.$this->id;
		$sql .= ' and date_planif="'.$this->db->idate($this->date_planif).'"';
		$resql = $this->db->query($sql);
		if($resql){
			$obj = $this->db->fetch_object($resql);
			return $obj->rowid;
		}

	}
	static function update_etiquette($id_event,$etiquettes){
		global $db;
		$sql='delete from '.MAIN_DB_PREFIX.'etiquette_actioncomm';
		$sql .=' where actioncomm_id='.$id_event;
		$resql = $db->query($sql);

		//insert
		if (count($etiquettes)>0)
		$sql='insert into '.MAIN_DB_PREFIX.'etiquette_actioncomm';
		$sql .='(actioncomm_id,etiquette_id) values ';
		foreach ($etiquettes as $etiquette){
			$sql.='('.$id_event.','.$etiquette.'),';
		}
		$sql=trim($sql,',');
		$resql = $db->query($sql);
	}

	static function getselectetiquette($id){
		global $db;
		$sql='select etiquette_id from '.MAIN_DB_PREFIX.'etiquette_actioncomm a,'.MAIN_DB_PREFIX.'actioncomm b';
		$sql .= ' where ref_ext='.$id;
		$sql .= ' and b.id=a.actioncomm_id';
		$resql = $db->query($sql);
		if($resql){
			$num = $db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $db->fetch_object($resql);
				$tab[]=$obj->etiquette_id;
				$i++;
			}
			return $tab;
		}

	}

	static function getselectetiquettefromevent($id){
		global $db;
		$sql='select etiquette_id from '.MAIN_DB_PREFIX.'etiquette_actioncomm ';
		$sql .= ' where actioncomm_id='.$id;
		
		$resql = $db->query($sql);
		if($resql){
			$num = $db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $db->fetch_object($resql);
				$tab[]=$obj->etiquette_id;
				$i++;
			}
			return $tab;
		}

	}

	public function update_refext($id_event){
		$sql = 'UPDATE  '.MAIN_DB_PREFIX.'actioncomm as t';
		$sql .= ' set ref_ext = '.$this->id;
		$sql .= ' ,extraparams=1'; // pour l'iso
		$sql .= ' where id = '.$id_event;
		$this->db->query($sql);
	}

	public static function list_commerciaux($selected,$onchange=1){
		global $db;
		$sql = "SELECT a.rowid,a.lastname,a.firstname from ".MAIN_DB_PREFIX."user a, ".MAIN_DB_PREFIX."usergroup_user b";
		$sql.= " where a.rowid=b.fk_user";
		$sql.= " and fk_usergroup in (".self::GROUP_COMMERCIAUX." )";
		$sql .= ' and a.statut=1';
		$sql.= " order by a.firstname";

		$resql = $db->query($sql);
		if ($resql)
		{
            $onchange=($onchange==1? " onchange='this.form.submit();' " : "" );
           
			$out = "<select id='fk_user_pos' class='flat minwidth200imp' name='fk_usercomm' ".$onchange.">";
			$out.="<option value=".$selected.">&nbsp;</option>";
			$num_rows = $db->num_rows($resql);
			$i = 0;
			while ($i < $num_rows)
			{
				$obj = $db->fetch_object($resql);
                if($obj->rowid == $selected) 
                    $sel='selected';
                else 
                    $sel='';
				$out.="<option value='".$obj->rowid."'  $sel >".$obj->firstname." ".$obj->lastname."</option>";
				$i++;

			}
			$out.="</select>";
		}
		return $out;
    }
	function get_alerte(){
		$now=new DateTime('now');
		if($this->date_planif){
			$date_planif=new DateTime();
			$date_planif->setTimestamp($this->date_planif);
			$diff=$now->diff($date_planif);
			if ($diff->invert==1 && $diff->d > 3 && $this->planification == self::STATUSPLANIF_PLANIFIE)
				$this->alerte_date_planif=true;
		}
		if($this->date_attente){
			$date_attente=new DateTime();
			$date_attente->setTimestamp($this->date_attente);
			$diff=$now->diff($date_attente);
			if ($diff->invert==1 && $diff->d > 1 && $this->planification == self::STATUSPLANIF_CMA)
				$this->alerte_date_attente=true;
		}
	}

}

/**
 * Class MyObjectLine. You can also remove this and generate a CRUD class for lines objects.
 */
class DeviscaraIsoLine extends CommonObject
{

	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'deviscaraisodet';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'cara_deviscaraisodet';

	public function __construct($db)
	{
		$this->db = $db;
	}
	
	
	public $fields = array(
	    'rowid'         	=> array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'visible'=>-2, 'noteditable'=>1, 'notnull'=> 1, 'index'=>1, 'position'=>1, 'comment'=>'Id'),
		'label'         => array('type'=>'varchar(255)', 'label'=>'Label', 'enabled'=>1, 'visible'=>1, 'position'=>30, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>'Help text', 'showoncombobox'=>1),
		'options'        => array('type'=>'smallint', 'label'=>'Options', 'enabled'=>1, 'visible'=>0, 'notnull'=> 1, 'default'=>0, 'index'=>1, 'position'=>110),
	    'fk_deviscaraiso' 		=> array('type'=>'integer', 'label'=>'ThirdParty', 'visible'=> 0, 'enabled'=>1, 'position'=>50, 'notnull'=>-1, 'index'=>1),
		'amount'        => array('type'=>'price', 'label'=>'Amount', 'enabled'=>1, 'visible'=>-2, 'default'=>'null', 'position'=>40, 'searchall'=>0, 'isameasure'=>1, 'help'=>'Montant chiffrage'),
	    'qty'           => array('type'=>'real', 'label'=>'Qty', 'enabled'=>1, 'visible'=>-2, 'default'=>'0', 'position'=>45, 'searchall'=>0, 'isameasure'=>1, 'help'=>'Quantité', 'css'=>'maxwidth75imp'),
	    'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'visible'=>-2, 'notnull'=> 1, 'position'=>510, 'foreignkey'=>'user.rowid'),
		'date_creation' => array('type'=>'datetime', 'label'=>'DateCreation', 'enabled'=>1, 'visible'=>1, 'notnull'=> 1, 'position'=>500),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'visible'=>-2, 'notnull'=>-1, 'position'=>511),
	);
	

	public function create(User $user, $notrigger = false)
	{
		$error=0;
		$this->db->begin();
		if (is_null($this->amount)) $this->amount='NULL';
		if (is_null($this->qty)) $this->qty='NULL';
		$sql = 'INSERT INTO '.MAIN_DB_PREFIX.$this->table_element;
		$sql .= ' (label,fk_deviscaraiso,fk_user_creat,options, amount,qty)';
		$sql .= ' VALUES ("'.$this->label.'",'.$this->fk_deviscaraiso.','.$user->id.','.$this->options.','.$this->amount.','.$this->qty.')';

		$res = $this->db->query($sql);
		if ($res === false) {
			$error++;
			$this->errors[] = $this->db->lasterror();
		}
		$this->db->commit();
	}

	public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		global $conf;
		return (-1);
		
	}
}
