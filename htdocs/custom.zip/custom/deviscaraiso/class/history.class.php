<?php


require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
/**
 * Class for MyObject
 */
class Histo extends CommonObject
{
    public function __construct(DoliDB $db)
	{
		global $conf, $langs;

        $this->db = $db;
    }
    public function fetch($id){
        
        $this->id=$id;
    }
    public function get_devis(){
        //devis iso
        $sql='select a.rowid, description, date_format(date_creation,"%d/%m/%Y") as date_creation,planification,a.fk_usercomm,firstname,lastname,date_format(date_planif,"%Y-%m-%d") as date_planif,"iso" from llx_cara_deviscaraiso a ';
        $sql.= ' left join llx_user b on a.fk_usercomm=b.rowid';
        $sql.= ' where a.fk_soc='.$this->id;
        $sql.=' union ';
        $sql.='select c.rowid, description, date_format(date_creation,"%d/%m/%Y") as date_creation,planification,c.fk_usercomm,firstname,lastname,date_format(date_planif,"%Y-%m-%d") as date_planif,"ces" from llx_cara_deviscaraces c ';
        $sql.= ' left join llx_user d on c.fk_usercomm=d.rowid';
        $sql.= ' where c.fk_soc='.$this->id;
        $sql.=' union ';
        $sql.='select e.rowid, description, date_format(date_creation,"%d/%m/%Y") as date_creation,planification,e.fk_usercomm,firstname,lastname,date_format(date_planif,"%Y-%m-%d") as date_planif,"rep" from llx_cara_deviscararep e ';
        $sql.= ' left join llx_user f on e.fk_usercomm=f.rowid';
        $sql.= ' where e.fk_soc='.$this->id;
        $sql.=' union ';
        $sql.='select f.rowid, description, date_format(date_creation,"%d/%m/%Y") as date_creation,planification,f.fk_usercomm,firstname,lastname,date_format(date_planif,"%Y-%m-%d") as date_planif,"toit" from llx_cara_deviscaratoit f';
        $sql.= ' left join llx_user d on f.fk_usercomm=d.rowid';
        $sql.= ' where f.fk_soc='.$this->id;
        $sql.= ' order by date_planif DESC';
        $resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
            	$this->lines[$i] = new stdClass();
            
				$this->lines[$i]->type = $obj->iso;
				$this->lines[$i]->rowid=$obj->rowid;
				$this->lines[$i]->description=$obj->description;
                $this->lines[$i]->date_creation=$obj->date_creation;
                $this->lines[$i]->fk_usercomm=$obj->fk_usercomm;
                $this->lines[$i]->firstname=$obj->firstname;
                $this->lines[$i]->lastname=$obj->lastname;
                $this->lines[$i]->status=$obj->planification;
                $this->lines[$i]->date_planif=$obj->date_planif;
				$i++;
            }
        }
    }

    public function get_pose(){
        $sql='select a.rowid, description, date_format(date_planif,"%Y-%m-%d") as date_planif,status,a.fk_user_pos,firstname,lastname,fk_devisiso,fk_devisces,fk_devisrep,fk_devistoit from llx_cara_deviscarapos a ';
        $sql.= ' left join llx_user b on a.fk_user_pos=b.rowid';
        $sql.= ' where a.fk_soc='.$this->id;
        $sql.= ' order by date_planif DESC';
        $resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
                
                $this->linespos[$i] = new stdClass();
            
				$this->linespos[$i]->rowid=$obj->rowid;
				$this->linespos[$i]->description=$obj->description;
                $this->linespos[$i]->date_planif=$obj->date_planif;
                $this->linespos[$i]->fk_user_pos=$obj->fk_user_pos;
                $this->linespos[$i]->firstname=$obj->firstname;
                $this->linespos[$i]->lastname=$obj->lastname;
                $this->linespos[$i]->status=$obj->status;
                if($obj->fk_devisiso>0){
                    $this->linespos[$i]->id_devis=$obj->fk_devisiso;
                    $this->linespos[$i]->ext='iso';
                }
                elseif($obj->fk_devisces>0){
                    $this->linespos[$i]->id_devis=$obj->fk_devisces;
                    $this->linespos[$i]->ext='ces';
                }
                elseif($obj->fk_devisrep>0){
                    $this->linespos[$i]->id_devis=$obj->fk_devisrep;
                    $this->linespos[$i]->ext='rep';
                }
                elseif($obj->fk_devistoit>0){
                    $this->linespos[$i]->id_devis=$obj->fk_devistoit;
                    $this->linespos[$i]->ext='toit';
                }
				$i++;
            }
        }
    }

    public function get_rendezvous(){
        $sql=' SELECT a.id,a.fk_soc,a.ref_ext,name, date_format(datep,"%Y-%m-%d") as datep,a.note, code,firstname, lastname,c.color,c.name,fk_user_action FROM llx_actioncomm a';
        $sql.=' left join llx_etat_actioncomm on id=actioncomm_id';
        $sql.=' left join llx_evenement_etat c on etat_id=c.rowid
        left join llx_user d on fk_user_action=d.rowid
        where a.fk_soc='.$this->id;
        $sql.=' order by datep DESC';

        $resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
            
                $this->linesrdv[$i] = new stdClass();
				
            	$this->linesrdv[$i]->code = $obj->code;
				$this->linesrdv[$i]->id=$obj->id;
				$this->linesrdv[$i]->note=$obj->note;
                $this->linesrdv[$i]->datep=$obj->datep;
                $this->linesrdv[$i]->fk_pos=$obj->ref_ext;
                $this->linesrdv[$i]->firstname=$obj->firstname;
                $this->linesrdv[$i]->lastname=$obj->lastname;
                $this->linesrdv[$i]->color=$obj->color;
                $this->linesrdv[$i]->name=$obj->name;
                $this->linesrdv[$i]->fk_user_action=$obj->fk_user_action;
				$i++;
            }
        }
    }

    public function LibStatutPlanif( $url,$status)
	{
        include_once DOL_DOCUMENT_ROOT.dol_buildpath("deviscaraiso/class/deviscaraiso.class.php",1);

		$mode=5;
		if (empty($this->labelStatusPlanif) || empty($this->labelStatusShortPlanif))
		{
			global $langs;
			//$langs->load("mymodule");
		
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_ATTENTE] = $langs->trans('Attente');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_PLANIFIE] = $langs->trans('Planifié');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_REPLANIFIE] = $langs->trans('Re planifié');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_POSE] = $langs->trans('Posé');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_IMPOSSIBLE] = $langs->trans('Impossible');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_INCOMPLET] = $langs->trans('Incomplet');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_PAYE] = $langs->trans('Payé');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_DEROULE] = $langs->trans('Deroulé');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_CANCELED] = $langs->trans('Abandonné');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_FACTURE] = $langs->trans('Facturé');
			$this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_PORTAIL] = $langs->trans('Portail');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_PAIEMENT] = $langs->trans('Paiement');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_DALLEFAITE] = $langs->trans('Dalle Faite');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_LIVRE] = $langs->trans('Livré');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_ALIVRE] = $langs->trans('A Livrer');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_PRIME] = $langs->trans('Primé');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_AFDALLE] = $langs->trans('Planif Dalle');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_PREVISITE] = $langs->trans('Pré-visite');
            $this->labelStatusPlanif[Deviscaraiso::STATUSPLANIF_CMA] = $langs->trans('TRVX');
			
			
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_ATTENTE] = $langs->trans('Attente');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_PLANIFIE] = $langs->trans('Planifié');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_REPLANIFIE] = $langs->trans('Re planifié');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_POSE] = $langs->trans('Posé');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_IMPOSSIBLE] = $langs->trans('Impossible');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_INCOMPLET] = $langs->trans('Incomplet');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_PAYE] = $langs->trans('Payé');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_DEROULE] = $langs->trans('Deroulé');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_CANCELED] = $langs->trans('Abandonné');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_FACTURE] = $langs->trans('Facturé');
			$this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_PORTAIL] = $langs->trans('Portail');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_PAIEMENT] = $langs->trans('Paiement');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_DALLEFAITE] = $langs->trans('Dalle Faite');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_LIVRE] = $langs->trans('Livré');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_ALIVRE] = $langs->trans('A Livrer');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_PRIME] = $langs->trans('Primé');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_AFDALLE] = $langs->trans('Planif Dalle');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_PREVISITE] = $langs->trans('Pré-visite');
            $this->labelStatusShortPlanif[Deviscaraiso::STATUSPLANIF_CMA] = $langs->trans('TRVX');
			
		}
        $statusType = 'status'.$status;
		
		return dolGetStatus($this->labelStatusPlanif[$status], $this->labelStatusShortPlanif[$status], '', $statusType, $mode,$url);
    }
    public function LibStatutPose($status)
	{
        include_once DOL_DOCUMENT_ROOT.dol_buildpath("deviscaraiso/class/deviscarapos.class.php",1);
        $mode=5;
        if (empty($this->labelStatus) || empty($this->labelStatusShort))
		{
			global $langs;
			//$langs->load("mymodule");
			$this->labelStatus[Deviscarapos::STATUS_DRAFT] = $langs->trans('Draft');
			$this->labelStatus[Deviscarapos::STATUS_VALIDATED] = $langs->trans('En attente');
			$this->labelStatus[Deviscarapos::STATUS_SIGNED] = $langs->trans('Posé/Signé');
			$this->labelStatus[Deviscarapos::STATUS_CANCELED] = $langs->trans('Disabled');
			$this->labelStatusShort[Deviscarapos::STATUS_DRAFT] = $langs->trans('Draft');
			$this->labelStatusShort[Deviscarapos::STATUS_VALIDATED] = $langs->trans('En attente');
			$this->labelStatusShort[Deviscarapos::STATUS_SIGNED] = $langs->trans('Posé/Signé');
			$this->labelStatusShort[Deviscarapos::STATUS_CANCELED] = $langs->trans('Disabled');
		}

		$statusType = 'status'.$status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		if ($status == Deviscarapos::STATUS_CANCELED) $statusType = 'status6';

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
	
    }
}

?>