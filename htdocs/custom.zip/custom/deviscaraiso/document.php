<?php

require_once "../../main.inc.php";
include_once DOL_DOCUMENT_ROOT . dol_buildpath("deviscaraiso/class/deviscaraiso.class.php", 1);

$action = GETPOST("action", "alpha");
$id = GETPOST("id", "int");
if($action == "") $action = "update_documents";
if($action == "update_documents") {
    $object = new Deviscaraiso($db);
    $object->fetch($id);
    $fk_soc =  $object->fk_soc;
    $type = "1";
    $backurlpage = "/custom/deviscaraiso/card.php?id=" . $id;
    $errorbackurlpage = "/custom/deviscaraiso/document.php?id=$id&fk_soc=$fk_soc&type=$type";
    llxHeader();
    dol_fiche_head();
    include_once dol_buildpath("caradocuments/form.php");
    dol_fiche_end();
    llxFooter();
}
else if($action == "valid_documents") {
    include_once dol_buildpath("caradocuments/form-add.php");
}
