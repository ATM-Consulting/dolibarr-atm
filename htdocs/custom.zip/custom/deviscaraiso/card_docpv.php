<?php


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
include_once DOL_DOCUMENT_ROOT . dol_buildpath("caradocuments/data/cara_document.class.php", 1);

// Load translation files required by the page
$langs->loadLangs(array("mymodule@mymodule", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'myobjectcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$type=      GETPOST('type','int');
$fk_objectid = GETPOST('fk_objectid','int');
$fk_object = GETPOST('fk_object');
$fk_soc=GETPOST('fk_soc','int');

// Initialize technical objects
$object = new CaraDocument($db);
$extrafields = new ExtraFields($db);

$object->fk_soc=$fk_soc;

//$diroutputmassaction = $conf->mymodule->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('myobjectcard', 'globalcard')); // Note that conf->hooks_modules contains array

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

$form = new Form($db);
$formfile = new FormFile($db);

/*
 * Actions
 */
include_once DOL_DOCUMENT_ROOT . dol_buildpath("caradocuments/insert_doc.php", 1);



/*
 * View
 *
 * Put here all code to build page
 */



$groupe_famille=array(
    "Documents Administratifs"  => array('identite'=>"Pièce d'identité RV",'taxefonciere'=>"Taxe Foncière RV","factureedf"=>"Facture EDF",
                                    'titrepropriete'=>"Titre propriete","permisconstruire"  => "Photo permis de construire",
                                    "offre"=>"offre" ,"promessebail"=>"Promesse de Bail","mandaturbanisme"=>"Mandat Urbanisme" , "cmad"=>"CMAD" ,"mandatedf"=>"Mandat EDF" ,"docscomplementaires"=>"+"),

    "Photos  PV"             => array("pv_pres" =>   "Photo de Près", "pv_loin"=>    "Photo de loin", "pv_edf"=>        "Photos poteau EDF"),

);
            


$doctoshow=$object->fetchMissingDocuments($fk_soc,'');
$families=array_merge($families,$doctoshow);

$caradocument = new CaraDocument($db);
$tabdoc = $caradocument->getListDocByFamilly($fk_soc);



llxHeader('', $langs->trans('Liste des documents'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">

</script>';
if ($formconfirm)
    print $formconfirm;
//affichage par défaut

print load_fiche_titre($langs->trans("Liste des Documents"));

print '<form method="POST" id="fileupdate" action="'.$_SERVER["PHP_SELF"].'" enctype="multipart/form-data">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="fk_soc" value="'. $fk_soc .'">';
print '<input type="hidden" name="famille" value="'. GETPOST('famille','int') .'">';
print '<input type="hidden" name="action" value="valid_documents">';
print '<input type="hidden" name="type" value="'. $type .'">';
print '<input type="hidden" name="fk_object" value="'. $fk_object .'">';
print '<input type="hidden" name="fk_objectid" value="'. $fk_objectid .'">';


dol_fiche_head(array(), '');

foreach ($groupe_famille as $lib_groupe=>$familles){

    print '<div class="fiche"><table class="border centpercent tableforfieldcreate" border=0>'."\n";
    if(isset($object->id_syno_doc))
        $urlrepertoire_client='<a href="http://192.168.1.98:5000/?launchApp=SYNO.SDS.Drive.Application#file_id='.$object->id_syno_doc.'" target="_blank">'.$lib_groupe.'</a>';
    else $urlrepertoire_client=$lib_groupe;
    print '<tr><td><b><FONT size="5pt">'.$urlrepertoire_client.'</font></b></td></tr>';
    $j=0;
    foreach ($familles as $id_famille=>$famille){
        $bool_green=false;
        print'<td>';
        foreach($tabdoc as $doc){
            
            if($doc['family']==$id_famille){
                
                if($bool_green!=true)
                    print'<input style="background-color:#37E152; border-radius:10px 10px 10px 10px" type="button" id="loadFileXml" value="'.$famille.'" onclick="document.getElementById(\'photo'.$id_famille.'\').click();" />
                    <input   type="file"  id="photo'.$id_famille.'" name="photo['.$id_famille.']" >';
                $bool_green=true;
                print '<br><a href="'.$doc['link'].'" target="_blank">'.$doc['filename'].'</a>';
                if (!in_array($group->id, array(2,3))) //si poseurs: impossible de supprimer les documents.
                    print'<a href="'.$_SERVER["PHP_SELF"].'?action=ask_delete&id_doc='.$doc['rowid'].'&fk_soc='.$fk_soc.'&fk_object='.$fk_object.'&fk_objectid='.$fk_objectid.'" >
                    <span class="fas fa-trash marginleftonly pictodelete" style=" color: #444;" title="Supprimer"></span></a>  ';
            }
    
        }

        if($bool_green==false)
        print'<input style="background-color:#F02D0A; border-radius:10px 10px 10px 10px" type="button" id="loadFileXml" value="'.$famille.'" onclick="document.getElementById(\'photo'.$id_famille.'\').click();" />
        <input type="file"  id="photo'.$id_famille.'" name="photo['.$id_famille.']"/>';
        if(($j%2)==1)
            print '</tr><tr>';
        $j++;
        print '</td>';
        
    }
    print '</tr>';
    print '</table></div><div class="tabsAction"><table bgcolor="#e5e5e5" width="100%"><tr><td>&nbsp;</td></tr></table></div>';
}


if ($fk_object=='carasun'){
    $url=dol_buildpath("/carasun/pv_listcomm.php?", 1).'id='.$fk_objectid;
    $lib="Retour Liste";
}

print '<a class="butAction" href="'.$url.'">'.$langs->trans($lib).'</a>';
$maxsize=(int)ini_get("upload_max_filesize")*10240000;
print '<script>
var isImageCompressed = false;
var isImageCompressable = true;
function compress(e) {
    const maxsize = 1200;
    const fileName = e.target.files[0].name;
    const reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = function (event) {
        const img = new Image();
        const scaleFactor = (img.width > img.height) ? maxsize / img.width : maxsize / img.height;
        img.src = event.target.result;
        img.onload = function () {
            const elem = document.createElement(\'canvas\');
            if(img.width > img.height) {
                elem.width = maxsize;
                elem.height = img.height * scaleFactor;
            }
            else {
                elem.width = img.width * scaleFactor;
                elem.height = maxsize;
            }
            const ctx = elem.getContext(\'2d\');
            // img.width and img.height will contain the original dimensions
            ctx.drawImage(img, 0, 0, width, height);
            ctx.canvas.toBlob(function (blob) {
                const file = new File([blob], fileName, {
                    type: \'image/jpeg\',
                    lastModified: Date.now()
                });
                $(e.target).after("<span>Nouvelle taille : " + file.size.toString() +" octets</span>")
            }, \'image/jpeg\', 1);
            isImageCompressed = true;
        };
        reader.onerror = error => console.log(error);
    };
}
$("input[type=file]").on("change", function (e) {

    var oldsize = e.target.files[0].size;
     if(e.target.files[0].size > Math.pow(2048, 3)) {
         compress(e);
         $(e.target).after("<span>Ancienne taille : " + oldsize.toString() +" octets</span>");
     } else {
         isImageCompressable = false;
     }
     var uploadInterval = null;
     
     
     if ( e.target.files[0].size < '.$maxsize.')
        uploadInterval = setInterval(function () {
         if(isImageCompressed === true || isImageCompressable === false ) {
             $("#fileupdate").append("<input type=\'hidden\' name=\'uploadimage\' value=\'On\'/>").submit();
             clearInterval(uploadInterval);
         }
         
        }, 1000);
    else
        alert ("fichier trop volumineux");

});
</script>';
print '</form>';






// End of page
llxFooter();
$db->close();
