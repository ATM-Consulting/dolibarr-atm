<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}


// Action to add record
if ($action == 'add'  && !empty($permissiontoadd))
{
	if( GETPOST('add') == 'Créer' or GETPOST('add') == "Create" ){
		foreach ($object->fields as $key => $val)
		{
			if ($object->fields[$key]['type'] == 'duration') {
				if (GETPOST($key.'hour') == '' && GETPOST($key.'min') == '') continue; // The field was not submited to be edited
			}
			else {
				if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
			}
			// Ignore special fields
			if (in_array($key, array('rowid', 'entity', 'date_creation', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

			// Set value to insert
			if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
				$value = GETPOST($key, 'none');
			} elseif ($object->fields[$key]['type'] == 'date') {
				$value = dol_mktime(12, 0, 0, GETPOST($key.'month', 'int'), GETPOST($key.'day', 'int'), GETPOST($key.'year', 'int'));
			} elseif ($object->fields[$key]['type'] == 'datetime') {
				$value = dol_mktime(GETPOST($key.'hour', 'int'), GETPOST($key.'min', 'int'), 0, GETPOST($key.'month', 'int'), GETPOST($key.'day', 'int'), GETPOST($key.'year', 'int'));
			} elseif ($object->fields[$key]['type'] == 'duration') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
				$value = price2num(GETPOST($key, 'none')); // To fix decimal separator according to lang setup
			} else {
				$value = GETPOST($key, 'alpha');
			}
			if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
			if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

			//var_dump($key.' '.$value.' '.$object->fields[$key]['type']);
			$object->$key = $value;
			if ($val['notnull'] > 0 && $object->$key == '' && !is_null($val['default']) && $val['default'] == '(PROV)')
			{
				$object->$key = '(PROV)';
			}
			if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
			{
				$error++;
				setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
			}
		}
		// on update le type client dans la fiche tiers (extrafields)
		$cara_typeclient=GETPOST('cara_typeclient'); // champ obligatoire
		$cara_typeclient_ctm=GETPOST('cara_typeclient_ctm'); // champ obligatoire
		if($cara_typeclient>0)
			$res=$object->update_cara_typeclient($cara_typeclient);
		else{
			setEventMessages('Precarité obligatoire', null, 'errors');
			$action = 'create';
			$error++;
		}
		if($cara_typeclient_ctm>0)
			$res=$object->update_cara_typeclient($cara_typeclient_ctm,'_ctm');

		if (!$error)
		{
			$result = $object->create($user);
			if ($result > 0)
			{
				// Creation OK
				/*$urltogo = $backtopage ? str_replace('__ID__', $result, $backtopage) : $backurlforlist;
				$urltogo = preg_replace('/--IDFORBACKTOPAGE--/', $object->id, $urltogo); // New method to autoselect project after a New on another form object creation
				header("Location: ".$urltogo);
				exit;*/
				$urltogo = dol_buildpath('deviscaraiso/card.php?action=create_documents',1).'&fk_soc='.GETPOST('fk_soc') . "&type=" . GETPOST("label"). "&id=" . $object->id;
				header("Location: ".$urltogo);
			}
			else
			{
				// Creation KO
				if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
				else  setEventMessages($object->error, null, 'errors');
				$action = 'create';
			}

			
		}
		else
		{
			$action = 'create';
		}
	}
	else{//reload avec la mise à jour du fk_soc
		$urltogo = dol_buildpath('deviscaraiso/card.php?action=create',1).'&fk_soc='.GETPOST('fk_soc');
		header("Location: ".$urltogo);
	}
}

// Action to update record
if ($action == 'update' && !empty($permissiontoadd))
{
	$statusplanif_avantmaj=$object->planification;
	$statusedf2_avantmaj=$object->status_edf2;
	$statusedf_avantmaj=$object->status_edf;
	$statusmpr_avantmaj=$object->status_mpr;
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	


	//update commentaire sur fiche de pose
	include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaraiso/class/deviscarapos.class.php',1);
    $fich_pos=new Deviscarapos($db);

	$fich_pos->fk_devisiso=$object->id;
	$fich_pos->id=$fich_pos->getidposfromobject('iso');
	if($fich_pos->id>0){
		$fich_pos->description=GETPOST('description');;
		$fich_pos->updatecommentaire();
	}
	//update des etiquettes
	Deviscaraiso::update_etiquette(GETPOST('eventid'),GETPOST('etiquettes'));

	//update commentaire sur event
	require_once DOL_DOCUMENT_ROOT . "/comm/action/class/actioncomm.class.php";
	$event=new ActionComm($db);
	//vérifier si l'evennement existe déjà pour ce client là
	$res=$event->fetch('','',$fich_pos->id);
	$event->note_private=GETPOST('description');
	$event->update($user);
	if($statusplanif_avantmaj==$object::STATUSPLANIF_POSE && $user->rights->deviscaratoit->deviscaratoit->modifpose==0) //si objet déjà posé, il reste posé
		$object->planification=$object::STATUSPLANIF_POSE;
	
	$newstatus_edf=GETPOST('status_edf');
	if($newstatus_edf==9) {//status edf annulé
		$sql='update '.MAIN_DB_PREFIX.$object->table_element.' set status='.$object::STATUSPLANIF_CANCELED.' where rowid ='.$object->id;
		$resql = $db->query($sql);
	}
	if (!$error)
	{
		
		//update statut edf : Si planification posé statut edf posé
		$newstatus=GETPOST('planification');
		$newstatus_edf2=GETPOST('status_edf2');
		$newstatus_edf=GETPOST('status_edf');
		$newstatus_mpr=GETPOST('status_mpr');
		if($statusplanif_avantmaj != $newstatus && $statusplanif_avantmaj!=$object::STATUSPLANIF_POSE ){
			$object->{'date_planif_'.$newstatus} = dol_now(); //date de changement de planification
			$object->status_mprop=$object::STATUSMPROP_ENCOURS;
			$object->status_edfop=$object::STATUSMPROP_ENCOURS;
			if($newstatus==$object::STATUSPLANIF_POSE ){
				$object->status_edf=2;// mise à jour du statut edf à posé dans le tableau edf
				$object->status_mprop=$object::STATUSMPROP_POSE;
				$object->status_edfop=$object::STATUSMPROP_POSE;
			}
			if($newstatus==$object::STATUSPLANIF_CANCELED ){
				$object->status_edf=9;
				$object->status_mprop=$object::STATUSMPROP_ANNULE;
				$object->status_edfop=$object::STATUSMPROP_ANNULE;
			}
			if($newstatus==$object::STATUSPLANIF_IMPOSSIBLE ){
				$object->status_edf=10;
			}
			if($newstatus==$object::STATUSPLANIF_INCOMPLET ){//mise à jour du statut edf si incomplet
				$object->status_edf=8;
			}
			if($newstatus==$object::STATUSPLANIF_PRIME ){//mise à jour du statut_cee dans edf
				$object->status_cee=$object::STATUSCEE_SANS;
				$object->status_edf=$object::STATUSPLANIF_PRIME;
			}	
			if($newstatus==$object::STATUSPLANIF_PACK ){//si planification=ATF alors status_op = atf
				$object->status_mprop=$object::STATUSMPROP_ATF;
				$object->status_edfop=$object::STATUSMPROP_ATF;
			}
		}
		if($statusedf_avantmaj != $newstatus_edf){//si modification du status edf
			$object->{'date_edf_'.$newstatus_edf} = dol_now(); //date de changement de statut
			if($newstatus_edf==9) {//status edf annulé
				$object->status=$object::STATUSPLANIF_CANCELED;
			}
			if($newstatus_edf==$object::STATUSPLANIF_PRIME) {//status edf annulé
				$object->status=$object::STATUSPLANIF_PRIME;
			}
		}
		if($statusedf2_avantmaj != $newstatus_edf2){//si modification du status pré-etat
			$object->{'date_edf2_'.$newstatus_edf2} = dol_now(); //date de changement de statut
			if($newstatus_edf2==4 || $newstatus_edf2==1) {
				$object->status_cee=$object::STATUSCEE_PREVU;
				$object->date_cee_3 = dol_now();
			}
			if($newstatus_edf2==2 ) {
				$object->status_cee=$object::STATUSCEE_CEE;
				$object->date_cee_2 = dol_now();
			}
			if($newstatus_edf2==6 ) {
				$object->status_cee=$object::STATUSCEE_SANS;
				$object->date_cee_1 = dol_now();
			}
		}
		if($statusmpr_avantmaj != $newstatus_mpr ){
			$object->{'date_mpr_'.$newstatus_mpr} = dol_now(); //date de changement de mpr
			$object->{'date_mpr_etat'} = dol_now(); //date de changement d'état du status actuel
		}
		
		$result = $object->update($user);
		
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
}

// Action to update one extrafield
if ($action == "update_extras" && !empty($permissiontoadd))
{
	$object->fetch(GETPOST('id', 'int'));

	$attributekey = GETPOST('attribute', 'alpha');
	$attributekeylong = 'options_'.$attributekey;
	$object->array_options['options_'.$attributekey] = GETPOST($attributekeylong, ' alpha');

	$result = $object->insertExtraFields(empty($triggermodname) ? '' : $triggermodname, $user);
	if ($result > 0)
	{
		setEventMessages($langs->trans('RecordSaved'), null, 'mesgs');
		$action = 'view';
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
		$action = 'edit_extras';
	}
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

// Remove a line
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
			$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}

		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action validate object
//if ($action == 'confirm_validate' && $confirm == 'yes' && $permissiontoadd)
if ($action == 'updateline' )
{
	$result = $object->validate($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			//$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action close object
if ($action == 'confirm_close' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->cancel($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action setdraft object
if ($action == 'confirm_setdraft' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->setDraft($user);
	if ($result >= 0)
	{
		// Nothing else done
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

if ($action == 'change_devis')
{
	$result = $object->setDevis($user);
	if ($result >= 0)
	{
		// Nothing else done
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}
if ($action == 'change_bc')
{
	$result = $object->setBc($user);
	if ($result >= 0)
	{
		// Nothing else done
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}
// Action reopen object
if ($action == 'confirm_reopen' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->reopen($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}


