<?php

$planifier_pose=GETPOST('planifier_pose');
if($planifier_pose){
    $date_planif=GETPOST('date_planif');
    $fk_user_pos=GETPOST('fk_user_pos','int');
   
    //creation fiche de pose
    if(count($date_planif) >= 1 && $fk_user_pos > 0){
        $date_planifyear=GETPOST('date_planifyear');
        $date_planifmonth=GETPOST('date_planifmonth');
        $date_planifday=GETPOST('date_planifday');
        $date_planifhour=GETPOST('date_planifhour');
        $date_planifmin=GETPOST('date_planifmin');
       
        include_once DOL_DOCUMENT_ROOT.dol_buildpath('deviscaraiso/class/deviscarapos.class.php',1);
        $fich_pos=new Deviscarapos($db);

        $fich_pos->fk_devisiso=$object->id;
        $fich_pos->fk_user_pos=$fk_user_pos;
        $date_planif=new DateTime($date_planifyear.'-'.$date_planifmonth.'-'.$date_planifday.' '.$date_planifhour.':'.$date_planifmin);
        $fich_pos->date_planif=$date_planif->getTimestamp();
        $fich_pos->description=$object->description;
        $fich_pos->fk_soc=$object->thirdparty->id;
        $fich_pos->status=Deviscarapos::STATUS_DRAFT;
        //si pas de date avant de renseigné on crée la fiche de pose
        $res=$fich_pos->check_exist(1);
        if(is_object($res) ){
            $date= new DateTime('now');
            $max_date_planif=new DateTime ($res->date_planif);
            $interv=$date->diff($max_date_planif);
            if($interv->invert ==0){
                $fich_pos->id=$res->rowid;
                $res=$fich_pos->update_dateplanif($user);
                setEventMessages("Fiche pose déjà existante", 'Mise à jour de la date de planification ', 'mesgs');
                //header("Location: ".dol_buildpath('/deviscaraiso/card_poseur.php',1).'?id='.$fich_pos->id);
                //header("Location: ".dol_buildpath('comm/action/index.php',1).'?userid='.$object->fk_user_pos);
                // header("Location: ".dol_buildpath('deviscaraiso/card.php',1).'?id='.$fich_pos->id.'&action=edit');
                // exit;
            }
            else{
                $fich_pos->ref=$fich_pos->getNextNumRef();
                $id=$fich_pos->create($user);
            }
        }
        else{
            $fich_pos->ref=$fich_pos->getNextNumRef();
            $id=$fich_pos->create($user);
        }

        $m2=GETPOST('qty');
        // $realisation=GETPOST('realisation');
        // $imperatif=GETPOST('imperatif'); 
    
         $sql="UPDATE ".MAIN_DB_PREFIX.$fich_pos->table_element_line;
         $sql .= ' set qty="'.$m2.'"';
         $sql .= ' where fk_deviscarapos='.$id.'';
         $sql .= ' and options=18'; //pour l'iso et en m2
         $res = $db->query($sql);
    
        // $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
        // $sql .= ' set qty="'.$realisation.'"';
        // $sql .= ' where fk_deviscarapos='.$id.'';
        // $sql .= ' and options=20'; //pour la trappe
        // $res = $db->query($sql);
        
        // $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
        // $sql .= ' set qty="'.$imperatif.'"';
        // $sql .= ' where fk_deviscarapos='.$id.'';
        // $sql .= ' and options=21'; //Client impératif
        // $res = $db->query($sql);
        
        { //on crée le rendez vous pour le poseur
    
            $date_planification=$object->date_planif;
            $fk_user_pos=$object->fk_user_pos;
            if($date_planification && $fk_user_pos > 0){
                $description=$object->description;
                $date_planif=new DateTime();
                $date_planif->setTimestamp($date_planification);
        
                require_once DOL_DOCUMENT_ROOT . "/custom/agendaplus/class/etat_actioncomm.class.php";
                $event=new ActionComm($db);
                $event->userownerid=$fk_user_pos;
                //$event->datep=$date_planif->format('Y-m-d H:i:s');
                $event->datep=$date_planif->getTimestamp();
                $date_planif->add(new DateInterval('PT1H'));
                //$event->datef=$date_planif->format('Y-m-d H:i:s');
                $event->datef=$date_planif->getTimestamp();
                $event->fk_soc=$object->fk_soc;
                
        
                //vérifier si l'evennement existe déjà pour ce client là
                //$res=$event->fetch('','',$object->id);
                //if($res){
                    
                  //  $event->update($user);
                    //setEventMessages("Evennement Modifié dans le calendrier du poseur", null, 'mesgs');
                //}
                //else
                {
                    $event->entity=1;
                    $event->fk_parent=0;
                    $event->fulldayevent=0;
                    $event->punctual=1;
                    $event->percent=-1;
                    $event->label="Pose ".strtoupper($object->ext)." chez le client";
                    
                    $event->note=$description;
                    $event->type_id=5;
                    $event->socid=$object->fk_soc;
                    $id_event=$event->create($user);
                    $fich_pos->update_refext($id_event);
                    setEventMessages("Evennement créé dans le calendrier du poseur", null, 'mesgs');
                }
        
                
        
                $type_etat = new EvenementEtat($db);
                $statut = "Planifié";
                $etat_trouves = $type_etat->fetchAll("", "", 1000, "", array("customsql" => "name = '$statut'"));
                // On vérifie si on trouve bien un statut avec cette état la
                if(sizeof($etat_trouves) == 0) {
                    echo "Erreur : Etat non trouvé";
                    exit(-1);
                }
                $etat_planifie = array_shift($etat_trouves);
                $etat_evenement = new EtatActioncomm($db);
                $result = $etat_evenement->fetchByEvent($event->id);
                $etat_evenement->actioncomm_id = $event->id;
                $etat_evenement->etat_id = $etat_planifie->id;
                
                //Si l'état n'existe pas encore
                if($result == -1) {
                    $etat_evenement->create($user);
                }
                else {
                    $etat_evenement->update($user);
                }

                //mise à jour des etiquettes 
                if($event->id) $id_event=$event->id;
                $object->update_etiquette($id_event,GETPOST('etiquettes','array'));

            }
        }
        
        header("Location: ".dol_buildpath('comm/action/index.php',1).'?userid='.$object->fk_user_pos.'&day='.$date_planif->format("Y-m-d"));
    
    }
    else{
        setEventMessages("Date de planification ou poseur non renseigné", null, 'errors');
        header("Location: ".dol_buildpath('/deviscaraiso/card.php',1).'?id='.$id.'&action=edit');
    }


}

?>