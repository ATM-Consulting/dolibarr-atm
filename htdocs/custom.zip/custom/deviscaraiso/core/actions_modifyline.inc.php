<?php

if($action == "updateline" || $action == 'calcul_remise'){
    $addline=GETPOST('addline');
    
    if($addline!='Ajouter' && $action == 'calcul_remise'){
        $qty=GETPOST('qty','array');
        $amount=GETPOST('amount', 'array');
        $options=GETPOST('options', 'array');

        $db->begin();
        foreach($qty as $rowid=>$qtymaj){

            if($amount[$rowid]=='') $amount[$rowid]='NULL';
            if ($qtymaj=='') $qtymaj='NULL';
            $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
            $sql .= ' set qty='.$qtymaj.',amount='.price2num($amount[$rowid]).'';
            $sql .= ' where rowid='.$rowid.'';
            $res = $db->query($sql);
            $object->lines[$options[$rowid]-1]->amount=$amount[$rowid];
            $object->lines[$options[$rowid]-1]->qty=$qtymaj;
            if ($res === false) $error++;

            if($options[$rowid]==1){ //quantité de la première valeur à mettre à jour dans l'objet
                $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element;
                $sql .= ' set qty='.$qtymaj.'';
                $sql .= ' where rowid='.$object->id.'';
                $res = $db->query($sql);
            }
            
        }

        if($error<=0)
            $db->commit();
        else{
            $db->rollback();
            setEventMessages("Erreur de mise à jour", $db->lasterror(), 'errors');
            header("Location: " . $_SERVER['PHP_SELF'].'?id='.$object->id);
            exit;
        }
        

    }
    elseif($addline=='Ajouter'){
        $qty=GETPOST('div_qty','int');
        $label=GETPOST('dp_desc','alpha');
        $amount=GETPOST('div_totalttc','int');
        $object_id=GETPOST('id','int');
    
        $sql="INSERT into ".MAIN_DB_PREFIX.$object->table_element_line;
        $sql .= ' ( qty,label,amount, fk_deviscaraiso) values ('.$qty.', "'.$label.'",'.price2num($amount).','.$object_id.') ';
    
        $res = $db->query($sql);
        if ($res === false) {
            setEventMessages("Erreur de mise à jour", $db->lasterror(), 'errors');
            header("Location: " . $_SERVER['PHP_SELF'].'?id='.$object->id);
            exit;
        }


    }
    //mise àjour du commentaire
    $description=GETPOST('description');
    $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element;
    $sql .= ' set description="'.$description.'"';
    $sql .= ' where rowid='.$object->id;
    $res = $db->query($sql);
    if ($res === false) {
        setEventMessages("Erreur de mise à jour", $db->lasterror(), 'errors');
    }
}
$totalttc=$object->gettotalttc();
if ($action == 'modereglement' && $confirm=="yes"){
    //update mode règlement obligatoire 
    $mod_paiement=GETPOST('modreglement','int');
    $mod_paiement_quand=GETPOST('modreglementquand', 'int');
    $mod_paiement_qty=GETPOST('qty', 'int');
    $acompte=GETPOST('acompte', 'int');
    if($acompte=="") $acompte='NULL';
    if($mod_paiement && $mod_paiement_quand ){
        if(!isset($mod_paiement_qty) || $mod_paiement_qty=="") $mod_paiement_qty='NULL';//si especes qty non renseigné
        $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element;
        $sql .= ' set mod_paiement='.$mod_paiement.'';
        $sql.= ', mod_paiement_quand='.$mod_paiement_quand.'';
        $sql.= ', mod_paiement_qty='.$mod_paiement_qty.'';
        $sql.= ', acompte='.$acompte.'';
        $sql .= ' where rowid='.$object->id.'';
        $res = $db->query($sql);
        $action="";
    }
    else{
        setEventMessages("Modalité de paiements obligatoire", "", 'errors');
        $action="";
    }
}

if($action == 'calcul_remise'){
//on considère que le devis est validé, on recalcule la remise et le ttc
// donc total ttc= 1 euros + détolage+ trappe

    $totalttc=0;
    foreach($object->lines as $line){
        if($line->options !=6 )
            $totalttc+=$line->amount*$line->qty;
        if(in_array($line->options,array(3,4)) || $line->options == null)
            $non_remise+=$line->amount*$line->qty;
        if($line->options==6)// pour la remise
            $rowid=$line->id;
    }
    $remise=$totalttc-$non_remise-1;
    //update remise
    $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
    $sql .= ' set qty=-1,amount='.price2num($remise).', fk_user_modif='.$user->id;
    $sql .= ' where rowid='.$rowid.'';
    $res = $db->query($sql);
    
    $newtotalttc=$non_remise+1;
    //update ttc
    $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element;
	$sql .= ' set amount='.price2num($newtotalttc).'';
	$sql .= ' where rowid='.$object->id.'';
	$res = $db->query($sql);
}


?>