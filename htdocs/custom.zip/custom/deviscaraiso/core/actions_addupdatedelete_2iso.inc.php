<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}


// Action to add record


// Action to update record
if ($action == 'update' && !empty($permissiontoadd))
{
	$statusdiso_avmaj=$object->status_2iso;

	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	
	if (!$error)
	{
		if(GETPOST('fk_user_agenda')>0 && GETPOST('date_rdvday') >0  ){
			//création tableau rdv previsite
			dol_include_once('/carardv/class/rdv_prev.class.php');
			$rdvprev=new rdv($db);
			$rdvprev->fk_soc=$object->fk_soc;
			$rdvprev->description="Creation rdv à partir du tableau double Iso";
			$rdvprev->date_creation=dol_now();
			$rdvprev->fk_user_creat=$user->id;
			$rdvprev->status=$rdvprev::STATUS_PREVISITE;
			$object->status_2iso=$object::STATUSDISO_PREVISITE;
			$rdvprev->fk_comm=56;//vente direction
			$rdvprev->origine=12; //groupe chef direction
			$rdvprev->fk_user_agenda=GETPOST('fk_user_agenda');
			$key='date_rdv';
			$rdvprev->date_rdv=dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
			$id_rdv=$rdvprev->create($user);

			//création du rdv dans l'agenda
			$date_planif=new DateTime('@'.$rdvprev->date_rdv);
			require_once DOL_DOCUMENT_ROOT . "/custom/agendaplus/class/etat_actioncomm.class.php";
			$event=new ActionComm($db);
			$event->fk_soc=$object->fk_soc;
			$event->fk_element=$id_rdv;
			$event->elementtype='carardv_prev';

			//vérifier si l'evennement existe déjà pour ce client là
			$res=$event->getActions($db,$event->fk_soc,$event->fk_element,$event->elementtype);
			if($res){
				$event->fetch($res[0]->id);
				$event->userownerid=$rdvprev->fk_user_agenda ;
				$event->datep=$date_planif->getTimestamp();
				$date_planif->add(new DateInterval('PT1H'));
				//$event->datef=$date_planif->format('Y-m-d H:i:s');
				$event->datef=$date_planif->getTimestamp();
			
				$event->update($user);
				setEventMessages("Evennement Modifié dans l agenda", null, 'mesgs');
			}
			else
			{
				$event->entity=1;
				$event->fk_parent=0;
				$event->fulldayevent=0;
				$event->punctual=1;
				$event->percent=-1;
				$event->label="Rdv client";
				
				$event->note=$description;
				$event->type_id=5;
				$event->socid=$object->fk_soc;
				$event->userownerid=$rdvprev->fk_user_agenda ;
				$event->datep=$date_planif->getTimestamp();
				$date_planif->add(new DateInterval('PT1H'));
				$event->datef=$date_planif->getTimestamp();
			
				$id_event=$event->create($user);
				$evtetat=new EtatActioncomm($db);
				$evtetat->actioncomm_id=$id_event;
				$evtetat->etat_id=1;
				$res=$evtetat->create($user);
				if($res>0)
					setEventMessages("Evennement créé dans l agenda", null, 'mesgs');
				else
					setEventMessages("pb création rdv dans agenda", null, 'error');
			}
			
		}
		$result = $object->update($user);
		
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
}


