<?php
/* Copyright (C) 2017-2019  Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $action
 * $conf
 * $langs
 */

// Protection to avoid direct call of template
if (empty($conf) || !is_object($conf))
{
	print "Error, template page can't be called as URL";
	exit;
}
if (!is_object($form)) $form = new Form($db);

?>
<!-- BEGIN PHP TEMPLATE commonfields_edit.tpl.php -->
<?php

//$object->fields = dol_sort_array($object->fields, 'position');
$info=$object->get_info_commonfileds_edit();
print '<tr><td>Client:</td><td>'. $info['nom'] .'</td>';
if($user->rights->deviscaraiso->deviscaraiso->date_creation == 1)
	print'<td >Date Création:</td><td align="left">'.$object->showInputField($object->fields['date_creation'], 'date_creation', $object->date_creation, '', '', '', 0).'</td>';
$url_doc=dol_buildpath("deviscaraiso/card_doc.php", 1);	
print '<td>';
if(sizeof($missing_documents) != 0) {
	print '<div style="color: darkred"><p><span class="fa fa-exclamation-triangle"></span> <a style="color: darkred" href="'.$url_doc.'?action=create_documents&fk_soc='.$object->thirdparty->id.'&type=2&fk_object=deviscaraisolist&fk_objectid='.$object->id.'">Dossier incomplet</a>. les fichiers suivant sont manquants :</p>
			<ul>';
	foreach ($missing_documents as $family => $label) { 
		print'<li>'.$label.' </li>';
	} 
	print'</ul></div>';
} else { 
	print'<p style="color:dodgerblue"><a style="color: darkred" href="'.$url_doc.'?action=create_documents&fk_soc='.$object->thirdparty->id.'&type=2&fk_object=deviscaraisolist&fk_objectid='.$object->id.'">Dossier complet</a></p>';
} 
print'</td>';



print'</tr>';
if($user->rights->deviscaraiso->deviscaraiso->label == 1)
	print '<tr><td>Type:</td><td>'.$object->fields['label']['arrayofkeyval'][$object->label].'</td>';
if($user->rights->deviscaraiso->deviscaraiso->fk_usercomm_modif==1)
	print '<td >Commercial:</td><td align="left">'.$object->list_commerciaux($object->fk_usercomm,0).'</td>';
elseif($user->rights->deviscaraiso->deviscaraiso->fk_usercomm == 1)
	print '<td align="right">Commercial:</td><td align="left">'.$info['commercial'].'</td>';
print '<td >planification</td><td align="left">'.$object->showInputField($object->fields['planification'], 'planification', $object->planification, '', '', '', 0).'</td>';
print '<td >Date attente</td><td align="left">'.$object->showInputField($object->fields['date_attente'], 'date_attente', $object->date_attente, '', '', '', 0).'</td>';
	print'</tr>';
if($user->rights->deviscaraiso->deviscaraiso->date_planif == 1)
print '<tr>
		<td>Date intervention:</td><td>'.$object->showInputField($object->fields['date_planif'], 'date_planif', $object->date_planif, '', '', '', 0).'</td>
		<td>Poseur:</td><td>'.$object->list_poseurs($object->fk_user_pos).'</td>
		<td >Facture poseur : </td><td>'.$object->showInputField($object->fields['fposeur'], 'fposeur', $object->fposeur, '', '', '', 0,'maxwidth5').'</td>
	</tr>';
print '<tr><td>M2 vendus</td><td>'.$object->showInputField($object->fields['qty'], 'qty', $object->qty, '', '', '', 0).'</td><td>'.$object->showInputField($object->fields['s_type'], 's_type', $object->s_type, '', '', '', 0).'</td>
</tr>';
print '<tr><td colspan=10 bgcolor="419EE2">Commentaire général</td></tr>';
print '<tr><td>Commentaire:</td><td>'.$object->showInputField($object->fields['description'], 'description', $object->description, '', '', '', 0).'</td>';
if($user->rights->deviscaraces->deviscaraces->fposeur == 1)
	print'<td></td><td></td>';
print'</tr>';

print '<tr><td colspan=10 bgcolor="#B04FA9">Etiquettes</td></tr></table>';
print '<table class="border  tableforfieldcreate">'."\n";




require_once DOL_DOCUMENT_ROOT . "/custom/agendaplus/class/evenement_etiquette.class.php";
require_once DOL_DOCUMENT_ROOT . "/custom/interventioncara/lib/interventioncara.lib.php";


new EvenementEtiquette($db);
$etiquettes = EvenementEtiquette::fetchAllEtiquettes($db);
$event=new ActionComm($db);
$idfichpose=$object->getidfichpose();
$event->fetch('','',$idfichpose);
$select_etiq=Deviscaraisotoit::getselectetiquettefromevent($event->id);

print '</table><input type="hidden" name="eventid" value="'.$event->id.'"><table><tr>';
foreach ($etiquettes as $key=>$etiquette) { 
	//'.$etiquettes->hasEtiquette($intervention, $etiquette) ? "checked" : " " .'
	if(in_array($etiquette->id,$select_etiq)) 
		$checked='checked';
	else $checked='';
	
	
	print'<td ><input type="checkbox" name="etiquettes[]" value="'.$etiquette->id.'" id="etiquette '.$etiquette->id.'" '.$checked.' >';
	print '<label for="etiquette '.$etiquette->id.'>"><span class="fa fa-'.$etiquette->icontitle.'" style="margin-right: 3px; color: '.$etiquette->color.'"></span>'.$etiquette->label.'</label></td>';
	if(($key%3)==0)
		print '</tr><tr>';
	
} 
print '</tr></table><br>';

print '<table class="border centpercent tableforfieldedit"><tr><td colspan=10 bgcolor="#FF5733">Zone EDF</td></tr>';
print'<tr>
		<td >Numéro edf : </td><td>'.$object->showInputField($object->fields['edf'], 'edf', $object->edf, '', '', '', 0,'maxwidth5').'</td>
		<td >Status Edf : </td><td>'.$object->showInputField($object->fields['status_edf'], 'status_edf', $object->status_edf, '', '', '', 0,'maxwidth5').'</td>';
print '</tr>';
print '<tr>
	<td >Numéro AF : </td><td>'.$object->showInputField($object->fields['af'], 'af', $object->af, '', '', '', 0,'maxwidth5').'</td>';
print'</tr>';
print '<tr>
	<td >Commentaire EDF : </td><td>'.$object->showInputField($object->fields['commentaire_edf'], 'commentaire_edf', $object->commentaire_edf, '', '', '', 0,'maxwidth5').'</td>
	<td >Pré Status EDF : </td><td>'.$object->showInputField($object->fields['status_edf2'], 'status_edf2', $object->status_edf2, '', '', '', 0,'maxwidth5').'</td>';
print'</tr>';
print '<tr>
				<td >Facture portail edf : </td><td>'.$object->showInputField($object->fields['numfac_edf'], 'numfac_edf', $object->numfac_edf, '', '', '', 0,'maxwidth5').'</td>';	
			print'</tr>';
print'</table>';

print '<table class="border centpercent tableforfieldedit"><tr><td colspan=10 bgcolor="#DCDF3E">Zone MPR</td></tr>';
print'<tr>
	<td align="right">Status mpr</td><td>'.$object->showInputField($object->fields['status_mpr'], 'status_mpr', $object->status_mpr, '', '', '', 0,'maxwidth5').'</td>
	<td align="right">Montant estimé</td> <td>'.$object->showInputField($object->fields['montant_estime_mpr'], 'montant_estime_mpr', $object->montant_estime_mpr, '', '', '', 0,'maxwidth5').'</td>
</tr>
<tr>
	<td align="right">Numéro mpr</td><td>'.$object->showInputField($object->fields['numero_mpr'], 'numero_mpr', $object->numero_mpr, '', '', '', 0,'maxwidth5').'</td>
	<td align="right">Numéro facture MPR</td><td>'.$object->showInputField($object->fields['numfacture_mpr'], 'numfacture_mpr', $object->numfacture_mpr, '', '', '', 0,'maxwidth5').'</td>
</tr>
<tr>
	<td align="right">Commentaire MPR : </td><td>'.$object->showInputField($object->fields['commentaire_mpr'], 'commentaire_mpr', $object->commentaire_mpr, '', '', '', 0,'maxwidth5').'</td>
	<td>Appel Téléphonique</td><td>'.$object->showInputField($object->fields['appel_mpr'], 'appel_mpr', $object->appel_mpr, '', '', '', 0).'</td>';
print '</tr>
<tr>
	<td align="right">Statut opérationnel : </td><td>'.$object->showInputField($object->fields['status_mprop'], 'status_mprop', $object->status_mprop, '', '', '', 0,'maxwidth5').'</td>
	<td>&nbsp;</td><td>&nbsp;</td>';
print '</tr></table>';

?>
<!-- END PHP TEMPLATE commonfields_edit.tpl.php -->
