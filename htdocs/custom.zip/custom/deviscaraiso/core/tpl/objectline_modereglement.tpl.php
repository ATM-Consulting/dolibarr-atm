<?php
/* Copyright (C) 2010-2013	Regis Houssin		<regis.houssin@inodbox.com>
 * Copyright (C) 2010-2011	Laurent Destailleur	<eldy@users.sourceforge.net>
 * Copyright (C) 2012-2013	Christophe Battarel	<christophe.battarel@altairis.fr>
 * Copyright (C) 2012       Cédric Salvador     <csalvador@gpcsolutions.fr>
 * Copyright (C) 2012-2014  Raphaël Doursenaud  <rdoursenaud@gpcsolutions.fr>
 * Copyright (C) 2013		Florian Henry		<florian.henry@open-concept.pro>
 * Copyright (C) 2017		Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $conf
 * $langs
 * $element     (used to test $user->rights->$element->creer)
 * $permtoedit  (used to replace test $user->rights->$element->creer)
 * $inputalsopricewithtax (0 by default, 1 to also show column with unit price including tax)
 * $outputalsopricetotalwithtax
 * $usemargins (0 to disable all margins columns, 1 to show according to margin setup)
 *
 * $type, $text, $description, $line
 */

// Protection to avoid direct call of template
if (empty($object) || ! is_object($object))
{
	print "Error, template page can't be called as URL";
	exit;
}

print "<!-- BEGIN PHP TEMPLATE objectline_title_modereglement.tpl.php -->\n";
print '<tr class=" nodrag nodrop">';
print '<td colspan=2 width=70% style="background-color: white;">&nbsp;</td>';
print '<td class="linecolqty left">';
print $form->selectarray('mod_paiement', $object->fields['mod_paiement']['arrayofkeyval'], $object->mod_paiement, $object->fields['mod_paiement']['notnull'], 0, 0, '', 1, 0, 0, '', '');
print '</td>';
print '<td class="linecolht ">';
print $form->selectarray('mod_paiement_quand', $object->fields['mod_paiement_quand']['arrayofkeyval'], $object->mod_paiement_quand, $object->fields['mod_paiement_quand']['notnull'], 0, 0, '', 1, 0, 0, '', '');
print'</td>';

print '<td class="linecolht ">';
if($object->mod_paiement==2){ //espèces
	$object->mod_paiement_qty=1;
	print '<input type="hidden" name="mod_paiement_qty" value="1" size=4>';
}
else{
	if ($object->mod_paiement_qty==0) $object->mod_paiement_qty='';
	print '<input type="text" name="mod_paiement_qty" value="'.$object->mod_paiement_qty.'" size=4>';
}
print'</td>';

print "</tr>\n";

if($object->status==Deviscaraiso::STATUS_VALIDATED ){
	print '<tr class=" nodrag nodrop">';
	print '<td colspan=2 width=70% style="background-color: white;">&nbsp;</td>';

	print '<td class="linecolht " colspan=3 >';
	$totalttc=$object->gettotalttc();
	$totalttc=str_replace(' ','',$totalttc);
	$periodic=$totalttc/$object->mod_paiement_qty;
	print 'Règlement en '.$object->mod_paiement_qty.' fois par '.$object->fields['mod_paiement']['arrayofkeyval'][$object->mod_paiement].' montant total de '.round($periodic).' Euros';
	print'</td>';

	print "</tr>\n";
}
print "<!-- END PHP TEMPLATE objectline_title_modereglement.tpl.php -->\n";
