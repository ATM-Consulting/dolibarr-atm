<?php
/* Copyright (C) 2010-2013	Regis Houssin		<regis.houssin@inodbox.com>
 * Copyright (C) 2010-2011	Laurent Destailleur	<eldy@users.sourceforge.net>
 * Copyright (C) 2012-2013	Christophe Battarel	<christophe.battarel@altairis.fr>
 * Copyright (C) 2012       Cédric Salvador     <csalvador@gpcsolutions.fr>
 * Copyright (C) 2012-2014  Raphaël Doursenaud  <rdoursenaud@gpcsolutions.fr>
 * Copyright (C) 2013		Florian Henry		<florian.henry@open-concept.pro>
 * Copyright (C) 2017		Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $conf
 * $langs
 * $dateSelector
 * $forceall (0 by default, 1 for supplier invoices/orders)
 * $element     (used to test $user->rights->$element->creer)
 * $permtoedit  (used to replace test $user->rights->$element->creer)
 * $senderissupplier (0 by default, 1 for supplier invoices/orders)
 * $inputalsopricewithtax (0 by default, 1 to also show column with unit price including tax)
 * $outputalsopricetotalwithtax
 * $usemargins (0 to disable all margins columns, 1 to show according to margin setup)
 * $object_rights->creer initialized from = $object->getRights()
 * $disableedit, $disablemove, $disableremove
 *
 * $type, $text, $description, $line
 */

// Protection to avoid direct call of template
if (empty($object) || !is_object($object))
{
	print "Error, template page can't be called as URL";
	exit;
}


global $forceall, $senderissupplier, $inputalsopricewithtax, $outputalsopricetotalwithtax;

$usemargins = 0;
if (!empty($conf->margin->enabled) && !empty($object->element) && in_array($object->element, array('facture', 'facturerec', 'propal', 'commande'))) $usemargins = 1;

if (empty($dateSelector)) $dateSelector = 0;
if (empty($forceall)) $forceall = 0;
if (empty($senderissupplier)) $senderissupplier = 0;
if (empty($inputalsopricewithtax)) $inputalsopricewithtax = 0;
if (empty($outputalsopricetotalwithtax)) $outputalsopricetotalwithtax = 0;

// add html5 elements
$domData  = ' data-element="'.$line->element.'"';
$domData .= ' data-id="'.$line->id.'"';
$domData .= ' data-qty="'.$line->qty.'"';
$domData .= ' data-product_type="'.$line->product_type.'"';


$coldisplay = 0; ?>
<!-- BEGIN PHP TEMPLATE objectline_view.tpl.php -->
<tr  id="row-<?php print $line->id?>" class="drag drop oddeven" <?php print $domData; ?> >
<?php if (!empty($conf->global->MAIN_VIEW_LINE_NUMBER)) { ?>
	<td class="linecolnum center"><?php $coldisplay++; ?><?php print ($i + 1); ?></td>
<?php } ?>
	<td class="linecoldescription minwidth300imp"><?php $coldisplay++; ?><div id="line_<?php print $line->id; ?>"></div>
<?php

$format = $conf->global->MAIN_USE_HOURMIN_IN_DATE_RANGE ? 'dayhour' : 'day';


{
	if ($type == 1) $text = img_object($langs->trans('Service'), 'service');
	else $text = img_object($langs->trans('Product'), 'product');

	
	$text .= ' <strong>'.$line->label.'</strong>';
	print $form->textwithtooltip($text, dol_htmlentitiesbr($line->description), 3, '', '', $i, 0, (!empty($line->fk_parent_line) ?img_picto('', 'rightarrow') : ''));
	
}


print '</td>';

?><td>&nbsp;</td>
<?
if($line->amount==null)  $amount="";
else $amount = round($line->amount,2);


print '<td class="right"><input type="text" class="flat right" size="5" id="amount['.$line->id.']" name="amount['.$line->id.']" value="'.$amount.'"';
if(in_array($line->options,array(3,4))) print ' readonly '; //si trappe ou détôlage
print '></td>';
?>

	<td class="linecolqty nowrap right"><?php $coldisplay++; ?>
<?php

if($line->options==1){// on met à jour le 2eme champ sur modification du premier.
	$nextid=$line->id+1;
	print '<script type="text/javascript">
	$(document).ready(function() {
		$(\'input[name="qty['.$line->id.']"]\').on ("change",function() {
			var amount1=$(\'input[name="amount['.$line->id.']"]\').val();
			var amount2=$(\'input[name="amount['.$nextid.']"]\').val();
			var qty2=$(\'input[name="qty['.$nextid.']"]\').val();
			var total1=amount1*$(this).val();
			var total2=amount2*$(this).val();

			$(\'input[name="qty['.$nextid.']"]\').val($(this).val());
			$(\'input[name="total['.$line->id.']"]\').val(total1);
			$(\'input[name="total['.$nextid.']"]\').val(total2);
		});
	});
	</script>' ;
}
if($line->options >=3){
	print '<script type="text/javascript">
	$(document).ready(function() {
		$(\'input[name="qty['.$line->id.']"]\').on ("change",function() {
			var amount1=$(\'input[name="amount['.$line->id.']"]\').val();
			var total1=amount1*$(this).val();
			$(\'input[name="total['.$line->id.']"]\').val(total1);
		});
	});
	</script>' ;
}

if($line->qty==null) $qty="";
else $qty = round($line->qty,2);
print '<input size="3" type="text" class="flat right" name="qty['.$line->id.']" id="qty['.$line->id.']" value="'.$qty.'">';
print '<input type="hidden" name="options['.$line->id.']" value="'.$line->options.'">';
print '</td>';
$total=$line->qty*$line->amount;
print '<td class="linecolht nowrap right" ><input size="5" type="text" class="flat right" readonly name="total['.$line->id.']" id="total['.$line->id.']" value="'.price($total).'">';	
print '</td>';
$coldisplay++;

{
	print '<td colspan="3"></td>';
	$coldisplay = $coldisplay + 3;
}

/*if ($action == 'selectlines') { ?>
	<td class="linecolcheck center"><input type="checkbox" class="linecheckbox" name="line_checkbox[<?php print $i + 1; ?>]" value="<?php print $line->id; ?>" ></td>
<?php //}*/

print "</tr>\n";

print "<!-- END PHP TEMPLATE objectline_view.tpl.php -->\n";
