<?php
/* Copyright (C) 2017-2019  Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $action
 * $conf
 * $langs
 */

// Protection to avoid direct call of template
if (empty($conf) || !is_object($conf))
{
	print "Error, template page can't be called as URL";
	exit;
}
if (!is_object($form)) $form = new Form($db);

?>
<!-- BEGIN PHP TEMPLATE commonfields_edit.tpl.php -->
<?php

dol_include_once('/carardv/class/rdv_prev.class.php','rdv');
$rdv=new rdv($db);
$info=$object->get_info_commonfileds_edit();
print '<tr><td>Client:</td><td>'. $info['nom'] .'</td>';
if($user->rights->deviscaraiso->deviscaraiso->date_creation == 1)
	print'<td >Date Création:</td><td align="left">'.$object->showInputField($object->fields['date_creation'], 'date_creation', $object->date_creation, '', '', '', 0).'</td>';
$url_doc=dol_buildpath("deviscaraiso/card_doc.php", 1);	
print '<td>';
print'</tr>';
print '<tr><td>Type:</td><td>'.$object->fields['label']['arrayofkeyval'][$object->label].'</td>';
print '<td >Commercial:</td><td align="left">'.$object->list_commerciaux($object->fk_usercomm,0).'</td>';
print '<tr><td colspan=10 bgcolor="#419EE2">Commentaire général + Parametres D-ISO</td></tr>';
print '<tr><td>Commentaire:</td><td>'.$object->showInputField($object->fields['description'], 'description', $object->description, '', '', '', 0).'</td>';
print'<td>Status D-ISO</td><td>'.$object->showInputField($object->fields['status_2iso'], 'status_2iso', $object->status_2iso, '', '', '', 0).'</td>';
print'</tr>';

print '<tr>';
print'<td>Status Planification</td><td>'.$object->showInputField($object->fields['planification'], 'planification', $object->planification, '', '', '', 0).'</td>';
print'</tr>';

print '<tr><td colspan=10 bgcolor="#43954D">Saisie rendez vous agenda</td></tr>';
print '<tr><td>Nom du technicien</td><td>'.$rdv->showInputField($rdv->fields['fk_user_agenda'], 'fk_user_agenda', $rdv->fk_user_agenda, '', '', '', 0).'</td><td>Date et heure</td><td>'.$rdv->showInputField($rdv->fields['date_rdv'], 'date_rdv', $rdv->date_rdv, '', '', '', 0).'</td>';

print '</table>';

?>
<!-- END PHP TEMPLATE commonfields_edit.tpl.php -->
