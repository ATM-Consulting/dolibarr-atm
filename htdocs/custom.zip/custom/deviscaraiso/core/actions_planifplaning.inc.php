<?php
if($action=='planification'){
    //enregistrement des infos dans la fiche de pose

    $trappe=GETPOST('trappe');
    $realisation=GETPOST('realisation');
    $imperatif=GETPOST('imperatif'); 

    $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
    $sql .= ' set qty="'.$trappe.'"';
    $sql .= ' where fk_deviscarapos='.$id.'';
    $sql .= ' and options=19'; //pour la trappe
    $res = $db->query($sql);

    $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
    $sql .= ' set qty="'.$realisation.'"';
    $sql .= ' where fk_deviscarapos='.$id.'';
    $sql .= ' and options=20'; //pour la trappe
    $res = $db->query($sql);
    
    $sql="UPDATE ".MAIN_DB_PREFIX.$object->table_element_line;
    $sql .= ' set qty="'.$imperatif.'"';
    $sql .= ' where fk_deviscarapos='.$id.'';
    $sql .= ' and options=21'; //Client impératif
    $res = $db->query($sql);
    
    { //on crée le rendez vous pour le poseur

        $date_planification=$object->date_planif;
        $fk_user_pos=$object->fk_user_pos;
        if($date_planification && $fk_user_pos > 0){
            $description=$object->get_devis_description();
            $date_planif=new DateTime();
            $date_planif->setTimestamp($date_planification);
    
            require_once DOL_DOCUMENT_ROOT . "/comm/action/class/actioncomm.class.php";
            $event=new ActionComm($db);
            $event->userownerid=$fk_user_pos;
            //$event->datep=$date_planif->format('Y-m-d H:i:s');
            $event->datep=$date_planif->getTimestamp();
            $date_planif->add(new DateInterval('PT1H'));
            //$event->datef=$date_planif->format('Y-m-d H:i:s');
            $event->datef=$date_planif->getTimestamp();
            $event->fk_soc=$object->fk_soc;
            
    
            //vérifier si l'evennement existe déjà pour ce client là
            $res=$event->fetch('','',$object->id);
            if($res){
                
                $event->update($user);
                setEventMessages("Evennement Modifié dans le calendrier du poseur", null, 'mesgs');
            }
            else{
                $event->entity=1;
                $event->fk_parent=0;
                $event->fulldayevent=0;
                $event->punctual=1;
                $event->percent=-1;
                $event->label="Pose ".strtoupper($object->ext)." chez le client";
                
                $event->note=$description;
                $event->type_id=5;
                $event->socid=$object->fk_soc;
                $id_event=$event->create($user);
                $object->update_refext($id_event);
                setEventMessages("Evennement créé dans le calendrier du poseur", null, 'mesgs');
            }
    
            
    
            $type_etat = new EvenementEtat($db);
            $statut = "Planifié";
            $etat_trouves = $type_etat->fetchAll("", "", 1000, "", array("customsql" => "name = '$statut'"));
            // On vérifie si on trouve bien un statut avec cette état la
            if(sizeof($etat_trouves) == 0) {
                echo "Erreur : Etat non trouvé";
                exit(-1);
            }
            $etat_planifie = array_shift($etat_trouves);
            $etat_evenement = new EtatActioncomm($db);
            $result = $etat_evenement->fetchByEvent($event->id);
            $etat_evenement->actioncomm_id = $event->id;
            $etat_evenement->etat_id = $etat_planifie->id;
            
            //Si l'état n'existe pas encore
            if($result == -1) {
                $etat_evenement->create($user);
            }
            else {
                $etat_evenement->update($user);
            }
        }
    }
    
    header("Location: ".dol_buildpath('comm/action/index.php',1).'?userid='.$object->fk_user_pos.'&day='.$date_planif->format("Y-m-d"));
}



?>