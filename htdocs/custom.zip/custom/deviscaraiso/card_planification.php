<?php
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

dol_include_once('/deviscaraiso/class/deviscarapos.class.php');
dol_include_once('/deviscaraiso/class/deviscaraiso.class.php');

$id = GETPOST('id', 'int');
$action = GETPOST('action', 'aZ09');
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');

$object=new Deviscarapos($db);
$object->fetch($id);
/*
 * Actions
 */

include DOL_DOCUMENT_ROOT.dol_buildpath('deviscaraiso/core/actions_planifplaning.inc.php',1);


llxHeader('', $langs->trans('Deviscarapos'), '');


	print load_fiche_titre($langs->trans("Fiche de planification", $langs->transnoentitiesnoconv("planification")));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
    print '<input type="hidden" name="action" value="planification">';
    print '<input type="hidden" name="id" value="'.GETPOST('id','int').'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');

	print '<table class="border  tableforfieldcreate">'."\n";
    $tab=$object->getinfos_planif(1);
    // Common attributes
    $selectrappe='<select name="trappe">';
    if($tab[19]=="Oui") $seloui='selected';
    if($tab[19]=="Non") $selnon='selected';
    $selectrappe.='<option value="" '.$sel.' ></option>';
    $selectrappe.='<option value="Oui" '.$seloui.' >Oui</option>';
    $selectrappe.='<option value="Non" '.$selnon .' >Non</option>';
    $selectrappe.='</select>';
    $realisation='<select name="realisation">';
    if($tab[20]=="N/A") $selna='selected';
    if($tab[20]=="Trappe") $seltrappe='selected';
    if($tab[20]=="Détolage") $seldetol='selected';
    
    $realisation.='<option value="N/A" '.$selna.' >N/A</option>';
    $realisation.='<option value="Trappe" '.$seltrappe.'>Trappe</option>';
    $realisation.='<option value="Détolage" '.$seldetol.'>Détôlage</option>';
    $realisation.='</select>';
    if($tab[21]=="Oui") $selimpe='checked';
    $imperatif='<input type="radio" name="imperatif" value="Oui" '.$selimpe.'>';
    
    

    print '<tr><td>Trappe:</td><td>'.$selectrappe.'</td></tr>';
    print '<tr><td>Si pas de trappe</td><td>'.$realisation.'</td></tr>';
    print '<tr><td>Client impératif</td><td>'.$imperatif.'</td></tr>';
    
	
	print '</table>'."\n";

	dol_fiche_end();

	print '<div class="left">';
	print '<input type="submit" class="button" name="add" value="'.dol_escape_htmltag($langs->trans("Valider")).'">';
	print '&nbsp; ';
	print '<input type="'.($backtopage ? "submit" : "button").'" class="button" name="cancel" value="'.dol_escape_htmltag($langs->trans("Cancel")).'"'.($backtopage ? '' : ' onclick="javascript:history.go(-1)"').'>'; // Cancel for create does not post form if we don't know the backtopage
	print '</div>';

    print '</form>';
    
    ?>