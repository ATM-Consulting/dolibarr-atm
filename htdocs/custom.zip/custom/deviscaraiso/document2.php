<?php
require_once "../../main.inc.php";
llxHeader();
dol_fiche_head();
include_once DOL_DOCUMENT_ROOT . "/custom/caradocuments/table.php";
dol_fiche_end();
llxFooter();