<?php


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
include_once DOL_DOCUMENT_ROOT . dol_buildpath("caradocuments/data/cara_document.class.php", 1);

// Load translation files required by the page
$langs->loadLangs(array("mymodule@mymodule", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'myobjectcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$type=      GETPOST('type','int');
$fk_objectid = GETPOST('fk_objectid','int');
$fk_object = GETPOST('fk_object');
$fk_soc=GETPOST('fk_soc','int');

// Initialize technical objects
$object = new CaraDocument($db);
$extrafields = new ExtraFields($db);

$object->fk_soc=$fk_soc;

//$diroutputmassaction = $conf->mymodule->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('myobjectcard', 'globalcard')); // Note that conf->hooks_modules contains array

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

$form = new Form($db);
$formfile = new FormFile($db);

/*
 * Actions
 */
include_once DOL_DOCUMENT_ROOT . dol_buildpath("caradocuments/insert_doc.php", 1);



/*
 * View
 *
 * Put here all code to build page
 */


$usergroup=new UserGroup($db);
$tab_group=$usergroup->listGroupsForUser($user->id);
if(count($tab_group)>0){
    foreach ($tab_group as $group){
        if (in_array($group->id, array(1))){// si le user appartient au groupe des commerciaux (id=1)
            $groupe_famille=array(
                 "Documents Commerciaux"  => array('identite'=>"PI",'bondecommande'=>'BC',
                                                    'facture'=>"EDF",'rib'=>"RIB",
                                                    'impot'=>"AI","assurance"=>"ASH",
                                                    "photochantier"  => "Photos","docscomplementaires"=>"+"),
            
            );
            
        }
        elseif (in_array($group->id, array(3))){// si le user appartient au groupe des poseurs(iso)
            $groupe_famille=array(
                "Documents Administratifs"  => array('facture'=>"Facture EDF / Certificat d'adressage",'identite'=>"Pièce d'identité",'adresse'=>"Justificatif d'adresse (optionnel)",'impot'=>"Avis d'imposition"
                ,'rib'=>"RIB",'tf'=>"Taxe Fonciere / titre propriete","livretfamille" => "Livret de Famille","photochantier"  => "Photo chantier", "bondecommande" => "Bon de commande","assurance"=>"Assurance habitation"),
                "Documents ISO"             => array("pos_sacs"=> "Photos Sacs","pos_avantcht" =>   "Photos avant chantier", "pos_aprescht"=>    "Photos après chantier"),
            
            );
            
        }
        elseif (in_array($group->id, array(2))){// si le user appartient au groupe des poseurs(ces)
            $groupe_famille=array(
                "Documents Administratifs"  => array('facture'=>"Facture EDF / Certificat d'adressage",'identite'=>"Pièce d'identité",'adresse'=>"Justificatif d'adresse (optionnel)",'impot'=>"Avis d'imposition"
                                                ,'rib'=>"RIB",'tf'=>"Taxe Fonciere / titre propriete","livretfamille" => "Livret de Famille","photochantier"  => "Photo chantier", "bondecommande" => "Bon de commande","assurance"=>"Assurance habitation"),
                
                "Documents CES"             => array("ces" =>   "Photos chauffeau","ns"=>    "Photo Numéro de série", "hydro"=>        "Photos Hydraulique",),
            
            );
            
        }
        elseif (in_array($group->id, array(5))){// si le user appartient au groupe des poseurs(rep)
            $groupe_famille=array(
                "Documents Administratifs"  => array('facture'=>"Facture EDF / Certificat d'adressage",'identite'=>"Pièce d'identité",'adresse'=>"Justificatif d'adresse (optionnel)",'impot'=>"Avis d'imposition"
                                                ,'rib'=>"RIB",'tf'=>"Taxe Fonciere / titre propriete","livretfamille" => "Livret de Famille","photochantier"  => "Photo chantier", "bondecommande" => "Bon de commande","assurance"=>"Assurance habitation"
                                                ,"rep_faceau"=>        "Facture d'eau","rep_dmep"=>        "Déclaration Mairie Eau de Pluie", "rep_dossier"=>      "Dossier REP",),
                
                "Photos Installation REP"             => array("rep_dalles" =>   "Photos Dalle",
                                                        "rep_cuve"=>    "Photo cuve", 
                                                        "rep_crap"=>        "Photos crapaudine",
                                                        "rep_goutiere"=>        "Photos goutiere + surverse",
                                                        "rep_pompe"=>        "Photos pompe installée",
                                                        "rep_gamm"=>        "Photos GAM trop plein",
                                                        "rep_puisage"=>        "Photos puisage+signalisation",
                                                        "rep_wc"=>        "Photos wc+signalisation",
                                                        "rep_fsp"=>        "Photos Filtres Duo",
                                                        "rep_compteur_eau"=>        "Photos compteur eau",
                                                        "rep_uv"=>        "Photos uv+signalisation",
                                                        "rep_elec"=>        "Photos Installation Electrique",
                                                        
                                                    ),
            
            );
            
        }
        elseif (in_array($group->id, array(4))){// si le user appartient au groupe des adminsistratifs
            $groupe_famille=array(
                "Documents Administratifs"  => array('facture'=>"Facture EDF / Certificat d'adressage",'identite'=>"Pièce d'identité",'adresse'=>"Justificatif d'adresse (optionnel)",'impot'=>"Avis d'imposition"
                                                ,'rib'=>"RIB",'tf'=>"Taxe Fonciere / titre propriete","livretfamille" => "Livret de Famille","photochantier"  => "Photo chantier", "bondecommande" => "Bon de commande","assurance"=>"Assurance habitation","docscomplementaires"=>"+"),
                "Documents ISO"             => array("pos_sacs"=> "Photos Sacs","pos_avantcht" =>   "Photos avant chantier", "pos_aprescht"=>    "Photos après chantier","docscomplementaires"=>"+"
                ,"rep_faceau"=>        "Facture d'eau","rep_dmep"=>        "Déclaration Mairie Eau de Pluie", "rep_dossier"=>      "Dossier REP",),
            
                "Documents CES"             => array("ces" =>   "Photos chauffeau","ns"=>    "Photo Numéro de série", "hydro"=>        "Photos Hydraulique",),
            
                "Photos Installation REP"             => array("rep_dalles" =>   "Photos Dalle","rep_cuve"=>    "Photo cuve", "rep_crap"=>        "Photos crapaudine","rep_goutiere"=>        "Photos goutiere + surverse","rep_pompe"=>        "Photos pompe installée",
                                                    "rep_gamm"=>        "Photos GAM trop plein","rep_puisage"=>        "Photos puisage+signalisation","rep_wc"=>        "Photos wc+signalisation","rep_fsp"=>        "Photos Filtres Duo",
                                                    "rep_compteur_eau"=>        "Photos compteur eau","rep_uv"=>        "Photos uv+signalisation","rep_elec"=>        "Photos Installation Electrique",
                                                    
            ),
            
                "Documents Toiture"         => array("toit_mesure" =>   "Photos Mesures/Visite" , "toit_chantier"=>    "Photos Chantier"),
            
            );
            
        }
        else{
            $groupe_famille=array(
                "Documents Administratifs"  => array('facture'=>"Facture EDF / Certificat d'adressage",'identite'=>"Pièce d'identité",'adresse'=>"Justificatif d'adresse (optionnel)",'impot'=>"Avis d'imposition"
                                                ,'rib'=>"RIB",'tf'=>"Taxe Fonciere / titre propriete","livretfamille" => "Livret de Famille","photochantier"  => "Photo chantier", "bondecommande" => "Bon de commande","assurance"=>"Assurance habitation","docscomplementaires"=>"+",
                                                 "rep_faceau"=>        "Facture d'eau","rep_dmep"=>        "Déclaration Mairie Eau de Pluie","rep_dossier"=>      "Dossier REP",),
                "Documents ISO"             => array("pos_sacs"=> "Photos Sacs","pos_avantcht" =>   "Photos avant chantier", "pos_aprescht"=>    "Photos après chantier"),
            
                "Documents CES"             => array("ces" =>   "Photos chauffeau","ns"=>    "Photo Numéro de série", "hydro"=>        "Photos Hydraulique",),
            
                "Photos Installation REP"             => array("rep_dalles" =>   "Photos Dalle","rep_cuve"=>    "Photo cuve", "rep_crap"=>        "Photos crapaudine","rep_goutiere"=>        "Photos goutiere + surverse","rep_pompe"=>        "Photos pompe installée",
                                                    "rep_gamm"=>        "Photos GAM trop plein","rep_puisage"=>        "Photos puisage+signalisation","rep_wc"=>        "Photos wc+signalisation","rep_fsp"=>        "Photos Filtres Duo",
                                                    "rep_compteur_eau"=>        "Photos compteur eau","rep_uv"=>        "Photos uv+signalisation","rep_elec"=>        "Photos Installation Electrique",
                                                   
            ),
                "Documents Toiture"         => array("toit_mesure" =>   "Photos Mesures/Visite" , "toit_chantier"=>    "Photos Chantier"),
            
            );
            
            
        }
        
    }
}
elseif ($user->admin==1){//admin car no group
    $groupe_famille=array(
        "Documents Administratifs"  => array('facture'=>"Facture EDF / Certificat d'adressage",'identite'=>"Pièce d'identité",'adresse'=>"Justificatif d'adresse (optionnel)",'impot'=>"Avis d'imposition"
                                        ,'rib'=>"RIB",'tf'=>"Taxe Fonciere / titre propriete","livretfamille" => "Livret de Famille","photochantier"  => "Photo chantier", "bondecommande" => "Bon de commande","assurance"=>"Assurance habitation","docscomplementaires"=>"+",
                                         "rep_faceau"=>        "Facture d'eau","rep_dmep"=>        "Déclaration Mairie Eau de Pluie","rep_dossier"=>      "Dossier REP",),
        "Documents ISO"             => array("pos_sacs"=> "Photos Sacs","pos_avantcht" =>   "Photos avant chantier", "pos_aprescht"=>    "Photos après chantier"),
    
        "Documents CES"             => array("ces" =>   "Photos chauffeau","ns"=>    "Photo Numéro de série", "hydro"=>        "Photos Hydraulique",),
    
        "Photos Installation REP"             => array("rep_dalles" =>   "Photos Dalle","rep_cuve"=>    "Photo cuve", "rep_crap"=>        "Photos crapaudine","rep_goutiere"=>        "Photos goutiere + surverse","rep_pompe"=>        "Photos pompe installée",
                                                    "rep_gamm"=>        "Photos GAM trop plein","rep_puisage"=>        "Photos puisage+signalisation","rep_wc"=>        "Photos wc+signalisation","rep_fsp"=>        "Photos Filtres Duo",
                                                    "rep_compteur_eau"=>        "Photos compteur eau","rep_uv"=>        "Photos uv+signalisation","rep_elec"=>        "Photos Installation Electrique",
            ),
        "Documents Toiture"         => array("toit_mesure" =>   "Photos Mesures/Visite" , "toit_chantier"=>    "Photos Chantier"),
    
    );
    
}


$doctoshow=$object->fetchMissingDocuments($fk_soc,'');
$families=array_merge($families,$doctoshow);

$caradocument = new CaraDocument($db);
$tabdoc = $caradocument->getListDocByFamilly($fk_soc);



llxHeader('', $langs->trans('Liste des documents'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">

</script>';
if ($formconfirm)
    print $formconfirm;
//affichage par défaut

print load_fiche_titre($langs->trans("Liste des Documents"));

print '<form method="POST" id="fileupdate" action="'.$_SERVER["PHP_SELF"].'" enctype="multipart/form-data">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="fk_soc" value="'. $fk_soc .'">';
print '<input type="hidden" name="famille" value="'. GETPOST('famille','int') .'">';
print '<input type="hidden" name="action" value="valid_documents">';
print '<input type="hidden" name="type" value="'. $type .'">';
print '<input type="hidden" name="fk_object" value="'. $fk_object .'">';
print '<input type="hidden" name="fk_objectid" value="'. $fk_objectid .'">';


dol_fiche_head(array(), '');

foreach ($groupe_famille as $lib_groupe=>$familles){

    print '<div class="fiche"><table class="border centpercent tableforfieldcreate" border=0>'."\n";
    if(isset($object->id_syno_doc))
        $urlrepertoire_client='<a href="http://192.168.1.98:5000/?launchApp=SYNO.SDS.Drive.Application#file_id='.$object->id_syno_doc.'" target="_blank">'.$lib_groupe.'</a>';
    else $urlrepertoire_client=$lib_groupe;
    print '<tr><td><b><FONT size="5pt">'.$urlrepertoire_client.'</font></b></td></tr>';
    $j=0;
    foreach ($familles as $id_famille=>$famille){
        $bool_green=false;
        print'<td>';
        foreach($tabdoc as $doc){
            
            if($doc['family']==$id_famille){
                
                if($bool_green!=true)
                    print'<input style="background-color:#37E152; border-radius:10px 10px 10px 10px" type="button" id="loadFileXml" value="'.$famille.'" onclick="document.getElementById(\'photo'.$id_famille.'\').click();" />
                    <input   type="file"  id="photo'.$id_famille.'" name="photo['.$id_famille.']" >';
                $bool_green=true;
                print '<br><a href="'.$doc['link'].'" target="_blank">'.$doc['filename'].'</a>';
                if (!in_array($group->id, array(2,3))) //si poseurs: impossible de supprimer les documents.
                    print'<a href="'.$_SERVER["PHP_SELF"].'?action=ask_delete&id_doc='.$doc['rowid'].'&fk_soc='.$fk_soc.'&fk_object='.$fk_object.'&fk_objectid='.$fk_objectid.'" >
                    <span class="fas fa-trash marginleftonly pictodelete" style=" color: #444;" title="Supprimer"></span></a>  ';
            }
    
        }

        if($bool_green==false)
        print'<input style="background-color:#F02D0A; border-radius:10px 10px 10px 10px" type="button" id="loadFileXml" value="'.$famille.'" onclick="document.getElementById(\'photo'.$id_famille.'\').click();" />
        <input type="file"  id="photo'.$id_famille.'" name="photo['.$id_famille.']"/>';
        if(($j%2)==1)
            print '</tr><tr>';
        $j++;
        print '</td>';
        
    }
    print '</tr>';
    print '</table></div><div class="tabsAction"><table bgcolor="#e5e5e5" width="100%"><tr><td>&nbsp;</td></tr></table></div>';
}


if ($fk_object=='deviscarapos'){
    $url=dol_buildpath("/deviscaraiso/card_poseur.php?", 1).'id='.$fk_objectid;
    $lib="Retour fiche Pose";
}
elseif ($fk_object=='deviscaraiso'){
    $url=dol_buildpath("/deviscaraiso/card.php?", 1).'id='.$fk_objectid;
    $lib="Devis";
}
elseif ($fk_object=='deviscaraces'){
    $url=dol_buildpath("/deviscaraces/card.php?", 1).'id='.$fk_objectid;
    $lib="Devis";
}
elseif ($fk_object=='deviscararep'){
    $url=dol_buildpath("/deviscararep/card.php?", 1).'id='.$fk_objectid;
    $lib="Devis";
}
elseif ($fk_object=='deviscaratoit'){
    $url=dol_buildpath("/deviscaratoit/card.php?", 1).'id='.$fk_objectid;
    $lib="Devis";
}
elseif ($fk_object=='deviscaratoitbislist'){
    $url=dol_buildpath("/deviscaratoit/list_toitbis.php?", 1).'id='.$fk_objectid;
    $lib="List toiture";
}
elseif ($fk_object=='deviscaraisolist'){
    $url=dol_buildpath("/deviscaraiso/list_iso.php?", 1).'id='.$fk_objectid;
    $lib="List ISO";
}
elseif ($fk_object=='deviscaraceslist'){
    $url=dol_buildpath("/deviscarces/list_ces.php?", 1).'id='.$fk_objectid;
    $lib="List CES";
}
elseif ($fk_object=='deviscarareplist'){
    $url=dol_buildpath("/deviscararep/list_rep.php?", 1).'id='.$fk_objectid;
    $lib="List REP";
}
elseif ($fk_object=='deviscara'){
    $url=dol_buildpath("/deviscara/dev_list.php?", 1);
    $lib="Liste Devis";
}
elseif ($fk_object=='deviscara_rep'){
    $url=dol_buildpath("/deviscara/rep_list.php?", 1);
    $lib="Liste Devis";
}

elseif ($fk_object=='agendaplus'){
    $url=dol_buildpath("comm/action/index.php", 1);
    $lib="Retour Agenda";
}
print '<a class="butAction" href="'.$url.'">'.$langs->trans($lib).'</a>';
$maxsize=(int)ini_get("upload_max_filesize")*10240000;
print '<script>
var isImageCompressed = false;
var isImageCompressable = true;
function compress(e) {
    const maxsize = 1200;
    const fileName = e.target.files[0].name;
    const reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = function (event) {
        const img = new Image();
        const scaleFactor = (img.width > img.height) ? maxsize / img.width : maxsize / img.height;
        img.src = event.target.result;
        img.onload = function () {
            const elem = document.createElement(\'canvas\');
            if(img.width > img.height) {
                elem.width = maxsize;
                elem.height = img.height * scaleFactor;
            }
            else {
                elem.width = img.width * scaleFactor;
                elem.height = maxsize;
            }
            const ctx = elem.getContext(\'2d\');
            // img.width and img.height will contain the original dimensions
            ctx.drawImage(img, 0, 0, width, height);
            ctx.canvas.toBlob(function (blob) {
                const file = new File([blob], fileName, {
                    type: \'image/jpeg\',
                    lastModified: Date.now()
                });
                $(e.target).after("<span>Nouvelle taille : " + file.size.toString() +" octets</span>")
            }, \'image/jpeg\', 1);
            isImageCompressed = true;
        };
        reader.onerror = error => console.log(error);
    };
}
$("input[type=file]").on("change", function (e) {

    var oldsize = e.target.files[0].size;
     if(e.target.files[0].size > Math.pow(2048, 3)) {
         compress(e);
         $(e.target).after("<span>Ancienne taille : " + oldsize.toString() +" octets</span>");
     } else {
         isImageCompressable = false;
     }
     var uploadInterval = null;
     
     
     if ( e.target.files[0].size < '.$maxsize.')
        uploadInterval = setInterval(function () {
         if(isImageCompressed === true || isImageCompressable === false ) {
             $("#fileupdate").append("<input type=\'hidden\' name=\'uploadimage\' value=\'On\'/>").submit();
             clearInterval(uploadInterval);
         }
         
        }, 1000);
    else
        alert ("fichier trop volumineux");

});
</script>';
print '</form>';






// End of page
llxFooter();
$db->close();
