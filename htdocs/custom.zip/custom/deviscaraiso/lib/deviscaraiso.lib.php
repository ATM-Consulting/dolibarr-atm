<?php
/* Copyright (C) 2020 SuperAdmin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    deviscaraiso/lib/deviscaraiso.lib.php
 * \ingroup deviscaraiso
 * \brief   Library files with common functions for Deviscaraiso
 */

/**
 * Prepare admin pages header
 *
 * @return array
 */
function deviscaraisoAdminPrepareHead()
{
	global $langs, $conf;

	$langs->load("deviscaraiso@deviscaraiso");

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/deviscaraiso/admin/setup.php", 1);
	$head[$h][1] = $langs->trans("Settings");
	$head[$h][2] = 'settings';
	$h++;
	$head[$h][0] = dol_buildpath("/deviscaraiso/admin/about.php", 1);
	$head[$h][1] = $langs->trans("About");
	$head[$h][2] = 'about';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@deviscaraiso:/deviscaraiso/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@deviscaraiso:/deviscaraiso/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, null, $head, $h, 'deviscaraiso');

	return $head;
}

/**
 * Prepare array of tabs for deviscaraces
 *
 * @param	MyObject	$object		deviscaraces
 * @return 	array					Array of tabs
 */
function deviscaraisoPrepareHead($object)
{
	global $db, $langs, $conf;

	$langs->load("deviscaraciso@deviscaraiso");

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/deviscaraiso/card.php", 1).'?id='.$object->id;
	$head[$h][1] = $langs->trans("Card");
	$head[$h][2] = 'card';
	$h++;

	

	require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';
	require_once DOL_DOCUMENT_ROOT.'/core/class/link.class.php';
	$upload_dir = $conf->deviscaraces->dir_output . "/deviscaraciso/" . dol_sanitizeFileName($object->ref);
	$nbFiles = count(dol_dir_list($upload_dir, 'files', 0, '', '(\.meta|_preview.*\.png)$'));
	$nbLinks=Link::count($db, $object->element, $object->id);
	$head[$h][0] = dol_buildpath("/deviscaraiso/document2.php", 1).'?id='.$object->id . "&type=1";
	$head[$h][1] = $langs->trans('Documents');
	if (($nbFiles+$nbLinks) > 0) $head[$h][1].= '<span class="badge marginleftonlyshort">'.($nbFiles+$nbLinks).'</span>';
	$head[$h][2] = 'document';
	$h++;

	$head[$h][0] = dol_buildpath("/deviscaraiso/agenda.php", 1).'?id='.$object->id;
	$head[$h][1] = $langs->trans("Events");
	$head[$h][2] = 'agenda';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@mymodule:/mymodule/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@mymodule:/mymodule/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'myobject@mymodule');

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'myobject@mymodule', 'remove');

	return $head;
}
function formconfirm($page, $title, $question, $action, $formquestion = '', $selectedchoice = '', $useajax = 0, $height = 250, $width = 500, $disableformtag = 0)
{
    global $langs, $conf;
    global $useglobalvars;

    $more = '<!-- formconfirm -->';
    $formconfirm = '';
    $inputok = array();
    $inputko = array();

    // Clean parameters
    $newselectedchoice = empty($selectedchoice) ? "no" : $selectedchoice;
    if ($conf->browser->layout == 'phone') $width = '95%';

    // Set height automatically if not defined
    if (empty($height)) {
        $height = 210;
        if (is_array($formquestion) && count($formquestion) > 2) {
            $height += ((count($formquestion) - 2) * 24);
        }
    }


    $moreonecolumn = '';
    $more .= '<div class="tagtable paddingtopbottomonly centpercent noborderspacing">' . "\n";
	$more .= '<div class="tagtd"><table width=100%>';
	$more.='<tr><td><b>Accompte</b></td><td colspan=2><input type="text" name="acompte" id="acompte" size="4"></td></tr>';
	$more.='<tr><td><b>Mode Reglement</b></td><td><b>Quand ?</b></td><td><b>Quantité</b></td></tr>';
	
	$more.=' <tr><td>';
	
	$more.= '<input type="radio" id="modreglement" name="modreglement" value="1">Cheque</input>
					<br><input type="radio" id="modreglement" name="modreglement" value="2">Espèces</input>
					<br><input type="radio" id="modreglement" name="modreglement" value="3">Prélèvement</input>';

	$more.='</td><td><input type="radio" id="modreglementquand" name="modreglementquand" value="1">A la signture</input>
		<br><input type="radio" id="modreglementquand" name="modreglementquand" value="2">A pose</input>
		</td>
		<td><input type="text" id="qty" name="qty" size="3"></td></tr>';
	
	$more.='</table>
	<br></div></div>' . "\n";
    //$more .= '</div>' . "\n";
    $more .= $moreonecolumn;

    // JQUI method dialog is broken with jmobile, we use standard HTML.
    // Note: When using dol_use_jmobile or no js, you must also check code for button use a GET url with action=xxx and check that you also output the confirm code when action=xxx
    // See page product/card.php for example
    if (!empty($conf->dol_use_jmobile)) $useajax = 0;
    if (empty($conf->use_javascript_ajax)) $useajax = 0;

    if ($useajax) {
        $autoOpen = true;
        $dialogconfirm = 'dialog-confirm';
        $button = '';
        if (!is_numeric($useajax)) {
            $button = $useajax;
            $useajax = 1;
            $autoOpen = false;
            $dialogconfirm .= '-' . $button;
        }
        $pageyes = $page . (preg_match('/\?/', $page) ? '&' : '?') . 'action=' . $action . '&confirm=yes';
        //$pageno = ($useajax == 2 ? $page.(preg_match('/\?/', $page) ? '&' : '?').'confirm=no' : '');
        // Add input fields into list of fields to read during submit (inputok and inputko)
        if (is_array($formquestion)) {
            foreach ($formquestion as $key => $input) {
                //print "xx ".$key." rr ".is_array($input)."<br>\n";
                if (is_array($input) && isset($input['name'])) array_push($inputok, $input['name']);
                if (isset($input['inputko']) && $input['inputko'] == 1) array_push($inputko, $input['name']);
            }
        }
        // Show JQuery confirm box. Note that global var $useglobalvars is used inside this template
        $formconfirm .= '<div id="' . $dialogconfirm . '" title="' . dol_escape_htmltag($title) . '" style="display: none;">';
        
        
        if (!empty($more)) {
            $formconfirm .= '<div class="confirmquestions">' . $more . '</div>' . "\n";
        }
        $formconfirm .= '</div>' . "\n";

        $formconfirm .= "\n<!-- begin ajax formconfirm page=" . $page . " -->\n";
        $formconfirm .= '<script type="text/javascript">' . "\n";
        $formconfirm .= 'jQuery(document).ready(function() {
            $(function() {
            	$( "#' . $dialogconfirm . '" ).dialog(
            	{
                    autoOpen: ' . ($autoOpen ? "true" : "false") . ',';
        if ($newselectedchoice == 'no') {
            $formconfirm .= '
						open: function() {
            				$(this).parent().find("button.ui-button:eq(2)").focus();
						},';
        }
        $formconfirm .= '
                    resizable: false,
                    height: "' . $height . '",
                    width: "' . $width . '",
                    modal: true,
                    closeOnEscape: false,
                    buttons: {
                        "' . dol_escape_js($langs->transnoentities("OK")) . '": function() {
							var options = "";
							var modereglement=$("input:radio[name=modreglement]:checked").val();
							var modereglementquand=$("input:radio[name=modreglementquand]:checked").val();
							var qty=$("input:text[name=qty]").val();
							var acompte=$("input:text[name=acompte]").val();
							//colsole.log(modereglement + " " + modereglementquand);
							//alert(qty);
                        	var inputok = ' . json_encode($inputok) . ';
                         	var pageyes = "' . dol_escape_js(!empty($pageyes) ? $pageyes : '') . '";
							 options += "&modreglement=" + encodeURIComponent(modereglement);
							 options += "&modreglementquand=" + encodeURIComponent(modereglementquand); 
							 options +=  "&qty=" + encodeURIComponent(qty); 
							 options +=  "&acompte=" + encodeURIComponent(acompte); 
							 options += "#baspage";
                         	var urljump = pageyes + (pageyes.indexOf("?") < 0 ? "?" : "") + options;
                         	//alert(urljump);
            				if (pageyes.length > 0) { location.href = urljump; }
                            $(this).dialog("close");
                        }
                        
                    }
                }
                );

            	var button = "' . $button . '";
            	if (button.length > 0) {
                	$( "#" + button ).click(function() {
                		$("#' . $dialogconfirm . '").dialog("open");
        			});
                }
            });
            });
            </script>';
        $formconfirm .= "<!-- end ajax formconfirm -->\n";
    }

    return $formconfirm;
}


