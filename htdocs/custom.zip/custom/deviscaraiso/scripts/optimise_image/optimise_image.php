<?php
// LMK Script pour réduire le poids des images
set_time_limit(0); // Temps d'exécution du script illimité
date_default_timezone_set('America/Martinique'); // Définiton du fuseau horaire
// Fonction pour compresser les images
if (!function_exists("compressImage")) {
function compressImage($source_url, $quality) {
  if(file_exists($source_url)) { // Si le fichier existe
	  $info = getimagesize($source_url); // On charge lers infos de l'image
	  if ($info['mime'] == 'image/jpeg' || $info['mime'] == 'image/jpg') // S'il s'agit bien d'un JPEG
	  {
		  $image = imagecreatefromjpeg($source_url); // On crée l'objet image à partir du fichier image
		  // Correction de l'orientation de l'image à partir des données exif du fichier image
		  if (function_exists('exif_read_data')) { // Précaution pour éviter une erreur selon le serveur
			  $exif = @exif_read_data($source_url); // On récupère les données exif du fichier image
			  (isset($exif['Orientation'])) ? $orientation = $exif['Orientation'] : $orientation = 0; // Orientation de l'image
			  if($orientation != 1) { // Si l'image doit réorientée
				  $deg = 0; // Degré de rotation, à zéro par défaut
				  switch ($orientation) {
					  case 3:
						  $deg = 180;
					  break;
					  case 6:
						  $deg = 270;
					  break;
					  case 8:
						  $deg = 90;
					  break;
				  }
				  if ($deg) $image = imagerotate($image, $deg, 0); // On retourne l'image
			  }
		  }
		  imagejpeg($image, $source_url, $quality); // On l'enregistre
		  imagedestroy($image); // On libère la mémoire
	  } else return FALSE;
	  return TRUE;
  } else return FALSE;
}
}
// Fonction pour les opérations sur la BDD
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  global $cara;
  $theValue = function_exists("mysqli_real_escape_string") ? $cara->real_escape_string($theValue) : $cara->escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Connexion BDD
$hostname_cara = 'localhost';
$database_cara = 'cara_doli';
$username_cara = 'prodcara';
$password_cara = 'eH122?wh';
$cara = mysqli_connect($hostname_cara, $username_cara, $password_cara, $database_cara) or trigger_error(mysqli_error($cara),E_USER_ERROR); 

// Déclaration des variables
$qualite = 10; // Qualité de l'image obtenue 0 (médiocre) à 100 (maximale)
$fichier_log = "optimise_image.log"; // fichier log du script
$fichier_compteur = "compteur"; // fichier d'enregistrement du dernier id traité
$log_images = "liste_images.log"; // log des images traitées
$debut = microtime(true); // Heure de début d'execution du script

$nb_fichier = 0; // Nombre de fichiers traités
$compteur = file ($fichier_compteur); // Lecture du fichier compteur
// Requête
$cara->select_db($database_cara);
$query_images = "SELECT * FROM `llx_caradocument` WHERE `socid` IS NOT NULL AND `filename` LIKE '%.jpg' AND rowid>".$compteur[0]." LIMIT 1000";
$images = $cara->query($query_images) or die(mysqli_error($cara));
$row_images = mysqli_fetch_assoc($images);
$totalRows_images = mysqli_num_rows($images);
if ($totalRows_images) { // S'il y a des images à traiter
	do {
		($row_images['tech_filename']) ? $image = $row_images['path']."/".$row_images['tech_filename'] : $image = $row_images['path'];
		if (file_exists($image)) { // Si le fichier image existe
			$taille_fichier = filesize($image);
			if ($taille_fichier > 1048576) {
				$resultat = compressImage($image , $qualite); // On compresse l'image
				if ($resultat) {
					$nb_fichier++; // Si le fichier a été compressé, on le déclare traité
					file_put_contents($log_images, $image."\n", FILE_APPEND); // Enregistrement de l'image dans le fichier log images
				}
			}
		}
		$compteur = $row_images['rowid']; // On enregistre l'enregistrement courant
	} while($row_images = mysqli_fetch_assoc($images));
	file_put_contents($fichier_compteur, $compteur); // Enregistrement du dernier enregistrement dans le fichier texte
}
// On écrit dans le fichier log à la toute fin du traitement
$texte_log = "Début : ".date("d-m-Y H:i:s" , $debut)." - Fin : ".date("d-m-Y H:i:s")." - ".$nb_fichier." fichiers traités\n";
//file_put_contents($fichier_log, $texte_log, FILE_APPEND); // Enregistrement du résultat dans le fichier log
echo $nb_fichier." fichier(s) traité(s)";
echo " - Id courant : ".$compteur;
?>