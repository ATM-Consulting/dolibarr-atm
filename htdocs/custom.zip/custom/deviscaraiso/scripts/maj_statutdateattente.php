<?php
//Si la date d’intervention est dépassée de 3j , et planification « planifiée » alors alerte. 
//Date en rouge ou planifié qui se met à clignoter.

$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';

require_once $path . "../../../master.inc.php";
require_once $path . "../class/deviscaraiso.class.php";

// Global variables
$version = DOL_VERSION;
$error = 0;

/*
 * Main
 */

@set_time_limit(0);
print "***** " . $script_file . " (" . $version . ") pid=" . dol_getmypid() . " *****\n";
dol_syslog($script_file . " launched with arg " . join(',', $argv));



$db->begin();
$now=dol_now();
$sql='update '. MAIN_DB_PREFIX . 'cara_deviscaraiso  set planification =1 , date_attente=null, alerte_date_attente=1 where planification=19 and date_attente < "'.$db->idate($now).'"';
$resql = $db->query($sql);
$sql='update '. MAIN_DB_PREFIX . 'cara_deviscaratoit  set planification =1 , date_attente=null, alerte_date_attente=1 where planification=19 and date_attente < "'.$db->idate($now).'"';
$resql = $db->query($sql);
$sql='update '. MAIN_DB_PREFIX . 'cara_deviscaraces  set planification =1 , date_attente=null, alerte_date_attente=1 where planification=19 and date_attente < "'.$db->idate($now).'"';
$resql = $db->query($sql);
$sql='update '. MAIN_DB_PREFIX . 'cara_deviscararep  set planification =1 , date_attente=null, alerte_date_attente=1 where planification=19 and date_attente < "'.$db->idate($now).'"';
$resql = $db->query($sql);
$sql='update '. MAIN_DB_PREFIX . 'cara_deviscaramen  set planification =1 , date_attente=null, alerte_date_attente=1 where planification=19 and date_attente < "'.$db->idate($now).'"';
$resql = $db->query($sql);
$db->commit();


?>