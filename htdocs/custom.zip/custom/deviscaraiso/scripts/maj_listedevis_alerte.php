<?php
//Si la date d’intervention est dépassée de 3j , et planification « planifiée » alors alerte. 
//Date en rouge ou planifié qui se met à clignoter.

$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';

require_once $path . "../../../master.inc.php";

// Global variables
$version = DOL_VERSION;
$error = 0;

/*
 * Main
 */

@set_time_limit(0);
print "***** " . $script_file . " (" . $version . ") pid=" . dol_getmypid() . " *****\n";
dol_syslog($script_file . " launched with arg " . join(',', $argv));


$now=new DateTime('now');

$tabdevis=array('deviscara_dev','deviscara_iso2');

foreach ($tabdevis as $ext){


    $sql = "SELECT rowid,status,date_creation ";
    $sql .= " FROM " . MAIN_DB_PREFIX . $ext ;

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);

        print "Lines " . $num . "\n";

        $i = 0;
        $db->begin();
        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if($obj->status==2){
                $date_planif=new DateTime($obj->date_creation);
                $diff=$now->diff($date_planif);
                if ($diff->invert==1 && $diff->d > 10 ){
                    $sql = 'update '. MAIN_DB_PREFIX .$ext.' set status = 4 where rowid='.$obj->rowid;
                    $resql2 = $db->query($sql);
                }
            }
            $i++;   
        }
        $db->commit();
    }

}
?>