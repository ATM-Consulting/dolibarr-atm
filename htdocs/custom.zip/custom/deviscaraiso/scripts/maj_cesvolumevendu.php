<?php
//Si la date d’intervention est dépassée de 3j , et planification « planifiée » alors alerte. 
//Date en rouge ou planifié qui se met à clignoter.
global $db;
$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';
set_time_limit ( 2500 ); 
require_once $path . "../../../master.inc.php";
require_once $path . "../class/deviscaraiso.class.php";

// Global variables
$version = DOL_VERSION;
$error = 0;
$date=dol_now();
$date=new dateTime('now',new DateTimeZone('America/Martinique'));




//next value ref
function get_next_value($type,$id_ligne){
    global $date;
    $annee=$date->format('y');
    $mois=$date->format('m');
    $compteur=str_pad($id_ligne, 4, "0", STR_PAD_LEFT);
    if($type=='ISO')
        $code_cli='ISO'.$annee.$mois.'-'.$compteur;
    elseif($type=='CES') 
        $code_cli='CES'.$annee.$mois.'-'.$compteur;
    elseif($type=='REP') 
        $code_cli='REP'.$annee.$mois.'-'.$compteur;
    
    return($code_cli);

}

function get_societe($data,$id_ligne){
    global $date,$db,$bool_nouveau_client;
    $annee=$date->format('y');
    $mois=$date->format('m');
    $bool_nouveau_client=false;
    
    $nom=$data[0]." ".$data[1];
    

    $sql = "SELECT a.rowid from " . MAIN_DB_PREFIX . "societe a";
    $sql .= " where nom like '%".addslashes($nom)."%' ";
 
    $resql = $db->query($sql);
    $num = $db->num_rows($resql);
   
        return ($obj->rowid);
    
}

function get_planif($planification){

    switch ($planification){

        case 'En attente':
        case 'Dossier à Faire':
            $planif=1;
        break;
        case 'Planifié':
        
            $planif=2;
        break;
        case 'A Replanifier':
            $planif=3;
        break;
        case 'Posé':
        case 'Livré':
            $planif=4;
        break;
        case 'Incomplet':
            $planif=6;
        break;
        case 'Annulé':
            $planif=9;
        break;
        case 'Déroulé':
            $planif=8;
        break;
        case 'Impossible':
            $planif=5;
        break;
        case 'Dalle faite':
            $planif=11;
        break;
        case 'Prés visite':
        case 'Prés visite ':
            $planif=10;
        break;
         
    }
    if($planification=='') $planif=1;
    return ($planif);
}


function get_id_usercomm($lib_comm){
    global $db;
    $lib=explode(' ',$lib_comm);
    $sql = "SELECT rowid from " . MAIN_DB_PREFIX . "user a ";
    $sql .= " where lastname like '%".$lib[1]."%' ";
    $sql .= " and firstname like '%".$lib[0]."%' ";
    $resql = $db->query($sql);
    $obj = $db->fetch_object($resql);
    if(is_numeric($obj->rowid))
        return($obj->rowid);
    else {
        print '<br>commercial non trouvé: '.$lib_comm.$sql.'<br>';
        return( 'NULL');

    }
}

function get_rac($mt){
    //retraitement du montant
    if($mt=='NC' || $mt=='' || $mt=="- €" || $mt==' ' || $mt=='? ')
        $ret='NULL';
    else{
        $re = '/([0-9]*[  ]*[0-9]+,[0-9]+)/m';
        preg_match($re, $mt, $matches);
        $ret=price2num($matches[0]);
        //$ret=str_replace(' ','',$ret );
        $ret=preg_replace('/[  ]/','',$ret);
        
    }
    
    return($ret);
}
function get_statuslisting($prod,$id_societe){
    global $db;
    if ($prod=='iso') $label=1;
    if ($prod=='ces') $label=2;
    if ($prod=='rep') $label=3;
    $sql = "SELECT planification from " . MAIN_DB_PREFIX . "cara_deviscara".$prod." a ";
    $sql .= " where fk_soc=".$id_societe;
    $sql.= " and label=".$label;
    $resql = $db->query($sql);
    $obj = $db->fetch_object($resql);
    return($obj->planification);
}
/** MAIN **/


$lines = file('planning2.csv');
$nbces=0;
foreach ($lines as $line_num => $line) {
   
    $data=explode(';',$line);
    
    $nom=$data[0].' '.$data[1];
    $re = '/CES+/m';
    //$str = 'CES';
    $str = $data[3];

    preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);
    if (count($matches)>0){
        $nbces++;
        //print $nom.' - '.$data[3].'<br>';
        if($data[4]) $qtyv="'".$data[4]."'";
        else $qtyv='NULL';
        if(is_numeric($data[5])) $qtyp=$data[5];
        else $qtyp='NULL';

        $id_societe=get_societe($data,$line_num);
        if($id_societe <0 ) {
            $error++;
            print 'client non créé';
        }
        $date_creation=DateTime::createFromFormat('d/m/Y', $data[2]);
        if(count($data[9])>2){
            $date_planif=DateTime::createFromFormat('d/m/Y', $data[9]);
            $date_p=$date_planif->format("%Y%m%d");
        }
        else $date_p='NULL';

        if(count($data[17])>2){
            $date_pose=DateTime::createFromFormat('d/m/Y', $data[17]);
            $date_po=$date_pose->format("%Y%m%d");
        }
        else $date_po='NULL';

        if(is_numeric($data[13])) $amount=$data[13];
        else $amount='NULL';
        $comment= str_replace("'", "\'", $data[15]);

        $type='CES';
        $line_num=$line_num+2046;
        $id_societe=get_societe($data,$line_num);
        $sql='select rowid from llx_societe where nom like "%'.$nom.'%";';
        $resql = $db->query($sql);
        $idsociete=$obj = $db->fetch_object($resql);
        $sql='update llx_cara_deviscaraces set qty='.$qtyv.' where fk_soc='.$idsociete->rowid.';';
        print $sql.'<br>';
        

    }
    //print $sql;
    
    //print $line_num.'; ';

}

print '<br>FINI nbces transféres='.$nbces.'<br>\n';

?>