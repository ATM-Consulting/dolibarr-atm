<?php
//Si la date d’intervention est dépassée de 3j , et planification « planifiée » alors alerte. 
//Date en rouge ou planifié qui se met à clignoter.

$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';

require_once $path . "../../../master.inc.php";
require_once $path . "../class/deviscaraiso.class.php";

// Global variables
$version = DOL_VERSION;
$error = 0;

/*
 * Main
 */

@set_time_limit(0);
print "***** " . $script_file . " (" . $version . ") pid=" . dol_getmypid() . " *****\n";
dol_syslog($script_file . " launched with arg " . join(',', $argv));


$now=new DateTime('now');

$tabdevis=array('iso','ces','rep','toit',);

foreach ($tabdevis as $ext){


    $sql = "SELECT rowid,date_planif, planification, date_pose ";
    $sql .= " FROM " . MAIN_DB_PREFIX . "cara_deviscara".$ext." ";

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);

        print "Lines " . $num . "\n";

        $i = 0;
        $db->begin();
        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if($obj->date_planif!=''){
                $date_planif=new DateTime($obj->date_planif);
                $diff=$now->diff($date_planif);
                if ($diff->invert==1 && $diff->d > 3 && $obj->planification == deviscaraiso::STATUSPLANIF_PLANIFIE){
                    $sql = 'update '. MAIN_DB_PREFIX . 'cara_deviscara'.$ext.' set alerte_date_planif = 1 where rowid='.$obj->rowid;
                    print $sql.'<br>';
                }
                else 
                    $sql = 'update '. MAIN_DB_PREFIX . 'cara_deviscara'.$ext.' set alerte_date_planif = 0 where rowid='.$obj->rowid;
                
                $resql2 = $db->query($sql);
            
            }
            $i ++;
        }
        $db->commit();
    }

}
?>