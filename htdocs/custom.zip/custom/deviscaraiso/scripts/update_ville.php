<?php
//Si la date d’intervention est dépassée de 3j , et planification « planifiée » alors alerte. 
//Date en rouge ou planifié qui se met à clignoter.

$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';
set_time_limit ( 2500 ); 
require_once $path . "../../../master.inc.php";
require_once $path . "../class/deviscaraiso.class.php";

// Global variables
$version = DOL_VERSION;
$error = 0;
$date=dol_now();
$date=new dateTime('now',new DateTimeZone('America/Martinique'));




//next value ref
function get_next_value($type,$id_ligne){
    global $date;
    $annee=$date->format('y');
    $mois=$date->format('m');
    $compteur=str_pad($id_ligne, 4, "0", STR_PAD_LEFT);
    if($type=='ISO')
        $code_cli='ISO'.$annee.$mois.'-'.$compteur;
    elseif($type=='CES') 
        $code_cli='CES'.$annee.$mois.'-'.$compteur;
    elseif($type=='REP') 
        $code_cli='REP'.$annee.$mois.'-'.$compteur;
    
    return($code_cli);

}

function get_societe($data,$id_ligne){
    global $date,$db,$bool_nouveau_client;
    $annee=$date->format('y');
    $mois=$date->format('m');
    $bool_nouveau_client=false;
    
    $nom=$data[0]." ".$data[1];
    $sql = "SELECT a.rowid from " . MAIN_DB_PREFIX . "societe a, " . MAIN_DB_PREFIX . "societe_extrafields b, " . MAIN_DB_PREFIX . "cara_cpville c";
    $sql .= " where nom like '%".$nom."%' ";
    $sql .= " and c.ville like '%".$data[8]."%' ";
    $sql .= " and c.rowid=b.ville ";
    $sql .= " and b.fk_object=a.rowid ";

    $sql = "SELECT a.rowid from " . MAIN_DB_PREFIX . "societe a";
    $sql .= " where nom like '%".addslashes($nom)."%' ";
 
    $resql = $db->query($sql);
    $num = $db->num_rows($resql);
    if ($num > 0){ //meme ville, meme nom
        $obj = $db->fetch_object($resql);
        //print 'client doublon: '.$nom.' id='.$obj->rowid.'<br>\n';
        return ($obj->rowid);
    }
    $bool_nouveau_client=true;
    $compteur_cli=str_pad($id_ligne, 6, "0", STR_PAD_LEFT);
    $code_cli='CU'.$annee.$mois.'-'.$compteur_cli;
    $phone=str_replace(' ','',$data[10]);
    $phone2=str_replace(' ','',$data[11]);
    $sql= "INSERT into " . MAIN_DB_PREFIX . "societe";
    $sql.= "(nom,entity, statut, code_client,phone,fax, client,fournisseur,datec)";
    $sql.= "values ( '".addslashes($nom)."', ";
    $sql.= " 1,";
    $sql.= "0,";
    $sql.= "'".$code_cli."' ,";
    $sql.= "'".$phone."', ";
    $sql.= "'".$data[11]."', ";
    $sql.= "1,0,";
    $sql.= "'".$date->format("Y-m-d")."' ";
    $sql.= ")";
    $resql = $db->query($sql);
    if(!$resql){
        print ($line_num.'//'.$db->lasterror().$sql);
        exit;
    }
    $id_societe=$db->last_insert_id(MAIN_DB_PREFIX."societe");
    print 'nouveau client : '.$nom.' '.$id_societe.'<br>';

    //insert address dans la table extrafields
    if($data[14]=='HORS PRECARITE' || $data[14]=='HP')
        $id_preca=1;
    elseif($data[14]=='PRECAIRE')
        $id_preca=2;
    elseif($data[14]=='GRAND PRECAIRE'|| $data[14]=='GP')
        $id_preca=3;
    else
        $id_preca="'NULL'";


    $sql= "INSERT into " . MAIN_DB_PREFIX . "societe_extrafields";
    $sql.= "(fk_object,cara_type_client,ville)";
    $sql.= ' SELECT '.$id_societe.','.$id_preca.', rowid from '. MAIN_DB_PREFIX .'cara_cpville where ville like "'.$data[8].'"  ' ;
    $resql = $db->query($sql);
    if(!$resql) $error--;

    if($error<0) return ($error);

    return($id_societe);
}

function get_planif($planification){

    switch ($planification){

        case 'En attente':
        case 'Dossier à Faire':
            $planif=1;
        break;
        case 'Planifié':
        
            $planif=2;
        break;
        case 'A Replanifier':
            $planif=3;
        break;
        case 'Posé':
        case 'Livré':
            $planif=4;
        break;
        case 'Incomplet':
            $planif=6;
        break;
        case 'Annulé':
            $planif=9;
        break;
        case 'Déroulé':
            $planif=8;
        break;
        case 'Impossible':
            $planif=5;
        break;
        case 'Dalle faite':
            $planif=11;
        break;
        case 'Prés visite':
        case 'Prés visite ':
            $planif=10;
        break;
         
    }
    if($planification=='') $planif=1;
    return ($planif);
}


function get_id_usercomm($lib_comm){
    global $db;
    $lib=explode(' ',$lib_comm);
    $sql = "SELECT rowid from " . MAIN_DB_PREFIX . "user a ";
    $sql .= " where lastname like '%".$lib[1]."%' ";
    $sql .= " and firstname like '%".$lib[0]."%' ";
    $resql = $db->query($sql);
    $obj = $db->fetch_object($resql);
    if(is_numeric($obj->rowid))
        return($obj->rowid);
    else {
        print '<br>commercial non trouvé: '.$lib_comm.$sql.'<br>';
        return( 'NULL');

    }
}

function get_rac($mt){
    //retraitement du montant
    if($mt=='NC' || $mt=='' || $mt=="- €" || $mt==' ')
        $ret='NULL';
    else{
        $re = '/([0-9]*[  ]*[0-9]+,[0-9]+)/m';
        preg_match($re, $mt, $matches);
        $ret=price2num($matches[0]);
        //$ret=str_replace(' ','',$ret );
        $ret=preg_replace('/[  ]/','',$ret);
        
    }
    
    return($ret);
}
function get_statuslisting($prod,$id_societe){
    global $db;
    if ($prod=='iso') $label=1;
    if ($prod=='ces') $label=2;
    if ($prod=='rep') $label=3;
    $sql = "SELECT planification from " . MAIN_DB_PREFIX . "cara_deviscara".$prod." a ";
    $sql .= " where fk_soc=".$id_societe;
    $sql.= " and label=".$label;
    $resql = $db->query($sql);
    $obj = $db->fetch_object($resql);
    return($obj->planification);
}
/** MAIN **/


$lines = file('planning2.csv');

foreach ($lines as $line_num => $line) {
   
    $data=explode(';',$line);
    $ville=$data[8];
    $nom=$data[0].' '.$data[1];
    if ($ville=="FONDS ST DENIS"){
        //$sql='update llx_societe_extrafields, llx_societe b set ville=33 where fk_object=b.rowid and b.nom like "%'.$nom.'%"';
        $sql='select a.rowid,nom,ville from llx_societe a
        left join llx_societe_extrafields on fk_object=a.rowid
        where nom like "%'.$nom.'%"';
        
        $resql = $db->query($sql);
        $obj = $db->fetch_object($resql);
        $idville=29;
        $sql='insert into llx_societe_extrafields (fk_object, ville) values ('.$obj->rowid.','.$idville.') on duplicate key update ville='.$idville.';<br>';

        print $sql;
    }
    //print $line_num.'; ';

}

print '<br>FINI <br>\n';

?>