<?php
/* Copyright (C) 2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *    \file       rep_card.php
 *        \ingroup    deviscara
 *        \brief      Page to create/edit/view rep
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB','1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER','1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC','1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN','1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION','1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION','1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK','1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL','1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK','1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU','1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML','1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX','1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN",'1');						// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK','1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT','auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE','aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN',1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP','none');					// Disable all Content Security Policies


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
    $i--;
    $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT . '/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/html.formfile.class.php';
dol_include_once('/carasun/class/pv.class.php');
dol_include_once('/product/class/product.class.php');
dol_include_once('/comm/propal/class/propal.class.php');
include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/lib/deviscara_tarifpv.lib.php', 1);
// Load translation files required by the page
$langs->loadLangs(array("deviscara@deviscara", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm = GETPOST('confirm', 'alpha');
$cancel = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ? GETPOST('contextpage', 'aZ') : 'repcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$lineid = GETPOST('lineid', 'int');

// Initialize technical objects
$object = new pv($db);
$extrafields = new ExtraFields($db);

$object_soc = new societe($db);
$extrafields_soc = new ExtraFields($db);
$tab = $object->get_fields_supp();
$object->fields = array_merge($object->fields, $tab);
$diroutputmassaction = $conf->deviscara->dir_output . '/temp/massgeneration/' . $user->id;
$hookmanager->initHooks(array('repcard', 'globalcard')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val) {
    if (GETPOST('search_' . $key, 'alpha')) $search[$key] = GETPOST('search_' . $key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

// Load object
include DOL_DOCUMENT_ROOT . '/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->statut == $object::STATUS_DRAFT) ? 1 : 0);
//$result = restrictedArea($user, 'deviscara', $object->id, '', '', 'fk_soc', 'rowid', $isdraft);

$permissiontoread = $user->rights->deviscara->rep->read;
$permissiontoadd = $user->rights->deviscara->rep->write; // Used by the include of actions_addupdatedelete.inc.php and actions_lineupdown.inc.php
$permissiontodelete = $user->rights->deviscara->rep->delete || ($permissiontoadd && isset($object->status) && $object->status == $object::STATUS_DRAFT);
$permissionnote = $user->rights->deviscara->rep->write; // Used by the include of actions_setnotes.inc.php
$permissiondellink = $user->rights->deviscara->rep->write; // Used by the include of actions_dellink.inc.php
$upload_dir = $conf->deviscara->multidir_output[isset($object->entity) ? $object->entity : 1];


/*
 * Actions
 */

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook)) {
    $error = 0;

    $backurlforlist = dol_buildpath('/deviscara/rep_list.php', 1);

    if (empty($backtopage) || ($cancel && empty($id))) {
        if (empty($backtopage) || ($cancel && strpos($backtopage, '__ID__'))) {
            if (empty($id) && (($action != 'add' && $action != 'create') || $cancel)) $backtopage = $backurlforlist;
            else $backtopage = dol_buildpath('/deviscara/rep_card.php', 1) . '?id=' . ($id > 0 ? $id : '__ID__');
        }
    }
    $triggermodname = 'DEVISCARA_REP_MODIFY'; // Name of trigger action code to execute when we modify record

    // Actions cancel, add, update, update_extras, confirm_validate, confirm_delete, confirm_deleteline, confirm_clone, confirm_close, confirm_setdraft, confirm_reopen
    include DOL_DOCUMENT_ROOT . dol_buildpath('deviscara/core/actions_addupdatedeletepv.inc.php', 1);
    // Actions when linking object each other
    include DOL_DOCUMENT_ROOT . '/core/actions_dellink.inc.php';

    // Actions when printing a doc from card
    include DOL_DOCUMENT_ROOT . '/core/actions_printing.inc.php';

    // Action to move up and down lines of object
    include DOL_DOCUMENT_ROOT . '/core/actions_lineupdown.inc.php';

    // Action to build doc
    include DOL_DOCUMENT_ROOT . '/core/actions_builddoc.inc.php';

    if ($action == 'set_thirdparty' && $permissiontoadd) {
        $object->setValueFrom('fk_soc', GETPOST('fk_soc', 'int'), '', '', 'date', '', $user, 'REP_MODIFY');
    }
    if ($action == 'classin' && $permissiontoadd) {
        $object->setProject(GETPOST('projectid', 'int'));
    }

    // Actions to send emails
    $triggersendname = 'REP_SENTBYMAIL';
    $autocopy = 'MAIN_MAIL_AUTOCOPY_REP_TO';
    $trackid = 'rep' . $object->id;
    include DOL_DOCUMENT_ROOT . '/core/actions_sendmails.inc.php';
}
//include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.


/*
 * View
 *
 * Put here all code to build page
 */

$form = new Form($db);
$formfile = new FormFile($db);

llxHeader('', $langs->trans('PV'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});


function affichproduit(idprod) {
	for(i=0;i<=4;i++){
		document.getElementById("idprod"+i).style.display="none";
	}
	document.getElementById("idprod"+idprod).style.display="block";
}
function affichbuttons() {
	document.getElementById("affichbuttons").style.display="block";
}
function affichreglement(){
	document.getElementById("zonereglement").style.display="block";
	document.getElementById("zonecma").style.display="none";
}
function validbanque(){
	document.form.action="' . $_SERVER["PHP_SELF"] . '?action=create";
	document.form.submit();
}

</script>';


// Part to create
if ($action == 'create') {
    include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/lib/deviscara_tarifrep.lib.php', 1);
    print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("PV")));

    print '<form method="POST" action="' . $_SERVER["PHP_SELF"] . '">';
    print '<input type="hidden" name="token" value="' . newToken() . '">';
    print '<input type="hidden" name="action" value="add">';
    if ($backtopage) print '<input type="hidden" name="backtopage" value="' . $backtopage . '">';
    if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="' . $backtopageforcancel . '">';

    dol_fiche_head(array(), '');

    print '<div id="iddiv0" style="display: block;"><table class="tableclassicrep"><tr>';
    print '<td>Ref fiscale : </td><td><input type="text" name="rfr" value=' . ($_SESSION["rfr"] > 0 ? $_SESSION["rfr"] : "") . '></td>';
    print '</tr><tr>';
    print '<td>nb parts :</td><td> 
	<select name="nbpart" style="width: 50px;" id="nbpart">';
    for ($i = 1; $i <= 10; $i += 0.5) {
        if ($_SESSION["nbpart"] == "$i")
            $selected = 'selected';
        else $selected = '';
        print '<option value="' . $i . '" ' . $selected . '>' . $i . '</option>';
    }
    print'</select>';
    print '</td></tr><tr><td>&nbsp;</td></tr>
	<tr><td></td><td><input class="demo2 demo" type="radio"  name="status_immo"  id="demo2-a"  onclick="affichproduit(0);" value="1" ' . ($_SESSION["status_immo"] == "1" ? "checked" : "") . '><label for="demo2-a">Proprietaire</label><br></td></tr>
	<tr><td></td><td><input class="demo2 demo"  type="radio" id="demo2-b" name="status_immo"  onclick="document.location.href=\'/custom/deviscara/dev_card.php?action=create2&err=pv_loc_impossible\'" value="2" ' . ($_SESSION["status_immo"] == "2" ? "checked" : "") . '><label for="demo2-b">Locataire</label></td></tr></td></tr>
	</table></div>';

    print '<div id="idprod0" style="display: none;"><table class="tableclassicrep" ><tr>
	<tr><td rowspan=4>Type d\'offre demandé</td><td><input class="demo2 demo"  type="radio" id="1" name="type_projet"   onclick="affichproduit(1);" value="1" ' . ($_SESSION['pv']["type_projet"] == "1" ? "checked" : "") . '><label for="1">' . $object->fields['type_projet']['arrayofkeyval'][1] . '</label></td></tr></td></tr>
	<tr><td><input class="demo2 demo" type="radio"  name="type_projet"  id="2"  onclick="affichproduit(1);" value="2" ' . ($_SESSION['pv']["type_projet"] == "2" ? "checked" : "") . '><label for="2">' . $object->fields['type_projet']['arrayofkeyval'][2] . '</label><br></td></tr>
	<tr><td><input class="demo2 demo" type="radio"  name="type_projet"  id="3"  onclick="affichproduit(1);" value="3" ' . ($_SESSION['pv']["type_projet"] == "3" ? "checked" : "") . '><label for="3">' . $object->fields['type_projet']['arrayofkeyval'][3] . '</label><br></td></tr>
	<tr><td><input class="demo2 demo" type="radio"  name="type_projet"  id="4"  onclick="this.form.submit();" value="4" ' . ($_SESSION['pv']["type_projet"] == "4" ? "checked" : "") . '><label for="4">' . $object->fields['type_projet']['arrayofkeyval'][4] . '</label><br></td></tr>
	</table></div>';

    print '<div id="idprod1" style="display: none;"><table class="tableclassicrep"><tr>
	<tr><td >Nombre de bâtiments</td><td>
	<select name="nb_batiments" style="width: 50px;" id="nb_batiments" >';
    foreach ($object->fields['nb_batiments']['arrayofkeyval'] as $nb) {
        if ($_SESSION['pv']["nb_batiments"] == "$nb")
            $selected = 'selected';
        else $selected = '';
        print '<option value="' . $nb . '" ' . $selected . '>' . $nb . '</option>';
    }
    print'</td></tr>
	<tr><td><input type="submit" name="vnb_batiemnts" value="valider"></td></tr>
	</table></div>';
    if ($_SESSION['pv']['nb_batiments']) print '<div id="idprod3" style="display: block;" >';
    else print '<div id="idprod2" style="display: none;" >';
    print'<table class="tableclassicrep"> <tr>';
    foreach ($object->fields['nb_batiments']['arrayofkeyval'] as $nb) {
        if ($nb > 0) {
            if ($nb > $_SESSION['pv']['nb_batiments']) break;
            print '<tr><td>Batiment ' . $nb . '</td><td>Longueur:' . $object->showInputField($object->fields['bat' . $nb . 'l1'], 'bat' . $nb . 'l1', $_SESSION[$prod]['bat' . $nb . 'l1'], '', '', '', 0) . '</td><td>Largeur:' . $object->showInputField($object->fields['bat' . $nb . 'l2'], 'bat' . $nb . 'l2', $_SESSION[$prod]['bat' . $nb . 'l2'], '', '', '', 0) . '</td></tr>';
        }
    }
    print '<tr><td><input type="submit" name="vbatiments" value="valider"></td></tr>';
    print'</table></div>';

    if ($_SESSION[$prod]['bat1l1'] > 0) print '<div id="idprod3" style="display: block;" >';
    else print '<div id="idprod3" style="display: none;" >';
    print'<table class="tableclassicrep"> <tr>
	<tr><td>Saisit du type de toiture</td><td></td></tr>';
    foreach ($object->fields['type_toiture']['arrayofkeyval'] as $key => $val) {
        if ($key > 0)
            print '<tr><td></td><td><input class="demo2 demo" type="radio"  name="type_toiture"  id="type_toiture_' . $key . '"  onclick="this.form.submit();" value="' . $key . '" ' . ($_SESSION['pv']["type_toiture"] == $key ? "checked" : "") . '><label for="type_toiture_' . $key . '">' . $object->fields['type_toiture']['arrayofkeyval'][$key] . '</label><br></td></tr>';
    }
    print '</table></div>';

    if ($_SESSION['pv']['surface_utile'] > 0) print '<div id="idprod4" style="display: block;" >';
    else print '<div id="idprod4" style="display: none;" >';

    print'<table class="tableclassicrep"> <tr>
	<tr><td>Surface Utile calculée</td><td>' . $_SESSION['pv']['surface_utile'] . ' M2</td></tr>
	<tr><td>Puissance Estimée </td><td>' . $_SESSION['pv']['puissance_estimee'] . ' Kwc</td></tr>
	<tr><td>Loyer Estimé </td><td>' . $_SESSION['pv']['loyer_estime'] . ' €/an</td></tr>
	<tr><td>Soulte Estimée </td><td>' . $_SESSION['pv']['soulte_estime'] . ' € </td></tr>
	<tr><td><input type="submit" name="poursuivre" value="Poursuivre"> </td><td><input type="submit" name="reinit" value="re-initialiser"></td></tr>
	';

    print '</table></div>';
    dol_fiche_end();

    print '<div class="center" id="affichbuttons"  style="display: none;">';
    print '<input type="submit" class="button" name="create" value="' . dol_escape_htmltag($langs->trans("Create")) . '">';
    print '&nbsp; ';
    print '<input type="submit" class="button" name="reinit" value="re-initialiser">';
    print '</div>';

    print '</form>';

    //dol_set_focus('input[name="ref"]');
}
if ($action == 'create_client') {
    $extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
    print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("deviscaratoitbis")));

    print '<form method="POST" name="creationclient" action="' . $_SERVER["PHP_SELF"] . '">';
    print '<input type="hidden" name="token" value="' . newToken() . '">';
    print '<input type="hidden" name="action" value="creerdevis">';
    if ($backtopage) print '<input type="hidden" name="backtopage" value="' . $backtopage . '">';
    if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="' . $backtopageforcancel . '">';

    dol_fiche_head(array(), '');

    print'<div id="zoneclient" style="display: block;">';
    // Ajout de la gestion des adresses identiques.
    print '<script type="text/javascript" language="javascript">

      function CopierAdresses(f) {
          if(f.adresseIdentique.checked == true) {
            f.address.value = f.address_projet.value;
            f.options_ville.value = f.ville_projet.value;
          }
        else
            {
                f.address.value = "";
                f.options_ville.value = "";
            }
        function check() {
        let inputs = document.getElementById(adresseIdentique);
        inputs.checked = true;
      }
      //create uncheck function
      function uncheck() {
        let inputs = document.getElementById(adresseIdentique);
        inputs.checked = false;
      }
      window.onload = function() {
//        window.addEventListener(load, check, false);
        document.getElementById(adresseIdentique).checked = true;
      }
    }</script>';
    print '<a href="#client"></a><table class="border ">';
    // Firstname

    print '<tr class="individualline fieldrequired"><td>' . $form->editfieldkey('Nom client', 'firstname', $value, $object_soc, 0) . '</td>';
    print '<td colspan="3"><input type="text" class="minwidth300" maxlength="128" name="firstname" id="firstname" value="' . GETPOST('firstname') . '"></td>';
    print '</tr>';
// Addresses
    print '<tr><td class="fieldrequired">' . $form->editfieldkey('Addresse Projet', 'adresse_projet', '', GETPOST('adresse_projet'), 0) . '</td>';
    print '<td colspan="3"><textarea name="address_projet" id="address_projet" placeholder="Saisir le N° puis le nom de la rue" class="quatrevingtpercent" rows="' . ROWS_2 . '" wrap="soft">';
    print GETPOST('adresse_projet');
    print '</textarea></td></tr>';
    print '<tr><td class="fieldrequired">Cp Ville Projet</td>';
    print '<td colspan="3">';
    print $object->showInputField($object->fields['ville_projet'], 'ville_projet', GETPOST('ville_projet'), '', '', '', 0);
    print '</td></tr>';
    print'<br>';
    print'<tr><td><label for="adresseIdentique">Cocher si les adresses sont identiques </label><input type = "checkbox" name = "adresseIdentique" id="adresseIdentique" onclick="CopierAdresses(this.form)"></tr></td>';
    print '<tr><td class="fieldrequired">' . $form->editfieldkey('Address', 'address', '', $object_soc, 0) . '</td>';
    print '<td colspan="3"><textarea name="address" id="address" placeholder="Saisir le N° puis le nom de la rue" class="quatrevingtpercent" rows="' . ROWS_2 . '" wrap="soft">';
    print $object_soc->address;
    print '</textarea></td></tr>';
    print '<tr><td class="fieldrequired">Cp ville</td>';
    print '<td colspan="3">';
    print $extrafields_soc->showInputField('ville', GETPOST('options_ville'), '', '', '', 0, $object_soc->id, 'societe');
    print '</td></tr>';
    print '<input type="hidden" name="country_id" value="1">';
    print '<tr><td class="fieldrequired">' . img_picto('', 'object_phoning') . ' ' . $form->editfieldkey('Phone', 'phone', '', $object_soc, 0) . '</td>';
    print '<td><input type="text" name="phone" id="phone" class="maxwidth200" value="' . (GETPOSTISSET('phone') ? GETPOST('phone', 'alpha') : $object_soc->phone) . '"></td>';

    print '<td>' . img_picto('', 'object_phoning_fax') . ' ' . $form->editfieldkey('Phone', 'fax', '', $object_soc, 0) . '</td>';
    print '<td><input type="text" name="fax" id="fax" class="maxwidth200" value="' . (GETPOSTISSET('fax') ? GETPOST('fax', 'alpha') : $object_soc->fax) . '"></td></tr>';

    // Email / Web
    print '<tr><td class="fieldrequired">' . img_picto('', 'object_email') . ' ' . $form->editfieldkey('Email', 'email', '', $object_soc, 0, 'string', '') . '</td>';
    print '<td ><input type="text" name="email" id="email" value="' . $object_soc->email . '"></td>';
    print '<td>' . img_picto('', 'globe') . ' ' . $form->editfieldkey('Phone', 'url', '', $object_soc, 0, 'string', '') . '</td>';
    print '<td colspan="3"><input type="text" name="url" id="url" value="' . $object_soc->url . '"></td></tr>';
    //profession
    print '<tr><td>Situation professionnelle Mr</td>';
    print '<td >' . $extrafields_soc->showInputField('spmo', GETPOST('options_spmo'), '', '', '', 0, $object_soc->id, 'societe') . '</td></tr>';

    print '<tr><td>Situation professionnelle Mme</td>';
    print '<td >' . $extrafields_soc->showInputField('spma', GETPOST('options_spma'), '', '', '', 0, $object_soc->id, 'societe') . '</td></tr>';

    print '<tr><td >Profession Mr</td>';
    print '<td >' . $extrafields_soc->showInputField('profession', GETPOST('options_profession'), '', '', '', 0, $object_soc->id, 'societe') . '</td></tr>';

    print '<tr><td >Profession Mme</td>';
    print '<td >' . $extrafields_soc->showInputField('professionmme', GETPOST('options_professionmme'), '', '', '', 0, $object_soc->id, 'societe') . '</td></tr>';

    print'<tr><td><input type="submit" class="button" name="devis" value="créer devis"></td></tr></table></div>';
    print '</form>';

    dol_fiche_end();
}
if ($action == 'create_technique') {

    $htm = load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("devis PV")));
    $bool = 0;
    $htm .= '<form method="POST" name="creationclient" action="' . $_SERVER["PHP_SELF"] . '">';
    $htm .= '<input type="hidden" name="token" value="' . newToken() . '">';
    $htm .= '<input type="hidden" name="action" value="enregistrer_demande">';
    if ($backtopage) print '<input type="hidden" name="backtopage" value="' . $backtopage . '">';
    if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="' . $backtopageforcancel . '">';

    dol_fiche_head(array(), '');

    $htm .= '<div id="zoneclient" style="display: block;">';

    $htm .= '<a href="#client"></a>';
    if ($_SESSION['type_projet'] != 1) {
        $bool = 1;
        $htm .= '<table class="tableclassictech">';
        //Age tole
        $htm .= '<tr class="individualline"><td>Age Tôle</td>';
        $htm .= '<td colspan="3">' . $object->showInputField($object->fields['age_tole'], 'age_tole', $_SESSION[$prod]['age_tole'], '', '', '', 0) . '</td>';
        $htm .= '</tr>';
        //omrage
        $htm .= '<tr class="individualline"><td>Ombrage</td>';
        $htm .= '<td ><input class="demo2 demo" type="radio"  name="ombrage"  id="ombrage_1"  value="1" ' . ($_SESSION['pv']["ombrage"] == "1" ? "checked" : "") . '><label for="ombrage_1">' . $object->fields['ombrage']['arrayofkeyval'][1] . '</label><br></td>';
        $htm .= '<td ><input class="demo2 demo" type="radio"  name="ombrage"  id="ombrage_2"  value="2" ' . ($_SESSION['pv']["ombrage"] == "2" ? "checked" : "") . '><label for="ombrage_2">' . $object->fields['ombrage']['arrayofkeyval'][2] . '</label><br></td>';
        $htm .= '<td ><input class="demo2 demo" type="radio"  name="ombrage"  id="ombrage_3"  value="3" ' . ($_SESSION['pv']["ombrage"] == "3" ? "checked" : "") . '><label for="ombrage_3">' . $object->fields['ombrage']['arrayofkeyval'][3] . '</label><br></td>';
        $htm .= '</tr>';
        //fuite
        $htm .= '<tr class="individualline"><td></td></tr>';
        $htm .= '<tr class="individualline"><td>Fuite</td>';
        $htm .= '<td ><input class="demo2 demo" type="radio"  name="fuite"  id="fuite_1"  value="1" ' . ($_SESSION['pv']["fuite"] == "1" ? "checked" : "") . '><label for="fuite_1">' . $object->fields['fuite']['arrayofkeyval'][1] . '</label><br></td>';
        $htm .= '<td ><input class="demo2 demo" type="radio"  name="fuite"  id="fuite_2"  value="2" ' . ($_SESSION['pv']["fuite"] == "2" ? "checked" : "") . '><label for="fuite_2">' . $object->fields['fuite']['arrayofkeyval'][2] . '</label><br></td>';
        $htm .= '</tr></table><br><br>';
    }

    $htm .= '<table class="tableclassictech">';
    $htm .= '<tr><td>Situation du client<br><select name="categorie" class="fieldrequired" required>
		<option value="0"></option>
		<option value="1" ' . ($_SESSION["pv"]['categorie'] == 1 ? 'selected' : '') . '>Actif</option>
		<option value="2" ' . ($_SESSION["pv"]['categorie'] == 2 ? 'selected' : '') . '>Non actif</option></select></td>
		<td width="50%"> Consommation Annuelle d\'électricité en kwh/an<br><input type="text" name="kwhan" value="' . $_SESSION["pv"]['kwhan'] . '"></td><td>
		<input type="button" class="button" name="calcul" value="Calcul Autonomie" onclick="document.creationclient.action.value=\'affichgraph\';document.creationclient.submit();"></td></tr>';
    $kwhan = $_SESSION["pv"]['kwhan'];
    $puissance_necessaire = $kwhan / 1500;
    $stockage_energie = $kwhan / 730;
    $budget_total = (2000 * $puissance_necessaire) + (1600 * $stockage_energie);
    $nombrepnxa = ($puissance_necessaire * 1000) / 410;
    $nombrepnxb = $stockage_energie / 2.4;

    $budget_total_html = '';
    if ($kwhan > 0) {
        $budget_total_html = '<tr><td></td><td colspan=4 >Votre besoin pour couvrir l\'équivalent de votre facture EDF : ' . number_format($puissance_necessaire, 2) . ' kWc ' . number_format($stockage_energie, 2) . ' kWh ' . ' </br> ' . ' soit ' . ceil($nombrepnxa) . ' panneaux de 410wc et ' . ceil($nombrepnxb) . ' batteries de 2.4kWh' . '</td></tr>';
    }


    $htm .= '<tr><td colspan="4"> ' . $budget_total_html . '</td></tr><br>';

    if (is_countable($taux_autonomie) > 0) {
        $htm .= '<table class="tableclassictech">';
        $htm .= '<tr><td>Type de formule</td><td>Composition</td><td>Taux d\'autonomie</td><td>Prix TTC</td><td>Economie sur 20 ans</td><td>ROI moyen / 20 ans</td></tr>';


        foreach ($taux_autonomie as $formule => $taux) {
            $compositions = $composition[$formule];
            if ($formule == '100% autonome') {
                $consommation_autonome = $_SESSION["pv"]['kwhan'];
                $taux_autonomie[$formule] = 100;

            }
            //load object devis moddèle
            $devis_pv1 = new propal($db);
            $devis_pv1->fetch($pv_devistype[$_SESSION['pv']['type_projet']][$formule]);
            // réinitialiser la variable cumul1 à zéro pour chaque formule
            $cumul1 = 0;

            foreach ($tarifEdf as $year => $prixedf) {
                $tarifedf1 = $prixedf * $_SESSION["pv"]['kwhan'];
                if ($formule != '100% autonome') {
                    $economie1 = ($prixedf * $_SESSION["pv"]['kwhan'] / 100 * $taux_autonomie[$formule]);
                }

                if ($year <= 2032)
                    // ajouter la valeur à la sortie en fonction de l'année
                    $htmxx .= '<td>' . number_format($economie1, 2) . '</td>';
                else
                    // ajouter la valeur à la sortie en fonction de l'année
                    $htmxx .= '<td>' . number_format($economie1, 2) . '</td>';
                // ajouter l'économie à la variable cumul1 pour cette formule
                $cumul1 += $economie1;


            }

            if ($tarifsFloc != 0) {
                // afficher la sortie pour chaque formule
                $htm .= '<tr ><td bgcolor="#D9D8D5">' . $lib_formule[$formule] . ' :</td><td>' . $compositions . '</td><td>' . number_format($taux, 2) . ' %</td><td>' . round($devis_pv1->total_ttc, 2) . ' €' . '</td><td>' . round($cumul1, 2) . ' €' . '</td><td>' . number_format($tarifsFloc[$formule] / ($cumul1 / 20), 0) . ' ans' . '</td></tr>';
                $_SESSION['pv']['economie'][$formule] = $cumul1;
                $_SESSION['pv']['roi'][$formule] = number_format($tarifsFloc[$formule] / ($cumul1 / 20), 0);
            }

        }

        // Calculer le budget total de la formule 100% autonome
        if ($formule == '100% autonome') {
            $budget_total = 0;
        } else {
            $puissance_necessaire = $_SESSION["pv"]['kwhan'] / 1500;
            $stockage_energie = $_SESSION["pv"]['kwhan'] / 730;
            $budget_total = (2000 * $puissance_necessaire) + (1600 * $stockage_energie);
            $nombrepnxa = ($puissance_necessaire * 1000) / 410;
            $nombrepnxb = $stockage_energie / 2.4;

        }

//        $budget_total_html = '';
//        if ($formule != '100% autonome') {
//            $budget_total_html = '<tr><td colspan=4 >Votre besoin pour être 100% autonome : ' . number_format($nombrepnxa, 0) . ' panneaux de 410wc et ' .  number_format($nombrepnxb, 0) .  ' batteries de 2.4kWh'.'</td></tr>';
//        }

        $htm .= '<tr><td colspan="4" style="color:#FF0000";>Le taux d\'autonomie peut varier de plus ou moins 10% en fonction de vos habitudes de consommation et du réglage des appareils consommateurs pour fonctionner en journée (machine à laver, sèche linge, lave vaisselle, piscine...) </td ></tr>';
//        $htm .= '<tr><td colspan="4"> ' . $budget_total_html . '</td></tr><br>';
        $htm .= '</table><br><br>';

    }

    $htm .= '</table><br><br>';

    $htm .= '<table class="tableclassictech">';

    //pvloc + autoconso uniquement pour pvloc+autoconso
    if ($_SESSION['pv']['type_projet'] == 3) {
        $bool = 1;
        $htm .= '<tr class="individualline"><td>Type Autoconso</td>';
        $htm .= '<td colspan="3">' . $object->showInputField($object->fields['type_autoconso'], 'type_autoconso', $_SESSION['pv']['type_autoconso'], ' onchange="document.creationclient.action.value=\'affichgraph\';document.creationclient.submit();" ', '', '', 0) . '</td>';
        $htm .= '</tr>';
    }
    if ($_SESSION['pv']['type_projet'] == 4) {
        $bool = 1;
        $htm .= '<tr class="individualline"><td>Type Autoconso seule</td>';
        $htm .= '<td colspan="3">' . $object->showInputField($object->fields['type_autoconso2'], 'type_autoconso2', $_SESSION['pv']['type_autoconso2'], 'onchange="document.creationclient.action.value=\'affichgraph\';document.creationclient.submit();"', '', '', 0) . '</td>';
        $htm .= '</tr>';
    }


    if ($actionbis == 'affichgraph') {
        if ($_SESSION['pv']['type_projet'] == 3)
            $formule = $_SESSION['pv']['type_autoconso'];
        elseif ($_SESSION['pv']['type_projet'] == 4)
            $formule = $_SESSION['pv']['type_autoconso2'];
        if (in_array($formule, array_keys($lib_formule))) {//si la formule choisie est dans la liste des libelles de formules car il y en a plus dans la classe.
            $htm .= '<table class="tagtable liste' . ($moreforfilter ? " listwithfilterbefore" : "") . '"><tr ><td colspan=20 align="center" bgcolor="#D9D8D5">Economie en euro pour les 20 prochaines années</td></tr><tr>';
            $htm2 = '<tr>';
            // Gestion des années.
            $startYear = date("Y");
            $endYear = $startYear + 19;
            for ($i = $startYear; $i <= ($startYear + 9); $i++) {
                $htm .= '<td bgcolor="lightgrey">' . $i . '</td>';
                $htm2 .= '<td bgcolor="lightgrey">' . ($i + 10) . '</td>';
            }
            $htm .= '</tr><tr class="oddeven">';
            $htm2 .= '</tr><tr class="oddeven">';
            $data = array();

            foreach ($tarifEdf as $year => $prixedf) {
                $tarifedf = $prixedf * $_SESSION["pv"]['kwhan'];
                $montant = $tarifedf - ($_SESSION["pv"]['kwhan'] / 100 * $taux_autonomie[$formule] * $prixedf);

                $economie = ($prixedf * $_SESSION["pv"]['kwhan'] / 100 * $taux_autonomie[$formule]);
                if ($year <= 2032)
                    // ajouter la valeur à la sortie en fonction de l'année
                    $htm .= '<td>' . number_format($economie, 2) . '</td>';
                else
                    // ajouter la valeur à la sortie en fonction de l'année
                    $htm2 .= '<td>' . number_format($economie, 2) . '</td>';
                // ajouter l'économie à la variable cumul pour cette formule
                $cumul += $economie;
                $data[] = array($year, $montant, $tarifedf);

            }
            $htm .= '</tr>';
            $htm2 .= '</tr>';
            $htm .= $htm2;
            $htm .= '</table><br><br>';
            $htm .= '<table class="tagtable liste' . ($moreforfilter ? " listwithfilterbefore" : "") . '"><tr ><td colspan=2 bgcolor="#D9D8D5">Economie sur 20 ans</td><td>Durée amortissement en années(formule avec location)</td><td>Durée amortissement en années(formule sans location)</td></tr>';
            $htm .= '<tr class="oddeven"><td>' . $lib_formule[$formule] . '</td><td>' . round($cumul, 2) . '€' . '</td><td align="center">' . number_format($tarifsFloc[$formule] / ($cumul / 20), 0) . '</td><td align="center">' . number_format($tarifsFsloc[$formule] / ($cumul / 20), 0) . '</td></tr>';
            $htm .= '</table><br><br>';
            $htm .= '<table  ><tr><td>';

            //affichage courbe
            include_once DOL_DOCUMENT_ROOT . '/core/class/dolgraph.class.php';
            print '<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.3.3/html2canvas.min.js">
            </script>';
            $dir = $conf->deviscara->multidir_output[$conf->entity] . "/temp";
            $objref = dol_sanitizeFileName($object->ref);
            $file = "_courbe.png";
            $fileurl = $dir . "/" . $file;
            $px1 = new DolGraph();
            $mesg = $px1->isGraphKo();
            if ($px1->isGraphKo()) {
                echo "Error: " . $px1->getGraphError();
            }


            if (!$mesg) {
                $langs->load("bills");
                $px1->SetData($data);
                unset($data);
                $px1->SetPrecisionY(0);
                $i = 0;
                $legend = array('Facture EDF avec photovoltaique', 'Facture EDF sans photovoltaique');
                $px1->SetLegend($legend);
                $px1->SetMaxValue($px1->GetCeilMaxValue());
                $px1->SetWidth(1000);
                $px1->SetHeight(400);
                $px1->SetYLabel($langs->trans("test"));
                $px1->SetShading(3);
                $px1->SetHorizTickIncrement(1);
                $px1->SetPrecisionY(0);
                $px1->SetCssPrefix("cssboxes");
                $px1->mode = 'depth';
                $px1->SetTitle($langs->trans("Economie Annuelle sur les 20 prochaines années / coût EDF"));
                $px1->SetType('lines');
                if (!is_writable(dirname($fileurl))) {
                    echo "Error: The directory " . dirname($fileurl) . " is not writable.";
                }
                error_log("Attempting to save the image to: " . $fileurl);
                $px1->draw($file, $fileurl);
                error_log("Image saved: " . (file_exists($fileurl) ? "Yes" : "No"));
                $htm .= '<div id="graph-container">';
                $htm .= $px1->show();
                $htm .= '</div>';
                $htm .= '<script type="text/javascript" language="javascript">
function captureAndSaveGraph() {
    var graphElement = document.getElementById("graph-container");

    html2canvas(graphElement).then(function(canvas) {
        var dataUrl = canvas.toDataURL("image/png");

        fetch("your-save-image-script.php", {
            method: "POST",
            headers: {
            "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "dataUrl=" + encodeURIComponent(dataUrl)
        })
        .then(function(response) {
            if (response.ok) {
                console.log("Image sauvegardée avec succès");
            } else {
                console.error("Erreur lors de la sauvegarde de l\'image");
            }
        })
        .catch(function(error) {
            console.error("Erreur réseau lors de la sauvegarde de l\'image:", error);
        });
    });
}

// Lancez la fonction de capture et de sauvegarde du graphique après le chargement de la page
// window.addEventListener("load", captureAndSaveGraph);
window.onload = function() {
    captureAndSaveGraph();
</script>';
                $htm .= '<br></td></tr>';
            }
        }
        $budget_total_html = str_replace(array('<tr><td></td><td colspan=4 >', '</td></tr>', '</br>'), '', $budget_total_html);
        $object->description = $budget_total_html;
        $htm .= '<tr><td>Commentaires : ' . $object->showInputField($object->fields['description'], 'description', $object->description, '', '', '', 0) . '</td></tr></table><br>';

        //load object devis moddèle
        $devis_pv = new propal($db);
        $devis_pv->fetch($pv_devistype[$_SESSION['pv']['type_projet']][$formule]);
        $_SESSION['financement']['totaldevis'] = $devis_pv->total;
        include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/lib/deviscara_tarifpv.lib.php', 1);

        $htm .= '<table class="tableclassicpv">';
        $htm .= '<tr class="individualline"><td>Mode de financement et montant à financer: ' . round($devis_pv->total_ttc, 2) . '</td>';

        $htm .= '<tr><td>CMA</td><td></td><td></td><td></td><td>Perso</td></tr>';
        $htm .= '<tr><td>Avec Report de 30 jours</td><td>Avec Report de 90 jours</td></tr>';
        $htm .= '<tr><td>';

        $mensualité = array_keys($tabfin[30]);
        $select = '';
        foreach ($mensualité as $mois) {
            $montant30 = $devis_pv->total * $tabfin[30][$mois]; //gérer l'acompte
            $montant90 = $devis_pv->total * $tabfin[90][$mois]; //gérer l'acompte
            //$select .= '' . $mois . ' :  <input type="radio" onclick="this.form.submit();" name="mode_reglement_cma" value="' . $mois . '/' . $montant30 . '" ' . ($_SESSION['financement']['fincma']['30'] == $mois ? 'checked' : '') . ' > <input type="text" name="montant" readonly value="' . price($montant, 0, '', 2, 2, 2) . '"><br>';
            $select .= '<tr><td>' . $mois . ' :  <input type="radio" name="mode_reglement_cma" value="1/' . $mois . '/' . round($montant30,2) . '" ' . ($_SESSION['financement']['fincma']['30'] == $mois ? 'checked' : '') . ' > <input type="text" name="montant" readonly value="' . price($montant30, 0, '', 2, 2, 2) . '"></td>';

            $select .= '<td>' . $mois . ' :  <input type="radio" name="mode_reglement_cma" value="2/' . $mois . '/' . round($montant90,2) . '" ' . ($_SESSION['financement']['fincma']['90'] == $mois ? 'checked' : '') . ' ><input type="text" name="montant" readonly value="' . price($montant90, 0, '', 2, 2, 2) . '"></td>';
        }
       // $htm .= $select . '</td><td></td><td></td><td></td><td><input type="radio" onclick="this.form.submit();"  name="mode_reglement_perso" value="3" > CHEQUE <br>
		//							<input type="radio" onclick="this.form.submit();" name="mode_reglement_perso" value="1">ESPECES<br>
			//						<input type="radio" onclick="this.form.submit();" name="mode_reglement_perso" value="2">Virement</td>';

        $htm .= $select . '</td><td><input type="radio"  name="mode_reglement_perso" value="3" > CHEQUE <br>
									<input type="radio"  name="mode_reglement_perso" value="1">ESPECES<br>
									<input type="radio"  name="mode_reglement_perso" value="2">Virement</td>';
        $htm .= '</tr></table><br>';

    }

    $htm .= '<tr><td><input type="submit" class="button" name="enregistrer_demande" value="valider"></td></tr></table></div>';
    //$htm .= '<tr><td><input type="submit" class="button" name="enregistrer_demande" value="Créer le client" ></td></tr></table></div>';
    $htm .= '</form>';
    $htm .= '</div>';
    if ($bool == 1)
        print $htm;
    else {
        $action = 'enregistrer_demande';
        //  $action = 'create_client';
        include_once DOL_DOCUMENT_ROOT . dol_buildpath('deviscara/core/actions_addupdatedeletepv.inc.php', 1);
    }
    dol_fiche_end();
}
// Part to edit record
if (($id || $ref) && $action == 'edit') {
    print load_fiche_titre($langs->trans("rep"));

    print '<form method="POST" action="' . $_SERVER["PHP_SELF"] . '">';
    print '<input type="hidden" name="token" value="' . newToken() . '">';
    print '<input type="hidden" name="action" value="update">';
    print '<input type="hidden" name="id" value="' . $object->id . '">';
    if ($backtopage) print '<input type="hidden" name="backtopage" value="' . $backtopage . '">';
    if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="' . $backtopageforcancel . '">';

    dol_fiche_head();

    print '<table class="border centpercent tableforfieldedit">' . "\n";

    // Common attributes
    include DOL_DOCUMENT_ROOT . dol_buildpath('deviscara/core/tpl/commonfields_edit.tpl.php', 1);

    // Other attributes
    include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_edit.tpl.php';

    print '</table>';

    dol_fiche_end();

    print '<div class="center"><input type="submit" class="button" name="save" value="' . $langs->trans("Save") . '">';
    print ' &nbsp; <input type="submit" class="button" name="cancel" value="' . $langs->trans("Cancel") . '">';
    print '</div>';

    print '</form>';
}

// Part to show record
if ($object->id > 0 && (empty($action) || ($action != 'edit' && $action != 'create'))) {
    $res = $object->fetch_optionals();

    $head = repPrepareHead($object);
    dol_fiche_head($head, 'card', $langs->trans("rep"), -1, $object->picto);

    $formconfirm = '';

    // Confirmation to delete
    if ($action == 'delete') {
        $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"] . '?id=' . $object->id, $langs->trans('Deleterep'), $langs->trans('ConfirmDeleteObject'), 'confirm_delete', '', 0, 1);
    }
    // Confirmation to delete line
    if ($action == 'deleteline') {
        $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"] . '?id=' . $object->id . '&lineid=' . $lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deleteline', '', 0, 1);
    }
    // Clone confirmation
    if ($action == 'clone') {
        // Create an array for form
        $formquestion = array();
        $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"] . '?id=' . $object->id, $langs->trans('ToClone'), $langs->trans('ConfirmClonerep', $object->ref), 'confirm_clone', $formquestion, 'yes', 1);
    } elseif ($action == 'ask_deleteline') {
        $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"] . '?id=' . $object->id . '&lineid=' . $lineid, $langs->trans('DeleteProductLine'), $langs->trans('ConfirmDeleteProductLine'), 'confirm_deleteline', '', 0, 1);
    }
    // Confirmation of action xxxx
    if ($action == 'xxx') {
        $formquestion = array();
        /*
        $forcecombo=0;
        if ($conf->browser->name == 'ie') $forcecombo = 1;	// There is a bug in IE10 that make combo inside popup crazy
        $formquestion = array(
            // 'text' => $langs->trans("ConfirmClone"),
            // array('type' => 'checkbox', 'name' => 'clone_content', 'label' => $langs->trans("CloneMainAttributes"), 'value' => 1),
            // array('type' => 'checkbox', 'name' => 'update_prices', 'label' => $langs->trans("PuttingPricesUpToDate"), 'value' => 1),
            // array('type' => 'other',    'name' => 'idwarehouse',   'label' => $langs->trans("SelectWarehouseForStockDecrease"), 'value' => $formproduct->selectWarehouses(GETPOST('idwarehouse')?GETPOST('idwarehouse'):'ifone', 'idwarehouse', '', 1, 0, 0, '', 0, $forcecombo))
        );
        */
        $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"] . '?id=' . $object->id, $langs->trans('XXX'), $text, 'confirm_xxx', $formquestion, 0, 1, 220);
    }

    // Call Hook formConfirm
    $parameters = array('formConfirm' => $formconfirm, 'lineid' => $lineid);
    $reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    if (empty($reshook)) $formconfirm .= $hookmanager->resPrint;
    elseif ($reshook > 0) $formconfirm = $hookmanager->resPrint;

    // Print form confirm
    print $formconfirm;


    // Object card
    // ------------------------------------------------------------
    $linkback = '<a href="' . dol_buildpath('/deviscara/rep_list.php', 1) . '?restore_lastsearch_values=1' . (!empty($socid) ? '&socid=' . $socid : '') . '">' . $langs->trans("BackToList") . '</a>';

    $morehtmlref = '<div class="refidno">';
    /*
    // Ref bis
    $morehtmlref.=$form->editfieldkey("RefBis", 'ref_client', $object->ref_client, $object, $user->rights->deviscara->rep->creer, 'string', '', 0, 1);
    $morehtmlref.=$form->editfieldval("RefBis", 'ref_client', $object->ref_client, $object, $user->rights->deviscara->rep->creer, 'string', '', null, null, '', 1);
    // Thirdparty
    $morehtmlref.='<br>'.$langs->trans('ThirdParty') . ' : ' . (is_object($object->thirdparty) ? $object->thirdparty->getNomUrl(1) : '');
    // Project
    if (! empty($conf->projet->enabled))
    {
        $langs->load("projects");
        $morehtmlref.='<br>'.$langs->trans('Project') . ' ';
        if ($permissiontoadd)
        {
            if ($action != 'classify')
                $morehtmlref.='<a class="editfielda" href="' . $_SERVER['PHP_SELF'] . '?action=classify&amp;id=' . $object->id . '">' . img_edit($langs->transnoentitiesnoconv('SetProject')) . '</a> : ';
            if ($action == 'classify') {
                //$morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'projectid', 0, 0, 1, 1);
                $morehtmlref.='<form method="post" action="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'">';
                $morehtmlref.='<input type="hidden" name="action" value="classin">';
                $morehtmlref.='<input type="hidden" name="token" value="'.newToken().'">';
                $morehtmlref.=$formproject->select_projects($object->socid, $object->fk_project, 'projectid', 0, 0, 1, 0, 1, 0, 0, '', 1);
                $morehtmlref.='<input type="submit" class="button valignmiddle" value="'.$langs->trans("Modify").'">';
                $morehtmlref.='</form>';
            } else {
                $morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'none', 0, 0, 0, 1);
            }
        } else {
            if (! empty($object->fk_project)) {
                $proj = new Project($db);
                $proj->fetch($object->fk_project);
                $morehtmlref.=$proj->getNomUrl();
            } else {
                $morehtmlref.='';
            }
        }
    }
    */
    $morehtmlref .= '</div>';


    dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref);


    print '<div class="fichecenter">';
    print '<div class="fichehalfleft">';
    print '<div class="underbanner clearboth"></div>';
    print '<table class="border centpercent">' . "\n";

    // Common attributes
    //$keyforbreak='fieldkeytoswitchonsecondcolumn';	// We change column just after this field
    //unset($object->fields['fk_project']);				// Hide field already shown in banner
    //unset($object->fields['fk_soc']);					// Hide field already shown in banner
    include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/core/tpl/commonfields_view.tpl.php', 1);

    // Other attributes. Fields from hook formObjectOptions and Extrafields.
    include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_view.tpl.php';

    print '</table>';
    print '</div>';
    print '</div>';

    print '<div class="clearboth"></div>';

    dol_fiche_end();


    /*
     * Lines
     */

    if (!empty($object->table_element_line)) {
        // Show object lines
        $result = $object->getLinesArray();

        print '	<form name="addproduct" id="addproduct" action="' . $_SERVER["PHP_SELF"] . '?id=' . $object->id . (($action != 'editline') ? '#addline' : '#line_' . GETPOST('lineid', 'int')) . '" method="POST">
    	<input type="hidden" name="token" value="' . $_SESSION ['newtoken'] . '">
    	<input type="hidden" name="action" value="' . (($action != 'editline') ? 'addline' : 'updateline') . '">
    	<input type="hidden" name="mode" value="">
    	<input type="hidden" name="id" value="' . $object->id . '">
    	';

        if (!empty($conf->use_javascript_ajax)) {
            include DOL_DOCUMENT_ROOT . '/core/tpl/ajaxrow.tpl.php';
        }

        print '<div class="div-table-responsive-no-min">';
        if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline')) {
            print '<table id="tablelines" class="noborder noshadow" width="100%">';
        }

        if (!empty($object->lines)) {
            $object->printObjectLines($action, $mysoc, null, GETPOST('lineid', 'int'), 1);
        }

        // Form to add new line
        if ($permissiontoadd && $action != 'selectlines') {
            if ($action != 'editline') {
                // Add products/services form
                $object->formAddObjectLine(1, $mysoc, $soc);

                $parameters = array();
                $reshook = $hookmanager->executeHooks('formAddObjectLine', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
            }
        }

        if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline')) {
            print '</table>';
        }
        print '</div>';

        print "</form>\n";
    }


    // Buttons for actions

    if ($action != 'presend' && $action != 'editline') {
        print '<div class="tabsAction">' . "\n";
        $parameters = array();
        $reshook = $hookmanager->executeHooks('addMoreActionsButtons', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
        if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

        if (empty($reshook)) {
            // Send
            print '<a class="butAction" href="' . $_SERVER["PHP_SELF"] . '?id=' . $object->id . '&action=presend&mode=init#formmailbeforetitle">' . $langs->trans('SendMail') . '</a>' . "\n";

            // Back to draft
            if ($object->status == $object::STATUS_VALIDATED) {
                if ($permissiontoadd) {
                    print '<a class="butAction" href="' . $_SERVER['PHP_SELF'] . '?id=' . $object->id . '&action=confirm_setdraft&confirm=yes">' . $langs->trans("SetToDraft") . '</a>';
                }
            }

            // Modify
            if ($permissiontoadd) {
                print '<a class="butAction" href="' . $_SERVER["PHP_SELF"] . '?id=' . $object->id . '&action=edit">' . $langs->trans("Modify") . '</a>' . "\n";
            } else {
                print '<a class="butActionRefused classfortooltip" href="#" title="' . dol_escape_htmltag($langs->trans("NotEnoughPermissions")) . '">' . $langs->trans('Modify') . '</a>' . "\n";
            }

            // Validate
            if ($object->status == $object::STATUS_DRAFT) {
                if ($permissiontoadd) {
                    if (empty($object->table_element_line) || (is_array($object->lines) && count($object->lines) > 0)) {
                        print '<a class="butAction" href="' . $_SERVER['PHP_SELF'] . '?id=' . $object->id . '&action=confirm_validate&confirm=yes">' . $langs->trans("Validate") . '</a>';
                    } else {
                        $langs->load("errors");
                        print '<a class="butActionRefused" href="" title="' . $langs->trans("ErrorAddAtLeastOneLineFirst") . '">' . $langs->trans("Validate") . '</a>';
                    }
                }
            }

            // Clone
            if ($permissiontoadd) {
                print '<a class="butAction" href="' . $_SERVER['PHP_SELF'] . '?id=' . $object->id . '&socid=' . $object->socid . '&action=clone&object=rep">' . $langs->trans("ToClone") . '</a>' . "\n";
            }

            /*
            if ($permissiontoadd)
            {
                if ($object->status == $object::STATUS_ENABLED)
                 {
                     print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=disable">'.$langs->trans("Disable").'</a>'."\n";
                 }
                 else
                 {
                     print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=enable">'.$langs->trans("Enable").'</a>'."\n";
                 }
            }
            if ($permissiontoadd)
            {
                if ($object->status == $object::STATUS_VALIDATED)
                 {
                     print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=close">'.$langs->trans("Cancel").'</a>'."\n";
                 }
                 else
                 {
                     print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=reopen">'.$langs->trans("Re-Open").'</a>'."\n";
                 }
            }
            */

            // Delete (need delete permission, or if draft, just need create/modify permission)
            if ($permissiontodelete) {
                print '<a class="butActionDelete" href="' . $_SERVER["PHP_SELF"] . '?id=' . $object->id . '&amp;action=delete">' . $langs->trans('Delete') . '</a>' . "\n";
            } else {
                print '<a class="butActionRefused classfortooltip" href="#" title="' . dol_escape_htmltag($langs->trans("NotEnoughPermissions")) . '">' . $langs->trans('Delete') . '</a>' . "\n";
            }
            print '<div class="fichehalfleft">' . "\n";
            if ($user->rights->carasun->pv->facturer) {
                print '<a class="butAction" href="' . $_SERVER["PHP_SELF"] . '?id=' . $object->id . '&action=facturer">' . $langs->trans("Facturer") . '</a>' . "\n";
            }
            print '</div>' . "\n";
        }
        print '</div>' . "\n";
    }


    // Select mail models is same action as presend
    if (GETPOST('modelselected')) {
        $action = 'presend';
    }

    if ($action != 'presend') {
        print '<div class="fichecenter"><div class="fichehalfleft">';
        print '<a name="builddoc"></a>'; // ancre

        //Documents
        $objref = dol_sanitizeFileName($object->ref);
        $relativepath = $objref . '/' . $objref . '.pdf';
        $filedir = $conf->deviscara->dir_output . '/' . $objref;
        $urlsource = $_SERVER["PHP_SELF"] . "?id=" . $object->id;
        $genallowed = $user->rights->deviscara->rep->read;    // If you can read, you can build the PDF to read content
        $delallowed = $user->rights->deviscara->rep->create;    // If you can create/edit, you can remove a file on card
        $object->modelpdf = 'soleilsign';
        print $formfile->showdocuments('deviscara', $objref, $filedir, $urlsource, $genallowed, $delallowed, $object->modelpdf, 1, 0, 0, 28, 0, '', '', '', $langs->defaultlang);


        // Show links to link elements
        $linktoelem = $form->showLinkToObjectBlock($object, null, array('rep'));
        $somethingshown = $form->showLinkedObjectBlock($object, $linktoelem);


        print '</div><div class="fichehalfright"><div class="ficheaddleft">';

        $MAXEVENT = 10;

        $morehtmlright = '<a href="' . dol_buildpath('/deviscara/rep_agenda.php', 1) . '?id=' . $object->id . '">';
        $morehtmlright .= $langs->trans("SeeAll");
        $morehtmlright .= '</a>';

        // List of actions on element
        include_once DOL_DOCUMENT_ROOT . '/core/class/html.formactions.class.php';
        $formactions = new FormActions($db);
        $somethingshown = $formactions->showactions($object, $object->element, (is_object($object->thirdparty) ? $object->thirdparty->id : 0), 1, '', $MAXEVENT, '', $morehtmlright);

        print '</div></div></div>';
    }

    //Select mail models is same action as presend
    // Presend form
    $modelmail = 'dev';
    $defaulttopic = 'InformationMessage';
    $diroutput = $conf->deviscara->dir_output;
    $trackid = 'rep' . $object->id;
    $object->modelpdf = 'soleilsign';
    include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/core/tpl/card_presend.tpl.php', 1); //'/core/tpl/card_presend.tpl.php';
}

// End of page
llxFooter();
$db->close();

