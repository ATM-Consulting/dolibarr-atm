<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/dev.class.php
 * \ingroup     deviscara
 * \brief       This file is a CRUD class file for dev (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
dol_include_once('/deviscara/class/toit.class.php');
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

/**
 * Class for dev
 */
class toitdef extends toit
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'deviscara_toitdef';
	public $modulename = 'deviscara';
	public $reptpl = 'tpl_toitdef';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'deviscara_toitdef';
	

	/**
	 * @var int  Does dev support multicompany module ? 0=No test on entity, 1=Test with field entity, 2=Test with link by societe
	 */
	public $ismultientitymanaged = 0;

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 1;

	/**
	 * @var string String with name of icon for dev. Must be the part after the 'object_' into object_dev.png
	 */
	public $picto = 'dev@deviscara';


	const STATUS_DRAFT = 0;
	const STATUS_VALIDATED = 1;
	const STATUS_INCOMPLET = 2;
	const STATUS_CLIENT = 3;
	const STATUS_ALERTE = 4;
	const STATUS_RETOURSATRAITER = 5;
	const STATUS_CANCELED = 9;

	const STATUSADMIN_DRAFT = 0;
	const STATUSADMIN_ATRAITER = 1;
	const STATUSADMIN_CONFORME = 2;
	const STATUSADMIN_INCOMPLET = 3;
	const STATUSADMIN_COMPLET = 4;
	const STATUSADMIN_NONCONFORME = 5;
	const STATUSADMIN_YONI = 6;


	/**
	 *  'type' if the field format ('integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter]]', 'varchar(x)', 'double(24,8)', 'real', 'price', 'text', 'html', 'date', 'datetime', 'timestamp', 'duration', 'mail', 'phone', 'url', 'password')
	 *         Note: Filter can be a string like "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.nature:is:NULL)"
	 *  'label' the translation key.
	 *  'enabled' is a condition when the field must be managed.
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 if you want to have a total on list for this field. Field type must be summable like integer or double(24,8).
	 *  'css' is the CSS style to use on field. For example: 'maxwidth200'
	 *  'help' is a string visible as a tooltip on field
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
	 *  'arraykeyval' to set list of value if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel")
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>1, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'ref' => array('type'=>'varchar(128)', 'label'=>'Ref', 'enabled'=>1, 'position'=>60, 'notnull'=>1, 'visible'=>4, 'noteditable'=>'1', 'default'=>'(PROV)', 'index'=>1, 'searchall'=>1, 'showoncombobox'=>'1', 'comment'=>"Reference of object"),
		'entity' => array('type'=>'integer', 'label'=>'Entity', 'enabled'=>1, 'position'=>20, 'notnull'=>1, 'visible'=>0, 'default'=>'1', 'index'=>1,),
		'label' => array('type'=>'varchar(255)', 'label'=>'Produit', 'enabled'=>1, 'position'=>30, 'notnull'=>1, 'visible'=>-2, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array('ces'=>'ces', 'toiture'=>'Toiture','iso'=>'Isolation')),
		'total_ttc' => array('type'=>'price', 'label'=>'Total TTC', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'total_tva' => array('type'=>'price', 'label'=>'Total TVA', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'total_ht' => array('type'=>'price', 'label'=>'Total HT', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'total_rac' => array('type'=>'price', 'label'=>'RAC', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>2, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'qty' => array('type'=>'real', 'label'=>'Qty', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>0, 'isameasure'=>'1', 'css'=>'maxwidth75imp', 'help'=>"Help text for quantity",),
		'fk_soc' => array('type'=>'integer:Societe:societe/class/societe.class.php:1:status=1 AND entity IN (__SHARED_ENTITIES__)', 'label'=>'Client', 'enabled'=>1, 'position'=>6, 'notnull'=>-1, 'visible'=>1, 'index'=>1, 'help'=>"LinkToThirparty",),
		'fk_devis' => array('type'=>'integer:toit:deviscara/class/toit.class.php:1', 'label'=>'Devis commercial', 'enabled'=>1, 'position'=>6, 'notnull'=>-1, 'visible'=>1, 'index'=>1, 'help'=>"lien vers le devis commercial",),
		'fk_project' => array('type'=>'integer:Project:projet/class/project.class.php:1', 'label'=>'Project', 'enabled'=>1, 'position'=>52, 'notnull'=>-1, 'visible'=>0, 'index'=>1,),
		'description' => array('type'=>'text', 'label'=>'Description', 'enabled'=>1, 'position'=>60, 'notnull'=>0, 'visible'=>0,),
		'note_public' => array('type'=>'html', 'label'=>'NotePublic', 'enabled'=>1, 'position'=>61, 'notnull'=>0, 'visible'=>-0,),
		'note_private' => array('type'=>'html', 'label'=>'NotePrivate', 'enabled'=>1, 'position'=>62, 'notnull'=>0, 'visible'=>-0,),
		'date_creation' => array('type'=>'date', 'label'=>'DateCreation', 'enabled'=>1, 'position'=>10, 'notnull'=>1, 'visible'=>1,'noteditable'=>'0'),
		'tms' => array('type'=>'timestamp', 'label'=>'DateModification', 'enabled'=>1, 'position'=>501, 'notnull'=>0, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'position'=>510, 'notnull'=>1, 'visible'=>-2, 'foreignkey'=>'user.rowid',),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		'import_key' => array('type'=>'varchar(14)', 'label'=>'ImportId', 'enabled'=>1, 'position'=>1000, 'notnull'=>-1, 'visible'=>-2,),
		'model_pdf' => array('type'=>'varchar(255)', 'label'=>'Model pdf', 'enabled'=>1, 'position'=>1010, 'notnull'=>-1, 'visible'=>0,),
		'status' => array('type'=>'smallint', 'label'=>'Etat Commercial', 'enabled'=>1, 'position'=>45, 'notnull'=>1, 'visible'=>6,  'index'=>1, 'arrayofkeyval'=>array('0'=>'PROSPECT', '1'=>'A TRAITER',  '5'=>'RETOUR A TRAITER','2'=>'INCOMPLET','3'=>'CLIENT','4'=>'ALERTE','9'=>'ANNULE')),
		'couleur_tole' => array('type'=>'smallint', 'label'=>'Couleur Toles', 'enabled'=>1, 'position'=>45, 'visible'=>6,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'Ciel de Lune',  '2'=>'Gris Pierre','3'=>'Blanc','4'=>'Vert Pastel','5'=>'Terre de lune','6'=>'Mer du sud','7'=>'Vert Bornéo','8'=>'Rouge Brique','9'=>'Rouge Tuile','10'=>'Gris anthracite','11'=>'Bleu Ardoise','12'=>'Terre du sud','13'=>'Gris Acier')),
		'type_tole' => array('type'=>'smallint', 'label'=>'Formes Toles', 'enabled'=>1, 'position'=>45, 'notnull'=>1, 'visible'=>6,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'Bac Acier',  '2'=>'Ondulee')),
		'type_tole2' => array('type'=>'smallint', 'label'=>'Type Toles', 'enabled'=>1, 'position'=>45, 'notnull'=>1, 'visible'=>6,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'Standard',  '2'=>'Protector')),

		'type_charpente' => array('type'=>'smallint', 'label'=>'Type Charpente', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>6,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'Tradi',  '2'=>'Empannage', '3'=>'Liteaunage')),
		'charpente_montant' => array('type'=>'price', 'label'=>'Montant charpente vendue', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Montant",),
		'chienassis_nb' => array('type'=>'smallint', 'label'=>'Nombre de chien assis', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>0, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'chenaux' => array('type'=>'smallint', 'label'=>'Type de chenaux', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array('0'=>'', '1'=>'Etancheite',  '2'=>'Suppression'),),
		'chenaux_ml' => array('type'=>'real', 'label'=>'ML Chenaux', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'pv' => array('type'=>'smallint', 'label'=>'PV Existant', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array('0'=>'', '1'=>'OUI',  '2'=>'NON'),),
		'pv_typedepose' => array('type'=>'smallint', 'label'=>'Pv type depose', 'enabled'=>1, 'position'=>1100, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array('0'=>'', '1'=>'DEPOSE/REPOSE',  '2'=>'DEPOSE'),),
		'pv_nb' => array('type'=>'int', 'label'=>'NB PV ', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>0, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'pv_montant' => array('type'=>'real', 'label'=>'PV €', 'enabled'=>1, 'position'=>1115, 'notnull'=>-1, 'visible'=>6,),
		'ces' => array('type'=>'smallint', 'label'=>'NB CES ', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array('0'=>'', '1'=>'Depose/repose',  '2'=>'Remplacement'),),
		'ces_nb' => array('type'=>'int', 'label'=>'NB CES ', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'ces_montant' => array('type'=>'price', 'label'=>'Montant CES ', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'gouttiere' => array('type'=>'real', 'label'=>'M2 GOUTTIERES', 'enabled'=>1, 'position'=>1000, 'notnull'=>-1, 'visible'=>6,),
		'acompte' => array('type'=>'price', 'label'=>'Acompte', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>1, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'mode_reglement_code' => array('type'=>'smallint', 'label'=>'Mode de paiement', 'enabled'=>1, 'position'=>160, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array(''=>'','1'=>'CMA', '2'=>'CH', '3'=>'ESPECES',  '4'=>'VIREMENT','5'=>'PRELEVEMENT','6'=>'BANQUE'),),
		'mode_reglement_nb' => array('type'=>'int', 'label'=>'Nombre(perso)', 'enabled'=>1, 'position'=>165, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'mode_reglement_montant' => array('type'=>'price', 'label'=>'Montant règlement périodique(perso)', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		
		'mode_reglement_cmanb' => array('type'=>'int', 'label'=>'Nombre (cma)', 'enabled'=>1, 'position'=>165, 'notnull'=>0, 'visible'=>6, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'mode_reglement_cmamontant' => array('type'=>'price', 'label'=>'Montant règlement périodique (cma)', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>6, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'cma_report' => array('type'=>'price', 'label'=>"Report", 'enabled'=>1, 'position'=>1822, 'notnull'=>-1, 'visible'=>6, 'arrayofkeyval'=>array('0'=>'', '1'=>'30',  '2'=>'90')),
		'fk_commercial' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'Comercial', 'enabled'=>1, 'position'=>40, 'notnull'=>-1, 'visible'=>1, 'index'=>1, 'help'=>"Commercial",),
		'fk_facture' => array('type'=>'integer:Facture:facture/class/facture.class.php', 'label'=>'Facture n°', 'enabled'=>1, 'position'=>40, 'notnull'=>-1, 'visible'=>6, 'index'=>1, 'help'=>"Nuémro de facture",),
        'commentairecommission' => array('type' => 'text', 'label' => 'Commentaire Commision', 'enabled' => 0, 'position' => 1915, 'notnull' => 0, 'visible' => 6,),
	);
	public $rowid;
	public $ref;
	public $entity;
	public $label;
	public $amount;
	public $qty;
	public $fk_soc;
	public $fk_project;
	public $description;
	public $note_public;
	public $note_private;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $import_key;
	public $model_pdf;
	public $status;
	// END MODULEBUILDER PROPERTIES


	// If this object has a subtable with lines

	/**
	 * @var int    Name of subtable line
	 */
	public $table_element_line = 'deviscara_toitdefline';

	/**
	 * @var int    Field with ID of parent key if this field has a parent
	 */
	public $fk_element = 'fk_deviscara_toitdef';

	/**
	 * @var int    Name of subtable class that manage subtable lines
	 */
	public $class_element_line = 'toitline';

	/**
	 * @var array	List of child tables. To test if we can delete object.
	 */
	//protected $childtables=array();

	/**
	 * @var array	List of child tables. To know object to delete on cascade.
	 */
	protected $childtablesoncascade=array('deviscara_toitline');

	/**
	 * @var devLine[]     Array of subtable lines
	 */
	public $lines = array();



	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $conf, $langs;

		$this->db = $db;

		if (empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && isset($this->fields['rowid'])) $this->fields['rowid']['visible'] = 0;
		if (empty($conf->multicompany->enabled) && isset($this->fields['entity'])) $this->fields['entity']['enabled'] = 0;

		// Example to show how to set values of fields definition dynamically
		/*if ($user->rights->deviscara->dev->read) {
			$this->fields['myfield']['visible'] = 1;
			$this->fields['myfield']['noteditable'] = 0;
		}*/

		// Unset fields that are disabled
		foreach ($this->fields as $key => $val)
		{
			if (isset($val['enabled']) && empty($val['enabled']))
			{
				unset($this->fields[$key]);
			}
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs))
		{
			foreach($this->fields as $key => $val)
			{
				if (is_array($val['arrayofkeyval']))
				{
					foreach($val['arrayofkeyval'] as $key2 => $val2)
					{
						$this->fields[$key]['arrayofkeyval'][$key2]=$langs->trans($val2);
					}
				}
			}
		}
	}
	public function getLinesArray()
	{
	    $this->lines = array();

	    $objectline = new toitdefLine($this->db);
	    $result = $objectline->fetchAll('ASC', 'rang', 0, 0, array('customsql'=>'fk_deviscara_toitdef = '.$this->id));

	    if (is_numeric($result))
	    {
	        $this->error = $this->error;
	        $this->errors = $this->errors;
	        return $result;
	    }
	    else
	    {
	        $this->lines = $result;
	        return $this->lines;
	    }
	}
	function get_info_deviscommercial($id){
		$sql = 'select array_liste_pieces FROM '.MAIN_DB_PREFIX.'deviscara_toit as toit';
		$sql .= ' where toit.rowid='.$id;

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
				$records['array_liste_pieces'] = $obj->array_liste_pieces;
				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	function get_liste109(){
		$sql = 'select rowid, ref FROM '.MAIN_DB_PREFIX.'product as p';
		$sql .= ' where rowid in (223,6)';
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
				$records[$obj->rowid] = $obj->ref;
				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}
	function get_liste106(){
		$sql = 'select rowid, ref FROM '.MAIN_DB_PREFIX.'product as p';
		$sql .= ' where rowid in (29,63,64)';
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);
				$records[$obj->rowid] = $obj->ref;
				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 *  @param	    string		$modele			Force template to use ('' to not force)
	 *  @param		Translate	$outputlangs	objet lang a utiliser pour traduction
	 *  @param      int			$hidedetails    Hide details of lines
	 *  @param      int			$hidedesc       Hide description
	 *  @param      int			$hideref        Hide ref
	 *  @param      null|array  $moreparams     Array to provide more information
	 *  @return     int         				0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	{
		global $conf, $langs;

		$langs->load("deviscara@deviscara");

		if (!dol_strlen($modele)) {
			$modele = 'standard';

			if ($this->modelpdf) {
				$modele = $this->modelpdf;
			} elseif (!empty($conf->global->DEV_ADDON_PDF)) {
				$modele = $conf->global->DEV_ADDON_PDF;
			}
		}

		//$modelpath = "core/modules/deviscara/doc/";
		$modelpath = dol_buildpath("core/modules/deviscaratoitdef/doc/",1);

		return $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
	}

	public function update_total($tabtarif=array()){
		global $db,$user;
		$total_primes=$total_ht=$total_tva=$total_primesedf=0;
		$this->fetchLines();
		foreach ($this->lines as $line){
			$product=new product($db);
			if($line->fk_product)
				$product->fetch_optionals($line->fk_product);
			if($product->array_options['options_prime']==1){
				$total_primes+=$line->total_ht;
			if($product->array_options['options_type_prime']==1)//prime edf
				$total_primesedf+=$line->total_ht;
			}
			else{
				$total_ht+=$line->total_ht;
				$total_tva+=$line->total_ht*$line->tva_tx/100;
			}
		}
		$this->total_ht=$total_ht;
		$this->total_tva=$total_tva;
		$this->total_ttc=$total_ht+$total_tva;
		
		$this->total_rac=$this->total_ttc+$total_primes;
		$this->update($user);
		$this->fetchLines(); //on update l'objet pour affichage
	}

}

/**
 * Class devLine. You can also remove this and generate a CRUD class for lines objects.
 */
class toitdefLine extends toitLine
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'toitline';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'deviscara_toitdefline';
	

	public function __construct($db)
	{
		$this->db = $db;
	}
	
	
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>1, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'ref' => array('type'=>'varchar(128)', 'label'=>'Label', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1',),
		'label' => array('type'=>'varchar(255)', 'label'=>'Label', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1',),
		'subprice' => array('type'=>'price', 'label'=>'Amount', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>1, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'qty' => array('type'=>'real', 'label'=>'Qty', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>1, 'isameasure'=>'1', 'css'=>'maxwidth75imp', 'help'=>"Help text for quantity",),
		'description' => array('type'=>'text', 'label'=>'Description', 'enabled'=>1, 'position'=>60, 'notnull'=>0, 'visible'=>3,),
		'date_creation' => array('type'=>'datetime', 'label'=>'DateCreation', 'enabled'=>1, 'position'=>500, 'notnull'=>1, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'position'=>510, 'notnull'=>1, 'visible'=>-2, 'foreignkey'=>'user.rowid',),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		//'fk_status' => array('type'=>'integer:Deviscaraiso:custom/deviscaraiso/class/deviscaraiso.class.php', 'label'=>'Status', 'enabled'=>1, 'position'=>1000, 'notnull'=>1, 'visible'=>1, 'index'=>1),
		'fk_deviscara_toitdef' => array('type'=>'integer', 'label'=>'Id_produit', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'fk_unit' => array('type'=>'integer', 'label'=>'Unité', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'total_ht' => array('type'=>'price', 'label'=>'Total HT', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'tva_tx'  => array('type'=>'price', 'label'=>'Taux de TVA', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>'taux'),
		'rang' => array('type'=>'integer', 'label'=>'position', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),
		'stotal_ht' => array('type'=>'price', 'label'=>'groupe', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-0, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),
		'fk_product' => array('type'=>'integer:Product:product/class/product.class.php', 'label'=>'Type produit', 'enabled'=>1, 'position'=>1002, 'notnull'=>1, 'visible'=>1, 'index'=>1,),
		'product_type' => array('type'=>'integer', 'label'=>'type produit', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-0, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),

	);




}



