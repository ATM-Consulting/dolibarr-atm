<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/dev.class.php
 * \ingroup     deviscara
 * \brief       This file is a CRUD class file for dev (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

/**
 * Class for dev
 */
class iso2 extends CommonObject
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'deviscara';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'deviscara_dev';
	

	/**
	 * @var int  Does dev support multicompany module ? 0=No test on entity, 1=Test with field entity, 2=Test with link by societe
	 */
	public $ismultientitymanaged = 0;

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 1;

	/**
	 * @var string String with name of icon for dev. Must be the part after the 'object_' into object_dev.png
	 */
	public $picto = 'dev@deviscara';


	const STATUS_DRAFT = 0;
	const STATUS_VALIDATED = 1;
	const STATUS_INCOMPLET = 2;
	const STATUS_CLIENT = 3;
	const STATUS_ALERTE = 4;
	const STATUS_RETOURSATRAITER = 5;
	const STATUS_CANCELED = 9;


	/**
	 *  'type' if the field format ('integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter]]', 'varchar(x)', 'double(24,8)', 'real', 'price', 'text', 'html', 'date', 'datetime', 'timestamp', 'duration', 'mail', 'phone', 'url', 'password')
	 *         Note: Filter can be a string like "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.nature:is:NULL)"
	 *  'label' the translation key.
	 *  'enabled' is a condition when the field must be managed.
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 if you want to have a total on list for this field. Field type must be summable like integer or double(24,8).
	 *  'css' is the CSS style to use on field. For example: 'maxwidth200'
	 *  'help' is a string visible as a tooltip on field
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
	 *  'arraykeyval' to set list of value if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel")
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>1, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'ref' => array('type'=>'varchar(128)', 'label'=>'Ref', 'enabled'=>1, 'position'=>310, 'notnull'=>1, 'visible'=>4, 'noteditable'=>'1', 'default'=>'(PROV)', 'index'=>1, 'searchall'=>1, 'showoncombobox'=>'1', 'comment'=>"Reference of object"),
		'entity' => array('type'=>'integer', 'label'=>'Entity', 'enabled'=>1, 'position'=>20, 'notnull'=>1, 'visible'=>0, 'default'=>'1', 'index'=>1,),
		'label' => array('type'=>'varchar(255)', 'label'=>'Produit', 'enabled'=>1, 'position'=>30, 'notnull'=>1, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1','arrayofkeyval'=>array('ces'=>'ces', 'toiture'=>'Toiture','iso'=>'Isolation')),
		'total_ttc' => array('type'=>'price', 'label'=>'Total TTC', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'total_tva' => array('type'=>'price', 'label'=>'Total TVA', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'total_ht' => array('type'=>'price', 'label'=>'Total HT', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'total_rac' => array('type'=>'price', 'label'=>'RAC', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>2, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'qty' => array('type'=>'real', 'label'=>'Qty', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>0, 'isameasure'=>'1', 'css'=>'maxwidth75imp', 'help'=>"Help text for quantity",),
		'fk_soc' => array('type'=>'integer:Societe:societe/class/societe.class.php:1:status=1 AND entity IN (__SHARED_ENTITIES__)', 'label'=>'Client', 'enabled'=>1, 'position'=>6, 'notnull'=>-1, 'visible'=>1, 'index'=>1, 'help'=>"LinkToThirparty",),
		'fk_project' => array('type'=>'integer:Project:projet/class/project.class.php:1', 'label'=>'Project', 'enabled'=>1, 'position'=>52, 'notnull'=>-1, 'visible'=>0, 'index'=>1,),
		'description' => array('type'=>'text', 'label'=>'Description', 'enabled'=>1, 'position'=>60, 'notnull'=>0, 'visible'=>0,),
		'note_public' => array('type'=>'html', 'label'=>'NotePublic', 'enabled'=>1, 'position'=>61, 'notnull'=>0, 'visible'=>-0,),
		'note_private' => array('type'=>'html', 'label'=>'NotePrivate', 'enabled'=>1, 'position'=>62, 'notnull'=>0, 'visible'=>-0,),
		'date_creation' => array('type'=>'date', 'label'=>'DateCreation', 'enabled'=>1, 'position'=>10, 'notnull'=>1, 'visible'=>1,'noteditable'=>'0'),
		'tms' => array('type'=>'timestamp', 'label'=>'DateModification', 'enabled'=>1, 'position'=>501, 'notnull'=>0, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'position'=>510, 'notnull'=>1, 'visible'=>-2, 'foreignkey'=>'user.rowid',),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		'import_key' => array('type'=>'varchar(14)', 'label'=>'ImportId', 'enabled'=>1, 'position'=>1000, 'notnull'=>-1, 'visible'=>-2,),
		'model_pdf' => array('type'=>'varchar(255)', 'label'=>'Model pdf', 'enabled'=>1, 'position'=>1010, 'notnull'=>-1, 'visible'=>0,),
		'status_immo' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>1, 'position'=>1000, 'notnull'=>1, 'visible'=>0, 'index'=>1, 'arrayofkeyval'=>array('1'=>'Proprietaire', '2'=>'Locataire'),),
		'status' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>1, 'position'=>200, 'notnull'=>1, 'visible'=>1,  'index'=>1, 'arrayofkeyval'=>array('0'=>'PROSPECT', '1'=>'A TRAITER',  '5'=>'RETOUR A TRAITER','2'=>'INCOMPLET','3'=>'CLIENT','4'=>'ALERTE','9'=>'ANNULE')),
		'mode_reglement_code' => array('type'=>'varchar(10)', 'label'=>'Règlement', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'mode_reglement_nb' => array('type'=>'varchar(10)', 'label'=>'Nombre', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'help'=>"Help text", 'showoncombobox'=>'1',),
		'fk_commercial' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'Comercial', 'enabled'=>1, 'position'=>210, 'notnull'=>-1, 'visible'=>1, 'index'=>1, 'help'=>"Commercial",),
		'commentaire' => array('type'=>'text', 'label'=>'Commentaire', 'enabled'=>1, 'position'=>300, 'notnull'=>0, 'visible'=>1,),
		'acompte' => array('type'=>'price', 'label'=>'Acompte', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'pencharge' => array('type'=>'price', 'label'=>'Prise en charge', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'mode_reglement_montant' => array('type'=>'price', 'label'=>'Montant règlement périodique', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>0, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'date_status_0'=>array('type'=>'datetime', 'label'=>'Date PROSPECT', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'date_status_1'=>array('type'=>'datetime', 'label'=>'Date A TRAITER', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'date_status_2'=>array('type'=>'datetime', 'label'=>'Date INCOMPLET', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'date_status_3'=>array('type'=>'datetime', 'label'=>'Date CLIENT', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'date_status_4'=>array('type'=>'datetime', 'label'=>'Date ALERTE', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'date_status_5'=>array('type'=>'datetime', 'label'=>'Date RETOUR A TRAITER', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'date_status_9'=>array('type'=>'datetime', 'label'=>'Date ANNULE', 'enabled'=>1, 'visible'=>0, 'notnull'=> 0,  'position'=>1000),
		'difficulte' => array('type'=>'smallint', 'label'=>'Difficulte', 'enabled'=>1, 'position'=>200, 'notnull'=>1, 'visible'=>3,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'DIFFICILE', '2'=>'FACILE','3'=>'IMPOSSIBLE')),
		'duree' => array('type'=>'smallint', 'label'=>'Durée', 'enabled'=>1, 'position'=>200, 'notnull'=>1, 'visible'=>3,  'index'=>1, 'arrayofkeyval'=>array('0'=>'', '1'=>'1', '2'=>'2','3'=>'3','4'=>'4','5'=>'5')),

	);
	public $rowid;
	public $ref;
	public $entity;
	public $label;
	public $amount;
	public $qty;
	public $fk_soc;
	public $fk_project;
	public $description;
	public $note_public;
	public $note_private;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $import_key;
	public $model_pdf;
	public $status;
	// END MODULEBUILDER PROPERTIES


	// If this object has a subtable with lines

	/**
	 * @var int    Name of subtable line
	 */
	public $table_element_line = 'deviscara_iso2line';

	/**
	 * @var int    Field with ID of parent key if this field has a parent
	 */
	public $fk_element = 'fk_deviscara';

	/**
	 * @var int    Name of subtable class that manage subtable lines
	 */
	public $class_element_line = 'iso2line';
	public $table_element_prime = 'deviscara_iso2prime';

	/**
	 * @var array	List of child tables. To test if we can delete object.
	 */
	//protected $childtables=array();

	/**
	 * @var array	List of child tables. To know object to delete on cascade.
	 */
	protected $childtablesoncascade=array('deviscara_devline');

	/**
	 * @var devLine[]     Array of subtable lines
	 */
	public $lines = array();



	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $conf, $langs;

		$this->db = $db;

		if (empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && isset($this->fields['rowid'])) $this->fields['rowid']['visible'] = 0;
		if (empty($conf->multicompany->enabled) && isset($this->fields['entity'])) $this->fields['entity']['enabled'] = 0;

		// Example to show how to set values of fields definition dynamically
		/*if ($user->rights->deviscara->dev->read) {
			$this->fields['myfield']['visible'] = 1;
			$this->fields['myfield']['noteditable'] = 0;
		}*/

		// Unset fields that are disabled
		foreach ($this->fields as $key => $val)
		{
			if (isset($val['enabled']) && empty($val['enabled']))
			{
				unset($this->fields[$key]);
			}
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs))
		{
			foreach($this->fields as $key => $val)
			{
				if (is_array($val['arrayofkeyval']))
				{
					foreach($val['arrayofkeyval'] as $key2 => $val2)
					{
						$this->fields[$key]['arrayofkeyval'][$key2]=$langs->trans($val2);
					}
				}
			}
		}
	}

	/**
	 * Create object into database
	 *
	 * @param  User $user      User that creates
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, Id of created object if OK
	 */
	public function create(User $user, $notrigger = false)
	{
		$this->status=1; //a traiter par défaut
		$this->date_creation=dol_now();
		$this->ref=$this->getNextNumRef();
		$this->createCommon($user, $notrigger);

		//create pimes
		// Create lines
		if (!empty($this->table_element_prime) && !empty($this->fk_element))
		{
			$num = (is_array($this->primes) ? count($this->primes) : 0);
			for ($i = 0; $i < $num; $i++)
			{
				$prime = $this->primes[$i];

				$keyforparent = $this->fk_element;
				$prime->$keyforparent = $this->id;

				// Test and convert into object this->lines[$i]. When coming from REST API, we may still have an array
				//if (! is_object($line)) $line=json_decode(json_encode($line), false);  // convert recursively array into object.
				if (!is_object($prime)) $prime = (object) $prime;
				$prime->fk_deviscara=$this->id;
				$result = $prime->create($user, 1);
				if ($result < 0)
				{
					$this->error = $this->db->lasterror();
					return -1;
				}
			}
		}
		return $this->id;
	}

	/**
	 * Clone an object into another one
	 *
	 * @param  	User 	$user      	User that creates
	 * @param  	int 	$fromid     Id of object to clone
	 * @return 	mixed 				New object created, <0 if KO
	 */
	public function createFromClone(User $user, $fromid)
	{
		global $langs, $extrafields;
	    $error = 0;

	    dol_syslog(__METHOD__, LOG_DEBUG);

	    $object = new self($this->db);

	    $this->db->begin();

	    // Load source object
	    $result = $object->fetchCommon($fromid);
	    if ($result > 0 && !empty($object->table_element_line)) $object->fetchLines();

	    // get lines so they will be clone
	    //foreach($this->lines as $line)
	    //	$line->fetch_optionals();

	    // Reset some properties
	    unset($object->id);
	    unset($object->fk_user_creat);
	    unset($object->import_key);


	    // Clear fields
	    $object->ref = empty($this->fields['ref']['default']) ? "copy_of_".$object->ref : $this->fields['ref']['default'];
	    $object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf")." ".$object->label : $this->fields['label']['default'];
	    $object->status = self::STATUS_DRAFT;
	    // ...
	    // Clear extrafields that are unique
	    if (is_array($object->array_options) && count($object->array_options) > 0)
	    {
	    	$extrafields->fetch_name_optionals_label($this->table_element);
	    	foreach ($object->array_options as $key => $option)
	    	{
	    		$shortkey = preg_replace('/options_/', '', $key);
	    		if (!empty($extrafields->attributes[$this->element]['unique'][$shortkey]))
	    		{
	    			//var_dump($key); var_dump($clonedObj->array_options[$key]); exit;
	    			unset($object->array_options[$key]);
	    		}
	    	}
	    }

	    // Create clone
		$object->context['createfromclone'] = 'createfromclone';
	    $result = $object->createCommon($user);
	    if ($result < 0) {
	        $error++;
	        $this->error = $object->error;
	        $this->errors = $object->errors;
	    }

	    if (!$error)
	    {
	    	// copy internal contacts
	    	if ($this->copy_linked_contact($object, 'internal') < 0)
	    	{
	    		$error++;
	    	}
	    }

	    if (!$error)
	    {
	    	// copy external contacts if same company
	    	if (property_exists($this, 'socid') && $this->socid == $object->socid)
	    	{
	    		if ($this->copy_linked_contact($object, 'external') < 0)
	    			$error++;
	    	}
	    }

	    unset($object->context['createfromclone']);

	    // End
	    if (!$error) {
	        $this->db->commit();
	        return $object;
	    } else {
	        $this->db->rollback();
	        return -1;
	    }
	}

	/**
	 * Load object in memory from the database
	 *
	 * @param int    $id   Id object
	 * @param string $ref  Ref
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null)
	{
		$result = $this->fetchCommon($id, $ref);
		if ($result > 0 && !empty($this->table_element_line)) $this->fetchLines();
		return $result;
	}

	/**
	 * Load object lines in memory from the database
	 *
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchLines()
	{
		$this->lines = array();
		$this->primes = array();

		$result = $this->fetchLinesCommon();
		$result = $this->fetchPrimes();
		return $result;
	}

	public function fetchPrimes($morewhere = '')
	{
		$objectlineclassname = get_class($this).'Prime';
		if (!class_exists($objectlineclassname))
		{
			$this->error = 'Error, class '.$objectlineclassname.' not found during call of fetchLinesCommon';
			return -1;
		}

		$objectline = new $objectlineclassname($this->db);

		$sql = 'SELECT '.$objectline->getFieldList();
		$sql .= ' FROM '.MAIN_DB_PREFIX.$objectline->table_element;
		$sql .= ' WHERE fk_'.$this->element.' = '.$this->id;
		if ($morewhere)   $sql .= $morewhere;

		$resql = $this->db->query($sql);
		if ($resql)
		{
			$num_rows = $this->db->num_rows($resql);
			$i = 0;
			while ($i < $num_rows)
			{
				$obj = $this->db->fetch_object($resql);
				if ($obj)
				{
					$newline = new $objectlineclassname($this->db);
					$newline->setVarsFromFetchObj($obj);

					$this->primes[] = $newline;
				}
				$i++;
			}

			return 1;
		}
		else
		{
			$this->error = $this->db->lasterror();
			$this->errors[] = $this->error;
			return -1;
		}
	}


	/**
	 * Load list of objects in memory from the database.
	 *
	 * @param  string      $sortorder    Sort Order
	 * @param  string      $sortfield    Sort field
	 * @param  int         $limit        limit
	 * @param  int         $offset       Offset
	 * @param  array       $filter       Filter array. Example array('field'=>'valueforlike', 'customurl'=>...)
	 * @param  string      $filtermode   Filter mode (AND or OR)
	 * @return array|int                 int <0 if KO, array of pages if OK
	 */
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		global $conf;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$records = array();

		$sql = 'SELECT ';
		$sql .= $this->getFieldList();
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		if (isset($this->ismultientitymanaged) && $this->ismultientitymanaged == 1) $sql .= ' WHERE t.entity IN ('.getEntity($this->table_element).')';
		else $sql .= ' WHERE 1 = 1';
		// Manage filter
		$sqlwhere = array();
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				if ($key == 't.rowid') {
					$sqlwhere[] = $key.'='.$value;
				}
				elseif (strpos($key, 'date') !== false) {
					$sqlwhere[] = $key.' = \''.$this->db->idate($value).'\'';
				}
				elseif ($key == 'customsql') {
					$sqlwhere[] = $value;
				}
				else {
					$sqlwhere[] = $key.' LIKE \'%'.$this->db->escape($value).'%\'';
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= ' AND ('.implode(' '.$filtermode.' ', $sqlwhere).')';
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= ' '.$this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i < min($limit, $num))
			{
			    $obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 * Update object into database
	 *
	 * @param  User $user      User that modifies
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = false)
	{
		return $this->updateCommon($user, $notrigger);
	}

	/**
	 * Delete object in database
	 *
	 * @param User $user       User that deletes
	 * @param bool $notrigger  false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function delete(User $user, $notrigger = false)
	{
		global $conf;
		//suppression du document 
		$oldref = dol_sanitizeFileName($this->ref);
		$document = $conf->deviscara->dir_output.'/'.$oldref.'/'.$oldref.'-sign.pdf';
		$document = $conf->deviscara->dir_output.'/'.$oldref;
		$ret=$this->recursiveRemoveDirectory($document);
		$this->dellink();// suppression liens entre les devis
		$this->deletePrime();
		return $this->deleteCommon($user, $notrigger);
	}

	function recursiveRemoveDirectory($directory)
	{
		foreach(glob("{$directory}/*") as $file)
		{
			if(is_dir($file)) { 
				recursiveRemoveDirectory($file);
			} else {
				unlink($file);
			}
		}
		return rmdir($directory);
	}
	/**
	 *  Delete a line of object in database
	 *
	 *	@param  User	$user       User that delete
	 *  @param	int		$idline		Id of line to delete
	 *  @param 	bool 	$notrigger  false=launch triggers after, true=disable triggers
	 *  @return int         		>0 if OK, <0 if KO
	 */
	public function deleteLine(User $user, $idline, $notrigger = false)
	{
		if ($this->status < 0)
		{
			$this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
			return -2;
		}

		return $this->deleteLineCommon($user, $idline, $notrigger);
	}

	function deletePrime(){
		$sql = "DELETE from ".MAIN_DB_PREFIX.$this->table_element_prime;
		$sql .= " WHERE fk_deviscara = ".$this->id;
		$resql = $this->db->query($sql);
	}

	/**
	 *	Validate object
	 *
	 *	@param		User	$user     		User making status change
	 *  @param		int		$notrigger		1=Does not execute triggers, 0= execute triggers
	 *	@return  	int						<=0 if OK, 0=Nothing done, >0 if KO
	 */
	public function validate($user, $notrigger = 0)
	{
		global $conf, $langs;

		require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

		$error = 0;

		// Protection
		if ($this->status == self::STATUS_VALIDATED)
		{
			dol_syslog(get_class($this)."::validate action abandonned: already validated", LOG_WARNING);
			return 0;
		}

		$now = dol_now();

		$this->db->begin();

		// Define new ref
		if (!$error && (preg_match('/^[\(]?PROV/i', $this->ref) || empty($this->ref))) // empty should not happened, but when it occurs, the test save life
		{
			$num = $this->getNextNumRef();
		}
		else
		{
			$num = $this->ref;
		}
		$this->newref = $num;

		// Validate
		$sql = "UPDATE ".MAIN_DB_PREFIX.$this->table_element;
		$sql .= " SET ref = '".$this->db->escape($num)."',";
		$sql .= " status = ".self::STATUS_VALIDATED.",";
		$sql .= " date_validation = '".$this->db->idate($now)."',";
		$sql .= " fk_user_valid = ".$user->id;
		$sql .= " WHERE rowid = ".$this->id;

		dol_syslog(get_class($this)."::validate()", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql)
		{
			dol_print_error($this->db);
			$this->error = $this->db->lasterror();
			$error++;
		}

		if (!$error && !$notrigger)
		{
			// Call trigger
			$result = $this->call_trigger('DEV_VALIDATE', $user);
			if ($result < 0) $error++;
			// End call triggers
		}

		if (!$error)
		{
			$this->oldref = $this->ref;

			// Rename directory if dir was a temporary ref
			if (preg_match('/^[\(]?PROV/i', $this->ref))
			{
				// Now we rename also files into index
				$sql = 'UPDATE '.MAIN_DB_PREFIX."ecm_files set filename = CONCAT('".$this->db->escape($this->newref)."', SUBSTR(filename, ".(strlen($this->ref) + 1).")), filepath = 'dev/".$this->db->escape($this->newref)."'";
				$sql .= " WHERE filename LIKE '".$this->db->escape($this->ref)."%' AND filepath = 'dev/".$this->db->escape($this->ref)."' and entity = ".$conf->entity;
				$resql = $this->db->query($sql);
				if (!$resql) { $error++; $this->error = $this->db->lasterror(); }

				// We rename directory ($this->ref = old ref, $num = new ref) in order not to lose the attachments
				$oldref = dol_sanitizeFileName($this->ref);
				$newref = dol_sanitizeFileName($num);
				$dirsource = $conf->deviscara->dir_output.'/dev/'.$oldref;
				$dirdest = $conf->deviscara->dir_output.'/dev/'.$newref;
				if (!$error && file_exists($dirsource))
				{
					dol_syslog(get_class($this)."::validate() rename dir ".$dirsource." into ".$dirdest);

					if (@rename($dirsource, $dirdest))
					{
						dol_syslog("Rename ok");
						// Rename docs starting with $oldref with $newref
						$listoffiles = dol_dir_list($conf->deviscara->dir_output.'/dev/'.$newref, 'files', 1, '^'.preg_quote($oldref, '/'));
						foreach ($listoffiles as $fileentry)
						{
							$dirsource = $fileentry['name'];
							$dirdest = preg_replace('/^'.preg_quote($oldref, '/').'/', $newref, $dirsource);
							$dirsource = $fileentry['path'].'/'.$dirsource;
							$dirdest = $fileentry['path'].'/'.$dirdest;
							@rename($dirsource, $dirdest);
						}
					}
				}
			}
		}

		// Set new ref and current status
		if (!$error)
		{
			$this->ref = $num;
			$this->status = self::STATUS_VALIDATED;
		}

		if (!$error)
		{
			$this->db->commit();
			return 1;
		}
		else
		{
			$this->db->rollback();
			return -1;
		}
	}


	/**
	 *	Set draft status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, >0 if OK
	 */
	public function setDraft($user, $notrigger = 0)
	{
		// Protection
		if ($this->status <= self::STATUS_DRAFT)
		{
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->deviscara->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->deviscara->deviscara_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_DRAFT, $notrigger, 'DEV_UNVALIDATE');
	}

	/**
	 *	Set cancel status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, 0=Nothing done, >0 if OK
	 */
	public function cancel($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_VALIDATED)
		{
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->deviscara->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->deviscara->deviscara_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_CANCELED, $notrigger, 'DEV_CLOSE');
	}

	/**
	 *	Set back to validated status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, 0=Nothing done, >0 if OK
	 */
	public function reopen($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_CANCELED)
		{
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->deviscara->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->deviscara->deviscara_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_VALIDATED, $notrigger, 'DEV_REOPEN');
	}

    /**
     *  Return a link to the object card (with optionaly the picto)
     *
     *  @param  int     $withpicto                  Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
     *  @param  string  $option                     On what the link point to ('nolink', ...)
     *  @param  int     $notooltip                  1=Disable tooltip
     *  @param  string  $morecss                    Add more css on link
     *  @param  int     $save_lastsearch_value      -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
     *  @return	string                              String with URL
     */
    public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
    {
        global $conf, $langs, $hookmanager;

        if (!empty($conf->dol_no_mouse_hover)) $notooltip = 1; // Force disable tooltips

        $result = '';

        $label = '<u>'.$langs->trans("dev").'</u>';
        $label .= '<br>';
        $label .= '<b>'.$langs->trans('Ref').':</b> '.$this->ref;
        if (isset($this->status)) {
        	$label.= '<br><b>' . $langs->trans("Status").":</b> ".$this->getLibStatut(5);
        }

        $url = dol_buildpath('/deviscara/dev_card.php', 1).'?id='.$this->id;

        if ($option != 'nolink')
        {
            // Add param to save lastsearch_values or not
            $add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
            if ($save_lastsearch_value == -1 && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) $add_save_lastsearch_values = 1;
            if ($add_save_lastsearch_values) $url .= '&save_lastsearch_values=1';
        }

        $linkclose = '';
        if (empty($notooltip))
        {
            if (!empty($conf->global->MAIN_OPTIMIZEFORTEXTBROWSER))
            {
                $label = $langs->trans("Showdev");
                $linkclose .= ' alt="'.dol_escape_htmltag($label, 1).'"';
            }
            $linkclose .= ' title="'.dol_escape_htmltag($label, 1).'"';
            $linkclose .= ' class="classfortooltip'.($morecss ? ' '.$morecss : '').'"';
        }
        else $linkclose = ($morecss ? ' class="'.$morecss.'"' : '');

		$linkstart = '<a href="'.$url.'"';
		$linkstart .= $linkclose.'>';
		$linkend = '</a>';

		$result .= $linkstart;
		if ($withpicto) $result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="'.(($withpicto != 2) ? 'paddingright ' : '').'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
		if ($withpicto != 2) $result .= $this->ref;
		$result .= $linkend;
		//if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

		global $action, $hookmanager;
		$hookmanager->initHooks(array('devdao'));
		$parameters = array('id'=>$this->id, 'getnomurl'=>$result);
		$reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) $result = $hookmanager->resPrint;
		else $result .= $hookmanager->resPrint;

		return $result;
    }

	/**
	 *  Return label of the status
	 *
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLibStatut($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

    // phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	/**
	 *  Return the status
	 *
	 *  @param	int		$status        Id status
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return string 			       Label of status
	 */
	public function LibStatut($status, $mode = 0)
	{
		// phpcs:enable
		if (empty($this->labelStatus) || empty($this->labelStatusShort))
		{
			global $langs;
			//$langs->load("deviscara");
			$this->labelStatus[self::STATUS_DRAFT] = $langs->trans('PROSPECT');
			$this->labelStatus[self::STATUS_VALIDATED] = $langs->trans('A TRAITER');
			$this->labelStatus[self::STATUS_CANCELED] = $langs->trans('ANNULE');
			$this->labelStatus[self::STATUS_INCOMPLET] = $langs->trans('INCOMPLET');
			$this->labelStatus[self::STATUS_CLIENT] = $langs->trans('CLIENT');
			$this->labelStatus[self::STATUS_RETOURSATRAITER] = $langs->trans('RETOUR A TRAITER');
			
			$this->labelStatusShort[self::STATUS_DRAFT] = $langs->trans('PROSPECT');
			$this->labelStatusShort[self::STATUS_VALIDATED] = $langs->trans('A TRAITER');
			$this->labelStatusShort[self::STATUS_CANCELED] = $langs->trans('ANNULE');
			$this->labelStatusShort[self::STATUS_INCOMPLET] = $langs->trans('INCOMPLET');
			$this->labelStatusShort[self::STATUS_CLIENT] = $langs->trans('CLIENT');
			$this->labelStatusShort[self::STATUS_RETOURSATRAITER] = $langs->trans('RETOUR A TRAITER');
		}

		$statusType = 'statusdevis'.$status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		//if ($status == self::STATUS_CANCELED) $statusType = 'status6';

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
	}

	/**
	 *	Load the info information in the object
	 *
	 *	@param  int		$id       Id of object
	 *	@return	void
	 */
	public function info($id)
	{
		$sql = 'SELECT rowid, date_creation as datec, tms as datem,';
		$sql .= ' fk_user_creat, fk_user_modif';
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		$sql .= ' WHERE t.rowid = '.$id;
		$result = $this->db->query($sql);
		if ($result)
		{
			if ($this->db->num_rows($result))
			{
				$obj = $this->db->fetch_object($result);
				$this->id = $obj->rowid;
				if ($obj->fk_user_author)
				{
					$cuser = new User($this->db);
					$cuser->fetch($obj->fk_user_author);
					$this->user_creation = $cuser;
				}

				if ($obj->fk_user_valid)
				{
					$vuser = new User($this->db);
					$vuser->fetch($obj->fk_user_valid);
					$this->user_validation = $vuser;
				}

				if ($obj->fk_user_cloture)
				{
					$cluser = new User($this->db);
					$cluser->fetch($obj->fk_user_cloture);
					$this->user_cloture = $cluser;
				}

				$this->date_creation     = $this->db->jdate($obj->datec);
				$this->date_modification = $this->db->jdate($obj->datem);
				$this->date_validation   = $this->db->jdate($obj->datev);
			}

			$this->db->free($result);
		}
		else
		{
			dol_print_error($this->db);
		}
	}

	/**
	 * Initialise object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return void
	 */
	public function initAsSpecimen()
	{
		$this->initAsSpecimenCommon();
	}

	/**
	 * 	Create an array of lines
	 *
	 * 	@return array|int		array of lines if OK, <0 if KO
	 */
	public function getLinesArray()
	{
	    $this->lines = array();

	    $objectline = new iso2Line($this->db);
	    $result = $objectline->fetchAll('ASC', 'position', 0, 0, array('customsql'=>'fk_deviscara = '.$this->id));

	    if (is_numeric($result))
	    {
	        $this->error = $this->error;
	        $this->errors = $this->errors;
	        return $result;
	    }
	    else
	    {
	        $this->lines = $result;
	        return $this->lines;
	    }
	}

	/**
	 *  Returns the reference to the following non used object depending on the active numbering module.
	 *
	 *  @return string      		Object free reference
	 */
	public function getNextNumRef()
	{
		global $langs, $conf;
		$langs->load("deviscara@dev");

		if (empty($conf->global->DEVISCARA_DEV_ADDON)) {
			$conf->global->DEVISCARA_DEV_ADDON = 'mod_deviscaraiso2_standard';
		}

		if (!empty($conf->global->DEVISCARA_DEV_ADDON))
		{
			$mybool = false;

			$file = $conf->global->DEVISCARA_DEV_ADDON.".php";
			$classname = $conf->global->DEVISCARA_DEV_ADDON;

			// Include file with class
			$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);
			foreach ($dirmodels as $reldir)
			{
				$dir = dol_buildpath($reldir."core/modules/deviscara/");

				// Load file with numbering class (if found)
				$mybool |= @include_once $dir.$file;
			}

			if ($mybool === false)
			{
				dol_print_error('', "Failed to include file ".$file);
				return '';
			}

			$obj = new $classname();
			$numref = $obj->getNextValue($this);

			if ($numref != "")
			{
				return $numref;
			}
			else
			{
				$this->error = $obj->error;
				//dol_print_error($this->db,get_class($this)."::getNextNumRef ".$obj->error);
				return "";
			}
		}
		else
		{
			print $langs->trans("Error")." ".$langs->trans("Error_DEVISCARA_DEV_ADDON_NotDefined");
			return "";
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 *  @param	    string		$modele			Force template to use ('' to not force)
	 *  @param		Translate	$outputlangs	objet lang a utiliser pour traduction
	 *  @param      int			$hidedetails    Hide details of lines
	 *  @param      int			$hidedesc       Hide description
	 *  @param      int			$hideref        Hide ref
	 *  @param      null|array  $moreparams     Array to provide more information
	 *  @return     int         				0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	{
		global $conf, $langs;

		$langs->load("deviscara@deviscara");

		if (!dol_strlen($modele)) {
			$modele = 'standard';

			if ($this->modelpdf) {
				$modele = $this->modelpdf;
			} elseif (!empty($conf->global->DEV_ADDON_PDF)) {
				$modele = $conf->global->DEV_ADDON_PDF;
			}
		}

		//$modelpath = "core/modules/deviscara/doc/";
		$modelpath = dol_buildpath("core/modules/deviscara/doc/",1);

		return $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
	}

	/**
	 * Action executed by scheduler
	 * CAN BE A CRON TASK. In such a case, parameters come from the schedule job setup field 'Parameters'
	 *
	 * @return	int			0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
	 */
	//public function doScheduledJob($param1, $param2, ...)
	public function doScheduledJob()
	{
		global $conf, $langs;

		//$conf->global->SYSLOG_FILE = 'DOL_DATA_ROOT/dolibarr_mydedicatedlofile.log';

		$error = 0;
		$this->output = '';
		$this->error = '';

		dol_syslog(__METHOD__, LOG_DEBUG);

		$now = dol_now();

		$this->db->begin();

		// ...

		$this->db->commit();

		return $error;
	}


	public function getcpville($id){
		$sql='select * ';
		$sql .= ' FROM '.MAIN_DB_PREFIX.'cara_cpville as t';
		$sql .= ' WHERE t.rowid = '.$id;
		$result = $this->db->query($sql);
		if ($result)
		{
			if ($this->db->num_rows($result))
				$obj = $this->db->fetch_object($result);
		}
		return $obj;
	}
	
	public function get_fields_supp(){
		global $user,$db;
		$list_villes=array(-1=>'');
		$sql='select rowid,ville from '.MAIN_DB_PREFIX.'cara_cpville';
		$sql .= ''; 
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $this->db->fetch_object($resql);
				$list_villes[$obj->rowid]=$obj->ville;
				$i++;
			}
		}
		$tab['ville']['type']="varchar(50)";
		$tab['ville']['label']="Ville";
		$tab['ville']['enabled']=1;
		$tab['ville']['visible']=1;
		$tab['ville']['position']="20";
		$tab['ville']['arrayofkeyval']=$list_villes;

		$tab['phone']['type']="varchar(50)";
		$tab['phone']['label']="Telephone";
		$tab['phone']['enabled']=1;
		$tab['phone']['visible']=1;
		$tab['phone']['position']="25";

		$user->conf->MAIN_SELECTEDFIELDS_deviscaraisolist.='ville,phone,address,carafinance';

		return($tab);
	}
	public function getinfo(){
		foreach ($this->lines as $line){

			if ($line->fk_product==29 && $this->label=='iso'){
				$info['surfaceiso']=$line->qty;
				
			}
			elseif($line->fk_product==22 && $this->label=='ces'){ //ces
				$info['ces200']=$line->qty;

			}
			elseif($line->fk_product==23 && $this->label=='ces'){ //ces
				$info['ces300']=$line->qty;
			}
			elseif(in_array($line->fk_product,array(2,3,27,28)) && $this->label=='toiture'){ //toiture
				$info['surftoit']=$line->qty;
				$info['surfaceiso']=$line->qty;
			}
		}
		if($this->label=='ces'){//Mantis 385
			$boolprimeavecedf=false;
			foreach ($this->primes as $prime){
			 	if($prime->type_prime ==2 )
					$boolprimeavecedf=true;
			}
			if($boolprimeavecedf == false){
				$info['status_edf']='NULL'; 
				$info['status_cee']=1;
			}
		}
		if($this->label=='toiture'){//Mantis 385
			$boolprimeisolation=0;
			foreach ($this->primes as $prime){
			 	if($prime->type_prime ==2 )
					$boolprimeisolation++;
			}
			if($boolprimeisolation == 1)
				$info['status_edf']='NULL'; 

		}
		return $info;
		
	}

	function link($idlinkto,$produit){

		//on insère le nouveau devis
		$sql='insert into '.MAIN_DB_PREFIX.'r_deviscara_clientdevis (fk_soc,id,type) values ('.$this->fk_soc.','.$idlinkto.',"'.$produit.'"), ('.$this->fk_soc.','.$this->id.',"'.$this->label.'")';
		$sql.=' on duplicate key update id=id ';
		$resql = $this->db->query($sql);
		if (!$resql) 
			setEventmessages('erreur requete',$this->db->lasterror(),'errors');

	}
	function dellink(){
		$sql='delete from '.MAIN_DB_PREFIX.'r_deviscara_clientdevis where id='.$this->id;
		$resql = $this->db->query($sql);
		if (!$resql) 
			setEventmessages('erreur requete',$this->db->lasterror(),'errors');

	}
	function getlink(){

		$sql='select * from llx_r_deviscara_clientdevis where fk_soc='.$this->fk_soc;
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
				$obj = $this->db->fetch_object($resql);
				$link[$i]=$obj->id;
				$i++;
			}
		}
		return $link;
	}

	function show_link(){
		$tablink=$this->getlink();
		$html='<table class="centpercent notopnoleftnoright table-fiche-title  showlinkedobjectblock"><tbody><tr><td class="nobordernopadding valignmiddle col-title"><div class="titre inline-block">Devis liés</div></td><td class="nobordernopadding titre_right wordbreakimp right valignmiddle">
		<dl class="dropdown" id="linktoobjectname">
		
		</div>
		</dd>
		</dl></td></tr></tbody></table>
		<div class="div-table-responsive-no-min"><table class="noborder allwidth" data-block="showLinkedObject" data-element="deviscara" data-elementid="872"><tbody>
		<tr class="liste_titre"><td>Type</td><td>Réf.</td><td class="center"></td><td class="center">Date</td></tr>';
		$url=dol_buildpath('/deviscara/dev_client.php', 1).'?id=';
		foreach($tablink as $devis){
			$prod=new $this($this->db);
			$prod->fetch($devis);
			$html.='<tr class="impair"><td>devis numéro: </td><td><a href='.$url.$prod->id.'>'.$prod->ref.'</a></td><td class="center"></td><td class="center">'.$prod->label.'</td></tr>';
		
		}
		
		
		return $html;
	}

	public function update_total($tabtarif=array()){
		global $db,$user;
		$total_ht=$total_tva=$mt_eligible=0;
		$this->fetchLines();
		foreach ($this->lines as $line){
			$total_ht+=$line->total_ht;
			$total_tva+=$line->total_ht*$line->tva_tx/100;
		}
		$this->total_ht=$total_ht;
		$this->total_tva=$total_tva;
		$this->total_ttc=$total_ht+$total_tva;
		if($mt_eligible>0)
			$this->totaleligible=$total_ht-$mt_eligible;
		else 
			$this->totaleligible=0;
		
	
		$objectPrimes=new devPrime($db);
		
		$object_soc=new Societe($db);
		$object_soc->fetch($this->fk_soc);

		$tabinfo=get_tarif(array($object_soc->array_options['options_nbpart'],$object_soc->array_options['options_rfr'],));
		$plafond=$tabinfo[1];
		

		//total des primes
		$primes=$objectPrimes->fetchAll('','',10,0,array('customsql'=>"fk_deviscara=".$this->id." "));
		$total_primes=0;
		foreach($primes as $prime){
			$total_primes+=$prime->total_ht;
		}
		$this->total_rac=$this->total_ttc+$total_primes;
		$this->update($user);
		$this->fetchLines(); //on update l'objet pour affichage
	}

	public function setDate($label){
		$sql='update '.MAIN_DB_PREFIX.$this->table_element.' set date_'.$label.'="'.$this->db->idate(dol_now()).'" where rowid='.$this->id;
		$result = $this->db->query($sql);
		if (!$result)
		{
			setEventMessages($this->db->lasterror(), null, 'errors');
		}
	}
}

/**
 * Class devLine. You can also remove this and generate a CRUD class for lines objects.
 */
class iso2Line extends CommonObjectLine
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'iso2line';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'deviscara_devline';
	

	public function __construct($db)
	{
		$this->db = $db;
	}
	
	
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>1, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'label' => array('type'=>'varchar(255)', 'label'=>'Label', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1',),
		'subprice' => array('type'=>'price', 'label'=>'Amount', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>1, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'qty' => array('type'=>'real', 'label'=>'Qty', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>1, 'isameasure'=>'1', 'css'=>'maxwidth75imp', 'help'=>"Help text for quantity",),
		'description' => array('type'=>'text', 'label'=>'Description', 'enabled'=>1, 'position'=>60, 'notnull'=>0, 'visible'=>3,),
		'date_creation' => array('type'=>'datetime', 'label'=>'DateCreation', 'enabled'=>1, 'position'=>500, 'notnull'=>1, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'position'=>510, 'notnull'=>1, 'visible'=>-2, 'foreignkey'=>'user.rowid',),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		//'fk_status' => array('type'=>'integer:Deviscaraiso:custom/deviscaraiso/class/deviscaraiso.class.php', 'label'=>'Status', 'enabled'=>1, 'position'=>1000, 'notnull'=>1, 'visible'=>1, 'index'=>1),
		'type' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>1, 'position'=>1000, 'notnull'=>1, 'visible'=>1, 'index'=>1, 'arrayofkeyval'=>array('0'=>'Aucun','1'=>'ISO', '2'=>'CES','3'=>'REP','4'=>'TOIT','5'=>'MEN','6'=>'PV'),),
		'fk_deviscara' => array('type'=>'integer', 'label'=>'Id_produit', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'fk_unit' => array('type'=>'integer', 'label'=>'Unité', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'total_ht' => array('type'=>'price', 'label'=>'Total HT', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'tva_tx'  => array('type'=>'price', 'label'=>'Taux de TVA', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>'taux'),
		'position' => array('type'=>'integer', 'label'=>'position', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),
		'stotal_ht' => array('type'=>'price', 'label'=>'groupe', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-0, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),
		'fk_product' => array('type'=>'integer:Product:product/class/product.class.php', 'label'=>'Type produit', 'enabled'=>1, 'position'=>1002, 'notnull'=>1, 'visible'=>1, 'index'=>1,),
		'product_type' => array('type'=>'integer', 'label'=>'type produit', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-0, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),

	);

	public function fetchAll($sortorder = '', $sortfield = '', $limit = 10, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		$sql = 'SELECT ';
		$sql .= $this->getFieldList();
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		//$sql .= 'left join '.MAIN_DB_PREFIX.'deviscara_devtypeprod as t';
		$sql .= ' WHERE 1 = 1';
		// Manage filter
		$sqlwhere = array();
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				if ($key == 't.rowid') {
					$sqlwhere[] = $key.'='.$value;
				}
				elseif (strpos($key, 'date') !== false) {
					$sqlwhere[] = $key.' = \''.$this->db->idate($value).'\'';
				}
				elseif ($key == 'customsql') {
					$sqlwhere[] = $value;
				}
				else {
					$sqlwhere[] = $key.' LIKE \'%'.$this->db->escape($value).'%\'';
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= ' AND ('.implode(' '.$filtermode.' ', $sqlwhere).')';
		}
		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		
		if (!empty($limit)) {
			$sql .= ' '.$this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);
				$record->ref='';
				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	public function create(User $user, $notrigger = false)
	{
		return $this->createCommon($user, $notrigger);
	}
	
	/**
	 * Load object in memory from the database
	 *
	 * @param int    $id   Id object
	 * @param string $ref  Ref
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null)
	{
		$result = $this->fetchCommon($id, $ref);
		return $result;
	}

	/**
	 * Update object into database
	 *
	 * @param  User $user      User that modifies
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = false)
	{
		return $this->updateCommon($user, $notrigger);
	}


}

class iso2Prime extends CommonObjectLine
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'iso2prime';

	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'deviscara_devprime';
	

	public function __construct($db)
	{
		$this->db = $db;
	}
	
	
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>1, 'position'=>1, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'label' => array('type'=>'varchar(255)', 'label'=>'Label', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1',),
		//'description' => array('type'=>'varchar(255)', 'label'=>'Description', 'enabled'=>1, 'position'=>30, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth200', 'help'=>"Help text", 'showoncombobox'=>'1',),
		'subprice' => array('type'=>'price', 'label'=>'Amount', 'enabled'=>1, 'position'=>40, 'notnull'=>0, 'visible'=>1, 'default'=>'null', 'isameasure'=>'1', 'help'=>"Help text for amount",),
		'date_creation' => array('type'=>'datetime', 'label'=>'DateCreation', 'enabled'=>1, 'position'=>500, 'notnull'=>1, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>1, 'position'=>510, 'notnull'=>1, 'visible'=>-2, 'foreignkey'=>'user.rowid',),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>1, 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		'type' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>1, 'position'=>1000, 'notnull'=>1, 'visible'=>1, 'index'=>1, 'arrayofkeyval'=>array('0'=>'Aucun','1'=>'ISO', '2'=>'CES','3'=>'REP','4'=>'TOIT','5'=>'MEN','6'=>'PV'),),
		'type_prime' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>1, 'position'=>1000, 'notnull'=>1, 'visible'=>1, 'index'=>1, 'arrayofkeyval'=>array(1=>'Prime MPR',2=>'Prime PEE'),),
		'fk_deviscara' => array('type'=>'integer', 'label'=>'Id_produit', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
		'position' => array('type'=>'integer', 'label'=>'position', 'enabled'=>1, 'position'=>1001, 'notnull'=>1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"position"),
		'qty' => array('type'=>'real', 'label'=>'Qty', 'enabled'=>1, 'position'=>45, 'notnull'=>0, 'visible'=>1, 'isameasure'=>'1', 'css'=>'maxwidth75imp', 'help'=>"Help text for quantity",),
		'total_ht' => array('type'=>'price', 'label'=>'Total HT', 'enabled'=>1, 'position'=>1001, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1, 'comment'=>"Id"),
	);

	public function fetchAll($sortorder = '', $sortfield = '', $limit = 10, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		$sql = 'SELECT ';
		$sql .= $this->getFieldList();
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		$sql .= ' WHERE 1 = 1';
		// Manage filter
		$sqlwhere = array();
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				if ($key == 't.rowid') {
					$sqlwhere[] = $key.'='.$value;
				}
				elseif (strpos($key, 'date') !== false) {
					$sqlwhere[] = $key.' = \''.$this->db->idate($value).'\'';
				}
				elseif ($key == 'customsql') {
					$sqlwhere[] = $value;
				}
				else {
					$sqlwhere[] = $key.' LIKE \'%'.$this->db->escape($value).'%\'';
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= ' AND ('.implode(' '.$filtermode.' ', $sqlwhere).')';
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= ' '.$this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
            $i = 0;
			while ($i <  $num)
			{
			    $obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}
	public function create(User $user, $notrigger = false)
	{
		return $this->createCommon($user, $notrigger);
	}
	
	public function update(User $user, $notrigger = false)
	{
		return $this->updateCommon($user, $notrigger);
	}
	
}

