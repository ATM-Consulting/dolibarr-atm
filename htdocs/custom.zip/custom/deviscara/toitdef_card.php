<?php
/* Copyright (C) 2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       iso1_card.php
 *		\ingroup    deviscara
 *		\brief      Page to create/edit/view rep
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB','1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER','1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC','1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN','1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION','1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION','1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK','1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL','1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK','1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU','1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML','1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX','1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN",'1');						// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK','1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT','auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE','aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN',1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP','none');					// Disable all Content Security Policies


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/deviscara/class/toitdefinitif.class.php');
dol_include_once('/deviscara/lib/deviscara_toitdef.lib.php');
dol_include_once('/product/class/product.class.php');
dol_include_once('/deviscara/class/toit.class.php');
dol_include_once('/compta/facture/class/facture.class.php');

// Load translation files required by the page
$langs->loadLangs(array("deviscara@deviscara", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'toitcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$lineid   = GETPOST('lineid', 'int');
$socid   = GETPOST('socid', 'int');
$fromid   = GETPOST('fromid', 'int');



// Initialize technical objects

$object = new toitdef($db);
$extrafields = new ExtraFields($db);
$object_bc =new toit($db);
$object_soc=new societe($db);

$extrafields_soc = new ExtraFields($db);
$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
$diroutputmassaction = $conf->deviscara->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('toitcard', 'globalcard','devcard')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

$object_bc->fetch($fromid);
// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->statut == $object::STATUS_DRAFT) ? 1 : 0);
//$result = restrictedArea($user, 'deviscara', $object->id, '', '', 'fk_soc', 'rowid', $isdraft);

$permissiontoread = $user->rights->deviscara->rep->read;
$permissiontoadd = $user->rights->deviscara->rep->write; // Used by the include of actions_addupdatedelete.inc.php and actions_lineupdown.inc.php
$permissiontodelete = $user->rights->deviscara->rep->delete || ($permissiontoadd && isset($object->status) && $object->status == $object::STATUS_DRAFT);
$permissionnote = $user->rights->deviscara->rep->write; // Used by the include of actions_setnotes.inc.php
$permissiondellink = $user->rights->deviscara->rep->write; // Used by the include of actions_dellink.inc.php
$upload_dir = $conf->deviscara->multidir_output[isset($object->entity) ? $object->entity : 1];


/*
 * Actions
 */

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook))
{
    $error = 0;

    $backurlforlist = dol_buildpath('/deviscara/toit_list.php', 1);

    if (empty($backtopage) || ($cancel && empty($id))) {
    	if (empty($backtopage) || ($cancel && strpos($backtopage, '__ID__'))) {
    		if (empty($id) && (($action != 'add' && $action != 'create') || $cancel)) $backtopage = $backurlforlist;
    		else $backtopage = dol_buildpath('/deviscara/toitdef_card.php', 1).'?id='.($id > 0 ? $id : '__ID__');
    	}
    }
    $triggermodname = 'DEVISCARA_REP_MODIFY'; // Name of trigger action code to execute when we modify record

    // Actions cancel, add, update, update_extras, confirm_validate, confirm_delete, confirm_deleteline, confirm_clone, confirm_close, confirm_setdraft, confirm_reopen
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/actions_addupdatedeletetoitdef.inc.php',1);
    // Actions when linking object each other
    include DOL_DOCUMENT_ROOT.'/core/actions_dellink.inc.php';

    // Actions when printing a doc from card
    include DOL_DOCUMENT_ROOT.'/core/actions_printing.inc.php';

    // Action to move up and down lines of object
    include DOL_DOCUMENT_ROOT.'/core/actions_lineupdown.inc.php';

    // Action to build doc
    include DOL_DOCUMENT_ROOT.'/core/actions_builddoc.inc.php';

    if ($action == 'set_thirdparty' && $permissiontoadd)
    {
    	$object->setValueFrom('fk_soc', GETPOST('fk_soc', 'int'), '', '', 'date', '', $user, 'REP_MODIFY');
    }
    if ($action == 'classin' && $permissiontoadd)
    {
    	$object->setProject(GETPOST('projectid', 'int'));
    }

    // Actions to send emails
    $triggersendname = 'REP_SENTBYMAIL';
    $autocopy = 'MAIN_MAIL_AUTOCOPY_REP_TO';
    $trackid = 'toitdef'.$object->id;
    include DOL_DOCUMENT_ROOT.'/core/actions_sendmails.inc.php';
}
//include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.



/*
 * View
 *
 * Put here all code to build page
 */

$form = new Form($db);
$formfile = new FormFile($db);

llxHeader('', $langs->trans('Devis Toiture Définitif'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});


function affichproduit(idprod) {
	for(i=1;i<=17;i++){
		document.getElementById("idprod"+i).style.display="none";
	}
	document.getElementById("buttonstoiture").style.display="none";
	document.getElementById("idprod"+idprod).style.display="block";
}

function test(champ,toaffich){
	if (champ.value > 0)
		affichproduit(toaffich);
	else alert( champ.name+": valeur >0 obligatoire");
}
function affichbuttonstoiture(){
	document.getElementById("buttonstoiture").style.display="block";
}
function affichcma(){
	document.getElementById("cma").style.display="block";
	document.getElementById("perso").style.display="none";
}
function affichperso(){
	document.getElementById("perso").style.display="block";
	document.getElementById("cma").style.display="none";
}
</script>';


// Part to create
if ($action == 'create')
{
	
	if($fromid>0) unset($_SESSION['client'],$_SESSION['toitdef'],$_SESSION['financement'],
	$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);

	if($socid>0)
		$object_soc->fetch($socid);
	else
		setEventMessages('Client non défini', '', 'errors');

	print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("Devis Toiture définitif")));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="create2">';
	print '<input type="hidden" name="socid" value="'.$socid.'">';
	print '<input type="hidden" name="fromid" value="'.$fromid.'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');
	if($_SESSION['toitdef']['surface']<=0 ){
		print '<div id="iddiv0" style="display: block;"><table class="tableclassicrep" ><tr>';
		print '<tr><td>Nom du Client  : </td><td>'.$object_soc->nom.'</td></tr>';
		$value=($_SESSION['cara_type_client']>0?$_SESSION['cara_type_client']:$object_soc->array_options['options_cara_type_client']);
		print '<td>Précarité client : </td><td>'.$extrafields_soc->showOutputField('cara_type_client', $value, '  ', '', '', 0, $object_soc->id, 'societe').'</td>';
		print '</tr><tr>';
		
		print '<tr><td>Conf EDF</td><td>'.$object_bc->showOutputField($object_bc->fields['conf_edf'],'conf_edf', $object_bc->conf_edf, '', '', ' ', $object_bc->id,'deviscara_toit').'</td></tr>';
		print '<tr><td>Conf MPR</td><td>'.$object_bc->showOutputField($object_bc->fields['conf_mpr'],'conf_mpr', $object_bc->conf_mpr, '', '', ' ', $object_bc->id,'deviscara_toit').'</td></tr>';
		$docs=explode('|',$object->get_info_deviscommercial($fromid)['array_liste_pieces']);
		$docmanquant='';
		foreach ($object::groupe_famille['Documents A récuperer'] as $id_famille=>$famille){
			if (in_array($id_famille,$docs)){
				$docmanquant.= $famille.'<br>';
			}
		}
		print '<tr><td>Pièces manquantes </td><td>'.$docmanquant.'</td>';
		print '</tr>';
		print'<tr><td>Surface Toiture (M2)</td><td><input  type="text"  name="surface"  value="'.$_SESSION['toitdef']["surface"].'"></td></tr>';
		//print'<tr><td>Combles déjà isolées</td><td>'.$extrafields_soc->showInputField('isocombles', $value, '  ', '', '', 'demo2 demo', $object_soc->id, 'societe').'</td></tr>';
		print '<tr><td>Combles déjà isolées </td>
		<td><input class="demo2 demo" type="radio" name="isocombles" id="isocomblesoui"   value="1" '.($_SESSION['toitdef']["isocombles"]=="1"?"checked":"").'> <label for="isocomblesoui">OUI</label><br><br>
		    <input class="demo2 demo" type="radio" name="isocombles" id="isocomblesnon"   value="2" '.($_SESSION['toitdef']["isocombles"]=="2"?"checked":"").'> <label for="isocomblesnon" >NON</label><br><br></td>';
		print '</tr>';
		print '<tr><td>Définition des primes: </td><td><input class="demo2 demo" type="radio" name="mpr" id="mproui"   value="1" '.($_SESSION['toitdef']["mpr"]=="1"?"checked":"").'> <label for="mproui">AVEC MPR</label><br><br>
		<input class="demo2 demo" type="radio" name="mpr" id="mprnon"   value="2" '.($_SESSION['totoitdefle']["mpr"]=="2"?"checked":"").'> <label for="mprnon" >SANS MPR</label><br><br></td>';
		print '</tr>';
		print '<tr><td>Type de tôles<br>Toles CARA Protector préconisé si -1km de la mer si non la tôle standard ne sera garantie que 2 ans</td>
			<td><input class="demo2 demo" type="radio" name="tole" id="tolesstandard"   value="2" '.($_SESSION['toitdef']["toles"]=="2"?"checked":"").'> <label for="tolesstandard">TG-10</label>&nbsp;
			<input class="demo2 demo" type="radio" name="tole" id="tolesprotector"   value="3" '.($_SESSION['toitdef']["toles"]=="3"?"checked":"").'> <label for="tolesprotector" >TG-20</label><br><br>
			<input class="demo2 demo" type="radio" name="tole" id="mi10"   value="28" '.($_SESSION['toitdef']["toles"]=="28"?"checked":"").'> <label for="mi10">MI-10</label>&nbsp;
			<input class="demo2 demo" type="radio" name="tole" id="mi20"   value="27" '.($_SESSION['toitdef']["toles"]=="27"?"checked":"").'> <label for="mi20" >MI-20</label></td>';
		print '</tr>';
		
		print'<tr><td>Forme de toles:</td><td><input class="demo2 demo" type="radio" name="type_tole" id="typetolebac"   value="1" '.($_SESSION['toitdef']["type_tole"]=="1"?"checked":"").'> <label for="typetolebac">Bac Acier</label><br><br>
		<input class="demo2 demo" type="radio" name="type_tole" id="typetoleondule"   value="2" '.($_SESSION['tole']["type_tole"]=="2"?"checked":"").'> <label for="typetoleondule">Ondulées</label><br><br></td></tr>';
		print'<tr><td>Couleur</td><td>'.$object->showInputField($object->fields['couleur_tole'], 'couleur_tole', '  ', '', '', '', $object->id, 'deviscara_toitdef').'</td></tr>';
		
		print'<tr><td colspan=2><input class="button" type="submit" name="valider" value="valider"><input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>';
		print '</table></div>';

	}
}
	
	//affichage choix produits
if($action=='create2' ){
	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="create2">';
	print '<input type="hidden" name="socid" value="'.$socid.'">';
	print '<input type="hidden" name="fromid" value="'.$fromid.'">';

	print '<div id="iddiv1" style="display: block;"><table class="tableclassicrep" >';
	$liste_produits109= $object->get_liste109();
	$options='<option value="">Article</option>';
	foreach($liste_produits109 as $iprod=>$ref){
		$options.='<option value="'.$iprod.'">'.$ref.'</option>';
	}
	$select='<select name="109" >'.$options.'</select>';
	print '<tr><td>Liste des produits 109 disponible</td><td>'.$select.'</td><td class="nowrap">M2:<input size="5" type="text" name="surface109" value="'.$_SESSION['toitdef']["surface"].'"></td></tr>';
	$liste_produits106= $object->get_liste106();
	$options='<option value="">Article</option>';
	foreach($liste_produits106 as $iprod=>$ref){
		$options.='<option value="'.$iprod.'">'.$ref.'</option>';
	}
	$select='<select name="106" >'.$options.'</select>';
	print '<tr><td>Liste des produits 106 disponible</td><td>'.$select.'</td><td class="nowrap" >M2:<input size="5" type="text" name="surface106" value="'.$_SESSION['toitdef']["surface"].'"></td></tr>';
	print'<tr><td colspan=2><input class="button" type="button" onclick="affichproduit(1);" name="valider" value="valider"></td></tr>';
	print '</table></div>';

	print '<div id="idprod1" style="display: none; ">';
	print'<table class="tableclassic">';
	print '<tr><td>Chien Assis </td>
	<td><input class="demo2 demo" type="radio" name="chienassis" id="chienassisoui" onclick="affichproduit(17);" value="oui" '.($_SESSION['toitdef']["charpente"]=="oui"?"checked":"").'> <label for="chienassisoui">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="chienassis" id="chienassisnon" onclick="affichproduit(2);" value="non" '.($_SESSION['toitdef']["charpente"]=="non"?"checked":"").'> <label for="chienassisnon">Non</label><br>
	</td></tr>';
	print '</table></div>';

	print '<div id="idprod2" style="display: none; ">';
	print'<table class="tableclassic">';
	print '<tr><td>Charpente </td>
	<td><input class="demo2 demo" type="radio" name="charpente" id="charpentea" onclick="affichproduit(3);" value="oui" '.($_SESSION['toitdef']["charpente"]=="oui"?"checked":"").'> <label for="charpentea">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="charpente" id="charpenteb" onclick="affichproduit(5);" value="non" '.($_SESSION['toitdef']["charpente"]=="non"?"checked":"").'> <label for="charpenteb">Non</label><br>
	</td></tr>';
	print '</table></div>';

	print '<div id="idprod3" class="idprod7">';
	print'<table class="tableclassic"><tr>';
	print'<td>Charpente : </td>';
	$valuecharp=($_SESSION[$_SESSION["produit"]]['metragecharpente']>0?$_SESSION[$_SESSION["toitdef"]]['metragecharpente']:$_SESSION[$_SESSION["toitdef"]]['metragecharpente']);
	print'<td>M2 </td><td><input type="text" id="metragecharpente"   name="metragecharpente" value="'.$valuecharp.'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragecharpente,4);"></td>';
	print'</table></div>';

	print '<div id="idprod4" class="idprod16">';
	print'<table class="tableclassic"><tr>';
	print'<td><input class="demo2 demo" type="radio" name="type_primech" id="typech1" onclick="affichproduit(5);" value="1" '.($_SESSION['toitdef']["type_primech"]=="1"?"checked":"").'><label for="typech1">Changement de Charpente</label><br><br>
	<input class="demo2 demo" type="radio" id="typech2" name="type_primech" onclick="affichproduit(5);"  value="2" '.($_SESSION['toitdef']["type_primech"]=="2"?"checked":"").'><label for="typech2">Changement de panne </label><br><br>
	<input class="demo2 demo" type="radio" id="typech3" name="type_primech" onclick="affichproduit(5);"  value="3" '.($_SESSION['toitdef']["type_primech"]=="3"?"checked":"").'><label for="typech3">Changement de Liteaux</label></td>';
	print '</tr>';
	print'</table></div>'; 

	print '<div id="idprod5" class="idprod5">';
	print'<table class="tableclassic">';
	print '<tr><td>Faux Plafond </td>
	<td><input class="demo2 demo" type="radio" id="fauxplafond1" name="fauxplafond"  onclick="affichproduit(6);" value="oui" '.($_SESSION['toitdef']["charpente"]=="oui"?"checked":"").'> <label for="fauxplafond1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" id="fauxplafond2" name="fauxplafond"  onclick="affichproduit(7);" value="non" '.($_SESSION['toitdef']["charpente"]=="non"?"checked":"").'> <label for="fauxplafond2">Non</label><br>
	</td></tr>';
	print '</table></div>';

	print '<div id="idprod6" class="idprod11">';
	print'<table class="tableclassic"><tr>';
	print '<td>Faux Plafond: </td>';
	print'<td>Metrage Faux plafond</td><td><input type="text" id="metragefauxplafond"  name="metragefauxplafond" value="'.$_SESSION[$_SESSION["toitdef"]]['metragefauxplafond'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragefauxplafond,9);"></td>';
	print'</table></div>';


	print '<div id="idprod7" class="idprod7">';
	print'<table class="tableclassic">';
	print '<tr><td>Chenaux</td>
	<td><input class="demo2 demo" type="radio" name="chenaux"  id="chenaux1"  onclick="affichproduit(11);" value="oui" '.($_SESSION['toitdef']["charpente"]=="oui"?"checked":"").'> <label for="chenaux1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="chenaux"  id="chenaux2" onclick="affichproduit(10);" value="non" '.($_SESSION['toitdef']["charpente"]=="non"?"checked":"").'> <label for="chenaux2">Non</label><br>
	</td></tr>';
	print '</table></div>';


	print '<div id="idprod8" class="idprod8">';
	print'<table class="tableclassic"><tr>';
	print '<td>Gouttières: </td>';
	print'<td>ML:</td><td><input type="text" id="metragegouttieres"  name="metragegouttieres" value="'.$_SESSION[$_SESSION["toitdef"]]['metragegouttieres'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragegouttieres,13);"></td>
	</table></div>';
	
	print '<div id="idprod9" class="idprod9">';
	print'<table class="tableclassic"><tr>';
	print '<td><input class="demo2 demo" type="radio" onclick="affichproduit(7);" name="type_primefp" id="typefp1" value="fpaparente" '.($_SESSION['toitdef']["type_primefp"]=="fpaparente"?"checked":"").'><label for="typefp1">FP Charpente apparente</label><br><br>
	<input class="demo2 demo" type="radio" onclick="affichproduit(7);" id="typefp2" name="type_primefp"  value="fprampante" '.($_SESSION['toitdef']["type_primefp"]=="fprampante"?"checked":"").'><label for="typefp2">FP Charpente rampante</label><br><br>
	<input class="demo2 demo" type="radio" onclick="affichproduit(7);" id="typefp3"  name="type_primefp"  value="fpossature" '.($_SESSION['toitdef']["type_primefp"]=="fpossature"?"checked":"").'><label for="typefp3">FP droit avec ossature</label></td>
	</tr></table></div>';

	print '<div id="idprod10" class="idprod10">';
	print'<table class="tableclassic">';
	print'<tr><td>Gouttieres </td>
	<td><input class="demo2 demo" type="radio" name="gouttiere" id="gouttiere1"  onclick="affichproduit(8);" value="oui" '.($_SESSION['toitdef']["gouttiere"]=="oui"?"checked":"").'> <label for="gouttiere1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="gouttiere"  id="gouttiere2" onclick="affichproduit(13);" value="non" '.($_SESSION['toitdef']["gouttiere"]=="non"?"checked":"").'> <label for="gouttiere2">Non</label><br></td></tr>
	</table></div>';

	print '<div id="idprod11" class="idprod11" >';
	print'<table class="tableclassic">';
	print '<tr><td>Chenaux: </td>';
	print'<td>ML: </td><td><input type="text" id="metragechenaux" name="metragechenaux" value="'.$_SESSION[$_SESSION["toitdef"]]['metragechenaux'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragechenaux,12);"></td>';
	print'</table></div>';

	print '<div id="idprod12" class="idprod12">';
	print'<table class="tableclassic"><tr>';
	print'<td><input class="demo2 demo" type="radio" onclick="affichproduit(10);" name="type_primechen" id="typechen1"  value="1" '.($_SESSION['toitdef']["type_primechen"]=="1"?"checked":"").'><label for="typechen1">Suppression</label><br><br>
	<input class="demo2 demo"  type="radio" onclick="affichproduit(10);" name="type_primechen"  id="typechen2" value="2" '.($_SESSION['toitdef']["type_primechen"]=="2"?"checked":"").'><label for="typechen2">Etancheité</label><br>
	</tr>';
	print'</table></div>';

	print '<div id="idprod13" class="idprod13">';
	print'<table class="tableclassic"><tr>
	<td>PV A déposer</td>
	<td><input class="demo2 demo" type="radio" name="pvdepose" id="pvdepose1"  onclick="affichproduit(14);" value="1" '.($_SESSION['toitdef']["pvdepose"]=="1"?"checked":"").'> <label for="pvdepose1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="pvdepose"  id="pvdepose2" onclick="affichproduit(15);" value="2" '.($_SESSION['toitdef']["pvdepose"]=="2"?"checked":"").'> <label for="pvdepose2">Non</label><br></td></tr>
	</tr>';
	print'</table></div>';

	print '<div id="idprod14" class="idprod14">';
	print'<table class="tableclassic">';
	print '<tr>
	<td>PV A déposer</td>
	<td><input class="demo2 demo" type="radio" name="pvtypedepose" id="pvtypedepose1"   value="1" '.($_SESSION['toitdef']["pvtypedepose"]=="1"?"checked":"").'> <label for="pvtypedepose1">DEPOSE/REPOSE</label><br><br>
	<input class="demo2 demo" type="radio" name="pvtypedepose"  id="pvtypedepose2"  value="2" '.($_SESSION['toitdef']["pvtypedepose"]=="2"?"checked":"").'> <label for="pvtypedepose2">DEPOSE</label><br></td></tr>
	</tr>';
	print '<tr><td>NB PV</td><td><input class="demo2 demo" type="text"  id="nbpanneaux"  name="nbpanneaux"  value="'.$_SESSION['toitdef']["nbpanneaux"].'" ><td><input class="button" type="button" name="valider" value="valider" onclick="test(nbpanneaux,15);"></td>
	</tr>';
	print'</table></div>';

	print '<div id="idprod15" class="idprod15">';
	print'<table class="tableclassic"><tr>
	<td>Dépose de CES ou Remplacement</td>
	<td><input class="demo2 demo" type="radio" name="cesdeposerepose" id="cesdeposerepose1"  onclick="affichproduit(16);" value="oui" '.($_SESSION['toitdef']["cesdeposerepose"]=="oui"?"checked":"").'> <label for="cesdeposerepose1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="cesdeposerepose"  id="cesdeposerepose2" onclick="affichbuttonstoiture();" value="non" '.($_SESSION['toitdef']["cesdeposerepose"]=="non"?"checked":"").'> <label for="cesdeposerepose2">Non</label><br></td></tr>
	</tr>';

	print'</table></div>';

	print '<div id="idprod16" class="idprod16">';
	print'<table class="tableclassic">';
	print '<tr><td>NB CES</td><td><input class="demo2 demo" type="text"  id="nbces"  name="nbces"  value="'.$_SESSION['toitdef']["nbces"].'" >
	</tr>';
	print '<tr>
	<td colspan=2><input class="demo2 demo" type="radio" name="cesdepose" id="cesdepose1"  onclick="affichbuttonstoiture();" value="1" '.($_SESSION['toitdef']["cesdepose"]=="1"?"checked":"").'> <label for="cesdepose1">Dépose/repose sans garantie forfait de 250€</label><br><br>
	<input class="demo2 demo" type="radio" name="cesdepose"  id="cesdepose2" onclick="affichbuttonstoiture();" value="2" '.($_SESSION['toitdef']["cesdepose"]=="2"?"checked":"").'> <label for="cesdepose2">CES NEUF pour GP/P/HPV : Forfait de 250€ </label><br></td></tr>
	</tr>';
	
	print'</table></div>';

	print '<div id="idprod17" class="idprod17">';
	print'<table class="tableclassic"><tr>';
	print'<td>NB chien assis</td><td><input type="text" id="chienassisnb" name="chienassisnb" value="'.$_SESSION[$_SESSION["toitdef"]]['chienassisnb'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="affichproduit(2);"></td>';
	print '</tr>';
	print'</table></div>';
	
	print'<div id="buttonstoiture" style="display: none;">';
	print '<table class="border  tableforfieldedit">
	<tr><td><input type="submit" class="button" name="toiture" value="Créer devis"></td><td><input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>
	</table></div>';


	
	print '<a name="bottom"></a>';
	print '</form>';
	dol_fiche_end();
	//dol_set_focus('input[name="ref"]');
}

if($action=="affichdevis"){
	
	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="affichfinancement">';
	print '<input type="hidden" name="socid" value="'.$socid.'">';
	print '<input type="hidden" name="fromid" value="'.$fromid.'">';
	if($socid>0)
		$object_soc->fetch($socid);
	else{
		setEventMessages('Client non défini', '', 'errors');
		exit;
	}
	$couleur=$object_soc->array_options['options_cara_type_client'];
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoitdef.lib.php',1);

	
	if($couleur=='3')
		$bgcolor='lightblue';
	elseif($couleur=='2')
		$bgcolor='yellow';
	elseif($couleur=='1')
		$bgcolor='mediumorchid';
	elseif($couleur=='5')
		$bgcolor='pink';

	print '<div id="devistoiture" class="fichehalfleft" >';
	print'<table class="noborder soixantepercent" border=1><tr>';
	print '<td bgcolor="'.$bgcolor.'" colspan=4 align="center">Devis Commercial Toiture </td>';
	$htm = '</tr>';
	$htm = '<tr><td>Libele</td><td>Quantité</td><td>Prix Unitaire TTC</td><td>Montant TTC</td></tr>';
	$htm .= '<tr class="oddeven">';
	$i=0;
	$total=array();
	if($_SESSION['client']['mpr']==1)//avec mpr
		$idaffich=0;
	if($_SESSION['client']['mpr']==2)//sans mpr
		$idaffich=1;
	$htm.='<td>'.$tabtarif['forfait'][$idaffich]['previsite']->ref.'</td><td>1</td><td>'.price($tabtarif['forfait'][$idaffich]['previsite']->price_ttc).'</td><td>'.price($tabtarif['forfait'][$idaffich]['previsite']->price_ttc).'</td></tr><tr class="oddeven">';
	
	$total=cumultotal($total,$tabtarif['forfait'][$idaffich]['previsite']);
	$total_edf=cumultotal($total_edf,$tabtarif['forfait'][$idaffich]['previsite']);
	$htm.='<td>'.$tabtarif['forfait'][$idaffich]['livraison']->ref.'</td><td>1</td><td>'.price($tabtarif['forfait'][$idaffich]['livraison']->price_ttc).'</td><td>'.price($tabtarif['forfait'][$idaffich]['livraison']->price_ttc).'</td></tr><tr class="oddeven">';
	$total_ttc+=(float)$tabtarif['forfait'][$idaffich]['livraison']->price_ttc;
	$total=cumultotal($total,$tabtarif['forfait'][$idaffich]['livraison']);
	$tarif=$tabtarif['pv'][$idaffich];
	foreach ($tarif as $id=>$product){
		$i++;
		$htm.='<td>'.$product->ref.'</td><td>'.$_SESSION['toitdef']['surface'].'</td><td>'.price($product->price_ttc).'</td><td>'.price($product->price_ttc*$_SESSION['toitdef']['surface']).'</td>';
		if($i%2)
			$htm.='</td></tr><tr class="oddeven">';
		else $htm.='</td></tr><tr class="pair">';
		$total=cumultotal($total,$product,$_SESSION['toitdef']['surface']);
	}
	$htm.='<tr ><td colspan=3 bgcolor="lightgray">Sous total couverture (TTC)</td><td bgcolor="lightgray">'.price($total['ttc'],0,'',1,2,2).'</td></tr>';
	
	$tarif=$tabtarif['pv109'][$idaffich];
	$total['pv109']=0;
	foreach ($tarif as $id=>$product){
		$i++;
		$htm.='<td>'.$product->ref.'</td><td>'.$_SESSION['toitdef']['surface109'].'</td><td>'.price($product->price_ttc).'</td><td>'.price($product->price_ttc*$_SESSION['toitdef']['surface109']).'';
		if($i%2)
			$htm.='</td></tr><tr class="oddeven">';
		else $htm.='</td></tr><tr class="pair">';
		$total['pv109']+=$product->price_ttc*$_SESSION['toitdef']['surface109'];
		$total=cumultotal($total,$product,$_SESSION['toitdef']['surface109']);
	}
	
	$htm.='<tr ><td colspan=3 bgcolor="lightgray">Sous Total 109 (TTC)</td><td bgcolor="lightgray">'.price($total['pv109'],0,'',1,2,2).'</td></tr>';

	$tarif=$tabtarif['pv106'][$idaffich];
	$total['pv106']=0;
	foreach ($tarif as $id=>$product){
		$i++;
		$htm.='<td>'.$product->ref.'</td><td>'.$_SESSION['toitdef']['surface106'].'</td><td>'.price($product->price_ttc).'</td><td>'.price($product->price_ttc*$_SESSION['toitdef']['surface106']).'';
		if($i%2)
			$htm.='</td></tr><tr class="oddeven">';
		else $htm.='</td></tr><tr class="pair">';
		$total['pv106']+=$product->price_ttc*$_SESSION['toitdef']['surface106'];
		$total=cumultotal($total,$product,$_SESSION['toitdef']['surface106']);
	}
	$htm.='</tr>';
	
	$htm.='<tr ><td colspan=3 bgcolor="lightgray">Sous Total 106 (TTC)</td><td bgcolor="lightgray">'.price($total['pv106'],0,'',1,2,2).'</td></tr>';

	if($_SESSION[$_SESSION["produit"]]['charpente']=='oui')
		$htm.='<tr class="oddeven"><td colspan=3><b>Charpente</b></td></tr>';
	$tarif=$tabtarif['option'][0];
	$i=0;
	foreach ($tarif as $id=>$product){
		$i++;
		if($id=='char'){
			$metrage=$_SESSION['toitdef']['metragecharpente'];
		}
		elseif($id=='gouttiere'){
			$metrage=$_SESSION['toitdef']['metragegouttieres'];
		}
		elseif($id=='fp'){
			$metrage=$_SESSION['toitdef']['metragefauxplafond'];
		}
		elseif($id=='chen'){
			$metrage=$_SESSION['toitdef']['metragechenaux'];
		}
		elseif($id=='nbpanneaux'){
			$metrage=$_SESSION['toitdef']['nbpanneaux'];
		}
		elseif($id=='chienassis'){
			$metrage=$_SESSION['toitdef']['chienassisnb'];
		}
		elseif($id=='cesdepose'){
			$metrage=$_SESSION['toitdef']['nbces'];
		}
		$htm.='<td>'.$product->label.'</td><td>'.$metrage.'</td><td>'.(float)$product->price_ttc.'</td><td>'.(float)$product->price_ttc*$metrage.'';
		if($i%2)
			$htm.='</td></tr><tr class="oddeven">';
		else $htm.='</td></tr><tr class="pair">';

		$total=cumultotal($total,$product,$metrage);
		$totalcharpente+=(float)$product->price_ttc*$metrage;

	}
	if($totalcharpente>0)
		$htm.='<tr ><td colspan=3 bgcolor="lightgray">Sous total Options</td><td bgcolor="lightgray">'.price($totalcharpente).'</td></tr>';
	
	$htm2= '</tr><tr ><td colspan=4 bgcolor="'.$bgcolor.'"><b>PRIMES</b></td></tr><tr>';
	$total_primes=array();
	$total_primes109=array();
	$total_primes106=array();
	$tarif=$tabtarif[$couleur]['pr'];	
	
	$ligtotal='<tr><td colspan=3 ></td></tr>';
	$ligtotal .= '<tr class="oddeven"><td colspan=3 bgcolor="lightgray">TOTAL HT</td><td bgcolor="lightgray">'.price($total['ht'],0,'',1,2,2).'<input type="hidden" name="totaldevis" value="'.$total.'"></td></tr>';
	$ligtotal .= '<tr class="oddeven"><td colspan=3 bgcolor="lightgray">TOTAL TVA</td><td bgcolor="lightgray">'.price($total['tva'],0,'',1,2,2).'</td></tr>';
	$ligtotal .= '<tr class="oddeven"><td colspan=3 bgcolor="lightgray">TOTAL TTC</td><td bgcolor="lightgray">'.price($total['ttc'],0,'',1,2,2).'<input type="hidden" name="totaldevis" value="'.$total.'"></td></tr>';
	foreach ($tarif as $id => $lib){
		if($_SESSION['client']['mpr']==1 && $lib->array_options['options_type_prime']==2){
			$ligtotal.='<tr><td>'.$lib->label.'</td><td>'.$_SESSION['toitdef']['surface109'].'</td><td>'.(float)$lib->price.'</td><td>'.(float)$lib->price*$_SESSION['toitdef']['surface109'].'</td></tr>';
			$total_primesMPR=cumultotal($total_primes109,$lib,$_SESSION['toitdef']['surface109']);
		}
		elseif($lib->array_options['options_type_prime']==1){
			$ligtotal.='<tr><td>'.$lib->label.'</td><td>'.$_SESSION['toitdef']['surface106'].'</td><td>'.(float)$lib->price.'</td><td>'.(float)$lib->price*$_SESSION['toitdef']['surface106'].'</td></tr>';
			$total_primesEDF=cumultotal($total_primes106,$lib,$_SESSION['toitdef']['surface106']);
		}
		$total_primes=cumultotal($total_primes,$lib,$_SESSION['toitdef']['surface']);
	}

	$rac_client=$total['ttc']+$total_primesEDF['ht']+$total_primesMPR['ht'];
	$ligtotal .= '<tr class="oddeven"><td colspan=3 bgcolor="lightgray">RESTE A PAYER CLIENT</td><td bgcolor="lightgray">'.price($rac_client,0,'',1,2,2).' <input type="hidden" name="totaldevis" value="'.$total.'"></td></tr>';
	print $htm.$ligtotal;
	$htm='<tr><td colspan=4><input type="submit" class="button" name="creationdevis" value="'.dol_escape_htmltag($langs->trans("Valider Devis définitif")).'">';
	$htm.='&nbsp; ';
	$htm.='<input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>';
	print $htm;
	$htm.='</table></div>';
	$_SESSION['financement']['total']=$rac_client;
	
}


if ($action == 'affichfinancement'){
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoitdef.lib.php',1);
	print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("Financement")));
	if($socid>0)
		$object_soc->id=$socid;
	print '<form method="POST" name="creationclient" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="financement2">';
	print '<input type="hidden" name="socid" value="'.$object_soc->id.'">';
	print '<input type="hidden" name="fromid" value="'.$fromid.'">';

	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');

	print'<div id="zonefinancement" style="display: bloc;">';
	print '<table class="border ">';
	// Firstname
	
	print '<tr ><td>Acompte:  <input type="text" name="acompte"  value="'.$object_bc->acompte.'" ><br></td></tr>'; //todo->sumbit le form et afficher les infos.&
	print '<tr ><td>CMA:  <input type="radio" onclick="this.form.submit();" name="typefin"  value="fincma" '.($_SESSION['financement']['type']=="fincma"?"checked":"").'><br></td></tr>';
	print '<tr ><td>Financement personnel:  <input type="radio" onclick="this.form.submit();" name="typefin"  value="perso" '.($_SESSION['financement']['type']=="perso"?"checked":"").'><br></td></tr>';
	print '</table></div>';
	
	if($_SESSION['financement']['type']=='fincma')
		print'<div id="cma" style="display: bloc;">';
	else
		print'<div id="cma" style="display: none;">';
	{
		print '<table class="border " >';
		$mensualité=array_keys($tabfin[30]);
		$tab=explode('/',GETPOST('cmanbmois'));
		

		foreach($mensualité as $mois){
			$checked1='';$checked2='';
			$_SESSION['financement']['acompte']=($_SESSION['financement']['acompte']>0?$_SESSION['financement']['acompte']:0);
			$montant=($_SESSION['financement']['total']-$_SESSION['financement']['acompte'])*$tabfin[30][$mois]; //gérer l'acompte
			$montant90=($_SESSION['financement']['total']-$_SESSION['financement']['acompte'])*$tabfin[90][$mois];
			if($tab[0]=='30' && $mois == $tab[1]) 
				$checked1='checked';
			if($tab[0]=='90' && $mois == $tab[1]) $checked2='checked';
			$select.= ' <tr><td>'.$mois.' </td> <td><input type="radio" onclick="this.form.submit();" name="cmanbmois" value="30/'.$mois.'/'.$montant.'"  '.$checked1.'></td>
			<td><input type="text" name="montant" readonly value="'.price($montant,0,'',2,2,2).'"></td>';
			$select.= '<td bgcolor="grey">&nbsp;</td><td>'.$mois.' :</td><td><input type="radio" onclick="this.form.submit();" name="cmanbmois" value="90/'.$mois.'/'.$montant90.'"  '.$checked2.'> </td>
			<td><input type="text" name="montant" readonly value="'.price($montant90,0,'',2,2,2).'"></td></tr>';
		}
		
		$htm.='<tr class="oddeven"><td>Mensualité : </td><td colspan=4>Report 30 jours</td><td>Mensuialité: </td><td colspan=4>Report 90 jours</td></tr>
		'.$select.'';
		$htm.= '
		</td></tr>';
		$htm.='</table></div>';
		print $htm;
	}
	if($_SESSION['financement']['type']=='perso')
		print'<div id="perso" style="display: bloc;">';
	else 
		print'<div id="perso" style="display: none;">';
	print '<table class="border ">';
	
	$selectchq='<select name="personbch" onchange="this.form.submit();" >';
	for ($i=0; $i<=4;$i++){
		$selectchq.='<option value='.$i.' >'.$i.'</option>';
	}
	$selectchq.='</select>'; 
	$selectprelev='<select name="personbprelev" onchange="this.form.submit();" >';
	for ($i=0; $i<=10;$i++){
		$selectprelev.='<option value='.$i.'>'.$i.'</option>';
	}
	$selectprelev.='</select>';
	
	$htm = '<tr><td>&nbsp;</td></tr><tr class="oddeven"><td> Règlement par: </td>
	<td>cheque :  Nombre de cheques: '.$selectchq.'<br>
	-25% signature<br>
	-25% conformité technique<br>
	-25% à la livraison<br>
	-25% solde<br><br>

	<b>Si un chèque :</b> 100% à la conformité technique<br>
	<b>Si 2 chèques :</b> 50% à la conformité technique / 50% au solde<br>
	<b>Si 3 chèques :</b> 1/3 à la signature, 1/3 à la livraison, 1/3 au solde.<br><br>

	<b>prelevement :</b> Nombre de prélévements: '.$selectprelev.'<br> Début des prélèvements à la conformité technique<br><br>';
	
	$htm.='<b>Banque :</b> (50% à la commande/ 45% livraison /5% PV fin de chantier : <input type="radio"  onclick="this.form.submit();" name="persobanque"  value="banque" ><br>
	</td></tr>';
	$htm.='</table></div>';
	print $htm;
	
	if($_SESSION['financement']['type'])
		print'<div id="reglement" style="display: bloc;">';
	else
		print'<div id="reglement" style="display: none;">';
	{
		print '<table class="border ">';
		$htm='';
		if($_SESSION['financement']['stype']['cma']>0){
			$htm.='<tr class="amountremaintopay"><td> Règlement par CMA en '.$_SESSION['financement']['stype']['mensualite'].' fois </td>
			<td> Echéance CMA:'.price($_SESSION['financement']['stype']['cmamontant'],0,'',1,2,2).'<br>
			</tr>';
		}
		if($_SESSION['financement']['stype']['ch']>0){
			$rac=($_SESSION['financement']['total']-$_SESSION['financement']['acompte'])/$_SESSION['financement']['stype']['ch'];
			$htm.='<tr class="amountremaintopay"><td> Règlement par chq en '.$_SESSION['financement']['stype']['ch'].' fois </td>
			<td> Montant de chaque chèque si EDF: '.price($rac,0,'',1,2,2).'</td></tr>';
		}
		if($_SESSION['financement']['stype']['pre']>0){
			$racedf=($_SESSION['financement']['total']-$_SESSION['financement']['acompte'])/$_SESSION['financement']['stype']['pre'];
			$racmpr=($_SESSION['financement']['total']-$_SESSION['financement']['acompte'])/$_SESSION['financement']['stype']['pre'];
			$htm.='<tr class="amountremaintopay"><td> règlement par prélèvement en '.$_SESSION['financement']['stype']['pre'].' fois </td>
			<td> Montant de chaque prélevement si EDF: '.price($racedf,0,'',1,2,2).'<br>Montant de chaque chèque si eligible MPR: '.price($racmpr,0,'',1,2,2).'</td></tr>';
		}
		if($_SESSION['financement']['stype']['persobanque'] !=''){
			$htm.='<tr class="amountremaintopay"><td> Règlement par virement bancaire :  </td>
			<td>-Commande= '.price($_SESSION['financement']['totaledf']*0.4,0,'',1,2,2).' <br> -Livraison sur chantier '.price($_SESSION['financement']['totaledf']*0.4,0,'',1,2,2).' <br>
			-Fin de chantier: '.price($_SESSION['financement']['totaledf']*0.2,0,'',1,2,2).' </td></tr>';
			$htm.='<tr class="amountremaintopay"><td> Règlement par virement bancaire si ELIGIBLE MPR:  </td>
			<td>-Commande= '.price($_SESSION['financement']['totalmpr']*0.4,0,'',1,2,2).' <br> -Livraison sur chantier '.price($_SESSION['financement']['totalmpr']*0.4,0,'',1,2,2).' <br>
			-Fin de chantier: '.price($_SESSION['financement']['totalmpr']*0.2,0,'',1,2,2).' </td></tr>';
		}
	}
	$htm.='<tr class="amountremaintopay"><td> <input class="button" type="submit" name="valid_financement" value="Création devis"><input class="button" type="submit" name="reset_financement" value="Re-init Financement"></td></tr>';
	$htm.='</table></div>';
	print $htm;

}

// Part to edit record
if (($id || $ref) && $action == 'edit')
{
	print load_fiche_titre($langs->trans("Devis toiture définitif"));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
    print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="update">';
	print '<input type="hidden" name="id" value="'.$object->id.'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	//dol_fiche_head();
	print '<table class="border centpercent tableforfieldedit" ><tr><td>';
	print '<table class="border centpercent tableforfieldedit">'."\n";

	// Common attributes
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/tpl_toitdef/commonfields_edit.tpl.php',1);

	// Other attributes
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_edit.tpl.php';

	print '</table>';
	print '</td><td><table class="border centpercent tableforfieldedit">';
	print '<tr><td class="titlefieldcreate fieldrequired" colspan=2>Primes Devis</td></tr>';
	$usergroup=new UserGroup($db);
	$tab_group=$usergroup->listGroupsForUser($user->id);
	$commercial=false;
	if(!in_array(1,array_keys($tab_group))){
		print '<tr><td class="titlefieldcreate fieldrequired" colspan=2>Primes Devis</td></tr>';
		foreach ($object->primes as $prime){
			print '<tr>
			<td class="soixantepercent">'.$prime->label.'</td><td><input  type="text" name="prime['.$prime->id.']" value="'.$prime->total_ht.'"></td>
			</tr>';
		}
	}

	print'</table></td>
	</tr></table>';
	dol_fiche_end();

	print '<div class="center"><input type="submit" class="button" name="save" value="'.$langs->trans("Save").'">';
	print ' &nbsp; <input type="submit" class="button" name="cancel" value="'.$langs->trans("Cancel").'">';
	print '</div>';

	print '</form>';
}

// Part to show record
if ($object->id > 0 && (empty($action) || ($action != 'edit' && $action != 'create')))
{
    $res = $object->fetch_optionals();

	$head = toitdefPrepareHead($object);
	dol_fiche_head($head, 'card', $langs->trans("Devis toiture définitif"), -1, $object->picto);

	$formconfirm = '';

	// Confirmation to delete
	if ($action == 'delete')
	{
	    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('Deleterep'), $langs->trans('ConfirmDeleteObject'), 'confirm_delete', '', 0, 1);
	}
	// Confirmation to delete line
	if ($action == 'deleteline')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&lineid='.$lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deleteline', '', 0, 1);
	}
	// Clone confirmation
	if ($action == 'clone') {
		// Create an array for form
		$formquestion = array();
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('ToClone'), $langs->trans('ConfirmClonerep', $object->ref), 'confirm_clone', $formquestion, 'yes', 1);
	}
	elseif ($action == 'ask_deleteline') {
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&lineid='.$lineid, $langs->trans('DeleteProductLine'), $langs->trans('ConfirmDeleteProductLine'), 'confirm_deleteline', '', 0, 1);
	}
	// Confirmation of action xxxx
	if ($action == 'xxx')
	{
		$formquestion = array();
	    /*
		$forcecombo=0;
		if ($conf->browser->name == 'ie') $forcecombo = 1;	// There is a bug in IE10 that make combo inside popup crazy
	    $formquestion = array(
	        // 'text' => $langs->trans("ConfirmClone"),
	        // array('type' => 'checkbox', 'name' => 'clone_content', 'label' => $langs->trans("CloneMainAttributes"), 'value' => 1),
	        // array('type' => 'checkbox', 'name' => 'update_prices', 'label' => $langs->trans("PuttingPricesUpToDate"), 'value' => 1),
	        // array('type' => 'other',    'name' => 'idwarehouse',   'label' => $langs->trans("SelectWarehouseForStockDecrease"), 'value' => $formproduct->selectWarehouses(GETPOST('idwarehouse')?GETPOST('idwarehouse'):'ifone', 'idwarehouse', '', 1, 0, 0, '', 0, $forcecombo))
        );
	    */
	    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('XXX'), $text, 'confirm_xxx', $formquestion, 0, 1, 220);
	}

	// Call Hook formConfirm
	$parameters = array('formConfirm' => $formconfirm, 'lineid' => $lineid);
	$reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $formconfirm .= $hookmanager->resPrint;
	elseif ($reshook > 0) $formconfirm = $hookmanager->resPrint;

	// Print form confirm
	print $formconfirm;


	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="'.dol_buildpath('/deviscara/toit_list.php', 1).'?restore_lastsearch_values=1'.(!empty($socid) ? '&socid='.$socid : '').'">'.$langs->trans("BackToList").'</a>';

	$morehtmlref = '<div class="refidno">';

	$morehtmlref .= '</div>';


	print'<div class="inline-block floatleft valignmiddle refid">'.$object->ref.'</div>';


	print '<div class="fichecenter">';
	print '<div class="fichehalfleft">';
	print '<div class="underbanner clearboth"></div>';
	print '<table class="border centpercent">'."\n";

	// Common attributes
	//$keyforbreak='fieldkeytoswitchonsecondcolumn';	// We change column just after this field
	//unset($object->fields['fk_project']);				// Hide field already shown in banner
	//unset($object->fields['fk_soc']);					// Hide field already shown in banner
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/tpl_toitdef/commonfields_view.tpl.php',1);
	// Other attributes. Fields from hook formObjectOptions and Extrafields.
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_view.tpl.php';

	print '</table>';
	print '</div>';
	print '</div>';

	print '<div class="clearboth"></div>';

	dol_fiche_end();


	/*
	 * Lines
	 */

	if (!empty($object->table_element_line))
	{
    	// Show object lines
    	$result = $object->getLinesArray();

    	print '	<form name="addproduct" id="addproduct" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.(($action != 'editline') ? '#addline' : '#line_'.GETPOST('lineid', 'int')).'" method="POST">
    	<input type="hidden" name="token" value="' . $_SESSION ['newtoken'].'">
    	<input type="hidden" name="action" value="' . (($action != 'editline') ? 'addline' : 'updateline').'">
    	<input type="hidden" name="mode" value="">
    	<input type="hidden" name="id" value="' . $object->id.'">
    	';

    	if (!empty($conf->use_javascript_ajax)) {
    	    include DOL_DOCUMENT_ROOT.'/core/tpl/ajaxrow.tpl.php';
    	}

    	print '<div class="div-table-responsive-no-min">';
    	if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline'))
    	{
    	    print '<table id="tablelines" class="noborder noshadow" width="100%">';
    	}

    	if (!empty($object->lines))
    	{
    		$object->printObjectLines($action, $mysoc, null, GETPOST('lineid', 'int'), 1);
    	}

    	// Form to add new line
    	if ( $permissiontoadd && $action != 'selectlines')
    	{
    	    if ($action != 'editline')
    	    {
    	        // Add products/services form
    	        $object->formAddObjectLine(1, $mysoc, $soc);

    	        $parameters = array();
    	        $reshook = $hookmanager->executeHooks('formAddObjectLine', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    	    }
    	}

    	if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline'))
    	{
    	    print '</table>';
    	}
    	print '</div>';

    	print "</form>\n";
	}


	// Buttons for actions

	if ($action != 'presend' && $action != 'editline') {
    	print '<div class="tabsAction">'."\n";
    	$parameters = array();
    	$reshook = $hookmanager->executeHooks('addMoreActionsButtons', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    	if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

    	if (empty($reshook))
    	{	// Facturation
			 // Send
			 print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=presend&mode=init#formmailbeforetitle">'.$langs->trans('SendMail').'</a>'."\n";
			
			if ($permissiontoadd){
				print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=facturer">'.$langs->trans('Créer facture').'</a>'."\n";
			}
            if ($permissiontoadd){
                print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=factureracompte">'.$langs->trans('Créer facture acompte').'</a>'."\n";
            }
            // Back to draft
            if ($object->status == $object::STATUS_VALIDATED)
            {
	            if ($permissiontoadd)
	            {
	            	print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=confirm_setdraft&confirm=yes">'.$langs->trans("SetToDraft").'</a>';
	            }
            }

            // Modify
            if ($permissiontoadd)
    		{
    			print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=edit">'.$langs->trans("Modify").'</a>'."\n";
    		}
    		else
    		{
    			print '<a class="butActionRefused classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans('Modify').'</a>'."\n";
    		}

    		// Validate
    		if ($object->status == $object::STATUS_DRAFT)
    		{
	    		if ($permissiontoadd)
	    		{
	    			if (empty($object->table_element_line) || (is_array($object->lines) && count($object->lines) > 0))
	    			{
	    				print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=confirm_validate&confirm=yes">'.$langs->trans("Validate").'</a>';
	    			}
	    			else
	    			{
	    				$langs->load("errors");
	    				print '<a class="butActionRefused" href="" title="'.$langs->trans("ErrorAddAtLeastOneLineFirst").'">'.$langs->trans("Validate").'</a>';
	    			}
	    		}
    		}

    		// Clone
    		if ($permissiontoadd)
    		{
    			print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&socid='.$object->socid.'&action=clone&object=iso1">'.$langs->trans("ToClone").'</a>'."\n";
    		}

    		/*
    		if ($permissiontoadd)
    		{
    			if ($object->status == $object::STATUS_ENABLED)
    		 	{
    		 		print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=disable">'.$langs->trans("Disable").'</a>'."\n";
    		 	}
    		 	else
    		 	{
    		 		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=enable">'.$langs->trans("Enable").'</a>'."\n";
    		 	}
    		}
    		if ($permissiontoadd)
    		{
    			if ($object->status == $object::STATUS_VALIDATED)
    		 	{
    		 		print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=close">'.$langs->trans("Cancel").'</a>'."\n";
    		 	}
    		 	else
    		 	{
    		 		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=reopen">'.$langs->trans("Re-Open").'</a>'."\n";
    		 	}
    		}
    		*/

    		// Delete (need delete permission, or if draft, just need create/modify permission)
    		if ($permissiontodelete)
    		{
    			print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=delete">'.$langs->trans('Delete').'</a>'."\n";
    		}
    		else
    		{
    			print '<a class="butActionRefused classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans('Delete').'</a>'."\n";
    		}
			
    	}
    	print '</div>'."\n";
	}


	// Select mail models is same action as presend
	if (GETPOST('modelselected')) {
		$action = 'presend';
	}

	if ($action != 'presend')
	{
	    print '<div class="fichecenter"><div class="fichehalfleft">';
	    print '<a name="builddoc"></a>'; // ancre

	    //Documents
	    $objref = dol_sanitizeFileName($object->ref);
	    $relativepath = $objref . '/' . $objref . '.pdf';
	    $filedir = $conf->deviscara->dir_output . '/' . $objref;
	    $urlsource = $_SERVER["PHP_SELF"] . "?id=" . $object->id;
	    $genallowed = $user->rights->deviscara->rep->read;	// If you can read, you can build the PDF to read content
	    $delallowed = $user->rights->deviscara->rep->create;	// If you can create/edit, you can remove a file on card
	    $object->modelpdf='soleilsign';
		print $formfile->showdocuments('deviscara', $objref, $filedir, $urlsource, $genallowed, $delallowed, $object->modelpdf, 1, 0, 0, 28, 0, '', '', '', $langs->defaultlang);
		

	    // Show links to link elements
	    $linktoelem = $form->showLinkToObjectBlock($object, null, array('rep'));
	    $somethingshown = $form->showLinkedObjectBlock($object, $linktoelem);


	    print '</div><div class="fichehalfright"><div class="ficheaddleft">';

	    $MAXEVENT = 10;

	    $morehtmlright = '<a href="'.dol_buildpath('/deviscara/rep_agenda.php', 1).'?id='.$object->id.'">';
	    $morehtmlright .= $langs->trans("SeeAll");
	    $morehtmlright .= '</a>';

	    // List of actions on element
	    include_once DOL_DOCUMENT_ROOT.'/core/class/html.formactions.class.php';
	    $formactions = new FormActions($db);
	    $somethingshown = $formactions->showactions($object, $object->element, (is_object($object->thirdparty) ? $object->thirdparty->id : 0), 1, '', $MAXEVENT, '', $morehtmlright);

	    print '</div></div></div>';
	}

	//Select mail models is same action as presend
	// Presend form
	$modelmail='dev';
	$defaulttopic='InformationMessage';
	$diroutput = $conf->deviscara->dir_output;
	$trackid = 'toitdef'.$object->id;
	$object->modelpdf='soleilsign';
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/core/tpl_toit/card_presend.tpl.php', 1); //'/core/tpl/card_presend.tpl.php';
}

// End of page
llxFooter();
$db->close();
