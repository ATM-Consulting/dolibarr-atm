<?php


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
include_once DOL_DOCUMENT_ROOT . dol_buildpath("deviscara/class/toit.class.php", 1);

// Load translation files required by the page
$langs->loadLangs(array("mymodule@mymodule", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'myobjectcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$type=      GETPOST('type','int');
$fk_object = GETPOST('fk_object');


$docs=GETPOST('doc');

// Initialize technical objects
$object = new toit($db);
$extrafields = new ExtraFields($db);

$object->fetch($fk_object);

//$diroutputmassaction = $conf->mymodule->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('myobjectcard', 'globalcard')); // Note that conf->hooks_modules contains array

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

$form = new Form($db);
$formfile = new FormFile($db);

/*
 * Actions
 */

 if($action=='docmanquant'){
    $object->array_liste_pieces='';
    foreach ($docs as $iddoc=>$lab){
        $object->array_liste_pieces .= $iddoc.'|';
    }
    //mise à jour du status_piecesmanquantes
    $status_piecesmanquantes_avantmaj=$object->status_piecesmanquantes;
    $newstatuspm=GETPOST('status_piecesmanquantes');
    if($status_piecesmanquantes_avantmaj != $newstatuspm && $newstatuspm!=''){
		$object->{'date_statuspm_'.$newstatuspm} = dol_now(); //date de changement de statut
		$object->date_statuspm_encours = dol_now();
	}
    $object->status_piecesmanquantes=GETPOST('status_piecesmanquantes');
    $object->date_statusactionpm_encours=$db->idate(dol_mktime(12,0,0,GETPOST('date_statusactionpm_encoursmonth'),GETPOST('date_statusactionpm_encoursday'),GETPOST('date_statusactionpm_encoursyear')));
    $object->date_prevuereceptiondoc=$db->idate(dol_mktime(12,0,0,GETPOST('date_prevuereceptiondocmonth'),GETPOST('date_prevuereceptiondocday'),GETPOST('date_prevuereceptiondocyear')));
    $object->commentaire_piecemanquantes=GETPOST('commentaire_piecemanquantes');
    $object->action_piecesmanquantes=GETPOST('action_piecesmanquantes');
    $object->update($user);
    if($backtopage=='gestionchamp'){
        $urltogo = dol_buildpath('deviscara/toit_card_modifchamps.php',1).'?id='.$fk_object;
    }
    else
        $urltogo = dol_buildpath('deviscara/toit_list.php',1);
	header("Location: ".$urltogo);
	exit;
}


/*
 * View
 *
 * Put here all code to build page
 */







llxHeader('', $langs->trans('Liste des documents manquants '), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">

</script>';
if ($formconfirm)
    print $formconfirm;
//affichage par défaut

print load_fiche_titre($langs->trans("Liste des Documents pour ".GETPOST('object_ref').""));

print '<form method="POST" id="docmanquant" action="'.$_SERVER["PHP_SELF"].'" >';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="famille" value="'. GETPOST('famille','int') .'">';
print '<input type="hidden" name="action" value="docmanquant">';
print '<input type="hidden" name="type" value="'. $type .'">';
print '<input type="hidden" name="fk_object" value="'. $fk_object .'">';
print '<input type="hidden" name="backtopage" value="'. $backtopage.'">';
print '<div class="fiche"><table class="border centpercent tableforfieldcreate" border=0>'."\n";

print'<tr><td class="nowrap" >'.$object->fields['status_piecesmanquantes']['label'].' : </td><td>'.$object->showInputField($object->fields['status_piecesmanquantes'], 'status_piecesmanquantes', $object->status_piecesmanquantes, '', '', '', 0,'maxwidth5').'</td></tr>';
print'<tr><td class="nowrap" >'.$object->fields['commentaire_piecemanquantes']['label'].' : </td><td>'.$object->showInputField($object->fields['commentaire_piecemanquantes'], 'commentaire_piecemanquantes', $object->commentaire_piecemanquantes, '', '', '', 0,'maxwidth5').'</td></tr>';
print'<tr><td class="nowrap" >'.$object->fields['action_piecesmanquantes']['label'].' : </td><td>'.$object->showInputField($object->fields['action_piecesmanquantes'], 'action_piecesmanquantes', $object->action_piecesmanquantes, '', '', '', 0,'maxwidth5').'</td></tr>';
print'<tr><td class="nowrap" >'.$object->fields['date_statusactionpm_encours']['label'].' : </td><td>'.$object->showInputField($object->fields['date_statusactionpm_encours'], 'date_statusactionpm_encours', $object->date_statusactionpm_encours, '', '', '', 0,'maxwidth5').'</td></tr>';
print'<tr><td class="nowrap" >'.$object->fields['date_prevuereceptiondoc']['label'].' : </td><td>'.$object->showInputField($object->fields['date_prevuereceptiondoc'], 'date_prevuereceptiondoc', $object->date_prevuereceptiondoc, '', '', '', 0,'maxwidth5').'</td></tr>';


print '</table>';
$array_liste_pieces=explode('|',$object->array_liste_pieces);
foreach ($object::groupe_famille as $lib_groupe=>$familles){

    print '<div class="fiche"><table class="border centpercent tableforfieldcreate" border=0>'."\n";
   
    $j=0;
    foreach ($familles as $id_famille=>$famille){
        $bool_green=false;
        print'<td>';
        $checked='';
        if (in_array($id_famille,$array_liste_pieces)) $checked=' checked ';
        print'<input type="checkbox" name="doc['.$id_famille.']" value='.$famille.' '.$checked.'>'.$famille.'';
        
        if(($j%2)==1)
            print '</tr><tr>';
        $j++;
        print '</td>';
        
    }
    print '</tr>';
    print '</table></div>';
}
print '<input class="button" type="submit" value="valider" >';
print '</form>';

dol_fiche_head(array(), '');











// End of page
llxFooter();
$db->close();
