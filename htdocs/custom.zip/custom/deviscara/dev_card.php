<?php
/* Copyright (C) 2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       dev_card.php
 *		\ingroup    deviscara
 *		\brief      Page to create/edit/view dev
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB','1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER','1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC','1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN','1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION','1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION','1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK','1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL','1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK','1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU','1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML','1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX','1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN",'1');						// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK','1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT','auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE','aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN',1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP','none');					// Disable all Content Security Policies


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/product/class/product.class.php');
dol_include_once('/deviscara/class/dev.class.php');
dol_include_once('/deviscara/lib/deviscara_dev.lib.php');
dol_include_once('/societe/class/societe.class.php');

// Load translation files required by the page
$langs->loadLangs(array("deviscara@deviscara", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'devcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');

//$lineid   = GETPOST('lineid', 'int');

// Initialize technical objects
$object = new dev($db);
$extrafields = new ExtraFields($db);

$object_soc=new societe($db);
$extrafields_soc = new ExtraFields($db);
$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);

$diroutputmassaction = $conf->deviscara->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('devcard', 'globalcard')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->statut == $object::STATUS_DRAFT) ? 1 : 0);
//$result = restrictedArea($user, 'deviscara', $object->id, '', '', 'fk_soc', 'rowid', $isdraft);

$permissiontoread = $user->rights->deviscara->dev->read;
$permissiontoadd = $user->rights->deviscara->dev->write; // Used by the include of actions_addupdatedelete.inc.php and actions_lineupdown.inc.php
$permissiontodelete = $user->rights->deviscara->dev->delete || ($permissiontoadd && isset($object->status) && $object->status == $object::STATUS_DRAFT);
$permissionnote = $user->rights->deviscara->dev->write; // Used by the include of actions_setnotes.inc.php
$permissiondellink = $user->rights->deviscara->dev->write; // Used by the include of actions_dellink.inc.php
$upload_dir = $conf->deviscara->multidir_output[isset($object->entity) ? $object->entity : 1];


/*
 * Actions
 */

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook))
{
    $error = 0;

    $backurlforlist = dol_buildpath('/deviscara/dev_list.php', 1);

    if (empty($backtopage) || ($cancel && empty($id))) {
    	if (empty($backtopage) || ($cancel && strpos($backtopage, '__ID__'))) {
    		if (empty($id) && (($action != 'add' && $action != 'create') || $cancel)) $backtopage = $backurlforlist;
    		else $backtopage = dol_buildpath('/deviscara/dev_card.php', 1).'?id='.($id > 0 ? $id : '__ID__');
    	}
    }
    $triggermodname = 'DEVISCARA_DEV_MODIFY'; // Name of trigger action code to execute when we modify record

    // Actions cancel, add, update, update_extras, confirm_validate, confirm_delete, confirm_deleteline, confirm_clone, confirm_close, confirm_setdraft, confirm_reopen
    include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/actions_addupdatedelete.inc.php',1);

    // Actions when linking object each other
    include DOL_DOCUMENT_ROOT.'/core/actions_dellink.inc.php';

    // Actions when printing a doc from card
    include DOL_DOCUMENT_ROOT.'/core/actions_printing.inc.php';

    // Action to move up and down lines of object
    //include DOL_DOCUMENT_ROOT.'/core/actions_lineupdown.inc.php';

    // Action to build doc
    include DOL_DOCUMENT_ROOT.'/core/actions_builddoc.inc.php';

    if ($action == 'set_thirdparty' && $permissiontoadd)
    {
    	$object->setValueFrom('fk_soc', GETPOST('fk_soc', 'int'), '', '', 'date', '', $user, 'DEV_MODIFY');
    }
    if ($action == 'classin' && $permissiontoadd)
    {
    	$object->setProject(GETPOST('projectid', 'int'));
    }

    // Actions to send emails
    $triggersendname = 'DEV_SENTBYMAIL';
    $autocopy = 'MAIN_MAIL_AUTOCOPY_DEV_TO';
    $trackid = 'dev'.$object->id;
    include DOL_DOCUMENT_ROOT.'/core/actions_sendmails.inc.php';

	if(GETPOST('err')=='pv_loc_impossible'){
		setEventMessages('PV: Location impossible', '' , 'errors');
	}
}




/*
 * View
 *
 * Put here all code to build page
 */

$form = new Form($db);
$formfile = new FormFile($db);

llxHeader('', $langs->trans('dev'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});

function ajouterces() {
	document.getElementById("buttonsces").style.display="block";	
}
function affichproduit(idprod) {
	
	for(i=0;i<=19;i++){
		document.getElementById("idprod"+i).style.display="none";
	}
	document.getElementById("buttonstoiture").style.display="none";
	document.getElementById("idprod"+idprod).style.display="block";
	if(idprod==5){
		if(document.getElementById("metragecharpente").value==""){
			document.getElementById("metragecharpente").value=document.getElementById("metrage").value;
		}
		if(document.getElementById("metragefauxplafond").value==""){
			document.getElementById("metragefauxplafond").value=document.getElementById("metrage").value;
		}
		
	}
	if(idprod==0){
		//affichage zone pour la saisie informations parts
		nbpart=document.getElementById("nbpart").value
		if(nbpart>1)
			document.getElementById("saisieparts").style.display="block";
	}
	else
		document.getElementById("saisieparts").style.display="none";
}
function affichbuttonstoiture(){
	document.getElementById("buttonstoiture").style.display="block";
}
function affichzoneclient(){
	document.getElementById("zoneclient").style.display="block";
	window.location.hash="client";
}
function affichzonefinancement(){
	document.getElementById("zonefinancement").style.display="block";
}
function affichreglement(){
	document.getElementById("zonereglement").style.display="block";
	document.getElementById("zonecma").style.display="none";
}
function affichzonecma(){
	document.getElementById("zonecma").style.display="block";
	document.getElementById("zonereglement").style.display="none";
}
function test(champ,toaffich){
	if (champ.value > 0)
		affichproduit(toaffich);
	else alert( champ.name+": valeur >0 obligatoire");
}
</script>';


// Part to create
if ($action == 'create'|| $action=='add')
{
	
	print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("Devis")));

	print '<form method="POST" name="toitbis" action="'.$_SERVER["PHP_SELF"].'#bottom">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="add">';
	print '<input type="hidden" name="fromid" value="'.GETPOST('fromid','int').'">';
	print '<input type="hidden" name="fk_soc" value="'.GETPOST('fk_soc','int').'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');
	print '<div id="iddiv0" style="display: block;"><table class="tableclassic"><tr>';
	print '<td>Ref fiscale : </td><td><input type="text" name="rfr" value='.($_SESSION["rfr"]>0?$_SESSION["rfr"]:"").'></td>';
	print '</tr><tr>';
	print '<td>nb personnes :</td><td> 
	<select name="nbpart" id="nbpart">';
	for ($i=1;$i<=10;$i++){
		if ($_SESSION["nbpart"]==$i)
			$selected='selected';
		else $selected='';
		print '<option value="'.$i.'" '.$selected.'>'.$i.'</option>';
	}
	//affichage suivant en fonctin du produit
	if($_SESSION['produit']=='toiture')
		$onclick='affichproduit(1);';
	elseif($_SESSION['produit']=='ces')
		$onclick='affichproduit(2);';
	elseif($_SESSION['produit']=='iso')
		$onclick='affichproduit(3);';
	print'</select>';
	print '</td></tr><tr><td> </td></tr>
	<tr><td></td><td><input class="demo2 demo" type="radio"  name="status_immo"  id="demo2-a"  onclick="'.$onclick.'" value="1" '.($_SESSION["status_immo"]=="1"?"checked":"").'><label for="demo2-a">Proprietaire</label><br></td></tr>
	<tr><td></td><td><input class="demo2 demo"  type="radio" id="demo2-b" name="status_immo"  onclick="'.$onclick.'" value="2" '.($_SESSION["status_immo"]=="2"?"checked":"").'><label for="demo2-b">Locataire</label></td></tr></td></tr>
	</table></div>';

	 print '<div id="idprod0" style="display: none;" >';
	// print'<table class="centpercent " bgcolor="lightgrey" ><tr><td> </td></tr></table>';
	// print'<table ><tr>';
	// print '<tr><td>Choix des produits</td></tr><tr>
	// 	<td>Produits : </td><td>
	// 	<input class="demo2 demo" type="radio" name="produit" id="toiture" onclick="affichproduit(1);" value="toiture" '.($_SESSION["produit"]=="toiture"?"checked":"").'> <label for="toiture">Toiture</label><br><br>
	// 	<input class="demo2 demo" type="radio"  name="produit" id="ces" onclick="affichproduit(2);" value="ces" '.($_SESSION["produit"]=="ces"?"checked":"").'> <label for="ces" >CES</label><br><br>
	// 	<input class="demo2 demo" type="radio"  name="produit" id="iso" onclick="affichproduit(3);" value="iso" '.($_SESSION["produit"]=="iso"?"checked":"").'> <label for="iso">ISO</label><br><br>
	// 	';
		
	// print '</td><td class="center valignmiddle" width="60px"><!-- Message to show:  -->
	// <a class="reposition" href="javascript:affichproduit(2);"></a>
	// </td></tr></table>
	print '</div>';
	// //idprod1
	
		print '<div id="idprod1" class="idprod1">';
	print'<table ><tr>';
	print '<td>Surface toiture</td><td>
		<input type="text" name="metrage" id="metrage"  value='.($_SESSION['toiture']["metrage"]>0?$_SESSION['toiture']["metrage"]:"").'>';
	print '</td><td><input type="button" class="button" value="valider" onclick="test(metrage,5);"></td></tr>
	</table></div>';

	print '<div id="idprod3" style="display: none; ">';
	print'<table class="tableclassic" ><tr>';
	print '<td>Surface: </td><td><input type="text" name="metrageiso" id="metrageiso"  value='.($_SESSION['iso']["metrage"]>0?$_SESSION['iso']["metrage"]:"").'> M2</td></tr>
	<tr><td colspan=2><input class="button" type="submit" name="valider" value="valider" ></td></tr>
	</table></div>';
	print '<div id="idprod4" style="display: none; ">';//doit rester car il y a le js(c'est un reste pour le rep)
	print'<table class="tableclassic"><tr>';
	print '</td></tr></table></div>';
	
	
	print '<div id="idprod5" class="idprod5">';
	print'<table class="tableclassic" border=1><tr>';
	print '<td>Combles déjà isolées ?</td>
	<td><input class="demo2 demo" type="radio" name="isocomble" id="isocombleoui"  onclick="affichproduit(15);" value="oui" '.($_SESSION['toiture']["isocomble"]=="oui"?"checked":"").'> <label for="isocombleoui">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="isocomble" id="isocomblenon"  onclick="affichproduit(15);" value="non" '.($_SESSION['toiture']["isocomble"]=="non"?"checked":"").'> <label for="isocomblenon" >Non</label><br></td></tr>';
	print '</table></div>';

	print '<div id="idprod15" class="idprod15">';
	print'<table class="tableclassic" border=1>';
	print '<tr><td>Type de tôles </td>
	<td><input class="demo2 demo" type="radio" name="typetole" id="typetolea"  onclick="affichproduit(9);" value="toleG10" '.($_SESSION['toiture']["typetole"]=="toleG10"?"checked":"").'> <label for="typetolea">Tole Standard</label><br><br>
	<input class="demo2 demo" type="radio" name="typetole" id="typetoleb" onclick="affichproduit(9);" value="toleG20" '.($_SESSION['toiture']["typetole"]=="toleG20"?"checked":"").'> <label for="typetoleb">Tole Protector</label><br>
	</td></tr>';
	print '</table></div>';

	print '<div id="idprod9" class="idprod9">';
	print'<table class="tableclassic">';
	print '<tr><td>Charpente </td>
	<td><input class="demo2 demo" type="radio" name="charpente" id="charpentea" onclick="affichproduit(7);" value="oui" '.($_SESSION['toiture']["charpente"]=="oui"?"checked":"").'> <label for="charpentea">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="charpente" id="charpenteb" onclick="affichproduit(13);" value="non" '.($_SESSION['toiture']["charpente"]=="non"?"checked":"").'> <label for="charpenteb">Non</label><br>
	</td></tr>';
	print '</table></div>';
	
	
	
	print '<div id="idprod7" class="idprod7">';
	print'<table class="tableclassic"><tr>';
	print'<td>Charpente : </td>';
	$valuecharp=($_SESSION[$_SESSION["produit"]]['metragecharpente']>0?$_SESSION[$_SESSION["produit"]]['metragecharpente']:$_SESSION[$_SESSION["produit"]]['metragecharpente']);
	print'<td>M2 </td><td><input type="text" id="metragecharpente"   name="metragecharpente" value="'.$valuecharp.'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragecharpente,16);"></td>';
	print'</table></div>';

	print '<div id="idprod16" class="idprod16">';
	print'<table class="tableclassic"><tr>';
	print'<td><input class="demo2 demo" type="radio" name="type_primech" id="typech1" onclick="affichproduit(13);" value="charpentestd" '.($_SESSION['toiture']["type_primech"]=="charpentestd"?"checked":"").'><label for="typech1">Changement de Charpente (99€/m2)</label><br><br>
	<input class="demo2 demo" type="radio" id="typech2" name="type_primech" onclick="affichproduit(13);"  value="empannage" '.($_SESSION['toiture']["type_primech"]=="empannage"?"checked":"").'><label for="typech2">Changement de panne (29.90€/m2)</label><br><br>
	<input class="demo2 demo" type="radio" id="typech3" name="type_primech" onclick="affichproduit(13);"  value="liteunage" '.($_SESSION['toiture']["type_primech"]=="liteunage"?"checked":"").'><label for="typech3">Changement de Liteaux (19.90€/m2)</label></td>';
	print '</tr>';
	print'</table></div>';

	print '<div id="idprod13" class="idprod13">';
	print'<table class="tableclassic">';
	print '<tr><td>Faux Plafond </td>
	<td><input class="demo2 demo" type="radio" id="fauxplafond1" name="fauxplafond"  onclick="affichproduit(11);" value="oui" '.($_SESSION['toiture']["charpente"]=="oui"?"checked":"").'> <label for="fauxplafond1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" id="fauxplafond2" name="fauxplafond"  onclick="affichproduit(14);" value="non" '.($_SESSION['toiture']["charpente"]=="non"?"checked":"").'> <label for="fauxplafond2">Non</label><br>
	</td></tr>';
	print '</table></div>';
	
	print '<div id="idprod11" class="idprod11">';
	print'<table class="tableclassic"><tr>';
	print '<td>Faux Plafond: </td>';
	print'<td>Metrage Faux plafond</td><td><input type="text" id="metragefauxplafond"  name="metragefauxplafond" value="'.$_SESSION[$_SESSION["produit"]]['metragefauxplafond'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragefauxplafond,17);"></td>';
	print'</table></div>';
	print '<div id="idprod17" class="idprod17">';
	print'<table class="tableclassic"><tr>';
	print '<td><input class="demo2 demo" type="radio" onclick="affichproduit(14);" name="type_primefp" id="typefp1" value="fpaparente" '.($_SESSION['toiture']["type_primefp"]=="fpaparente"?"checked":"").'><label for="typefp1">FP Charpente apparente (49.90 €/m2)</label><br><br>
	<input class="demo2 demo" type="radio" onclick="affichproduit(14);" id="typefp2" name="type_primefp"  value="fprampante" '.($_SESSION['toiture']["type_primefp"]=="fprampante"?"checked":"").'><label for="typefp2">FP Charpente rampante (59.90€/m2)</label><br><br>
	<input class="demo2 demo" type="radio" onclick="affichproduit(14);" id="typefp3"  name="type_primefp"  value="fpossature" '.($_SESSION['toiture']["type_primefp"]=="fpossature"?"checked":"").'><label for="typefp3">FP droit avec ossature (89.90€/m2)</label></td>
	</tr>';
	print'</table></div>';
	print '<div id="idprod14" class="idprod14">';
	print'<table class="tableclassic">';
	print '<tr><td>Chenaux</td>
	<td><input class="demo2 demo" type="radio" name="chenaux"  id="chenaux1"  onclick="affichproduit(12);" value="oui" '.($_SESSION['toiture']["charpente"]=="oui"?"checked":"").'> <label for="chenaux1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="chenaux"  id="chenaux2" onclick="affichproduit(10);" value="non" '.($_SESSION['toiture']["charpente"]=="non"?"checked":"").'> <label for="chenaux2">Non</label><br>
	</td></tr>';
	print '</table></div>';
	print '<div id="idprod12" class="idprod12">';
	print'<table class="tableclassic">';
	print '<tr><td>Chenaux: </td>';
	print'<td>ML: </td><td><input type="text" id="metragechenaux" name="metragechenaux" value="'.$_SESSION[$_SESSION["produit"]]['metragechenaux'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragechenaux,18);"></td>';
	print'</table></div>';
	
	print '<div id="idprod18" class="idprod18">';
	print'<table class="tableclassic"><tr>';
	print'<td><input class="demo2 demo" type="radio" onclick="affichproduit(10);" name="type_primechen" id="typechen1"  value="chsupp" '.($_SESSION['toiture']["type_primechen"]=="chsupp"?"checked":"").'><label for="typechen1">Suppression (120€/ml)</label><br><br>
	<input class="demo2 demo"  type="radio" onclick="affichproduit(10);" name="type_primechen"  id="typechen2" value="chetanche" '.($_SESSION['toiture']["type_primechen"]=="chetanche"?"checked":"").'><label for="typechen2">Etancheité (80€/ml)</label><br>
	</tr>';
	print'</table></div>';

	print '<div id="idprod10" class="idprod10">';
	print'<table class="tableclassic">';
	print'<tr><td>Gouttieres </td>
	<td><input class="demo2 demo" type="radio" name="gouttiere" id="gouttiere1"  onclick="affichproduit(8);" value="oui" '.($_SESSION['toiture']["gouttiere"]=="oui"?"checked":"").'> <label for="gouttiere1">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="gouttiere"  id="gouttiere2" onclick="affichbuttonstoiture();" value="non" '.($_SESSION['toiture']["gouttiere"]=="non"?"checked":"").'> <label for="gouttiere2">Non</label><br></td></tr>
	</table></div>';

	
	print '<div id="idprod8" class="idprod8">';
	print'<table class="tableclassic"><tr>';
	print '<td>Gouttières: </td>';
	print'<td>ML:</td><td><input type="text" id="metragegouttieres"  name="metragegouttieres" value="'.$_SESSION[$_SESSION["produit"]]['metragegouttieres'].'"></td><td><input class="button" type="button" name="valider" value="valider" onclick="test(metragegouttieres,19);"></td>
	</table></div>';
	print '<div id="idprod19" class="idprod19">';
	print'<table class="tableclassic"><tr>
	<td><input class="demo2 demo" type="radio" name="type_primegouttiere" id="typegouttiere1" onclick="affichbuttonstoiture();" value="alustandard" '.($_SESSION['toiture']["type_primegouttiere"]=="alustandard"?"checked":"").'><label for="typegouttiere1">Alu standard (25.90€/ml)</label><br><br>
	<input class="demo2 demo" type="radio"  id="typegouttiere2" onclick="affichbuttonstoiture();"  name="type_primegouttiere"  value="alustdplanche" '.($_SESSION['toiture']["type_primegouttiere"]=="alustdplanche"?"checked":"").'><label for="typegouttiere2">Alu Standard + planche de rive (45,90€/ml)</label><br><br>
	</tr>';
	print'</table></div>';
	
		print'<div id="buttonstoiture" style="display: none;">';
	print '<table class="border  tableforfieldedit">
	<tr><td><input type="submit" class="button" name="toiture" value="valider"></td><td><input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>
	</table></div>';

	print '<div id="idprod2" class="idprod2">';
	print'
		<table class="tableclassic"><tr><td>Le Chauffeau</td></tr><tr>';
	print '<td>Choix du volume</td>
	<td><input class="demo2 demo" type="radio" name="vol" id="vol1" onclick="affichproduit(6);" value="200" '.($_SESSION[$_SESSION["produit"]]["vol"]=="200"?"checked":"").'> <label for="vol1">200 L</label><br><br>
	<input class="demo2 demo" type="radio" name="vol"  id="vol2" onclick="affichproduit(6);" value="300" '.($_SESSION[$_SESSION["produit"]]["vol"]=="300"?"checked":"").'> <label for="vol2" >300 L </label><br></td>';
	
	print '</td></tr></table></div>';

	print '<div id="saisieparts" style="display: none;" >';
	print'<table class="tablesaiseparts " bgcolor="lightgrey" >';
	print'<tr>';
	print '<tr><td>Saisie informations parts</td></tr>
	<tr><td><textarea id="idparts" name="idparts" rows="7" cols="75" placeholder="Nom,prenom, date de naissance des parts supplémentaires">'.$_SESSION[$_SESSION["produit"]]["idparts"].'</textarea></td>';
		
	print '</tr></table></div>';

	if($_SESSION[$_SESSION["produit"]]['prime']){
		print '<div id="idprod6" style="display: block;">';
	}
	else 
		print '<div id="idprod6" style="display: none;">';
	print'<table class="tableclassic"><tr>';
	print '<td>PRIMES CES</td>
	<td><input class="demo2 demo" type="radio" id="prime1" name="prime" onclick="ajouterces();"  value="oui" '.($_SESSION[$_SESSION["produit"]]["prime"]=="oui"?"checked":"").'> <label for="prime1">Avec EDF</label><br><br>
	<input class="demo2 demo" type="radio" id="prime2" name="prime" onclick="ajouterces();" value="non" '.($_SESSION[$_SESSION["produit"]]["prime"]=="non"?"checked":"").'> <label for="prime2" >Sans EDF</label><br></td>';
	
	print '</td></tr></table/></div>';
	if($_SESSION['ces'])
		print'<div id="buttonsces" style="display: block;">';
	else
		print'<div id="buttonsces" style="display: none;">';
	print '<table><tr><td><input type="submit" class="button" name="ces" value="valider"></td><td><input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>
	</table></div>';
	if($_SESSION['toiture'] && isset($_SESSION['toiture']['sproduit']))
		print'<div id="buttonscestoiture" style="display: block;">';
	else
		print'<div id="buttonscestoiture" style="display: none;">';
	print '<table><tr><td><input type="submit" class="button" name="cestoiture" value="valider"></td><td><input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>
	</table></div>';


	if($_SESSION['toiture'] && GETPOST('toiture'=='valider')){
		$couleur=get_tarif();
		include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoit.lib.php',1);
		
		if($couleur=='b')
			$bgcolor='lightblue';
		elseif($couleur=='j')
			$bgcolor='yellow';
		elseif($couleur=='v')
			$bgcolor='mediumorchid';
		elseif($couleur=='r')
			$bgcolor='pink';

		print '<div  class="tabBar" >';
		print '<div id="devistoiture" class="fichehalfleft" >';
		print'<table class="noborder soixantepercent"><tr>';
		print '<td bgcolor="'.$bgcolor.'" colspan=4 align="center">Devis toiture</td>';
		$htm = '</tr>';
		$htm = '<tr><td>Libele</td><td>Quantité</td><td>Prix Unitaire TTC</td><td>Montant TTC</td></tr>';
		$htm .= '<tr class="oddeven">';
		
		$htm.='<td>'.$tabtarif['forfait']['pv']['previsite']->ref.'</td><td>1</td><td>'.price($tabtarif['forfait']['pv']['previsite']->price_ttc,0,'',1,2,2).'</td><td>'.price($tabtarif['forfait']['pv']['previsite']->price_ttc,0,'',1,2,2).'</td></tr><tr class="oddeven">';
		$total+=(float)$tabtarif['forfait']['pv']['previsite']->price_ttc;
		$tarif=$tabtarif['pv'];
		$i=0;
		foreach ($tarif as $id=>$product){
			$i++;
			$htm.='<td>'.$product->ref.'</td><td>'.$_SESSION['toiture']['metrage'].'</td><td>'.price($product->price_ttc,0,'',1,2,2).'</td><td>'.price($product->price_ttc*$_SESSION['toiture']['metrage'],0,'',1,2,2).'';
			if($i%2)
				$htm.='</td></tr><tr class="oddeven">';
			else $htm.='</td></tr><tr class="pair">';
			$total+=$product->price_ttc*$_SESSION['toiture']['metrage'];

		}
		
		$htm.='<td>'.$tabtarif['forfait']['pv']['livraison']->ref.'</td><td>1</td><td>'.price($tabtarif['forfait']['pv']['livraison']->price_ttc,0,'',1,2,2).'</td><td>'.price($tabtarif['forfait']['pv']['livraison']->price_ttc,0,'',1,2,2).'</td></tr><tr class="oddeven">';
		$total+=(float)$tabtarif['forfait']['pv']['livraison']->price_ttc;
		if(count($tabtarif['remise'])>0){
			$htm.='<td>'.$tabtarif['remise']->ref.'</td><td>'.$_SESSION['toiture']['metrage'].'</td><td>'.price($tabtarif['remise']->price_ttc,0,'',1,2,2).'</td><td>'.price($tabtarif['remise']->price_ttc*$_SESSION['toiture']['metrage'],0,'',1,2,2).'</td></tr><tr class="oddeven">';
			$total+=(float)$tabtarif['remise']->price_ttc*$_SESSION['toiture']['metrage'];
		}

		$htm.='<tr ><td colspan=3 bgcolor="lightgray">Couverture isolée</td><td bgcolor="lightgray">'.price($total,0,'',1,2,2).'</td></tr>';
		if($_SESSION[$_SESSION["produit"]]['charpente']=='oui')
			$htm.='<tr class="oddeven"><td colspan=3><b>Charpente</b></td></tr>';
		$tarif=$tabtarif['option'];
		$i=0;
		foreach ($tarif as $id=>$product){
			$i++;
			if($id=='char'){
				$metrage=$_SESSION['toiture']['metragecharpente'];
			}
			elseif($id=='gouttiere'){
				$metrage=$_SESSION['toiture']['metragegouttieres'];
			}
			elseif($id=='fp'){
				$metrage=$_SESSION['toiture']['metragefauxplafond'];
			}
			elseif($id=='chen'){
				$metrage=$_SESSION['toiture']['metragechenaux'];
			}
			$htm.='<td>'.$product->label.'</td><td>'.$metrage.'</td><td>'.(float)$tabtarif['option'][$id]->price_ttc.'</td><td>'.(float)$tabtarif['option'][$id]->price_ttc*$metrage.'';
			if($i%2)
				$htm.='</td></tr><tr class="oddeven">';
			else $htm.='</td></tr><tr class="pair">';
			$total+=(float)$tabtarif['option'][$id]->price_ttc*$metrage;
			$totalcharpente+=(float)$tabtarif['option'][$id]->price_ttc*$metrage;

		}
		if($totalcharpente>0)
			$htm.='<tr ><td colspan=3 bgcolor="lightgray">Sous total Options</td><td bgcolor="lightgray">'.$totalcharpente.'</td></tr>';
		if($_SESSION[$prod]['sproduit']=='ces'){
			$htm.='<tr><td><b>CES</b></td></tr>';
			$htm.='<tr><td>'.$tabtarifces['pv']['lib'][$_SESSION[$prod]['vol']].'</td><td>1</td><td>'.(float)$tabtarifces['pv']['mt'][$_SESSION[$prod]['vol']].'</td></tr>';
			$total+=(float)$tabtarifces['pv']['mt'][$_SESSION[$prod]['vol']];
			$totalces=(float)$tabtarifces['pv']['mt'][$_SESSION[$prod]['vol']];
			$htm.='<tr ><td colspan=3 bgcolor="lightgray">Sous total CES</td><td bgcolor="lightgray">'.$totalces.'</td></tr>';
		}
		$htm2= '</tr><tr ><td colspan=4 bgcolor="'.$bgcolor.'"><b>PRIMES</b></td></tr><tr>';
		$tarif=$tabtarif[$couleur]['pr']['lib'];	
		foreach ($tarif as $id=>$lib){
			$htm2.='<tr><td>'.$lib->label.'</td><td>'.$_SESSION['toiture']['metrage'].'</td><td>'.(float)$lib->price.'</td><td>'.(float)$lib->price*$_SESSION['toiture']['metrage'].'</td></tr>';
			$total+=(float)$lib->price*$_SESSION['toiture']['metrage'];
		}
		
		$tarif=$tabtarifces[$couleur]['pr']['lib'];	
		foreach ($tarif as $id=>$lib){
			$htm2.='<td>'.$lib.'</td><td>1</td><td>'.(float)$tabtarifces[$couleur]['pr']['mt'][$id].'</td></tr><tr class="oddeven">';
			$total+=(float)$tabtarifces[$couleur]['pr']['mt'][$id];
		}
		
		$ligtotal='<tr class="oddeven"><td colspan=3 bgcolor="lightgray">Reste à charge</td><td bgcolor="lightgray">'.price($total,0,'',1,2,2).'<input type="hidden" name="totaldevis" value="'.$total.'"></td></tr>';
		print $htm.$htm2.$ligtotal;
		print '</table></div>';

	}
	if($_SESSION['ces'] && GETPOST('ces'=='valider')){
		include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifces.lib.php',1);
		$couleur=get_tarif();
		if($couleur=='b')
			$bgcolor='lightblue';
		elseif($couleur=='j')
			$bgcolor='yellow';
		elseif($couleur=='v')
			$bgcolor='mediumorchid';
		elseif($couleur=='r')
			$bgcolor='pink';

		print '<div  class="tabBar" >';
		print '<div id="devistoiture" class="fichehalfleft" >';
		print'<table class="border soixantepercent"><tr>';
		print '<td bgcolor="'.$bgcolor.'" colspan=3 align="center">Devis CES</td>';
		$htm= '</tr><tr class="oddeven">';
		$htm2= '</tr><tr ><td colspan=3 bgcolor="'.$bgcolor.'"> </td></tr><tr>';
		//previsite
		$htm.='<td>'.$tabtarif['prev']->label.'</td><td>'.number_format($tabtarif['prev']->price_ttc,2,'.',' ').'</td></tr><tr class="oddeven">';
		$total=$tabtarif['prev']->price_ttc;
		//produit
		$htm.='<td>'.$tabtarif['pv'][$_SESSION['ces']["vol"]]->label.'</td><td>'.number_format($tabtarif['pv'][$_SESSION['ces']["vol"]]->price_ttc,2,'.',' ').'</td></tr><tr class="oddeven">';
		$total+=(float)$tabtarif['pv'][$_SESSION['ces']["vol"]]->price_ttc;
		//livraison
		$htm.='<td>'.$tabtarif['liv'][$_SESSION['ces']["vol"]]->label.'</td><td>'.number_format($tabtarif['liv'][$_SESSION['ces']["vol"]]->price_ttc,2,'.',' ').'</td></tr><tr class="oddeven">';
		$total+=(float)$tabtarif['liv'][$_SESSION['ces']["vol"]]->price_ttc;
		//primes
		$tarif=$tabtarif[$couleur]['pr']['mt'];	
		foreach ($tarif as $id=>$mt){
			$htm2.='<td>'.$tabtarif['pr']['lib'][$id]->label.'</td><td>'.(float)$tabtarif[$couleur]['pr']['mt'][$id].'</td></tr><tr class="oddeven">';
			$total+=(float)$tabtarif[$couleur]['pr']['mt'][$id];
		}
		
		$ligtotal='<tr class="oddeven"><td>Reste à charge</td><td>'.$total.'<input type="hidden" name="totaldevis" value="'.$total.'"></td></tr>';
		print $htm.$htm2.$ligtotal;
		print '</table></div></div>';
	}
	if($_SESSION['iso'] && GETPOST('iso'=='valider')){
		$couleur=get_tarif();
		include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifiso.lib.php',1);
		
		if($couleur=='b')
			$bgcolor='lightblue';
		elseif($couleur=='j')
			$bgcolor='yellow';
		elseif($couleur=='v')
			$bgcolor='mediumorchid';
		elseif($couleur=='r')
			$bgcolor='pink';

		print '<div  class="tabBar" >';
		print '<div id="devistoiture" class="fichehalfleft" >';
		print'<table class="noborder soixantepercent"><tr>';
		print '<td bgcolor="'.$bgcolor.'" colspan=4 align="center">Devis ISOLATION</td>';
		$htm = '</tr>';
		$htm = '<tr><td>Libele</td><td>Quantité</td><td>Prix Unitaire TTC</td><td>Montant TTC</td></tr>';
		$htm .= '<tr class="oddeven">';
		
		$product=$tabtarif['pv']['iso'];
		$i=0;
		$htm.='<td>'.$product->ref.'</td><td>'.$_SESSION['iso']['metrage'].'</td><td>'.price($product->price_ttc,0,'',1,2,2).'</td><td>'.price($product->price_ttc*$_SESSION['iso']['metrage'],0,'',1,2,2).'';
		$htm.='</td></tr><tr class="pair">';
		$total+=$product->price_ttc*$_SESSION['iso']['metrage'];
		$tarif=$tabtarif[$couleur]['pr']['mt'];	
		foreach ($tarif as $id=>$mt){
			$htm2.='<td>'.$tabtarif['pr']['lib'][$id].'</td><td>1</td><td>'.$tabtarif[$couleur]['pr']['mt'][$id].'</td><td>'.(float)$tabtarif[$couleur]['pr']['mt'][$id]*$_SESSION['iso']['metrage'].'</td></tr><tr class="oddeven">';
			$total+=(float)$tabtarif[$couleur]['pr']['mt'][$id]*$_SESSION['iso']['metrage'];
		}
		
		$totalremise=-$total+1;
		$_SESSION[$prod]['totalremise']=$totalremise;
		$total=1;
		$product=$tabtarif['pv']['remise'];
		$ligremise.='<td>'.$product->ref.'</td><td>1</td><td>'.price($totalremise,0,'',1,2,2).'</td><td>'.price($totalremise,0,'',1,2,2).'</td><input type="hidden" name="totalremise" value="'.$totalremise.'">';
		
		//$ligremise='<tr class="oddeven"><td>Remise</td><td><td></td></td><td>'.$totalremise.'<input type="hidden" name="totaldevis" value="'.$totalremise.'"></td></tr>';
		$ligtotal='<tr class="oddeven"><td>Reste à charge</td><td><td></td></td><td>'.$total.'<input type="hidden" name="totaldevis" value="'.$total.'"></td></tr>';
		print $htm.$htm2.$ligremise.$ligtotal;
		print '</table></div></div>';
	}
	
	if($_SESSION['financement']){
		
		print'<div  class="financement" ><div class="fichehalfleft"  style="display: block;">';
	}
	else{
		print'<div  class="financement" ><div class="fichehalfleft"  style="display: none;">';
	}
	$htm='</a><table class="border soixantepercent"><tr>';
	$htm.= '<tr>';
	$htm.= '<td bgcolor="'.$bgcolor.'" colspan=3 >Financement</td>';
	$htm.= '</tr>';
	if($_SESSION['toiture']){
		$htm.= '<tr><td  >Acompte</td><td><input type="text" name="acompte" value="'.$_SESSION['financement']['acompte'].'"></td></tr>';
	}
	if($_SESSION['ces']){
		$htm.= '<tr><td  >Montant à charge</td><td><input type="text" name="pencharge" value="'.$_SESSION['financement']['pencharge'].'"></td>';
		if($_SESSION['financement']['pencharge']){
			$prisechargesociete=$total-$_SESSION['financement']['pencharge'];
			$htm.= '<td > Pour CARA='.$prisechargesociete.'</td>';
		}
		$htm.='</tr>';
	}	
	if(!$_SESSION['iso'])
		$htm.= '<tr ><td colspan=3> Perso: <input type="radio" onclick="affichreglement();" name="typefin"  value="finperso" '.($_SESSION['financement']['type']=="finperso"?"checked":"").'><br></td></tr>';
	//elseif($_SESSION['iso'])
	if($_SESSION['toiture'])
		$htm.= '<tr ><td>CMA:  <input type="radio" onclick="this.form.submit();" name="typefin"  value="fincma" '.($_SESSION['financement']['type']=="fincma"?"checked":"").'><br></td>';
	
	$htm.= '</table></div></div>';
	if($_SESSION['financement']['type']=='finperso' || $_SESSION['iso'])
		$htm.='<div id="zonereglement" class="financement " style="display: block;">';
	else
		$htm.='<div id="zonereglement" class="financement " style="display: none;">';
	$htm.='<table border=0 width="50%">';
	
	$selectchq='<select name="personbch" onchange="this.form.submit();" >';
	for ($i=0; $i<=10;$i++){
		$selectchq.='<option value='.$i.' '.($_SESSION['financement']['finperso']['nb']==$i&& $_SESSION['financement']['finperso']['code']=='CH' ?'selected':'').'>'.$i.'</option>';
	}
	$selectchq.='</select>'; 
	$selectprelev='<select name="personbprelev" onchange="this.form.submit();" >';
	for ($i=0; $i<=20;$i++){
		$selectprelev.='<option value='.$i.' '.($_SESSION['financement']['finperso']['nb']==$i&&$_SESSION['financement']['finperso']['code']=='PR'?'selected':'').'>'.$i.'</option>';
	}
	$selectprelev.='</select>';
	if(!$_SESSION['iso']){
		$htm.= '<tr class="oddeven"><td> Règlement par: </td>
			<td>chq :  Nombre de cheques: '.$selectchq.'<br>
			prelevement : Nombre de prélévements: '.$selectprelev.'<br>';
		if($_SESSION['toiture'])
			$htm.='Banque (40% à la commande/ 40% livraison /20% PV fin de chantier : <input type="radio"  onclick="this.form.submit();" name="persobanque" '.($_SESSION['financement']['finperso']['banque']==1?'checked':'').' value="banque" ><br>
		</td></tr>';
		if($_SESSION['toiture']){
			if($_SESSION['financement']['finperso']['code']=='CH'){
				$rac=($_SESSION['financement']['totaldevis']-$_SESSION['financement']['acompte'])/$_SESSION['financement']['finperso']['nb'];
				$htm.='<tr class="amountremaintopay"><td> Règlement par chq en '.$_SESSION['financement']['finperso']['nb'].' fois </td>
				<td> Montant de chaque chèque: '.price($rac,0,'',1,2,2).'</td></tr>';
			}
			if($_SESSION['financement']['finperso']['code']=='PR'){
				$rac=($_SESSION['financement']['totaldevis']-$_SESSION['financement']['acompte'])/$_SESSION['financement']['finperso']['nb'];
				$htm.='<tr class="amountremaintopay"><td> règlement par prélèvement en '.$_SESSION['financement']['finperso']['nb'].' fois </td>
				<td> Montant de chaque prélevement: '.price($rac,0,'',1,2,2).'</td></tr>';
			}
			if($_SESSION['financement']['finperso']['code']=='BQ'){
				$htm.='<tr class="amountremaintopay"><td> Règlement par virement bancaire:  </td>
				<td>-Commande= '.price($_SESSION['financement']['totaldevis']*0.4,0,'',1,2,2).' <br> -Livraison sur chantier '.price($_SESSION['financement']['totaldevis']*0.4,0,'',1,2,2).' <br>
				-Fin de chantier: '.price($_SESSION['financement']['totaldevis']*0.2,0,'',1,2,2).' </td></tr>';
			}
		}
		if($_SESSION['ces']){
			if($_SESSION['financement']['finperso']['code']=='CH'){
				$htm.='<tr class="amountremaintopay"><td> Règlement par chq en '.$_SESSION['financement']['finperso']['nb'].' fois </td>';
			}
			if($_SESSION['financement']['finperso']['code']=='PR'){
				$htm.='<tr class="amountremaintopay"><td> règlement par prélèvement en '.$_SESSION['financement']['finperso']['nb'].' fois </td>';
			}
		}

	}
	elseif($_SESSION['iso']){
		$htm.= '<tr class="oddeven"><td> Règlement en Espèces pour le montant de un euro</td>';
	}

	//$htm.='<tr><td><input type="submit" class="button" name="validcma" value="valider"></td></tr>';
	$htm.='</table></div>';


	if($_SESSION['financement']['type']=="fincma")
		$htm.='<div id="zonecma" class="financement " style="display: block;">';
	else
		$htm.='<div id="zonecma" class="financement " style="display: none;">';
	$htm.='<table border=0 width="40%">';

	$mensualité=array_keys($tabfin[30]);
	
	foreach($mensualité as $mois){
		$montant=($total-$_SESSION['financement']['acompte'])*$tabfin[30][$mois]; //gérer l'acompte
		$select.= ''.$mois.' :  <input type="radio" onclick="this.form.submit();" name="cmanbmois" value="30/'.$mois.'/'.$montant.'" '.($_SESSION['financement']['fincma']['30']==$mois?'checked':'').' > <input type="text" name="montant" readonly value="'.price($montant,0,'',2,2,2).'"><br>';
	}
	$select2='';
	foreach($mensualité as $mois){
		$montant=($total-$_SESSION['financement']['acompte'])*$tabfin[90][$mois];
		$select2.= ''.$mois.' :  <input type="radio" onclick="this.form.submit();" name="cmanbmois" value="90/'.$mois.'/'.$montant.'" '.($_SESSION['financement']['fincma']['90']==$mois?'checked':'').' > <input type="text" name="montant" readonly value="'.price($montant,0,'',2,2,2).'"><br>';
	}
	$htm.='<tr class="oddeven"><td>Mensualité : </td></tr><tr><td>Report 30 jours</td><td>Report 90 jours</td></tr><tr><td>'.$select.'</td><td>'.$select2.'</td>';
	$htm.= '
	</td></tr>';
	$htm.='</table></div></div>';
	print $htm;
	if($_SESSION['financement']['type']!="" || $_SESSION['iso']){
		print '<input type="button" class="button" name="creerclient" onclick="window.location.href=\''.dol_buildpath('deviscara/dev_client.php',1).'?action=create\'" value="Créer client" >';
		print '  ';
		print '<input type="submit" class="button" name="reinit" value="re-initialiser">'; // Cancel for create does not post form if we don't know the backtopage
	}
	print '<a name="bottom"></a>';
	print '</form>';
	dol_fiche_end();


}
	//dol_set_focus('input[name="ref"]');

if ($action == 'create2')
{
	unset($_SESSION['client'],$_SESSION['produit'],$_SESSION[$prod],$_SESSION['toiture'],$_SESSION['ces'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client'],$_SESSION['iso'],$_SESSION['toit'],$_SESSION['fk_soc']);
	print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("Devis")));

	print '<form method="POST" name="prédevis" action="'.$_SERVER["PHP_SELF"].'#bottom">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="add2">';
	print '<input type="hidden" name="fromid" value="'.GETPOST('fromid','int').'">';
	print '<input type="hidden" name="fk_soc" value="'.GETPOST('fk_soc','int').'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');
	
	print '<div id="idprod0" style="display: block;" >';

	print'<table ><tr>';
	print '<tr><td>Choix des produits</td></tr><tr>
		<td>Produits : </td><td>
		<input class="demo2 demo" type="radio" name="produit" id="toiture" onclick="javascript:this.form.submit();" value="toiture" '.($_SESSION["produit"]=="toiture"?"checked":"").'> <label for="toiture">Toiture</label><br><br>
		<input class="demo2 demo" type="radio"  name="produit" id="ces" onclick="javascript:this.form.submit();" value="ces" '.($_SESSION["produit"]=="ces"?"checked":"").'> <label for="ces" >CES</label><br><br>
		<input class="demo2 demo" type="radio"  name="produit" id="iso" onclick="javascript:this.form.submit();" value="iso" '.($_SESSION["produit"]=="iso"?"checked":"").'> <label for="iso">ISO</label><br><br>
		<!-- <input class="demo2 demo" type="radio"  name="produit" id="rep" onclick="javascript:this.form.submit();" value="rep" '.($_SESSION["produit"]=="rep"?"checked":"").'> <label for="rep">REP</label><br><br> -->
		<input class="demo2 demo" type="radio"  name="produit" id="pv" onclick="javascript:this.form.submit();" value="pv" '.($_SESSION["produit"]=="pv"?"checked":"").'> <label for="pv">PV</label><br><br>
		';
		
	print '</td><td class="center valignmiddle" width="60px"><!-- Message to show:  -->
	<a class="reposition" href="javascript:affichproduit(2);"></a>
	</td></tr></table></div>';
	
	print '<a name="bottom"></a>';
	print '</form>';
	dol_fiche_end();

}
// Part to edit record
if (($id || $ref) && $action == 'edit')
{
	print load_fiche_titre($langs->trans("dev"));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
    print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="update">';
	print '<input type="hidden" name="id" value="'.$object->id.'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head();

	print '<table class="border centpercent tableforfieldedit">'."\n";

	// Common attributes
	include DOL_DOCUMENT_ROOT.'/core/tpl/commonfields_edit.tpl.php';

	// Other attributes
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_edit.tpl.php';

	print '</table>';

	dol_fiche_end();

	print '<div class="center"><input type="submit" class="button" name="save" value="'.$langs->trans("Save").'">';
	print '   <input type="submit" class="button" name="cancel" value="'.$langs->trans("Cancel").'">';
	print '</div>';

	print '</form>';
}

// Part to show record
if ($object->id > 0 && (empty($action) || ($action != 'edit' && $action != 'create')))
{
    $res = $object->fetch_optionals();

	$head = devPrepareHead($object);
	dol_fiche_head($head, 'card', $langs->trans("dev"), -1, $object->picto);

	$formconfirm = '';

	// Confirmation to delete
	if ($action == 'delete')
	{
	    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('Deletedev'), $langs->trans('ConfirmDeleteObject'), 'confirm_delete', '', 0, 1);
	}
	// Confirmation to delete line
	if ($action == 'deleteline')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&lineid='.$lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deleteline', '', 0, 1);
	}
	// Clone confirmation
	if ($action == 'clone') {
		// Create an array for form
		$formquestion = array();
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('ToClone'), $langs->trans('ConfirmClonedev', $object->ref), 'confirm_clone', $formquestion, 'yes', 1);
	}

	// Confirmation of action xxxx
	if ($action == 'xxx')
	{
		$formquestion = array();
	    /*
		$forcecombo=0;
		if ($conf->browser->name == 'ie') $forcecombo = 1;	// There is a bug in IE10 that make combo inside popup crazy
	    $formquestion = array(
	        // 'text' => $langs->trans("ConfirmClone"),
	        // array('type' => 'checkbox', 'name' => 'clone_content', 'label' => $langs->trans("CloneMainAttributes"), 'value' => 1),
	        // array('type' => 'checkbox', 'name' => 'update_prices', 'label' => $langs->trans("PuttingPricesUpToDate"), 'value' => 1),
	        // array('type' => 'other',    'name' => 'idwarehouse',   'label' => $langs->trans("SelectWarehouseForStockDecrease"), 'value' => $formproduct->selectWarehouses(GETPOST('idwarehouse')?GETPOST('idwarehouse'):'ifone', 'idwarehouse', '', 1, 0, 0, '', 0, $forcecombo))
        );
	    */
	    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('XXX'), $text, 'confirm_xxx', $formquestion, 0, 1, 220);
	}

	// Call Hook formConfirm
	$parameters = array('formConfirm' => $formconfirm, 'lineid' => $lineid);
	$reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $formconfirm .= $hookmanager->resPrint;
	elseif ($reshook > 0) $formconfirm = $hookmanager->resPrint;

	// Print form confirm
	print $formconfirm;


	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="'.dol_buildpath('/deviscara/dev_list.php', 1).'?restore_lastsearch_values=1'.(!empty($socid) ? '&socid='.$socid : '').'">'.$langs->trans("BackToList").'</a>';

	$morehtmlref = '<div class="refidno">';
	/*
	// Ref bis
	$morehtmlref.=$form->editfieldkey("RefBis", 'ref_client', $object->ref_client, $object, $user->rights->deviscara->dev->creer, 'string', '', 0, 1);
	$morehtmlref.=$form->editfieldval("RefBis", 'ref_client', $object->ref_client, $object, $user->rights->deviscara->dev->creer, 'string', '', null, null, '', 1);
	// Thirdparty
	$morehtmlref.='<br>'.$langs->trans('ThirdParty') . ' : ' . (is_object($object->thirdparty) ? $object->thirdparty->getNomUrl(1) : '');
	// Project
	if (! empty($conf->projet->enabled))
	{
	    $langs->load("projects");
	    $morehtmlref.='<br>'.$langs->trans('Project') . ' ';
	    if ($permissiontoadd)
	    {
	        if ($action != 'classify')
	            $morehtmlref.='<a class="editfielda" href="' . $_SERVER['PHP_SELF'] . '?action=classify&amp;id=' . $object->id . '">' . img_edit($langs->transnoentitiesnoconv('SetProject')) . '</a> : ';
            if ($action == 'classify') {
                //$morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'projectid', 0, 0, 1, 1);
                $morehtmlref.='<form method="post" action="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'">';
                $morehtmlref.='<input type="hidden" name="action" value="classin">';
                $morehtmlref.='<input type="hidden" name="token" value="'.newToken().'">';
                $morehtmlref.=$formproject->select_projects($object->socid, $object->fk_project, 'projectid', 0, 0, 1, 0, 1, 0, 0, '', 1);
                $morehtmlref.='<input type="submit" class="button valignmiddle" value="'.$langs->trans("Modify").'">';
                $morehtmlref.='</form>';
            } else {
                $morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'none', 0, 0, 0, 1);
	        }
	    } else {
	        if (! empty($object->fk_project)) {
	            $proj = new Project($db);
	            $proj->fetch($object->fk_project);
	            $morehtmlref.=$proj->getNomUrl();
	        } else {
	            $morehtmlref.='';
	        }
	    }
	}
	*/
	$morehtmlref .= '</div>';


	dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref);


	print '<div class="fichecenter">';
	print '<div class="fichehalfleft">';
	print '<div class="underbanner clearboth"></div>';
	print '<table class="border centpercent">'."\n";

	// Common attributes
	//$keyforbreak='fieldkeytoswitchonsecondcolumn';	// We change column just after this field
	//unset($object->fields['fk_project']);				// Hide field already shown in banner
	//unset($object->fields['fk_soc']);					// Hide field already shown in banner
	include DOL_DOCUMENT_ROOT.'/core/tpl/commonfields_view.tpl.php';

	// Other attributes. Fields from hook formObjectOptions and Extrafields.
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_view.tpl.php';

	print '</table>';
	print '</div>';
	print '</div>';

	print '<div class="clearboth"></div>';

	dol_fiche_end();


	/*
	 * Lines
	 */

	if (!empty($object->table_element_line))
	{
    	// Show object lines
    	$result = $object->getLinesArray();

    	print '	<form name="addproduct" id="addproduct" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.(($action != 'editline') ? '#addline' : '#line_'.GETPOST('lineid', 'int')).'" method="POST">
    	<input type="hidden" name="token" value="' . $_SESSION ['newtoken'].'">
    	<input type="hidden" name="action" value="' . (($action != 'editline') ? 'addline' : 'updateline').'">
    	<input type="hidden" name="mode" value="">
    	<input type="hidden" name="id" value="' . $object->id.'">
    	';

    	if (!empty($conf->use_javascript_ajax) && $object->status == 0) {
    	    include DOL_DOCUMENT_ROOT.'/core/tpl/ajaxrow.tpl.php';
    	}

    	print '<div class="div-table-responsive-no-min">';
    	if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline'))
    	{
    	    print '<table id="tablelines" class="noborder noshadow" width="100%">';
    	}

    	if (!empty($object->lines))
    	{
    		$object->printObjectLines($action, $mysoc, null, GETPOST('lineid', 'int'), 1);
    	}

    	// Form to add new line
    	if ($object->status == 0 && $permissiontoadd && $action != 'selectlines')
    	{
    	    if ($action != 'editline')
    	    {
    	        // Add products/services form
    	        $object->formAddObjectLine(1, $mysoc, $soc);

    	        $parameters = array();
    	        $reshook = $hookmanager->executeHooks('formAddObjectLine', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    	    }
    	}

    	if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline'))
    	{
    	    print '</table>';
    	}
    	print '</div>';

    	print "</form>\n";
	}


	// Buttons for actions

	if ($action != 'presend' && $action != 'editline') {
    	print '<div class="tabsAction">'."\n";
    	$parameters = array();
    	$reshook = $hookmanager->executeHooks('addMoreActionsButtons', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    	if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

    	if (empty($reshook))
    	{
    	    // Send
            print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=presend&mode=init#formmailbeforetitle">'.$langs->trans('SendMail').'</a>'."\n";

            // Back to draft
            if ($object->status == $object::STATUS_VALIDATED)
            {
	            if ($permissiontoadd)
	            {
	            	print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=confirm_setdraft&confirm=yes">'.$langs->trans("SetToDraft").'</a>';
	            }
            }

            // Modify
            if ($permissiontoadd)
    		{
    			print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=edit">'.$langs->trans("Modify").'</a>'."\n";
    		}
    		else
    		{
    			print '<a class="butActionRefused classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans('Modify').'</a>'."\n";
    		}

    		// Validate
    		if ($object->status == $object::STATUS_DRAFT)
    		{
	    		if ($permissiontoadd)
	    		{
	    			if (empty($object->table_element_line) || (is_array($object->lines) && count($object->lines) > 0))
	    			{
	    				print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=confirm_validate&confirm=yes">'.$langs->trans("Validate").'</a>';
	    			}
	    			else
	    			{
	    				$langs->load("errors");
	    				print '<a class="butActionRefused" href="" title="'.$langs->trans("ErrorAddAtLeastOneLineFirst").'">'.$langs->trans("Validate").'</a>';
	    			}
	    		}
    		}

    		// Clone
    		if ($permissiontoadd)
    		{
    			print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&socid='.$object->socid.'&action=clone&object=dev">'.$langs->trans("ToClone").'</a>'."\n";
    		}

    		/*
    		if ($permissiontoadd)
    		{
    			if ($object->status == $object::STATUS_ENABLED)
    		 	{
    		 		print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=disable">'.$langs->trans("Disable").'</a>'."\n";
    		 	}
    		 	else
    		 	{
    		 		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=enable">'.$langs->trans("Enable").'</a>'."\n";
    		 	}
    		}
    		if ($permissiontoadd)
    		{
    			if ($object->status == $object::STATUS_VALIDATED)
    		 	{
    		 		print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=close">'.$langs->trans("Cancel").'</a>'."\n";
    		 	}
    		 	else
    		 	{
    		 		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=reopen">'.$langs->trans("Re-Open").'</a>'."\n";
    		 	}
    		}
    		*/

    		// Delete (need delete permission, or if draft, just need create/modify permission)
    		if ($permissiontodelete)
    		{
    			print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=delete">'.$langs->trans('Delete').'</a>'."\n";
    		}
    		else
    		{
    			print '<a class="butActionRefused classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans('Delete').'</a>'."\n";
    		}
    	}
    	print '</div>'."\n";
	}


	// Select mail models is same action as presend
	if (GETPOST('modelselected')) {
		$action = 'presend';
	}

	if ($action != 'presend')
	{
	    print '<div class="fichecenter"><div class="fichehalfleft">';
	    print '<a name="builddoc"></a>'; // ancre

	    // Documents
	    /*$objref = dol_sanitizeFileName($object->ref);
	    $relativepath = $objref . '/' . $objref . '.pdf';
	    $filedir = $conf->deviscara->dir_output . '/' . $objref;
	    $urlsource = $_SERVER["PHP_SELF"] . "?id=" . $object->id;
	    $genallowed = $user->rights->deviscara->dev->read;	// If you can read, you can build the PDF to read content
	    $delallowed = $user->rights->deviscara->dev->create;	// If you can create/edit, you can remove a file on card
	    print $formfile->showdocuments('deviscara', $objref, $filedir, $urlsource, $genallowed, $delallowed, $object->modelpdf, 1, 0, 0, 28, 0, '', '', '', $langs->defaultlang);
		*/

	    // Show links to link elements
	    $linktoelem = $form->showLinkToObjectBlock($object, null, array('dev'));
	    $somethingshown = $form->showLinkedObjectBlock($object, $linktoelem);


	    print '</div><div class="fichehalfright"><div class="ficheaddleft">';

	    $MAXEVENT = 10;

	    $morehtmlright = '<a href="'.dol_buildpath('/deviscara/dev_agenda.php', 1).'?id='.$object->id.'">';
	    $morehtmlright .= $langs->trans("SeeAll");
	    $morehtmlright .= '</a>';

	    // List of actions on element
	    include_once DOL_DOCUMENT_ROOT.'/core/class/html.formactions.class.php';
	    $formactions = new FormActions($db);
	    $somethingshown = $formactions->showactions($object, $object->element, (is_object($object->thirdparty) ? $object->thirdparty->id : 0), 1, '', $MAXEVENT, '', $morehtmlright);

	    print '</div></div></div>';
	}

	//Select mail models is same action as presend
	/*
	if (GETPOST('modelselected')) $action = 'presend';

	// Presend form
	$modelmail='dev';
	$defaulttopic='InformationMessage';
	$diroutput = $conf->deviscara->dir_output;
	$trackid = 'dev'.$object->id;

	include DOL_DOCUMENT_ROOT.'/core/tpl/card_presend.tpl.php';
	*/
}

// End of page
llxFooter();
$db->close();
