<?php


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
include_once DOL_DOCUMENT_ROOT . dol_buildpath("deviscara/class/dev.class.php", 1);

// Load translation files required by the page
$langs->loadLangs(array("mymodule@mymodule", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');

$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$type=      GETPOST('type','int');

// Initialize technical objects
$object = new dev($db);
$extrafields = new ExtraFields($db);
$object->fetch($id);

//$diroutputmassaction = $conf->mymodule->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('myobjectcard', 'globalcard')); // Note that conf->hooks_modules contains array

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

$form = new Form($db);
$formfile = new FormFile($db);

/*
 * Actions
 */

if(GETPOST('valider')=='valider'){
    $status_avantmaj=$object->status;
    $object->status=GETPOST('status_commercial');
    $object->commentaire=$object->commentaire.$user->login.'/'.$db->idate(dol_now()).':  '.GETPOST('commentaire').'<br>';
    $newstatus=GETPOST('status');
    if($status_avantmaj != $newstatus && $newstatus!=''){
		$object->{'date_status_'.$newstatus} = dol_now(); //date de changement de statut
	}
    $res=$object->update($user);
    if ($res > 0){
        setEventMessages("Mise à jour réussie", null, 'mesgs');
        $urltogo = dol_buildpath('deviscara/dev_list.php',1);
		header("Location: ".$urltogo);
        exit;
    }
    else{
        setEventMessages("Problème de mise à jour", null, 'errors');
    }
}


/*
 * View
 *
 * Put here all code to build page
 */







llxHeader('', $langs->trans('Modification statuts '), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">

</script>';
if ($formconfirm)
    print $formconfirm;
//affichage par défaut

print load_fiche_titre($langs->trans("Modification statuts pour devis ".GETPOST('object_ref').""));

print '<form method="POST" id="docmanquant" action="'.$_SERVER["PHP_SELF"].'" >';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="id" value="'. $object->id .'">';



dol_fiche_head(array(), '');

$htm='<table><tr><td>Modofication des Status du devis</td><td>';
$liste_status=array("0"=>"PROSPECT","1"=>"A TRAITER","6"=>"A COMPLETER");
$htm.= $form->selectarray('status_commercial',$liste_status, $object->status,'', 0, 0, '', 1, 0, 0, '', 'maxwidth100');
$htm.='</td></tr>';
$htm .= '<td>Commentaire sur devis</td><td><textarea name="commentaire" rows=5 cols=33></textarea></td></tr>';
$htm .= '<tr><td><input type="submit" class="button" name="valider" value="valider"></td></tr>';
$htm .= '<tr><td>'.$object->commentaire.'</td></tr>';
$htm .= '</table>';

print $htm;








// End of page
llxFooter();
$db->close();
