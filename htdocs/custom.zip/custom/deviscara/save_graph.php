<?php
$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = __DIR__ . '/';

require_once $path . "../../master.inc.php";

// Récupérer les données POST
$dataURL = isset($_POST["image"]) ? $_POST["image"] : null;
$filename = isset($_POST["filename"]) ? $_POST["filename"] : null;

if ($dataURL && $filename) {
    $dir = $conf->deviscara->multidir_output[$conf->entity] . "/temp";
    $fileurl = $dir . "/" . $filename;

    $dataURL = str_replace("data:image/png;base64,", "", $dataURL);
    $dataURL = str_replace(" ", "+", $dataURL);
    $imageData = base64_decode($dataURL);

    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    if (file_put_contents($fileurl, $imageData)) {
        echo "Image enregistrée avec succès.";
    } else {
        echo "Erreur lors de l'enregistrement de l'image.";
    }
} else {
    echo "Données manquantes.";
}
?>
