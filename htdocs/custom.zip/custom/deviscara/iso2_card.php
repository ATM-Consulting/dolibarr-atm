<?php
/* Copyright (C) 2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       rep_card.php
 *		\ingroup    deviscara
 *		\brief      Page to create/edit/view rep
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB','1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER','1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC','1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN','1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION','1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION','1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK','1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL','1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK','1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU','1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML','1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX','1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN",'1');						// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK','1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT','auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE','aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN',1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP','none');					// Disable all Content Security Policies


// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/deviscara/class/iso2.class.php');
dol_include_once('/deviscara/lib/deviscara_iso2.lib.php');
dol_include_once('/product/class/product.class.php');
include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifiso2.lib.php',1);
// Load translation files required by the page
$langs->loadLangs(array("deviscara@deviscara", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'repcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$lineid   = GETPOST('lineid', 'int');
$fk_soc=GETPOST('fk_soc', 'int');

// Initialize technical objects

$object = new iso2($db);
$extrafields = new ExtraFields($db);

$object_soc=new societe($db);
$extrafields_soc = new ExtraFields($db);
	
$diroutputmassaction = $conf->deviscara->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('repcard', 'globalcard')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->statut == $object::STATUS_DRAFT) ? 1 : 0);
//$result = restrictedArea($user, 'deviscara', $object->id, '', '', 'fk_soc', 'rowid', $isdraft);

$permissiontoread = $user->rights->deviscara->rep->read;
$permissiontoadd = $user->rights->deviscara->rep->write; // Used by the include of actions_addupdatedelete.inc.php and actions_lineupdown.inc.php
$permissiontodelete = $user->rights->deviscara->rep->delete || ($permissiontoadd && isset($object->status) && $object->status == $object::STATUS_DRAFT);
$permissionnote = $user->rights->deviscara->rep->write; // Used by the include of actions_setnotes.inc.php
$permissiondellink = $user->rights->deviscara->rep->write; // Used by the include of actions_dellink.inc.php
$upload_dir = $conf->deviscara->multidir_output[isset($object->entity) ? $object->entity : 1];


/*
 * Actions
 */

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook))
{
    $error = 0;

    $backurlforlist = dol_buildpath('/deviscara/rep_list.php', 1);

    if (empty($backtopage) || ($cancel && empty($id))) {
    	if (empty($backtopage) || ($cancel && strpos($backtopage, '__ID__'))) {
    		if (empty($id) && (($action != 'add' && $action != 'create') || $cancel)) $backtopage = $backurlforlist;
    		else $backtopage = dol_buildpath('/deviscara/rep_card.php', 1).'?id='.($id > 0 ? $id : '__ID__');
    	}
    }
    $triggermodname = 'DEVISCARA_REP_MODIFY'; // Name of trigger action code to execute when we modify record

    // Actions cancel, add, update, update_extras, confirm_validate, confirm_delete, confirm_deleteline, confirm_clone, confirm_close, confirm_setdraft, confirm_reopen
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/actions_addupdatedeleteiso2.inc.php',1);
    // Actions when linking object each other
    include DOL_DOCUMENT_ROOT.'/core/actions_dellink.inc.php';

    // Actions when printing a doc from card
    include DOL_DOCUMENT_ROOT.'/core/actions_printing.inc.php';

    // Action to move up and down lines of object
    include DOL_DOCUMENT_ROOT.'/core/actions_lineupdown.inc.php';

    // Action to build doc
    include DOL_DOCUMENT_ROOT.'/core/actions_builddoc.inc.php';

    if ($action == 'set_thirdparty' && $permissiontoadd)
    {
    	$object->setValueFrom('fk_soc', GETPOST('fk_soc', 'int'), '', '', 'date', '', $user, 'REP_MODIFY');
    }
    if ($action == 'classin' && $permissiontoadd)
    {
    	$object->setProject(GETPOST('projectid', 'int'));
    }

    // Actions to send emails
    $triggersendname = 'REP_SENTBYMAIL';
    $autocopy = 'MAIN_MAIL_AUTOCOPY_REP_TO';
    $trackid = 'rep'.$object->id;
    include DOL_DOCUMENT_ROOT.'/core/actions_sendmails.inc.php';
}
//include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.



/*
 * View
 *
 * Put here all code to build page
 */

$form = new Form($db);
$formfile = new FormFile($db);

llxHeader('', $langs->trans('Double iso'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});


function affichproduit(idprod) {
	for(i=0;i<=1;i++){
		document.getElementById("idprod"+i).style.display="none";
	}
	document.getElementById("idprod"+idprod).style.display="block";
}


</script>';


// Part to create
if ($action == 'create')
{
	print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("Fiche Intervention")));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'" enctype="multipart/form-data"">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="create">';
	print '<input type="hidden" name="fk_soc" value="'.$fk_soc.'">';
	print '<input type="hidden" name="difficulte" value="'.GETPOST('difficulte').'">';
	print '<input type="hidden" name="postidevent" value="'.(GETPOST('idevent')==''?GETPOST('postidevent'):GETPOST('idevent')).'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');
	$object->fk_soc=$fk_soc;
	print '<table class="border centpercent tableforfieldcreate">'."\n";
	dol_include_once('/deviscaraiso/class/history.class.php');
	if($object->fk_soc>0){
		$histo=new Histo($db);
		$histo->fetch($object->fk_soc);
		$histo->get_rendezvous();
		$object_soc=new societe($db);
		$extrafields_soc = new ExtraFields($db);
		$object_soc->fetch($object->fk_soc);
		$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
	}
	print '<tr><td>client: '.$object_soc->nom.'</td></tr>';
	print '<td><table><tr><td>Historique Travaux</td></tr>';
	foreach($histo->linesrdv as $key=>$line){
		$date_planif=new DateTime($line->datep);
		$url_agenda=dol_buildpath('comm/action/index.php',1).'?userid='.$line->fk_user_action.'&day='.$date_planif->format("Y-m-d");
		$out.= '<tr><td width="150"><a href="'.$url_agenda.'">'.$date_planif->format("d/m/Y").'</a><td width="200">'.$line->firstname.' '.$line->lastname.'</td>';
		$out.= '<td>'.$line->note.'</td><td><div class="status-list">
		<span class="circle" style="background:'.$line->color.'">&nbsp;'.$line->name.'&nbsp;</span>
		</div></td></tr>';
		
	}
	print $out;
	print'</table></td><td>';
	$htm.= '<div id="iddiv0"  style="display: bloc;">';
	$htm.='<table class="tableclassic" ><tr>';
	$htm.='<td>difficulté du chantier:</td><td>
		<input class="demo2 demo" type="radio" name="difficulte" id="facile"    value="1"><label for="facile">Facile</label> <br><br>
		<input class="demo2 demo" type="radio" name="difficulte" id="difficile"  value="2"><label for="difficile">Difficile</label><br>
		<br><input class="demo2 demo" type="radio" name="difficulte" id="impossible"   onclick="this.form.submit();" value="3"><label for="impossible">Impossible</label></td>
		</tr>';
	if(GETPOST('duree'))
		$object->duree=GETPOST('duree');
	$htm.='<tr><td>Durée estimée du chantier</td>
		<td>'.$object->showInputField($object->fields['duree'],'duree' , $object->duree, 'onchange="affichproduit(0);"', '', '', 0).'</td></tr>	';
	$htm.='</table></div>';
	print $htm;
	
	print '<div id="idprod0" style="display: none;"><table class="tableclassicrep" ><tr>';
	$value_rfr=str_replace(array(' ',','),array('','.'), (GETPOST('options_rfr')?GETPOST('options_rfr'):$object_soc->array_options['options_rfr']));
	$_SESSION['value_rfr']=$value_rfr;
	print '<td>Ref fiscale : </td><td>'.$extrafields_soc->showInputField('rfr',$value_rfr, '', '', '', 0, $object_soc->id, 'societe').'</td>';
	print '</tr><tr>';
	print '<td>nb parts :</td><td> 
	<select name="nbpart" id="nbpart">';
	$value_nbpart=(GETPOST('nbpart')?GETPOST('nbpart'):$object_soc->array_options['options_nbpart']);
	for ($i=1;$i<=10;$i++){
		if ($_SESSION["nbpart"]=="$i" || (isset($value_nbpart) && $value_nbpart=="$i"))
			$selected='selected';
		else $selected='';
		print '<option value="'.$i.'" '.$selected.'>'.$i.'</option>';
	}
	print'</select>';
	print '</td></tr><tr><td>Age du <b>logement</b></td></tr>
	<tr><td></td><td><input class="demo2 demo"  type="radio" id="maisonplus2+" name="maisonplus2"   onclick="affichproduit(1);" value="1" '.($object_soc->array_options['options_maisonplus2']="1"?"checked":"").'><label for="maisonplus2+">+ 2ans</label></td></tr></td></tr>
	<tr><td></td><td><input class="demo2 demo" type="radio"  name="maisonplus2"  id="maisonplus2-"  onclick="affichproduit(1);" value="2" '.($object_soc->array_options['options_maisonplus2']=="2"?"checked":"").'><label for="maisonplus2-">- 2ans</label><br></td></tr>
	</table></div>';
	$status_immo=(GETPOST('status_immo')?GETPOST('status_immo'):$object_soc->array_options['options_status_immo']);
	print '<div id="idprod1" style="display: none;"><table class="tableclassicrep"><tr>
	<tr><td></td><td><input class="demo2 demo" type="radio"  name="status_immo"  id="demo2-a"  onclick="affichproduit(2);" value="1" '.($status_immo=="1"?"checked":"").'><label for="demo2-a">Proprietaire</label><br></td></tr>
	<tr><td></td><td><input class="demo2 demo"  type="radio" id="demo2-b" name="status_immo"  onclick="affichproduit(2);" value="2" '.($status_immo=="2"?"checked":"").'><label for="demo2-b">Locataire</label></td></tr></td></tr>
	</table></div>';

	print '<div id="idprod2" class="idprod1">';
	print'<table class="tableclassic" border=1><tr>';

	$isocombles=(GETPOST('isocomble')?GETPOST('isocomble'):$object_soc->array_options['options_isocombles']);
	print '<td>Combles déjà isolées ?</td>
	<td><input class="demo2 demo" type="radio" name="isocomble" id="isocombleoui"   value="1" '.($isocombles=="1"?"checked":"").' onclick="this.form.submit();"> <label for="isocombleoui">Oui</label><br><br>
	<input class="demo2 demo" type="radio" name="isocomble" id="isocomblenon"   value="2" '.($isocombles=="2"?"checked":"").' onclick="this.form.submit();"> <label for="isocomblenon" >Non</label><br></td></tr>
	';
	print '</table></div>';


	//affichage choix produits
	if($_SESSION['iso2']['choix']>0 && $_SESSION['iso2']['prod']<=0){
		$couleur=get_tarif();
		
		$htm= '<div id="affichproduits"  style="display: bloc;">';
		$htm.='<table class="tableclassic" ><tr>';
		$htm.= "<td><b>produits disponibles:</b> </td></tr>";
		$htm.= '<input type="hidden" name="couleur" value="'.$couleur.'">';
		$htm.= '<input type="hidden" name="fk_soc" value="'.$fk_soc.'">';
		if(count($tabproduct[$_SESSION['status_immo']][$_SESSION['iso2']['maisonplus2']][$_SESSION['iso2']['isocomble']][$couleur])>0){
			$tab_productdejaaffiches=array();
			foreach(($tabproduct[$_SESSION['status_immo']][$_SESSION['iso2']['maisonplus2']][$_SESSION['iso2']['isocomble']][$couleur]) as $product){
				if(is_object($product) && !in_array($product->id,$tab_productdejaaffiches)){
					array_push($tab_productdejaaffiches,$product->id);
					$htm.='<tr><td><input class="styled" type="button"  name="prod" id="prod'.$product->id.'"  value="'.$product->ref.'" > &nbsp; M2:<input type="text" name="m['.$product->id.']"></td></tr>';
				}
				elseif(is_array($product) ){
					foreach($product as $multi){
						if(is_object($multi) && !in_array($multi->id,$tab_productdejaaffiches)){
							array_push($tab_productdejaaffiches,$multi->id);
							$htm.='<tr><td>';
							$htm.='<input class="styled" type="button" name="'.$multi->ref.'" id="'.$multi->ref.'"  value="'.$multi->ref.'" > &nbsp; M2:<input type="text" name="m['.$multi->id.']
							">';
							$htm.='</td></tr>';
						}
					}	
				}
			}
		}
		if(count($tab_productdejaaffiches)==0){
			$htm.='<tr><td>';
			$htm.='impossible';
			$htm.='</td></tr>';
		}
		$htm.='</table></div>';

		$htm.= '<div id="affichbuttons"  style="display: bloc;">';
		$htm.='<table class="tableclassic" >';
		$htm.='<tr><td colspan=2><input type="submit" class="button" name="create" value="'.dol_escape_htmltag($langs->trans("créer Devis Primaire")).'">';
		$htm.='&nbsp; ';
		$htm.='<input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>';
		$htm.='</div>';
		print $htm;
	}
	//affichage du devis primaire
	if($_SESSION['iso2']['devis_primaire']>0 ){
		$tabinfo=get_tarif();
		$couleur=$tabinfo;
		if($couleur=='b')
			$bgcolor='lightblue';
		elseif($couleur=='j')
			$bgcolor='yellow';
		elseif($couleur=='v')
			$bgcolor='mediumorchid';
		elseif($couleur=='r')
			$bgcolor='pink';

		print '<div id="devisrep" class="centpercent tableforfieldcreate" >';
		print'<table class="noborder soixantepercent" border=1><tr>';
		print '<td bgcolor="'.$bgcolor.'" colspan=4 align="center">Devis Double ISO</td>';
		$htm = '</tr>';
		$htm = '<tr><td>Libele</td><td>Quantité</td><td>Prix Unitaire TTC</td><td>Montant TTC</td></tr>';
		$htm .= '<tr class="oddeven">';
		$i=0;
		$tarif=$tabproduct[$_SESSION['status_immo']][$_SESSION['iso2']['maisonplus2']][$_SESSION['iso2']['isocomble']][$couleur];
		//previsite
		$htm .= '<td>'.$previsite->label.'</td><td>1</td><td>'.price($previsite->price,0,'',1,2,2).'</td><td>'.price($previsite->price_ttc,0,'',1,2,2).'</td></tr>';
		$htm .= '<tr class="oddeven">';
		$total=$previsite->price_ttc;
		$total_ht=$previsite->price;
		$tab_productdejaaffiches=array();
		foreach ($tarif as $key=>$product){
			if(is_object($product) && !in_array($product->id,$tab_productdejaaffiches)){
				$metrage=$_SESSION[$prod]['prod'][$product->id];
				if($metrage>0){
					array_push($tab_productdejaaffiches,$product->id);
					
					$htm.='<td>'.$product->ref.'</td><td>'.$metrage.'</td><td>'.price($product->price_ttc,0,'',1,2,2).'</td><td>'.price($product->price_ttc*$metrage,0,'',1,2,2).'</tr>';
					$htm.='<tr><td>'.$tabmo[$key]->ref.'</td><td>'.$metrage.'</td><td>'.price($tabmo[$key]->price_ttc,0,'',1,2,2).'</td><td>'.price($tabmo[$key]->price_ttc*$metrage,0,'',1,2,2).'';
					$total+=$product->price_ttc*$metrage;
					$total_ht+=$product->price*$metrage;
					if($i%2)
						$htm.='</td></tr><tr class="oddeven">';
						else $htm.='</td></tr><tr class="pair">';
				}
			}
			elseif(is_array($product) ){
				foreach($product as $key2=>$multi){
					if(is_object($multi) && !in_array($multi->id,$tab_productdejaaffiches)){
						$metrage=$_SESSION[$prod]['prod'][$multi->id];
						if($metrage>0){
							array_push($tab_productdejaaffiches,$multi->id);
							
							$htm.='<td>'.$multi->ref.'</td><td>'.$metrage.'</td><td>'.price($multi->price_ttc,0,'',1,2,2).'</td><td>'.price($multi->price_ttc*$metrage,0,'',1,2,2).'</tr>';
							if($tabmo[$key2])
								$htm.='<tr><td>'.$tabmo[$key2]->ref.'</td><td>'.$metrage.'</td><td>'.price($tabmo[$key2]->price_ttc,0,'',1,2,2).'</td><td>'.price($tabmo[$key2]->price_ttc*$metrage,0,'',1,2,2).'';
							$total+=$multi->price_ttc*$metrage;
							$total_ht+=$multi->price*$metrage;
							if($i%2)
								$htm.='</td></tr><tr class="oddeven">';
								else $htm.='</td></tr><tr class="pair">';
						}
					}
				}	
			}
			
			
		}
		//total avant prime.
		$ligtotalhorsprime= '<tr class="oddeven"><td colspan=3 bgcolor="lightgray">TOTAL hors prime(TTC)</td><td bgcolor="lightgray">'.price($total,0,'',1,2,2).'<input type="hidden" name="totalhorsprime" value="'.$total.'"></td></tr>';

		$prise_en_charge=-$total+1;	
		$total+=$prise_en_charge;
		$ligtotal='<tr class="oddeven"><td colspan=3 bgcolor="lightgray">Reste à charge (TTC)</td><td bgcolor="lightgray">'.price($total,0,'',1,2,2).'<input type="hidden" name="totalresteacharge" value="'.$total.'"></td></tr>';
		print $htm.$ligtotalhorsprime.$ligeligible.$htm2.$ligtotal;
		$htm='<tr><td colspan=4><input type="submit" class="button" name="create_client" value="'.dol_escape_htmltag($langs->trans("créer Devis Secondaire")).'">';
		$htm.='&nbsp; ';
		$htm.='<input type="submit" class="button" name="reinit" value="re-initialiser"></td></tr>';
		print $htm;
		print '</form>';
		
		$htm.='</table></div>';
		
		
	}
	dol_fiche_end();
	//dol_set_focus('input[name="ref"]');
}
if ($action == 'create_client')
{
	$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
	print load_fiche_titre($langs->trans("NewObject", $langs->transnoentitiesnoconv("deviscaratoitbis")));
	if($fk_soc>0){
		$object_soc=new societe($db);
		$extrafields_soc = new ExtraFields($db);
		$object_soc->fetch($fk_soc);
		$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
	}
	print '<form method="POST" name="creationclient" action="'.$_SERVER["PHP_SELF"].'">';
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="creerdevis">';
	print '<input type="hidden" name="fk_soc" value="'.$fk_soc.'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head(array(), '');

	print'<div id="zoneclient" style="display: block;">';
	print '<a href="#client"></a><table class="border ">';
	// Firstname
	print '<tr class="individualline"><td>'.$form->editfieldkey('Nom client', 'name', '', $object_soc, 0).'</td>';
	print '<td colspan="3"><input type="text" class="minwidth300" maxlength="128" name="firstname" id="firstname" value="'.$object_soc->nom.'"></td>';
	print '</tr>';
	print '<tr><td class="tdtop">'.$form->editfieldkey('Address', 'address', '', $object_soc, 0).'</td>';
	print '<td colspan="3"><textarea name="address" id="address" class="quatrevingtpercent" rows="'.ROWS_2.'" wrap="soft">';
	print $object_soc->address;
	print '</textarea></td></tr>';
	print '<tr><td class="fieldrequired">Cp ville</td>';
	print '<td colspan="3">';
	print $extrafields_soc->showInputField('ville', $object_soc->array_options['options_ville'], '', '', '', 0, $object_soc->id, 'societe');
	print '</td></tr>';
	print '<input type="hidden" name="country_id" value="1">';
	print '<tr><td>'.img_picto('', 'object_phoning').' '.$form->editfieldkey('Phone', 'phone', '', $object_soc, 0).'</td>';
	print '<td><input type="text" name="phone" id="phone" class="maxwidth200" value="'.(GETPOSTISSET('phone') ?GETPOST('phone', 'alpha') : $object_soc->phone).'"></td>';
	
	print '<td>'.img_picto('', 'object_phoning_fax').' '.$form->editfieldkey('Phone', 'fax', '', $object_soc, 0).'</td>';
	print '<td><input type="text" name="fax" id="fax" class="maxwidth200" value="'.(GETPOSTISSET('fax') ?GETPOST('fax', 'alpha') : $object_soc->fax).'"></td></tr>';

	// Email / Web
	print '<tr><td>'.img_picto('', 'object_email').' '.$form->editfieldkey('Email', 'email', '', $object_soc, 0, 'string', '').'</td>';
	print '<td ><input type="text" name="email" id="email" value="'.$object_soc->email.'"></td>';
	print '<td>'.img_picto('', 'globe').' '.$form->editfieldkey('Phone', 'url', '', $object_soc, 0,'string', '').'</td>';
	print '<td colspan="3"><input type="text" name="url" id="url" value="'.$object_soc->url.'"></td></tr>';
	print'<tr><td><input type="submit" class="button" name="devis" value="créer devis"></td></tr></table></div>';
	print '</form>';

	dol_fiche_end();
}
// Part to edit record
if (($id || $ref) && $action == 'edit')
{
	print load_fiche_titre($langs->trans("rep"));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
    print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="action" value="update">';
	print '<input type="hidden" name="id" value="'.$object->id.'">';
	if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
	if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

	dol_fiche_head();

	print '<table class="border centpercent tableforfieldedit">'."\n";

	// Common attributes
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/tpl/commonfields_edit.tpl.php',1);

	// Other attributes
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_edit.tpl.php';

	print '</table>';

	dol_fiche_end();

	print '<div class="center"><input type="submit" class="button" name="save" value="'.$langs->trans("Save").'">';
	print ' &nbsp; <input type="submit" class="button" name="cancel" value="'.$langs->trans("Cancel").'">';
	print '</div>';

	print '</form>';
}

// Part to show record
if ($object->id > 0 && (empty($action) || ($action != 'edit' && $action != 'create')))
{
    $res = $object->fetch_optionals();

	$head = repPrepareHead($object);
	dol_fiche_head($head, 'card', $langs->trans("rep"), -1, $object->picto);

	$formconfirm = '';

	// Confirmation to delete
	if ($action == 'delete')
	{
	    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('Deleterep'), $langs->trans('ConfirmDeleteObject'), 'confirm_delete', '', 0, 1);
	}
	// Confirmation to delete line
	if ($action == 'deleteline')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&lineid='.$lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deleteline', '', 0, 1);
	}
	// Clone confirmation
	if ($action == 'clone') {
		// Create an array for form
		$formquestion = array();
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('ToClone'), $langs->trans('ConfirmClonerep', $object->ref), 'confirm_clone', $formquestion, 'yes', 1);
	}
	elseif ($action == 'ask_deleteline') {
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&lineid='.$lineid, $langs->trans('DeleteProductLine'), $langs->trans('ConfirmDeleteProductLine'), 'confirm_deleteline', '', 0, 1);
	}
	// Confirmation of action xxxx
	if ($action == 'xxx')
	{
		$formquestion = array();
	    /*
		$forcecombo=0;
		if ($conf->browser->name == 'ie') $forcecombo = 1;	// There is a bug in IE10 that make combo inside popup crazy
	    $formquestion = array(
	        // 'text' => $langs->trans("ConfirmClone"),
	        // array('type' => 'checkbox', 'name' => 'clone_content', 'label' => $langs->trans("CloneMainAttributes"), 'value' => 1),
	        // array('type' => 'checkbox', 'name' => 'update_prices', 'label' => $langs->trans("PuttingPricesUpToDate"), 'value' => 1),
	        // array('type' => 'other',    'name' => 'idwarehouse',   'label' => $langs->trans("SelectWarehouseForStockDecrease"), 'value' => $formproduct->selectWarehouses(GETPOST('idwarehouse')?GETPOST('idwarehouse'):'ifone', 'idwarehouse', '', 1, 0, 0, '', 0, $forcecombo))
        );
	    */
	    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('XXX'), $text, 'confirm_xxx', $formquestion, 0, 1, 220);
	}

	// Call Hook formConfirm
	$parameters = array('formConfirm' => $formconfirm, 'lineid' => $lineid);
	$reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $formconfirm .= $hookmanager->resPrint;
	elseif ($reshook > 0) $formconfirm = $hookmanager->resPrint;

	// Print form confirm
	print $formconfirm;


	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="'.dol_buildpath('/deviscara/rep_list.php', 1).'?restore_lastsearch_values=1'.(!empty($socid) ? '&socid='.$socid : '').'">'.$langs->trans("BackToList").'</a>';

	$morehtmlref = '<div class="refidno">';
	/*
	// Ref bis
	$morehtmlref.=$form->editfieldkey("RefBis", 'ref_client', $object->ref_client, $object, $user->rights->deviscara->rep->creer, 'string', '', 0, 1);
	$morehtmlref.=$form->editfieldval("RefBis", 'ref_client', $object->ref_client, $object, $user->rights->deviscara->rep->creer, 'string', '', null, null, '', 1);
	// Thirdparty
	$morehtmlref.='<br>'.$langs->trans('ThirdParty') . ' : ' . (is_object($object->thirdparty) ? $object->thirdparty->getNomUrl(1) : '');
	// Project
	if (! empty($conf->projet->enabled))
	{
	    $langs->load("projects");
	    $morehtmlref.='<br>'.$langs->trans('Project') . ' ';
	    if ($permissiontoadd)
	    {
	        if ($action != 'classify')
	            $morehtmlref.='<a class="editfielda" href="' . $_SERVER['PHP_SELF'] . '?action=classify&amp;id=' . $object->id . '">' . img_edit($langs->transnoentitiesnoconv('SetProject')) . '</a> : ';
            if ($action == 'classify') {
                //$morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'projectid', 0, 0, 1, 1);
                $morehtmlref.='<form method="post" action="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'">';
                $morehtmlref.='<input type="hidden" name="action" value="classin">';
                $morehtmlref.='<input type="hidden" name="token" value="'.newToken().'">';
                $morehtmlref.=$formproject->select_projects($object->socid, $object->fk_project, 'projectid', 0, 0, 1, 0, 1, 0, 0, '', 1);
                $morehtmlref.='<input type="submit" class="button valignmiddle" value="'.$langs->trans("Modify").'">';
                $morehtmlref.='</form>';
            } else {
                $morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'none', 0, 0, 0, 1);
	        }
	    } else {
	        if (! empty($object->fk_project)) {
	            $proj = new Project($db);
	            $proj->fetch($object->fk_project);
	            $morehtmlref.=$proj->getNomUrl();
	        } else {
	            $morehtmlref.='';
	        }
	    }
	}
	*/
	$morehtmlref .= '</div>';


	dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref);


	print '<div class="fichecenter">';
	print '<div class="fichehalfleft">';
	print '<div class="underbanner clearboth"></div>';
	print '<table class="border centpercent">'."\n";

	// Common attributes
	//$keyforbreak='fieldkeytoswitchonsecondcolumn';	// We change column just after this field
	//unset($object->fields['fk_project']);				// Hide field already shown in banner
	//unset($object->fields['fk_soc']);					// Hide field already shown in banner
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/core/tpl/commonfields_view.tpl.php', 1);

	// Other attributes. Fields from hook formObjectOptions and Extrafields.
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_view.tpl.php';

	print '</table>';
	print '</div>';
	print '</div>';

	print '<div class="clearboth"></div>';

	dol_fiche_end();


	/*
	 * Lines
	 */

	if (!empty($object->table_element_line))
	{
    	// Show object lines
    	$result = $object->getLinesArray();

    	print '	<form name="addproduct" id="addproduct" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.(($action != 'editline') ? '#addline' : '#line_'.GETPOST('lineid', 'int')).'" method="POST">
    	<input type="hidden" name="token" value="' . $_SESSION ['newtoken'].'">
    	<input type="hidden" name="action" value="' . (($action != 'editline') ? 'addline' : 'updateline').'">
    	<input type="hidden" name="mode" value="">
    	<input type="hidden" name="id" value="' . $object->id.'">
    	';

    	if (!empty($conf->use_javascript_ajax)) {
    	    include DOL_DOCUMENT_ROOT.'/core/tpl/ajaxrow.tpl.php';
    	}

    	print '<div class="div-table-responsive-no-min">';
    	if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline'))
    	{
    	    print '<table id="tablelines" class="noborder noshadow" width="100%">';
    	}

    	if (!empty($object->lines))
    	{
    		$object->printObjectLines($action, $mysoc, null, GETPOST('lineid', 'int'), 1);
    	}

    	// Form to add new line
    	if ( $permissiontoadd && $action != 'selectlines')
    	{
    	    if ($action != 'editline')
    	    {
    	        // Add products/services form
    	        $object->formAddObjectLine(1, $mysoc, $soc);

    	        $parameters = array();
    	        $reshook = $hookmanager->executeHooks('formAddObjectLine', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    	    }
    	}

    	if (!empty($object->lines) || ($object->status == $object::STATUS_DRAFT && $permissiontoadd && $action != 'selectlines' && $action != 'editline'))
    	{
    	    print '</table>';
    	}
    	print '</div>';

    	print "</form>\n";
	}


	// Buttons for actions

	if ($action != 'presend' && $action != 'editline') {
    	print '<div class="tabsAction">'."\n";
    	$parameters = array();
    	$reshook = $hookmanager->executeHooks('addMoreActionsButtons', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
    	if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

    	if (empty($reshook))
    	{
    	    // Send
            print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=presend&mode=init#formmailbeforetitle">'.$langs->trans('SendMail').'</a>'."\n";

            // Back to draft
            if ($object->status == $object::STATUS_VALIDATED)
            {
	            if ($permissiontoadd)
	            {
	            	print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=confirm_setdraft&confirm=yes">'.$langs->trans("SetToDraft").'</a>';
	            }
            }

            // Modify
            if ($permissiontoadd)
    		{
    			print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=edit">'.$langs->trans("Modify").'</a>'."\n";
    		}
    		else
    		{
    			print '<a class="butActionRefused classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans('Modify').'</a>'."\n";
    		}

    		// Validate
    		if ($object->status == $object::STATUS_DRAFT)
    		{
	    		if ($permissiontoadd)
	    		{
	    			if (empty($object->table_element_line) || (is_array($object->lines) && count($object->lines) > 0))
	    			{
	    				print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&action=confirm_validate&confirm=yes">'.$langs->trans("Validate").'</a>';
	    			}
	    			else
	    			{
	    				$langs->load("errors");
	    				print '<a class="butActionRefused" href="" title="'.$langs->trans("ErrorAddAtLeastOneLineFirst").'">'.$langs->trans("Validate").'</a>';
	    			}
	    		}
    		}

    		// Clone
    		if ($permissiontoadd)
    		{
    			print '<a class="butAction" href="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'&socid='.$object->socid.'&action=clone&object=rep">'.$langs->trans("ToClone").'</a>'."\n";
    		}

    		/*
    		if ($permissiontoadd)
    		{
    			if ($object->status == $object::STATUS_ENABLED)
    		 	{
    		 		print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=disable">'.$langs->trans("Disable").'</a>'."\n";
    		 	}
    		 	else
    		 	{
    		 		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=enable">'.$langs->trans("Enable").'</a>'."\n";
    		 	}
    		}
    		if ($permissiontoadd)
    		{
    			if ($object->status == $object::STATUS_VALIDATED)
    		 	{
    		 		print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=close">'.$langs->trans("Cancel").'</a>'."\n";
    		 	}
    		 	else
    		 	{
    		 		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=reopen">'.$langs->trans("Re-Open").'</a>'."\n";
    		 	}
    		}
    		*/

    		// Delete (need delete permission, or if draft, just need create/modify permission)
    		if ($permissiontodelete)
    		{
    			print '<a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=delete">'.$langs->trans('Delete').'</a>'."\n";
    		}
    		else
    		{
    			print '<a class="butActionRefused classfortooltip" href="#" title="'.dol_escape_htmltag($langs->trans("NotEnoughPermissions")).'">'.$langs->trans('Delete').'</a>'."\n";
    		}
			print '<div class="fichehalfleft">'."\n";	
			if($user->rights->deviscara->dev->facturer){
				//print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=facturer">'.$langs->trans("Facturer").'</a>'."\n";
				print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=mop">'.$langs->trans("Mise en operation").'</a>'."\n";
		}
			print '</div>'."\n";
    	}
    	print '</div>'."\n";
	}


	// Select mail models is same action as presend
	if (GETPOST('modelselected')) {
		$action = 'presend';
	}

	if ($action != 'presend')
	{
	    print '<div class="fichecenter"><div class="fichehalfleft">';
	    print '<a name="builddoc"></a>'; // ancre

	    //Documents
	    $objref = dol_sanitizeFileName($object->ref);
	    $relativepath = $objref . '/' . $objref . '.pdf';
	    $filedir = $conf->deviscara->dir_output . '/' . $objref;
	    $urlsource = $_SERVER["PHP_SELF"] . "?id=" . $object->id;
	    $genallowed = $user->rights->deviscara->rep->read;	// If you can read, you can build the PDF to read content
	    $delallowed = $user->rights->deviscara->rep->create;	// If you can create/edit, you can remove a file on card
	    $object->modelpdf='soleilsign';
		print $formfile->showdocuments('deviscara', $objref, $filedir, $urlsource, $genallowed, $delallowed, $object->modelpdf, 1, 0, 0, 28, 0, '', '', '', $langs->defaultlang);
		

	    // Show links to link elements
	    $linktoelem = $form->showLinkToObjectBlock($object, null, array('rep'));
	    $somethingshown = $form->showLinkedObjectBlock($object, $linktoelem);


	    print '</div><div class="fichehalfright"><div class="ficheaddleft">';

	    $MAXEVENT = 10;

	    $morehtmlright = '<a href="'.dol_buildpath('/deviscara/rep_agenda.php', 1).'?id='.$object->id.'">';
	    $morehtmlright .= $langs->trans("SeeAll");
	    $morehtmlright .= '</a>';

	    // List of actions on element
	    include_once DOL_DOCUMENT_ROOT.'/core/class/html.formactions.class.php';
	    $formactions = new FormActions($db);
	    $somethingshown = $formactions->showactions($object, $object->element, (is_object($object->thirdparty) ? $object->thirdparty->id : 0), 1, '', $MAXEVENT, '', $morehtmlright);

	    print '</div></div></div>';
	}

	//Select mail models is same action as presend
	// Presend form
	$modelmail='dev';
	$defaulttopic='InformationMessage';
	$diroutput = $conf->deviscara->dir_output;
	$trackid = 'rep'.$object->id;
	$object->modelpdf='soleilsign';
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/core/tpl/card_presend.tpl.php', 1); //'/core/tpl/card_presend.tpl.php';
}

// End of page
llxFooter();
$db->close();
