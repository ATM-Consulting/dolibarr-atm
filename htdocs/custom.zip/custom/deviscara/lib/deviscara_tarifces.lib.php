<?php

//ces

$product= new Product($db);
$product->fetch(24);
$tabtarif['prev']=$product;

$product= new Product($db);
$product->fetch(22);
$tabtarif['pv']['200']=$product; 
$product= new Product($db);
$product->fetch(23);
$tabtarif['pv']['300']=$product;

if($_SESSION['ces']['vol']==200){
	$product= new Product($db);
	$product->fetch(25);
}
elseif($_SESSION['ces']['vol']==300){
	$product= new Product($db);
	$product->fetch(26);
}
$tabtarif['liv'][$_SESSION['ces']['vol']]=$product;

if($_SESSION['ces']['prime']=='oui'){
	// Au 1er Janvier 2023 la prime CTM disparait

	//$tabtarif['pr']['lib']['primectm']=new Product ($db);
	//$tabtarif['pr']['lib']['primectm']->fetch(100);
	$tabtarif['pr']['lib']['primecee']=new Product ($db);
	$tabtarif['pr']['lib']['primecee']->fetch(97);

	if($_SESSION['ces']["vol"]=='200'){
		$tabtarif['b']['pr']['mt']['primecee']=-700;
		//$tabtarif['b']['pr']['mt']['primectm']=-250;
		$tabtarif['j']['pr']['mt']['primecee']=-700;
		//$tabtarif['j']['pr']['mt']['primectm']=-250;
		$tabtarif['v']['pr']['mt']['primecee']=-450;
		//$tabtarif['v']['pr']['mt']['primectm']=-250;
		$tabtarif['r']['pr']['mt']['primecee']=-450;
		//$tabtarif['r']['pr']['mt']['primectm']=-250;
	}
	elseif($_SESSION['ces']["vol"]=='300'){
		$tabtarif['b']['pr']['mt']['primecee']=-750;
		//$tabtarif['b']['pr']['mt']['primectm']=-250;
		$tabtarif['j']['pr']['mt']['primecee']=-750;
		//$tabtarif['j']['pr']['mt']['primectm']=-250;
		$tabtarif['v']['pr']['mt']['primecee']=-450;
		//$tabtarif['v']['pr']['mt']['primectm']=-250;
		$tabtarif['r']['pr']['mt']['primecee']=-450;
		//$tabtarif['r']['pr']['mt']['primectm']=-250;
		
	}	
}


?>