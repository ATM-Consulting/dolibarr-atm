<?php
/* Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    lib/deviscara_rep.lib.php
 * \ingroup deviscara
 * \brief   Library files with common functions for rep
 */

/**
 * Prepare array of tabs for rep
 *
 * @param	rep	$object		rep
 * @return 	array					Array of tabs
 */

function toitPrepareHead($object)
{
	global $db, $langs, $conf;

	$langs->load("deviscara@deviscara");

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/deviscara/toit_card.php", 1).'?id='.$object->id;
	$head[$h][1] = $langs->trans("Card");
	$head[$h][2] = 'card';
	$h++;

	if (isset($object->fields['note_public']) || isset($object->fields['note_private']))
	{
		$nbNote = 0;
		if (!empty($object->note_private)) $nbNote++;
		if (!empty($object->note_public)) $nbNote++;
		$head[$h][0] = dol_buildpath('/deviscara/toit_note.php', 1).'?id='.$object->id;
		$head[$h][1] = $langs->trans('Notes');
		if ($nbNote > 0) $head[$h][1].= '<span class="badge marginleftonlyshort">'.$nbNote.'</span>';
		$head[$h][2] = 'note';
		$h++;
	}


	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@deviscara:/deviscara/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@deviscara:/deviscara/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'rep@deviscara');

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'rep@deviscara', 'remove');

	return $head;
}
function get_tarif($tabsoc=array()){
	
	$tabplafond = array(	//key=nbparts
		
			1=>array(16229=>'b',20805=>'j',29148=>'v'),
			2=>array(23734=>'b',30427=>'j',42848=>'v'),
			3=>array(28545=>'b',36591=>'j',51592=>'v'),
			4=>array(33346=>'b',42748=>'j',60336=>'v'),
			5=>array(38168=>'b',48930=>'j',69081=>'v'),
			6=>array(4813=>'b',6165=>'j',8744=>'v'),
	);

	if(count($tabsoc)>0){
		$nbpart=$tabsoc[0];$rfr=$tabsoc[1];
		if($nbpart<=5 ){ //si proprietaire
			foreach ($tabplafond[$nbpart] as $ressource=>$couleur){
				if($rfr<= $ressource)
					return(array($couleur,$ressource));
			}
			return(array('r',$rfr)); //tarif rose
		}else{
			//todo si supérieur à 6 parts
			foreach($tabplafond[5] as $plafond=>$key){
				$valueurplafond6=array_flip($tabplafond[6]);
				$plafondcalc=$plafond+$valueurplafond6[$key]*($nbpart-5); //on augmente le plafond du tabplafond[6] * ne nombre de personnes supplémentaires à 5.
				if( $rfr<= $plafondcalc )
				return(array($key,$rfr)); 
			}//sinon
			return(array('r',$rfr)); //tarif rose
		}
	}
	else{
		if($_SESSION['nbpart']<=5 ){ //si proprietaire
			foreach ($tabplafond[$_SESSION['nbpart']] as $ressource=>$couleur){
				if($_SESSION['rfr']<= $ressource)
					return $couleur;
			}
			return('r'); //tarif rose
		}else{
			$nbpart=$_SESSION['nbpart'];
			$rfr=$_SESSION['rfr'];
			foreach($tabplafond[5] as $plafond=>$key){
				$valueurplafond6=array_flip($tabplafond[6]);
				$plafondcalc=$plafond+$valueurplafond6[$key]*($nbpart-5); //on augmente le plafond du tabplafond[6] * ne nombre de personnes supplémentaires à 5.
				if( $rfr<= $plafondcalc )
					return($key); //tarif rose
			}//sinon
			return('r'); //tarif rose
		}
	}

	
}

function cumultotal(&$total,$object,$qty=1){
	$total['ttc']+=$object->price_ttc*$qty;
	$total['ht']+=$object->price*$qty;
	$total['tva']+=($object->price*$object->tva_tx*$qty)/100;
	return ($total);
}
function cumulinsertdevis(&$total,$object){
	$total['ttc']+=$object->total_ttc;
	$total['tva']+=$object->total_ttc-$object->total_ht;
	$total['ht']+=$object->total_ht;
	$total['ttc_edf']+=$object->total_ttc_edf;
	$total['tva_edf']+=$object->total_ttc_edf-$object->total_ht_edf;
	$total['ht_edf']+=$object->total_ht_edf;
	return($total);
}