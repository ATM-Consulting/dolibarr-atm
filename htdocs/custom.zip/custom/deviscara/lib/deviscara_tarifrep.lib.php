<?php

//REP
$arraycuvehs=array(''=>'',1=>'1000',2=>'2000',3=>'3000',4=>'4000',5=>'5000');
$arraycuveenterree=array(''=>'',3=>'3000',5=>'5000');
$arrayrobinet=array(''=>'',0=>'0',1=>'1',2=>"2");
$arraywc=array(''=>'',0=>'0',1=>'1',2=>"2",3=>"3",4=>"4");

$tabtarif['pv']['rep']['t1']="<b>FOURNITURES ELIGIBLES SREP</b>";
if($_SESSION['rep']['cuve']==1){
    $product= new Product($db);
    $product->fetch(35);
    $tabtarif['pv']['rep']['cuve']=$product; 
}
elseif($_SESSION['rep']['cuve']==2){
    $product= new Product($db);
    $product->fetch(36);
    $tabtarif['pv']['rep']['cuve']=$product; 
}
if($_SESSION['rep']['position'] =='horssol'){
    if($_SESSION['rep']['cuve']==4  ){
        $product= new Product($db);
        $product->fetch(61);
        $tabtarif['pv']['rep']['cuve']=$product; 
    }
    if($_SESSION['rep']['cuve']==3  ){
        $product= new Product($db);
        $product->fetch(37);
        $tabtarif['pv']['rep']['cuve']=$product; 
    }
    elseif($_SESSION['rep']['cuve']==5 ){
        $product= new Product($db);
        $product->fetch(38);
        $tabtarif['pv']['rep']['cuve']=$product; 
    }
}
if($_SESSION['rep']['position'] =='enterree'){
    if($_SESSION['rep']['cuve']==3  ){
        $product= new Product($db);
        $product->fetch(39);
        $tabtarif['pv']['rep']['cuve']=$product; 
    }
    elseif($_SESSION['rep']['cuve']==5 ){
        $product= new Product($db);
        $product->fetch(40);
        $tabtarif['pv']['rep']['cuve']=$product; 
    }
   
}
$tabtarif['pv']['rep']['t2']="<b>ELEMENTS DE FILTRATION</b>";
$product= new Product($db);
$product->fetch(41);
$tabtarif['pv']['rep']['crap']=$product;

$product= new Product($db);
$product->fetch(44);
$tabtarif['pv']['rep']['fgt']=$product; 

$product= new Product($db);
$product->fetch(42);
$tabtarif['pv']['rep']['gam']=$product; 

if($_SESSION['rep']['pompe'] =='pompeoui'){//si pompe, on ajoute l'installation elec
    $product= new Product($db);
    $product->fetch(43);
    $tabtarif['pv']['rep']['fsp']=$product; 
}

$tabtarif['pv']['rep']['t3']="<b>ELEMENTS DE RACCORDEMENT</b>";

$product= new Product($db);
$product->fetch(45);
$tabtarif['pv']['rep']['cli']=$product; 

$product= new Product($db);
$product->fetch(46);
$tabtarif['pv']['rep']['deriv']=$product;

if($_SESSION['rep']['wc1']>0){ //mantis 326
    $product= new Product($db);
    $product->fetch(52);
    $tabtarif['pv']['rep']['surv']=$product;
}

$tabtarif['pv']['rep']['t4']="<b>DISPOSITIF DE POMPAGE</b>";
$product= new Product($db);
$product->fetch(49);
$tabtarif['pv']['rep']['pompe']=$product;

$tabtarif['pv']['rep']['t5']="<b>ALIMENTATION EN EAU DE PLUIE</b>";

$product= new Product($db);
$product->fetch(47);
$tabtarif['pv']['rep']['rob']=$product; 

$product= new Product($db);
$product->fetch(50);
$tabtarif['pv']['rep']['wcpl']=$product;

$product= new Product($db);
$product->fetch(48);
$tabtarif['pv']['rep']['signal']=$product;
//$tabtarif['pv']['rep']['t6']="DISPOSITIF DE POMPAGE";

//$tabtarif['pv']['rep']['t6']="ALIMENTATION DES WC";

// $product= new Product($db);
// $product->fetch(51);
// $tabtarif['pv']['rep']['wcpot']=$product;

if($_SESSION['rep']['raccord'] =='ttalegout' && $_SESSION['rep']['wc1']>0){ //si nbwc>0 et tout à l'egout // mantis 327
    $product= new Product($db);
    $product->fetch(53);
    $tabtarif['pv']['rep']['cpto']=$product;
}

$tabtarif['pv']['rep']['t7']="<b>INSTALLATION ELIGIBLE SREP</b>";

if($_SESSION['rep']['position'] =='enterree'){
    $product= new Product($db);
    $product->fetch(57);
    $tabtarif['pv']['rep']['cuveent']=$product;
}
else{
    $product= new Product($db);
    $product->fetch(54);
    $tabtarif['pv']['rep']['dalle']=$product;
}
if($_SESSION['rep']['pompe'] =='pompeoui'){//si pompe, on ajoute l'installation elec
    $product= new Product($db);
    $product->fetch(55);
    $tabtarif['pv']['rep']['inselec']=$product;
}
$product= new Product($db);
$product->fetch(56);
$tabtarif['pv']['rep']['lir']=$product;

$product= new Product($db);//lampe UV
$product->fetch(58);
$tabtarif['pv']['rep']['lampeuv']=$product;


$tabtarif['plafond'][1]=400;
$tabtarif['plafond'][2]=500;


if(!isset($rfrc) && $_SESSION['rfr']>0)
    $rfrc=$_SESSION['rfr']/$_SESSION['nbpart']; //rfr calculé

if($rfrc<=9000){ //gp
    $tabtarif['lib2']['srep']= new Product($db);
    $tabtarif['lib2']['srep']->fetch(94);
}
if($rfrc>9000 && $rfrc<=18000){ //p (80%)
    $tabtarif['lib2']['srep']= new Product($db);
    $tabtarif['lib2']['srep']->fetch(116);
    
}
if($rfrc>18000 ){ //HP (50%)
    $tabtarif['lib2']['srep']= new Product($db);
    $tabtarif['lib2']['srep']->fetch(117);
}

// Barème inférieur ou égal à 3000€
if($_SESSION['financement']['totaldevis'] >=1 && $_SESSION['financement']['totaldevis'] <= 3000){
	$tabfin[30] = array(12 => 0.09052, 24 => 0.04862, 36 => 0.03433, 48 => 0.02727, 60 => 0.02311, 72 => 0.02035, 84 => 0.0184);
    $tabfin[90] = array(12 => 0.09233, 24 => 0.04953, 36 => 0.03497, 48 => 0.02778, 60 => 0.02354, 72 => 0.02073, 84 => 0.01874);
}
// Barème entre 3001€ et 6000€
if($_SESSION['financement']['totaldevis'] >=3001 && $_SESSION['financement']['totaldevis'] <= 6000){
	$tabfin[30] = array(10 => 0.10506, 12 => 0.08833, 18 => 0.06251, 24 => 0.04841, 36 => 0.034138, 48 => 0.02707, 60 => 0.0229, 72 => 0.02014, 84 => 0.01818, 96 => 0.01685);
    $tabfin[90] = array(10 => 0.1079, 12 => 0.0907, 18 => 0.0642, 24 => 0.04974, 36 => 0.035054, 48 => 0.0278, 60 => 0.023522, 72 => 0.020679, 84 => 0.018667, 96 => 0.01729);
}
// Barème supérieur à 6000€
if($_SESSION['financement']['totaldevis'] >= 6001){
	$tabfin[30] = array(10 => 0.102977, 12 => 0.086268, 18 => 0.060404, 24 => 0.0463139, 36 => 0.03197, 48 => 0.024857, 60 => 0.020629, 72 => 0.017807, 84 => 0.01578, 96 => 0.014372, 108 => 0.01315, 120 => 0.012119, 132 => 0.0114, 144 => 0.01075, 156 => 0.010201, 168 => 0.009736, 180 => 0.00934);
    $tabfin[90] = array(10 => 0.104624, 12 => 0.087542, 18 => 0.06137, 24 => 0.047055, 36 => 0.032486, 48 => 0.025254, 60 => 0.02096, 72 => 0.01809, 84 => 0.016036, 96 => 0.014602, 108 => 0.013364, 120 => 0.012379, 132 => 0.01157, 144 => 0.01092, 156 => 0.010363, 168 => 0.00989, 180 => 0.00948);
}
?>