<?php

//ISO
$product= new Product($db);
$product->fetch(29); // 29 => ISO-LV
$tabtarif['pv']['iso']=$product; 

//remise iso
$product= new Product($db);
$product->fetch(31); // 31 => CARA-ISO
$tabtarif['pv']['remise']=$product; 
	
// devis commerciaux
$tabtarif['b']['pr']['primeedf'] = new Product ($db);
$tabtarif['b']['pr']['primeedf']->fetch(99); // 101 => b-PRIME_EDF
$tabtarif['j']['pr']['primeedf']=new Product ($db);
$tabtarif['j']['pr']['primeedf']->fetch(110); // 113 => j-PRIME_EDF
$tabtarif['v']['pr']['primeedf']=new Product ($db);
$tabtarif['v']['pr']['primeedf']->fetch(108); // 114 => v-PRIME_EDF
$tabtarif['r']['pr']['primeedf']=new Product ($db);
$tabtarif['r']['pr']['primeedf']->fetch(109); // 115 => r-PRIME_EDF
	

?>