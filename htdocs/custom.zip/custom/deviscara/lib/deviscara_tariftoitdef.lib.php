<?php
//0=client
//1=edf
//2 =MPR
$product= new Product($db);
$product->fetch(1);
$tabtarif['forfait'][0]['previsite']=$product;
$tabtarif['forfait'][1]['previsite']=$product;
$product= new Product($db); //LIV_MAT
$product->fetch(283);
$tabtarif['forfait'][0]['livraison']=$product;
$tabtarif['forfait'][1]['livraison']=$product;
if($object_soc->array_options['options_cara_type_client']==5){//HPR
	if($_SESSION['toitdef']['tole']){
		$product= new Product($db);
		$product->fetch($_SESSION['toitdef']['tole']);
		$tabtarif['pv'][0]['tole']=$product; 
		$product= new Product($db);
		if($_SESSION['toitdef']['tole'] ==28){
			$product->fetch(301);
		}
		if($_SESSION['toitdef']['tole'] ==27){
			$product->fetch(302);
		}
		else
			$product->fetch($_SESSION['toitdef']['tole']);
		$tabtarif['pv'][1]['tole']=$product; 
	}
	
	if($_SESSION['client']['isolation']==1){//si isolée
		$product= new Product($db);
		$product->fetch(278);//MOT4
		$tabtarif['pv'][0]['posetole']=$product;
		$tabtarif['pv'][1]['posetole']=$product;
	}
}
elseif ($object_soc->array_options['options_cara_type_client']==1){//HPV
	if($_SESSION['toitdef']['tole'] ){
		$product= new Product($db);
		$product->fetch($_SESSION['toitdef']['tole']);
		$tabtarif['pv'][1]['tole']=$product; 
		//produit spécifique
		$product= new Product($db);
		
		//définition pour edf
		if($_SESSION['toitdef']['tole'] ==2){
			$product->fetch(290);
		}
		elseif($_SESSION['toitdef']['tole'] ==3){
			$product->fetch(292);
		}
		//pour la MI
		else {
			$product->fetch($_SESSION['toitdef']['tole']);
		}
		$tabtarif['pv'][0]['tole']=$product; 
	}
	

	$product= new Product($db); //MOT
	$product_edf= new Product($db); //MOT
	if($_SESSION['client']['isolation']==1){//si isolée
		$product->fetch(282);//MOT8
		$product_edf->fetch(278);//MOT4
		$tabtarif['pv'][0]['posetole']=$product;
		$tabtarif['pv'][1]['posetole']=$product_edf;
	}
	else{
		$product->fetch(281);//MOT7
		$tabtarif['pv'][0]['posetole']=$product;
		unset($tabtarif['pv'][1]['posetole']);
	}
	
}
elseif($object_soc->array_options['options_cara_type_client']==2){ //PJ
	if($_SESSION['toitdef']['tole']){
		$product= new Product($db);
		$product->fetch($_SESSION['toitdef']['tole']);
		$tabtarif['pv'][1]['tole']=$product; 
		//produit spécifique
		$product= new Product($db);
		//définition pour edf
		if($_SESSION['toitdef']['tole'] ==2){
			$product->fetch(290);
		}
		elseif($_SESSION['toitdef']['tole'] ==3){
			$product->fetch(292);
		}
		//pour la MI
		else {
			$product->fetch($_SESSION['toitdef']['tole']);
		}
		
		$tabtarif['pv'][0]['tole']=$product; 
	}
	$product= new Product($db); //MOT
	$product_edf= new Product($db); //MOT
	if($_SESSION['client']['isolation']==1){//si isolée
		$product->fetch(282);//MOT8
		$product_edf->fetch(278);//MOT4
		$tabtarif['pv'][0]['posetole']=$product;
		$tabtarif['pv'][1]['posetole']=$product_edf;
	}
	else{
		$product->fetch(278);//MOT8
		$tabtarif['pv'][0]['posetole']=$product;
		unset($tabtarif['pv'][1]['posetole']);
	}
	
}
elseif($object_soc->array_options['options_cara_type_client']==3){ //GP B
	if($_SESSION['toitdef']['tole']){
		$product= new Product($db);
		$product->fetch($_SESSION['toitdef']['tole']);
		$tabtarif['pv'][0]['tole']=$product; 
		$product= new Product($db);
		$product->fetch($_SESSION['toitdef']['tole']);
		$tabtarif['pv'][1]['tole']=$product; 
	}
	
	$product= new Product($db); //MOT
	$product_edf= new Product($db); //MOT
	if($_SESSION['client']['isolation']==1){//si isolée
		$product->fetch(282);//MOT8
		$product_edf->fetch(278);//MOT4
		$tabtarif['pv'][0]['posetole']=$product;
		$tabtarif['pv'][1]['posetole']=$product_edf;
	}
	else{
		$product->fetch(278);//MOT8
		$tabtarif['pv'][0]['posetole']=$product;
		unset($tabtarif['pv'][1]['posetole']);
	}
	

}

$product= new Product($db);
$product->fetch($_SESSION[$prod][109]);
$tabtarif['pv109'][0]['109']=$product;
$tabtarif['pv109'][1]['109']=$product;
if(in_array($_SESSION['toitdef']['tole'],array(28,27))){
	unset($tabtarif['pv109'][1]); //pas de 109 si MI sélectionnée pour EDF
}

// si professionnel a supprimer
if($object_soc->array_options['options_type_client']==1 && $object_soc->array_options['options_cara_type_client']!=5){//MO109
	$product= new Product($db);
	$product->fetch(285);
	$tabtarif['pv109'][0]['pose109']=$product;
	unset($tabtarif['pv109'][1]['pose109']);
}

if($_SESSION['client']['isolation']==1 && $object_soc->array_options['options_cara_type_client']!=5){ //isole=oui
	$product= new Product($db);
	$product->fetch($_SESSION[$prod][106]);
	$tabtarif['pv106'][0]['106']=$product;
	unset($tabtarif['pv106'][1]['106']);
}
elseif($_SESSION['client']['isolation']==1 && $object_soc->array_options['options_cara_type_client']==5){
	unset($tabtarif['pv106'][0]['106']);
	unset($tabtarif['pv106'][1]['106']);
}
else{
	$product= new Product($db);
	$product->fetch($_SESSION[$prod][106]);
	$tabtarif['pv106'][0]['106']=$product;
	$tabtarif['pv106'][1]['106']=$product;
}

//si professionnel a supprimer
if($object_soc->array_options['options_type_client']==1 && $object_soc->array_options['options_cara_type_client']!=5){//MO106
	$product= new Product($db);
	$product->fetch(287);
	$tabtarif['pv106'][0]['pose106']=$product;
	unset($tabtarif['pv106'][1]['pose106']);
}

//b->3 j->2 v->1 r->5
$tabtarif['3']['pr']['MPR109']=new Product ($db);
$tabtarif['3']['pr']['MPR109']->fetch(96);
$tabtarif['3']['pr']['MPR106']=new Product ($db);
$tabtarif['3']['pr']['MPR106']->fetch(102);

$tabtarif['3']['pr']['EDF109']=new Product ($db);
$tabtarif['3']['pr']['EDF109']->fetch(98);
if($_SESSION['client']['isolation']==2){
	$tabtarif['3']['pr']['EDF106']=new Product ($db);
	$tabtarif['3']['pr']['EDF106']->fetch(99);
}
$tabtarif['2']['pr']['MPR109']=new Product ($db);
$tabtarif['2']['pr']['MPR109']->fetch(103);
$tabtarif['2']['pr']['MPR106']=new Product ($db);
$tabtarif['2']['pr']['MPR106']->fetch(105);

$tabtarif['2']['pr']['EDF109']=new Product ($db);
$tabtarif['2']['pr']['EDF109']->fetch(107);
if($_SESSION['client']['isolation']==2){
	$tabtarif['2']['pr']['EDF106']=new Product ($db);
	$tabtarif['2']['pr']['EDF106']->fetch(110);
}
$tabtarif['1']['pr']['MPR109']=new Product ($db);
$tabtarif['1']['pr']['MPR109']->fetch(104);
$tabtarif['1']['pr']['MPR106']=new Product ($db);
$tabtarif['1']['pr']['MPR106']->fetch(106);

$tabtarif['1']['pr']['EDF109']=new Product ($db);
$tabtarif['1']['pr']['EDF109']->fetch(108);
if($_SESSION['client']['isolation']==2){
	$tabtarif['1']['pr']['EDF106']=new Product ($db);
	$tabtarif['1']['pr']['EDF106']->fetch(111);
}


$tabtarif['5']['pr']['EDF109']=new Product ($db);
$tabtarif['5']['pr']['EDF109']->fetch(109);
if($_SESSION['client']['isolation']==2){
	$tabtarif['5']['pr']['EDF106']=new Product ($db);
	$tabtarif['5']['pr']['EDF106']->fetch(112);
}



if($_SESSION[$prod]['metragecharpente']>0){
	
	if($_SESSION[$prod]['type_primech']=='1'){//charpente sdd
		$product= new Product($db);
		$product->fetch(10);
		$tabtarif['option'][0]['char']=$product; 	
	}
	elseif($_SESSION[$prod]['type_primech']=='2'){ //empannage
		$product= new Product($db);
		$product->fetch(11);
		$tabtarif['option'][0]['char']=$product; 	
	}
	elseif($_SESSION[$prod]['type_primech']=='3'){//liteunage
		$product= new Product($db);
		$product->fetch(12);
		$tabtarif['option'][0]['char']=$product; 
	}	
}
if($_SESSION[$prod]['metragegouttieres']>0){
		$product= new Product($db);
		$product->fetch(13);
		$tabtarif['option'][0]['gouttiere']=$product; 
}
if($_SESSION[$prod]['metragefauxplafond']>0){
	if($_SESSION[$prod]['type_primefp']=='fpaparente'){
		$product= new Product($db);
		$product->fetch(17);
		$tabtarif['option'][0]['fp']=$product;
	}
	elseif($_SESSION[$prod]['type_primefp']=='fprampante'){
		$product= new Product($db);
		$product->fetch(18);
		$tabtarif['option'][0]['fp']=$product;
	}
	elseif($_SESSION[$prod]['type_primefp']=='fpossature'){
		$product= new Product($db);
		$product->fetch(19);
		$tabtarif['option'][0]['fp']=$product;
	}	
}
if($_SESSION[$prod]['metragechenaux']>0){
	if($_SESSION[$prod]['type_primechen']=='1'){ //suppression
		$product= new Product($db);
		$product->fetch(20);
		$tabtarif['option'][0]['chen']=$product;
	}
	elseif($_SESSION[$prod]['type_primechen']=='2'){ //etanche
		$product= new Product($db);
		$product->fetch(21);
		$tabtarif['option'][0]['chen']=$product;
	}
}

if($_SESSION[$prod]['chienassisnb']>0){
	$product= new Product($db);
	$product->fetch(303);
	$tabtarif['option'][0]['chienassis']=$product;
}
if($_SESSION[$prod]['pvtypedepose']==1){
	$product= new Product($db);
	$product->fetch(306);
	$tabtarif['option'][0]['nbpanneaux']=$product;
}
if($_SESSION[$prod]['pvtypedepose']==2){
	$product= new Product($db);
	$product->fetch(298);
	$tabtarif['option'][0]['nbpanneaux']=$product;
}

if($_SESSION[$prod]['cesdepose']==1){
	$product= new Product($db);
	$product->fetch(300);
	$tabtarif['option'][0]['cesdepose']=$product;
}
if($_SESSION[$prod]['cesdepose']==2){
	$product= new Product($db);
	$product->fetch(304);
	$tabtarif['option'][0]['cesdepose']=$product;
}

// Barème inférieur ou égal à 3000€
if($_SESSION['financement']['total'] >=1 && $_SESSION['financement']['total'] <= 3000){
	$tabfin[30] = array(12 => 0.09052, 24 => 0.04862, 36 => 0.03433, 48 => 0.02727, 60 => 0.02311, 72 => 0.02035, 84 => 0.0184);
    $tabfin[90] = array(12 => 0.09233, 24 => 0.04953, 36 => 0.03497, 48 => 0.02778, 60 => 0.02354, 72 => 0.02073, 84 => 0.01874);
}
// Barème entre 3001€ et 6000€
if($_SESSION['financement']['total'] >=3001 && $_SESSION['financement']['total'] <= 6000){
	$tabfin[30] = array(10 => 0.10506, 12 => 0.08833, 18 => 0.06251, 24 => 0.04841, 36 => 0.034138, 48 => 0.02707, 60 => 0.0229, 72 => 0.02014, 84 => 0.01818, 96 => 0.01685);
	$tabfin[90] = array(10 => 0.1079, 12 => 0.0907, 18 => 0.0642, 24 => 0.04974, 36 => 0.035054, 48 => 0.0278, 60 => 0.023522, 72 => 0.020679, 84 => 0.018667, 96 => 0.01729);
}
// Barème supérieur à 6000€
if($_SESSION['financement']['total'] >= 6001){
	$tabfin[30] = array(10 => 0.102977, 12 => 0.086268, 18 => 0.060404, 24 => 0.0463139, 36 => 0.03197, 48 => 0.024857, 60 => 0.020629, 72 => 0.017807, 84 => 0.01578, 96 => 0.014372, 108 => 0.01315, 120 => 0.012119, 132 => 0.0114, 144 => 0.01075, 156 => 0.010201, 168 => 0.009736, 180 => 0.00934);
	$tabfin[90] = array(10 => 0.104624, 12 => 0.087542, 18 => 0.06137, 24 => 0.047055, 36 => 0.032486, 48 => 0.025254, 60 => 0.02096, 72 => 0.01809, 84 => 0.016036, 96 => 0.014602, 108 => 0.013364, 120 => 0.012379, 132 => 0.01157, 144 => 0.01092, 156 => 0.010363, 168 => 0.00989, 180 => 0.00948);
}
?>
