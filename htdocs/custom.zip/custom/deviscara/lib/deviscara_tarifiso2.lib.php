<?php

//remise iso à améliorer car ne s'affiche pas automatiquement sur le ISO2301-0335
$product = new Product($db);
$product->fetch(31); // 31 => CARA-ISO
$tabtarif['pv']['remise'] = $product;

// Liste des produits disponible
// IBR
$isor = new Product($db);
$isor->fetch(8); // 8 => IBR

// ISO-LV
$isolv = new Product($db);
$isolv->fetch(29); // 29 => ISO-LV

// ISO-LR
$isolr = new Product($db);
$isolr->fetch(63); // 63 => ISO-LR

// ISO-DR
$isodr = new Product($db);
$isodr->fetch(64); // 64 => ISO-DR

// ISO-S
$isos = new Product($db);
$isos->fetch(65); // 65 => ISO-S

// AIRFLEX
$isoa = new Product($db);
$isoa->fetch(6); // 6 => AIRFLEX

// ATF
$isot = new Product($db);
$isot->fetch(223); // 223 => ATF

// ISOCONF
$isoc = new Product($db);
$isoc->fetch(277); // 311=> ISOCONF (311 en base test et 277 en base prod.

// scénario dans multi
$multi = array('e61' => $isolv, 'e62' => $isolr, 'e63' => $isodr, 'e63' => $isor, 'e63' => $isoc); // Ajouter isoc
$multiedf = array('e61' => $isolv, 'e62' => $isolr); // Pour la gestion R
$multimpr = array('m91' => $isot, 'm92' => $isoa);
$multiedfneuf = array('e61' => $isolv, 'e62' => $isolr, 'e63' => $isoc); // gestion d'une maison neuve.
$multimpriso = array('e62' => $isor, 'e63' => $isodr);
$multinoniso = array('e62' => $isor,'e63' => $isoc); // IBR + ISOCONF


// Items produits composant la facture
$previsite = new Product($db);
$previsite->fetch(1); // 1=> PREVI-T
//
$mor = new Product($db);
$mor->fetch(9); // 9=> MOIBR
//
$mo106 = new Product($db);
$mo106->fetch(287); // 287 => MO106
//
$moa = new Product($db);
$moa->fetch(7); // 7=> MOAIRFLEX
//
$mot = new Product($db);
$mot->fetch(285); // avant il y avait l'ID du produit 66 ||  285 => MO109


$tabproduct = array(
    1 => array( //status_immo Proprietaire
        1 => array(//2ans+
            1 => array(//isolation oui
                'b' => array('e6' => '', 'e9' => $isoa, 'm6' => $multinoniso, 'm9' => $multimpr),
                'j' => array('e6' => '', 'e9' => $isoa, 'm6' => $multinoniso, 'm9' => $multimpr),
                'v' => array('e6' => '', 'e9' => $isoa, 'm6' => $multinoniso, 'm9' => $multimpr),
                'r' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
            2 => array(//isolation non
                'b' => array('e6' => $multi, 'e9' => $isoa, 'm6' => $isor, 'm9' => $multimpr),
                'j' => array('e6' => $multi, 'e9' => $isoa, 'm6' => $isor, 'm9' => $multimpr),
                'v' => array('e6' => $multi, 'e9' => $isoa, 'm6' => $isor, 'm9' => $multimpr),
                'r' => array('e6' => $multiedf, 'e9' => '', 'm6' => '', 'm9' => ''), //
            ),
        ),
        2 => array(//2ans-
            1 => array(//isolation oui
                'b' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'j' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'v' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'r' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
            2 => array(//isolation non
                'b' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'j' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'v' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'r' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
        )
    ),
    2 => array( //status_immo Locataire
        1 => array(//2ans+
            1 => array(//isolation oui
                'b' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'j' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'v' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'r' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
            2 => array(//isolation non
                'b' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'j' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'v' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'r' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
        ),
        2 => array(//2ans-
            1 => array(//isolation oui
                'b' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'j' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'v' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'r' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
            2 => array(//isolation non
                'b' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'j' => array('e6' => $multiedfneuf, 'e9' => '', 'm6' => '', 'm9' => ''),
                'v' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
                'r' => array('e6' => '', 'e9' => '', 'm6' => '', 'm9' => ''),
            ),
        )
    )//prop
);

// Tableau des MO
$tabmo = array('e6' => '', 'e62' => $mo106, 'e63' => $mo106, 'e9' => $moa, 'm6' => $mor, 'm9' => $moa, 'm91' => $mot, 'm92' => $moa,);

// devis peter
$tabtarif['lib']['priseencharge'] = 'Prise en charge';
//prime edf produit fk_product 66 => 285
$tabtarif['b']['pr']['primeedf'][66] = new Product ($db);
$tabtarif['b']['pr']['primeedf'][66]->fetch(99); //101 => b-PRIME_EDF  | mettre 99

$tabtarif['j']['pr']['primeedf'][66] = new Product ($db);
$tabtarif['j']['pr']['primeedf'][66]->fetch(113); // 113 => j-PRIME_EDF

$tabtarif['v']['pr']['primeedf'][66] = new Product ($db);
$tabtarif['v']['pr']['primeedf'][66]->fetch(114); // 114 => v-PRIME_EDF

$tabtarif['r']['pr']['primeedf'][66] = new Product ($db);
$tabtarif['r']['pr']['primeedf'][66]->fetch(115); // 115 => r-PRIME_EDF


//PRIMES
/*
 Ce code PHP vérifie si le prospect est propriétaire et si la maison à plus de 2 ans. Si c'est le cas, il crée
 des primes pour les propriétaires, les P.E.E et les MPR. Les produits sont récupérés à partir d'une base de
 données et sont stockés dans un tableau appelé "prime".
*/
if ($_SESSION['status_immo'] == 1) { // si proprietaire
    if ($_SESSION['iso2']['maisonplus2'] == 1) { //si maison plus 2 ans
        //E9
        $prime['b'][$isoa->id]['e9'] = new Product ($db);
        $prime['b'][$isoa->id]['e9']->fetch(98); // 98 => b-P.E.E_PRS_BAR-EN-109
        $prime['b'][$isot->id]['e9'] = new Product ($db);
        $prime['b'][$isot->id]['e9']->fetch(98); // 98 => b-P.E.E_PRS_BAR-EN-109
        //M9
        $prime['b'][$isoa->id]['m9'] = new Product ($db);
        $prime['b'][$isoa->id]['m9']->fetch(96); // 96 => b-MPR_PRS_BAR-EN-109
        $prime['b'][$isot->id]['m9'] = new Product ($db);
        $prime['b'][$isot->id]['m9']->fetch(96); // 96 => b-MPR_PRS_BAR-EN-109
        //M6
        $prime['b'][$isor->id]['m6'] = new Product ($db);
        $prime['b'][$isor->id]['m6']->fetch(102); // 102 => b-MPR_Rampant_BAR-EN-106
        $prime['b'][$isodr->id]['m6'] = new Product ($db);
        $prime['b'][$isodr->id]['m6']->fetch(102); // 102 => b-MPR_Rampant_BAR-EN-106
        $prime['b'][$isoc->id]['m6'] = new Product ($db);
        $prime['b'][$isoc->id]['m6']->fetch(102); // 102 => b-MPR_Rampant_BAR-EN-106
        //E9
        $prime['j'][$isoa->id]['e9'] = new Product ($db);
        $prime['j'][$isoa->id]['e9']->fetch(107); // 107 => j-P.E.E_PRS_BAR-EN-109
        $prime['j'][$isot->id]['e9'] = new Product ($db);
        $prime['j'][$isot->id]['e9']->fetch(107); // 107 => j-P.E.E_PRS_BAR-EN-109
        //M9
        $prime['j'][$isoa->id]['m9'] = new Product ($db);
        $prime['j'][$isoa->id]['m9']->fetch(103); // 103 => j-MPR_PRS_BAR-EN-109
        $prime['j'][$isot->id]['m9'] = new Product ($db);
        $prime['j'][$isot->id]['m9']->fetch(103); // 103 => j-MPR_PRS_BAR-EN-109
        //M6
        $prime['j'][$isor->id]['m6'] = new Product ($db);
        $prime['j'][$isor->id]['m6']->fetch(105); // 105 => j-MPR_Rampant_BAR-EN-106
        $prime['j'][$isodr->id]['m6'] = new Product ($db);
        $prime['j'][$isodr->id]['m6']->fetch(105); // 105 => j-MPR_Rampant_BAR-EN-106
        $prime['j'][$isoc->id]['m6'] = new Product ($db);
        $prime['j'][$isoc->id]['m6']->fetch(105); // 105 => j-MPR_Rampant_BAR-EN-106
        //E9
        $prime['v'][$isoa->id]['e9'] = new Product ($db);
        $prime['v'][$isoa->id]['e9']->fetch(108); // 108 => v-P.E.E_PRS_BAR-EN-109
        $prime['v'][$isot->id]['e9'] = new Product ($db);
        $prime['v'][$isot->id]['e9']->fetch(108); // 108 => v-P.E.E_PRS_BAR-EN-109
        //M9
        $prime['v'][$isoa->id]['m9'] = new Product ($db);
        $prime['v'][$isoa->id]['m9']->fetch(104); // 104 => v-MPR_PRS_BAR-EN-109
        $prime['v'][$isot->id]['m9'] = new Product ($db);
        $prime['v'][$isot->id]['m9']->fetch(104); // 104 => v-MPR_PRS_BAR-EN-109
        //M6
        $prime['v'][$isor->id]['m6'] = new Product ($db);
        $prime['v'][$isor->id]['m6']->fetch(106); // 106 => v-MPR_Rampant_BAR-EN-106
        $prime['v'][$isodr->id]['m6'] = new Product ($db);
        $prime['v'][$isodr->id]['m6']->fetch(106); // 106 => v-MPR_Rampant_BAR-EN-106
        $prime['v'][$isoc->id]['m6'] = new Product ($db);
        $prime['v'][$isoc->id]['m6']->fetch(106); // 106 => v-MPR_Rampant_BAR-EN-106

        if ($_SESSION['iso2']["isocomble"] == '2') { //non isolé
            // B- E6
            $prime['b'][$isos->id]['e6'] = new Product ($db);
            $prime['b'][$isos->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isodr->id]['e6'] = new Product ($db);
            $prime['b'][$isodr->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isor->id]['e6'] = new Product ($db);
            $prime['b'][$isor->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolv->id]['e6'] = new Product ($db);
            $prime['b'][$isolv->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolr->id]['e6'] = new Product ($db);
            $prime['b'][$isolr->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isoc->id]['e6'] = new Product ($db);
            $prime['b'][$isoc->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            // B- E9
            $prime['b'][$isoa->id]['e9'] = new Product ($db);
            $prime['b'][$isoa->id]['e9']->fetch(98); // 98 => b-P.E.E_PRS_BAR-EN-109
            $prime['b'][$isot->id]['e9'] = new Product ($db);
            $prime['b'][$isot->id]['e9']->fetch(98); // 98 => b-P.E.E_PRS_BAR-EN-109
            // B- M6
            $prime['b'][$isor->id]['m6'] = new Product ($db);
            $prime['b'][$isor->id]['m6']->fetch(102); // 102 => b-MPR_Rampant_BAR-EN-106
            $prime['b'][$isoc->id]['m6'] = new Product ($db);
            $prime['b'][$isoc->id]['m6']->fetch(102); // 102 => b-MPR_Rampant_BAR-EN-106
            // B- M9
            $prime['b'][$isoa->id]['m9'] = new Product ($db);
            $prime['b'][$isoa->id]['m9']->fetch(96); // 96 => b-MPR_PRS_BAR-EN-109
            $prime['b'][$isot->id]['m9'] = new Product ($db);
            $prime['b'][$isot->id]['m9']->fetch(96); // 96 => b-MPR_PRS_BAR-EN-109
            // J- E6
            $prime['j'][$isos->id]['e6'] = new Product ($db);
            $prime['j'][$isos->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isodr->id]['e6'] = new Product ($db);
            $prime['j'][$isodr->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isor->id]['e6'] = new Product ($db);
            $prime['j'][$isor->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolv->id]['e6'] = new Product ($db);
            $prime['j'][$isolv->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolr->id]['e6'] = new Product ($db);
            $prime['j'][$isolr->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isoc->id]['e6'] = new Product ($db);
            $prime['j'][$isoc->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            // J- E9
            $prime['j'][$isoa->id]['e9'] = new Product ($db);
            $prime['j'][$isoa->id]['e9']->fetch(107); // 107 => j-P.E.E_PRS_BAR-EN-109
            $prime['j'][$isot->id]['e9'] = new Product ($db);
            $prime['j'][$isot->id]['e9']->fetch(107); // 107 => j-P.E.E_PRS_BAR-EN-109
            // J- M6
            $prime['j'][$isor->id]['m6'] = new Product ($db);
            $prime['j'][$isor->id]['m6']->fetch(105); // 110 => j-MPR_Rampant_BAR-EN-106
            $prime['j'][$isoc->id]['m6'] = new Product ($db);
            $prime['j'][$isoc->id]['m6']->fetch(105); // 110 => j-MPR_Rampant_BAR-EN-106
            // J- M9
            $prime['j'][$isoa->id]['m9'] = new Product ($db);
            $prime['j'][$isoa->id]['m9']->fetch(103); // 103 => j-MPR_PRS_BAR-EN-109
            $prime['j'][$isot->id]['m9'] = new Product ($db);
            $prime['j'][$isot->id]['m9']->fetch(103); // 103 => j-MPR_PRS_BAR-EN-109
            // V- E6
            $prime['v'][$isos->id]['e6'] = new Product ($db);
            $prime['v'][$isos->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isodr->id]['e6'] = new Product ($db);
            $prime['v'][$isodr->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isor->id]['e6'] = new Product ($db);
            $prime['v'][$isor->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isolv->id]['e6'] = new Product ($db);
            $prime['v'][$isolv->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isolr->id]['e6'] = new Product ($db);
            $prime['v'][$isolr->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isoc->id]['e6'] = new Product ($db);
            $prime['v'][$isoc->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            // V- E9
            $prime['v'][$isoa->id]['e9'] = new Product ($db);
            $prime['v'][$isoa->id]['e9']->fetch(108); // 108 => v-P.E.E_PRS_BAR-EN-109
            $prime['v'][$isot->id]['e9'] = new Product ($db);
            $prime['v'][$isot->id]['e9']->fetch(108); // 108 => v-P.E.E_PRS_BAR-EN-109
            // V- M6
            $prime['v'][$isor->id]['m6'] = new Product ($db);
            $prime['v'][$isor->id]['m6']->fetch(106); // 106 => v-MPR_Rampant_BAR-EN-106
            $prime['v'][$isoc->id]['m6'] = new Product ($db);
            $prime['v'][$isoc->id]['m6']->fetch(106); // 106 => v-MPR_Rampant_BAR-EN-106
            // V- M9
            $prime['v'][$isoa->id]['m9'] = new Product ($db);
            $prime['v'][$isoa->id]['m9']->fetch(104); // 104 => m-MPR_PRS_BAR-EN-109
            $prime['v'][$isot->id]['m9'] = new Product ($db);
            $prime['v'][$isot->id]['m9']->fetch(104); // 104 => m-MPR_PRS_BAR-EN-109
            // R- E6
            $prime['r'][$isolv->id]['e6'] = new Product ($db);
            $prime['r'][$isolv->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106
            $prime['r'][$isolr->id]['e6'] = new Product ($db);
            $prime['r'][$isolr->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106
        }
    }

    /*
     Si la maison a moins de 2 ans et n'est pas isolée, ce code PHP crée 4 nouveaux produits à partir de la base de données
     et les stocke dans un tableau appelé "prime". Les produits sont identifiés par leurs identifiants 99, 110, 111 et 112.
    */
    if ($_SESSION['iso2']['maisonplus2'] == 2) { //si maison moins 2 ans
        if ($_SESSION['iso2']["isocomble"] == '2') {//si pas isole
            // B - E6
            $prime['b'][$isos->id]['e6'] = new Product ($db);
            $prime['b'][$isos->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolv->id]['e6'] = new Product ($db);
            $prime['b'][$isolv->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolr->id]['e6'] = new Product ($db);
            $prime['b'][$isolr->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isoc->id]['e6'] = new Product ($db);
            $prime['b'][$isoc->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            // J - E6
            $prime['j'][$isos->id]['e6'] = new Product ($db);
            $prime['j'][$isos->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolv->id]['e6'] = new Product ($db);
            $prime['j'][$isolv->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolr->id]['e6'] = new Product ($db);
            $prime['j'][$isolr->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isoc->id]['e6'] = new Product ($db);
            $prime['j'][$isoc->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
        }
    }
}

/*
 Si la session de statut immobilier est égale à 2 (locataire) et que la maison a plus de 2 ans et que l'isolation est
 complète, alors créer des produits pour les différents types de primes (b, j, v et r) et les récupérer à partir de la
 base de données.
*/
if ($_SESSION['status_immo'] == 2) { // si locataire
    if ($_SESSION['iso2']['maisonplus2'] == 1) { //si maison plus 2 ans
        if ($_SESSION['iso2']["isocomble"] == '2') {
            // B- E6
            $prime['b'][$isos->id]['e6'] = new Product ($db);
            $prime['b'][$isos->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolv->id]['e6'] = new Product ($db);
            $prime['b'][$isolv->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolr->id]['e6'] = new Product ($db);
            $prime['b'][$isolr->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isoc->id]['e6'] = new Product ($db);
            $prime['b'][$isoc->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            // J- E6
            $prime['j'][$isos->id]['e6'] = new Product ($db);
            $prime['j'][$isos->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolv->id]['e6'] = new Product ($db);
            $prime['j'][$isolv->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolr->id]['e6'] = new Product ($db);
            $prime['j'][$isolr->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isoc->id]['e6'] = new Product ($db);
            $prime['j'][$isoc->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            // V- E6
            $prime['v'][$isos->id]['e6'] = new Product ($db);
            $prime['v'][$isos->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isolv->id]['e6'] = new Product ($db);
            $prime['v'][$isolv->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isolr->id]['e6'] = new Product ($db);
            $prime['v'][$isolr->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            $prime['v'][$isoc->id]['e6'] = new Product ($db);
            $prime['v'][$isoc->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            // R- E6
            $prime['r'][$isos->id]['e6'] = new Product ($db);
            $prime['r'][$isos->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106
            $prime['r'][$isolv->id]['e6'] = new Product ($db);
            $prime['r'][$isolv->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106
            $prime['r'][$isolr->id]['e6'] = new Product ($db);
            $prime['r'][$isolr->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106
            $prime['r'][$isoc->id]['e6'] = new Product ($db);
            $prime['r'][$isoc->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106

        }
    }


    if ($_SESSION['iso2']['maisonplus2'] == 2) { //si maison moins 2 ans
        if ($_SESSION['iso2']["isocomble"] == '2') {//si pas isole
            // B- E6
            $prime['b'][$isos->id]['e6'] = new Product ($db);
            $prime['b'][$isos->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolv->id]['e6'] = new Product ($db);
            $prime['b'][$isolv->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isolr->id]['e6'] = new Product ($db);
            $prime['b'][$isolr->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            $prime['b'][$isoc->id]['e6'] = new Product ($db);
            $prime['b'][$isoc->id]['e6']->fetch(99); // 99 => b-P.E.E_Rampant_BAR-EN-106
            // J- E6
            $prime['j'][$isos->id]['e6'] = new Product ($db);
            $prime['j'][$isos->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolv->id]['e6'] = new Product ($db);
            $prime['j'][$isolv->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isolr->id]['e6'] = new Product ($db);
            $prime['j'][$isolr->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            $prime['j'][$isoc->id]['e6'] = new Product ($db);
            $prime['j'][$isoc->id]['e6']->fetch(110); // 110 => j-P.E.E_Rampant_BAR-EN-106
            // V- E6
//            $prime['v'][$isos->id]['e6'] = new Product ($db);
//            $prime['v'][$isos->id]['e6']->fetch(111); // 111 => v-P.E.E_Rampant_BAR-EN-106
            // R- E6
//            $prime['r'][$isos->id]['e6'] = new Product ($db);
//            $prime['r'][$isos->id]['e6']->fetch(112); // 112 => r-P.E.E_Rampant_BAR-EN-106
        }
    }
}

?>