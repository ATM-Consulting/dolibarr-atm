<?php
/* Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    lib/deviscara_facrep.lib.php
 * \ingroup deviscara
 * \brief   Library files with common functions for facrep
 */

/**
 * Prepare array of tabs for facrep
 *
 * @param	facrep	$object		facrep
 * @return 	array					Array of tabs
 */
function facrepPrepareHead($object)
{
	global $db, $langs, $conf;

	$langs->load("deviscara@deviscara");

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/deviscara/facrep_card.php", 1).'?id='.$object->id;
	$head[$h][1] = $langs->trans("Card");
	$head[$h][2] = 'card';
	$h++;

	if (isset($object->fields['note_public']) || isset($object->fields['note_private']))
	{
		$nbNote = 0;
		if (!empty($object->note_private)) $nbNote++;
		if (!empty($object->note_public)) $nbNote++;
		$head[$h][0] = dol_buildpath('/deviscara/facrep_note.php', 1).'?id='.$object->id;
		$head[$h][1] = $langs->trans('Notes');
		if ($nbNote > 0) $head[$h][1].= '<span class="badge marginleftonlyshort">'.$nbNote.'</span>';
		$head[$h][2] = 'note';
		$h++;
	}

	require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';
	require_once DOL_DOCUMENT_ROOT.'/core/class/link.class.php';
	$upload_dir = $conf->deviscara->dir_output . "/facrep/" . dol_sanitizeFileName($object->ref);
	$nbFiles = count(dol_dir_list($upload_dir, 'files', 0, '', '(\.meta|_preview.*\.png)$'));
	$nbLinks=Link::count($db, $object->element, $object->id);
	$head[$h][0] = dol_buildpath("/deviscara/facrep_document.php", 1).'?id='.$object->id;
	$head[$h][1] = $langs->trans('Documents');
	if (($nbFiles+$nbLinks) > 0) $head[$h][1].= '<span class="badge marginleftonlyshort">'.($nbFiles+$nbLinks).'</span>';
	$head[$h][2] = 'document';
	$h++;

	$head[$h][0] = dol_buildpath("/deviscara/facrep_agenda.php", 1).'?id='.$object->id;
	$head[$h][1] = $langs->trans("Events");
	$head[$h][2] = 'agenda';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@deviscara:/deviscara/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@deviscara:/deviscara/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'facrep@deviscara');

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'facrep@deviscara', 'remove');

	return $head;
}

function get_tarif($tabpreca=array()){
	
	$tabplafond = array(	
			1=>array(1=>'4500',2=>'5400',),
			2=>array(1=>'4000',2=>'4800',),
			3=>array(1=>'2500',2=>'3000',)
	);
	if(count($tabpreca)>0){
		$preca=$tabpreca[0];
		if($preca==3){ //b GP
			$plafond=$tabplafond[1][$tabpreca[1]];
			$couleur='b';
		}
		elseif($preca==2){ //j  P
			$plafond=$tabplafond[2][$tabpreca[1]];
			$couleur='j';
		}
		elseif($preca==1 || $preca==5){ //v R  HP
			$couleur='v';
			$plafond=$tabplafond[3][$tabpreca[1]];
		}
		return(array($couleur,$plafond));
	}
	else{
		$qf=$_SESSION['rfr']/$_SESSION['nbpart'];
		if($qf<9000 ) {
			$couleur='b';
			if($_SESSION['rep']['cuve']<5)
				$plafond=$tabplafond[1][1];
			elseif($_SESSION['rep']['cuve']>=5)
				$plafond=$tabplafond[1][2];
		}
		if($qf>=9000 && $qf<=18000) {
			$couleur='j';
			if($_SESSION['rep']['cuve']<5)
				$plafond=$tabplafond[2][1];
			elseif($_SESSION['rep']['cuve']>=5)
				$plafond=$tabplafond[2][2];
		}
		if($qf>18000 ) {
			$couleur='v';
			if($_SESSION['rep']['cuve']<5)
				$plafond=$tabplafond[3][1];
			elseif($_SESSION['rep']['cuve']>=5)
				$plafond=$tabplafond[3][2];
		}
		return array($couleur, $plafond);
	}
}