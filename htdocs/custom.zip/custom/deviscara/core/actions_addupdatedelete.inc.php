<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}

if ($action == 'add2' && !empty($permissiontoadd)){
	$_SESSION['produit']=GETPOST('produit');
	if(in_array($_SESSION['produit'],array('ces')))
		$action='create';
	elseif($_SESSION['produit']=='iso'){
		header("Location: ".dol_buildpath('/deviscara/iso1_card.php',1)."?action=create");
		exit;
	}
	elseif($_SESSION['produit']=='rep'){
		header("Location: ".dol_buildpath('/deviscara/rep_card.php',1)."?action=create");
		exit;
	}
	elseif($_SESSION['produit']=='pv'){
		header("Location: ".dol_buildpath('/deviscara/pv_card.php',1)."?action=create");
		exit;
	}
	elseif($_SESSION['produit']=='toiture'){
		unset($_SESSION['client'],$_SESSION['produit'],$_SESSION['toit'],$_SESSION['toitdef'],$_SESSION['toiture'],$_SESSION['ces'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client'],$_SESSION['iso'],$_SESSION['fk_soc']);
		header("Location: ".dol_buildpath('/deviscara/toit_card.php',1)."?action=create");
		exit;
	}

}
// Action to add record
if ($action == 'add' && !empty($permissiontoadd))
{
	
	if (!$error)
	{	
		$prod=$_SESSION['produit'];
		if(GETPOST('reinit')=='re-initialiser'){
			unset($_SESSION['client'],$_SESSION['produit'],$_SESSION[$prod],$_SESSION['toiture'],$_SESSION['ces'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client'],$_SESSION['iso'],$_SESSION['fk_soc']);
			$action='create2';
		}
		else{
			$_SESSION['nbpart']=GETPOST('nbpart');
			$_SESSION['rfr']=GETPOST('rfr');
			$_SESSION['status_immo']=GETPOST('status_immo');
			$_SESSION['client']=GETPOST('client');
			
			
			$_SESSION['financement']['type']=GETPOST('typefin');
			$_SESSION['fk_soc']=GETPOST('fk_soc');
			$formid=GETPOST('fromid');
			if($formid >0 ){
				$_SESSION['fromid']=$formid; //pour la liaison entre les devis.
			}
			if($_SESSION['produit']=='toiture'){
				
				$_SESSION[$prod]['metrage']=GETPOST('metrage');
				$_SESSION[$prod]['isocomble']=GETPOST('isocomble');
				$_SESSION[$prod]['charpente']=GETPOST('charpente');
				$_SESSION[$prod]['typetole']=GETPOST('typetole');
				$_SESSION[$prod]['type_primech']=GETPOST('type_primech');
				$_SESSION[$prod]['metragecharpente']=GETPOST('metragecharpente');
				$_SESSION[$prod]['metragegouttieres']=GETPOST('metragegouttieres');
				$_SESSION[$prod]['gouttiere']=GETPOST('gouttiere');
				$_SESSION[$prod]['type_primegouttiere']=GETPOST('type_primegouttiere');
				$_SESSION[$prod]['metragefauxplafond']=GETPOST('metragefauxplafond');
				$_SESSION[$prod]['type_primefp']=GETPOST('type_primefp');
				$_SESSION[$prod]['metragechenaux']=GETPOST('metragechenaux');
				$_SESSION[$prod]['type_primechen']=GETPOST('type_primechen');
				$_SESSION[$prod]['vol']=GETPOST('vol');
				$_SESSION[$prod]['prime']=GETPOST('prime');
				$_SESSION[$prod]['idparts']=GETPOST('idparts');
				if($_SESSION[$prod]['vol']>0)
					$_SESSION[$prod]['sproduit']='ces';


			}
			elseif($_SESSION['produit']=='ces'){
				
				$_SESSION[$prod]['vol']=GETPOST('vol');
				$_SESSION[$prod]['prime']=GETPOST('prime');

			}
			elseif($_SESSION['produit']=='iso'){
				$_SESSION[$prod]['metrage']=GETPOST('metrageiso');
				$_SESSION[$prod]['totalremise']=GETPOST('totalremise');
				$_SESSION['financement']['finperso']['code']='ES';
				$_SESSION['financement']['finperso']['nb']=1;
			}
			if($_SESSION['financement']['type']=='fincma'){
				$totaldevis=GETPOST('totaldevis');
				unset($_SESSION['financement']['finperso']);
				$choixfin=explode('/',GETPOST('cmanbmois'));
				$_SESSION['financement']['fincma']['report']=(int)$choixfin[0];
				$_SESSION['financement']['fincma']['nbmois']=(int)$choixfin[1];
				$_SESSION['financement']['fincma'][$choixfin[0]]=(int)$choixfin[1];
				$_SESSION['financement']['fincma']['code']='CMA';
				$_SESSION['financement']['fincma']['nb']=(int)$choixfin[1].'|'.(int)$choixfin[0];
				$_SESSION['financement']['totaldevis']=$totaldevis;
				$_SESSION['financement']['acompte']=GETPOST('acompte');
				$_SESSION['financement']['fincma']['montant']=number_format($choixfin[2],2);

			}
			if($_SESSION['financement']['type']=='finperso'){
				unset($_SESSION['financement']['fincma']);
				$totaldevis=GETPOST('totaldevis');
				$_SESSION['financement']['pencharge']=GETPOST('pencharge');
				$_SESSION['financement']['totaldevis']=$totaldevis;
				$nbch=GETPOST('personbch');
				$nbprelev=GETPOST('personbprelev');
				$bq=GETPOST('persobanque');
				$_SESSION['financement']['acompte']=GETPOST('acompte');
				
				if($nbch>0){
					$_SESSION['financement']['finperso']['nb']=$nbch;
					$_SESSION['financement']['finperso']['code']='CH';
					$_SESSION['financement']['finperso']['montant']=($totaldevis-$_SESSION['financement']['acompte'])/$nbch;
				}
				elseif($nbprelev>0){
					$_SESSION['financement']['finperso']['nb']=$nbprelev;
					$_SESSION['financement']['finperso']['code']='PR';
					$_SESSION['financement']['finperso']['montant']=($totaldevis-$_SESSION['financement']['acompte'])/$nbprelev;
				}
				elseif($bq=='banque'){
					$_SESSION['financement']['finperso']['banque']=1;
				 	$_SESSION['financement']['finperso']['code'] = 'BQ';
					$_SESSION['financement']['finperso']['nb'] = '0';
					$_SESSION['financement']['finperso']['montant']=($totaldevis-$_SESSION['financement']['acompte']);
					
				}
				else {
					unset($_SESSION['financement']['finperso']);
				}
				

			}
		}
	}
	else
	{
		$action = 'create';
	}

}
