<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}


// Action to add record
if ($action == 'add' && !empty($permissiontoadd))
{
	
	if (!$error)
	{	
		$prod=GETPOST('produit');
		if(GETPOST('reinit')=='re-initialiser'){
			unset($_SESSION['client'],$_SESSION['produit'],$_SESSION[$prod],$_SESSION['toiture'],$_SESSION['ces'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client'],$_SESSION['iso']);
		}
		else{
			$_SESSION['nbpart']=GETPOST('nbpart');
			$_SESSION['rfr']=GETPOST('rfr');
			$_SESSION['status_immo']=GETPOST('status_immo');
			$_SESSION['client']=GETPOST('client');
			
			$_SESSION['produit']=GETPOST('produit');
			$_SESSION['financement']['type']=GETPOST('typefin');
			$formid=GETPOST('fromid');
			if($formid >0 ){
				$_SESSION['fromid']=$formid; //pour la liaison entre les devis.
			}
			if($_SESSION['produit']=='toiture'){
				
				$_SESSION[$prod]['metrage']=GETPOST('metrage');
				$_SESSION[$prod]['isocomble']=GETPOST('isocomble');
				$_SESSION[$prod]['charpente']=GETPOST('charpente');
				$_SESSION[$prod]['typetole']=GETPOST('typetole');
				$_SESSION[$prod]['type_primech']=GETPOST('type_primech');
				$_SESSION[$prod]['metragecharpente']=GETPOST('metragecharpente');
				$_SESSION[$prod]['metragegouttieres']=GETPOST('metragegouttieres');
				$_SESSION[$prod]['gouttiere']=GETPOST('gouttiere');
				$_SESSION[$prod]['type_primegouttiere']=GETPOST('type_primegouttiere');
				$_SESSION[$prod]['metragefauxplafond']=GETPOST('metragefauxplafond');
				$_SESSION[$prod]['type_primefp']=GETPOST('type_primefp');
				$_SESSION[$prod]['metragechenaux']=GETPOST('metragechenaux');
				$_SESSION[$prod]['type_primechen']=GETPOST('type_primechen');
				$_SESSION[$prod]['vol']=GETPOST('vol');
				$_SESSION[$prod]['prime']=GETPOST('prime');
				if($_SESSION[$prod]['vol']>0)
					$_SESSION[$prod]['sproduit']='ces';


			}
			elseif($_SESSION['produit']=='ces'){
				
				$_SESSION[$prod]['vol']=GETPOST('vol');
				$_SESSION[$prod]['prime']=GETPOST('prime');

			}
			elseif($_SESSION['produit']=='iso'){
				$_SESSION[$prod]['metrage']=GETPOST('metrageiso');
				$_SESSION[$prod]['totalremise']=GETPOST('totalremise');
				$_SESSION['financement']['finperso']['code']='ES';
				$_SESSION['financement']['finperso']['nb']=1;
			}
			if($_SESSION['financement']['type']=='fincma'){
				$totaldevis=GETPOST('totaldevis');
				unset($_SESSION['financement']['finperso']);
				$choixfin=explode('/',GETPOST('cmanbmois'));
				$_SESSION['financement']['fincma']['report']=(int)$choixfin[0];
				$_SESSION['financement']['fincma']['nbmois']=(int)$choixfin[1];
				$_SESSION['financement']['fincma'][$choixfin[0]]=(int)$choixfin[1];
				$_SESSION['financement']['fincma']['code']='CMA';
				$_SESSION['financement']['fincma']['nb']=(int)$choixfin[1].'|'.(int)$choixfin[0];
				$_SESSION['financement']['totaldevis']=$totaldevis;
				$_SESSION['financement']['acompte']=GETPOST('acompte');

			}
			if($_SESSION['financement']['type']=='finperso'){
				unset($_SESSION['financement']['fincma']);
				$totaldevis=GETPOST('totaldevis');
				$_SESSION['financement']['pencharge']=GETPOST('pencharge');
				$_SESSION['financement']['totaldevis']=$totaldevis;
				$nbch=GETPOST('personbch');
				$nbprelev=GETPOST('personbprelev');
				$bq=GETPOST('persobanque');
				$_SESSION['financement']['acompte']=GETPOST('acompte');
				if($nbch>0){
					$_SESSION['financement']['finperso']['nb']=$nbch;
					$_SESSION['financement']['finperso']['code']='CH';
				}
				elseif($nbprelev>0){
					$_SESSION['financement']['finperso']['nb']=$nbprelev;
					$_SESSION['financement']['finperso']['code']='PR';
				}
				elseif($bq=='banque'){
					$_SESSION['financement']['finperso']['banque']=1;
				 	$_SESSION['financement']['finperso']['code'] = 'BQ';
					 $_SESSION['financement']['finperso']['nb'] = '0';
				}
				else {
					unset($_SESSION['financement']['finperso']);
				}

			}
		}
	}
	else
	{
		$action = 'create';
	}

}

if ($action == 'update' && !empty($permissiontoadd))
{
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$tab_prime=GETPOST('prime','array');
	if($tab_prime){
		foreach ($object->primes as $id=>$prime){
			foreach($tab_prime as $id_prime=>$mtprime){
				if($prime->id ==$id_prime ){
					$prime->total_ht=$mtprime;
					$prime->update($user);
					$totalprime+=$mtprime;
				}
			}
		}
		//update le reste à charge
		$object->total_rac=$object->total_ttc+$totalprime;
	}
	
	if (!$error)
	{
		$result = $object->update($user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
	//mise à jour des primes
	
}

// Action to update one extrafield
if ($action == "update_extras" && !empty($permissiontoadd))
{
	$object->fetch(GETPOST('id', 'int'));

	$attributekey = GETPOST('attribute', 'alpha');
	$attributekeylong = 'options_'.$attributekey;
	$object->array_options['options_'.$attributekey] = GETPOST($attributekeylong, ' alpha');

	$result = $object->insertExtraFields(empty($triggermodname) ? '' : $triggermodname, $user);
	if ($result > 0)
	{
		setEventMessages($langs->trans('RecordSaved'), null, 'mesgs');
		$action = 'view';
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
		$action = 'edit_extras';
	}
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

// Remove a line
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
			$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}

		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action validate object
if ($action == 'confirm_validate' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->validate($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action close object
if ($action == 'confirm_close' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->cancel($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action setdraft object
if ($action == 'confirm_setdraft' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->setDraft($user);
	if ($result >= 0)
	{
		// Nothing else done
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action reopen object
if ($action == 'confirm_reopen' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->reopen($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action clone object
if ($action == 'confirm_clone' && $confirm == 'yes' && !empty($permissiontoadd))
{
	if (1 == 0 && !GETPOST('clone_content') && !GETPOST('clone_receivers'))
	{
		setEventMessages($langs->trans("NoCloneOptionsSpecified"), null, 'errors');
	}
	else
	{
	    $objectutil = dol_clone($object, 1); // To avoid to denaturate loaded object when setting some properties for clone or if createFromClone modifies the object. We use native clone to keep this->db valid.
		//$objectutil->date = dol_mktime(12, 0, 0, GETPOST('newdatemonth', 'int'), GETPOST('newdateday', 'int'), GETPOST('newdateyear', 'int'));
        // ...
	    $result = $objectutil->createFromClone($user, (($object->id > 0) ? $object->id : $id));
	    if (is_object($result) || $result > 0)
		{
			$newid = 0;
			if (is_object($result)) $newid = $result->id;
			else $newid = $result;
			header("Location: ".$_SERVER['PHP_SELF'].'?id='.$newid); // Open record of new object
			exit;
		}
		else
		{
		    setEventMessages($objectutil->error, $objectutil->errors, 'errors');
			$action = '';
		}
	}
}
if ($action == 'facturer' && !empty($user->rights->deviscara->dev->facturer))
{
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/class/fac.class.php',1);
	$fac=new fac($db);
	$fac->date=dol_now();
	$fac->fk_soc=$object->fk_soc;
	
	$fac->total_ht=$object->total_ht;
	$fac->total_tva=$object->total_tva;
	$fac->total_ttc=$object->total_ttc;
	$fac->status=0;
	$fac->fk_commercial=$object->fk_commercial;
	$fac->total_rac=$object->total_rac;
	$i=0;
	foreach($object->lines as $line){
		$facline=new facLine($db);
		$facline->label=$line->label;
		$facline->subprice=$line->subprice;
		$facline->qty=$line->qty;
		$facline->description=$line->description;
		$facline->date_creation=dol_now();
		$facline->fk_product=$line->fk_product;
		$facline->position=$line->position;
		$facline->type=$line->type;
		$facline->fk_unit=$line->fk_unit;
		$facline->total_ht=$line->total_ht;
		$facline->tva_tx=$line->tva_tx;
		$facline->product_type=$line->product_type;
		$facline->stotal_ht=$line->stotal_ht;
		$fac->lines[$i]=$facline;
		$i++;
	}
	$i=0;
	foreach($object->primes as $line){
		$facprime=new facPrime($db);
		$facprime->label=$line->label;
		$facprime->subprice=$line->subprice;
		$facprime->qty=$line->qty;
		$facprime->description=$line->description;
		$facprime->date_creation=dol_now();
		$facprime->fk_prodict=$line->fk_product;
		$facprime->position=$line->position;
		$facprime->type=$line->type;
		$facprime->fk_unit=$line->fk_unit;
		$facprime->total_ht=$line->total_ht;
		$facprime->tva_tx=$line->tva_tx;
		$facprime->product_type=$line->product_type;
		$facprime->stotal_ht=$line->stotal_ht;
		$fac->primes[$i]=$facprime;
		$i++;
	}

	{
		$result = $fac->create($user);
		if ($result > 0)
		{
			setEventMessages($langs->trans('Facture créée'), null, 'mesgs');
			$url=dol_buildpath('deviscara/fac_card.php',1);
			header('Location: '.$url.'?id='.$fac->id);
		}
	}
}
// Mise en opération automatique
if ($action == 'mop' && !empty($user->rights->deviscara->dev->facturer)){
	//on met le tiers de prospect à client
	//on crée l'affaire
	// on crée l'objet
	//on paramètre l'objet
	//on inscrit l'objet dans les tableaux alternatifs (tableau mpr...) si ça se fait pas tout seul.
	$object_soc->fetch($object->fk_soc);
	$object_soc->client=1;
	$object_soc->entity=1;
	$db->begin();
	$res=$object_soc->update($object_soc->id,$user);
	if($res>0){
		dol_include_once('/carafinance/class/carafinance.class.php');
		$newaffaire=new carafinance($db);
		$newaffaire->fk_soc=$object_soc->id;
		$newaffaire->entity=1;
		$newaffaire->description_pertinente="Affaire du devis ".$object->ref;
		$newaffaire->description="Affaire du devis ".$object->ref;
		$newaffaire->date_creation=dol_now();
		$newaffaire->fk_usercomm=$object->fk_commercial;
		$newaffaire->fk_user_creat=$user->id;
		if ($object->label=='iso')
			$newaffaire->pack=5; //pour l'iso
		if ($object->label=='ces')
			$newaffaire->pack=6; //pour l'ces
		if ($object->label=='toiture')
			$newaffaire->pack=1; //pour toiture
		if ($object->mode_reglement_code=='CMA'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=4;
		}
		elseif ($object->mode_reglement_code=='CH' || $object->mode_reglement_code=='PRELE' || $object->mode_reglement_code=='BQ' || $object->label=='iso'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_ACCEPTE;
			$newaffaire->mod_financement=1;
		}
		else{ //si pas de mode de règlement
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=1;
		}
		
		$idAffaire=$newaffaire->create($user);
		if ($idAffaire>0){
			$info=$object->getinfo();
			//on récupere l'id pour créer les produits
			$line=new carafinanceLine($db);	
			$tabdevisacreer=$object->getlink();	
			if(count($tabdevisacreer)==0) $tabdevisacreer[0]=$object->id;
			foreach($tabdevisacreer as $id_devis){
				$obj=new dev($db);
				$obj->fetch($id_devis);
				if ($obj->label=='iso'){
					
					dol_include_once('/deviscaraiso/class/deviscaraiso.class.php');
					$prod=new Deviscaraiso($db);
					if($obj->mode_reglement_code=='CMA')
						$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
					else
						$prod->planificatiaon=$prod::STATUSPLANIF_ATTENTE; //A TRAITER
					$prod->fk_soc=$obj->fk_soc;
					$prod->fk_usercomm=$obj->fk_commercial;
					$prod->label=1;
					$prod->status=Deviscaraiso::STATUS_DRAFT; //statut brouillon
					$prod->date_creation=$obj->date_creation;;
					$prod->date_accepte_mpr=$newaffaire->date_creation;
					$prod->status_mpr=1;
					$prod->status_edf2=1;
					
					$prod->description="Création Devis ISO via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$object->id,1).">Devis Commercial</a>" ;
					$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
					$prod->surfaceiso=$info['surfaceiso'];
					$idprod=$prod->create($user);
					$line->fk_type=1;
					if($idprod>0){
						$line->fk_carafinance=$idAffaire;
						$line->amount=1;
						$line->description=$obj->description;
						$line->fk_prod=$idprod;
						$res=$line->insert();
		
						$obj->status=dev::STATUS_CLIENT;
						$obj->update($user);
						$totalracaffaire+=1;//iso à un euro
					}
				}
				elseif ($obj->label=='ces'){
					dol_include_once('/deviscaraces/class/deviscaraces.class.php');
					$prod= new deviscaraces($db);
					$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER

					$prod->fk_soc=$obj->fk_soc;
					$prod->fk_usercomm=$obj->fk_commercial;
					$prod->label=2;
					$prod->status=Deviscaraces::STATUS_DRAFT; //statut brouillon
					$prod->date_creation=$newaffaire->date_creation;
					$prod->date_accepte_mpr=$newaffaire->date_creation;
					$prod->status_mpr=1;
					$prod->status_edf2=1;
					$prod->typeces=$info;
					$prod->description="Création Devis CES via le <a href=".dol_buildpath('deviscara/al_card.php?id='.$object->id,1).">Devis Commercial</a>" ;
					$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
					$idprod=$prod->create($user);
					$line->fk_type=2;
					if($idprod>0){
						$line->fk_carafinance=$idAffaire;
						if($object->pencharge>0)
							$line->amount=$obj->pencharge;
						else
							$line->amount=$obj->total_rac;
						$line->description=$obj->description;
						$line->fk_prod=$idprod;
						$res=$line->insert();
		
						$obj->status=dev::STATUS_CLIENT;
						$obj->update($user);
						$totalracaffaire+=$obj->total_rac;
					}
				}
				elseif ($obj->label=='toiture'){
					dol_include_once('/deviscaratoit/class/deviscaratoitbis.class.php');
					$prod= new Deviscaratoit($db);
					if($obj->mode_reglement_code=='CMA')
						$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
					else
						$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER

					$prod->fk_soc=$obj->fk_soc;
					$prod->fk_usercomm=$obj->fk_commercial;
					$prod->label=4;
					$prod->status=Deviscaratoit::STATUS_DRAFT; //statut brouillon
					$prod->date_creation=$obj->date_creation;;
					$prod->date_accepte_mpr=$obj->date_creation;;
					$prod->status_mpr=1;
					$prod->status_edf2=1;
					$prod->typetoit=$info;
					$prod->description="Création Devis TOITURE via le <a href=".dol_buildpath('deviscara/al_card.php?id='.$obj->id,1).">Devis Commercial</a>" ;
					$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
					$idprod=$prod->create($user);
					$line->fk_type=4;
					if($idprod>0){
						$line->fk_carafinance=$idAffaire;
						$line->amount=$obj->total_rac;
						$line->description=$obj->description;
						$line->fk_prod=$idprod;
						$res=$line->insert();
						$totalracaffaire+=$obj->total_rac;
					}
					//ajout objet iso
					dol_include_once('/deviscaraiso/class/deviscaraiso.class.php');
					$prod=new Deviscaraiso($db);
					if($obj->mode_reglement_code=='CMA')
						$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
					else
						$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER
					$prod->fk_soc=$obj->fk_soc;
					$prod->fk_usercomm=$obj->fk_commercial;
					$prod->label=1;
					$prod->status=Deviscaraiso::STATUS_DRAFT; //statut brouillon
					$prod->date_creation=$obj->date_creation;;
					$prod->date_accepte_mpr=$obj->date_creation;;
					$prod->status_mpr=1;
					$prod->status_edf2=1;
					
					$prod->description="Création Devis ISO via le <a href=".dol_buildpath('deviscara/al_card.php?id='.$obj->id,1).">Devis Commercial</a>" ;
					$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
					$prod->surfaceiso=$info['surfaceiso'];
					$idprodisotoit=$prod->create($user);
					$line->fk_type=1;
					if($idprodisotoit>0){
						$line->fk_carafinance=$idAffaire;
						$line->amount=1;
						$line->description=$obj->description;
						$line->fk_prod=$idprodisotoit;
						$res=$line->insert();
		
						$obj->status=dev::STATUS_CLIENT;
						$obj->update($user);
						$totalracaffaire+=1;//iso=1 euro
					}
				}
				
				else{
					$error++;
				}
			}
			$newaffaire->fetch($idAffaire);
			$newaffaire->date_creation=$obj->date_creation;
			$newaffaire->amount=$totalracaffaire;
			$newaffaire->update($user);
		}
		else{
			$error++;
		}
	}
	else{
		$error++;
	}
	if($error>0){
		$db->rollback();
		setEventMessage('Erreur de mise en operation','','errors');
	}
	else
		$db->commit();

}

if( $_SESSION['fromid'] > 0 )
	goto clientexit;

// Action to add record
if ($action == 'insert_devis' && !empty($permissiontoadd))
{
	
		
	if(GETPOST('devis')){
		clientexit:
		if($_SESSION['fromid']){//client déjà existant
			$object_soc->fetch($_SESSION['fk_soc']);
			$couleur=get_tarif();
			$db->begin();
		}
		else{
		
			//création client
			
			$object_soc->nom=GETPOST('firstname');
			$object_soc->address=GETPOST('address');

			$object_soc->array_options['ville']=GETPOST('options_ville');
			$object_soc->array_options['nbpart']=$_SESSION['nbpart'];
			$object_soc->array_options['rfr']=$_SESSION['rfr'];
			
			$object_soc->phone=GETPOST('phone');
			$object_soc->fax=GETPOST('fax');
			$object_soc->url=GETPOST('url');
			$object_soc->email=GETPOST('email');
			$object_soc->client=2; //prospect
			$object_soc->status=1; //prospect
			$object_soc->fk_pays=1; //france
			$object_soc->commercial_id=$user->id;
			$module = (!empty($conf->global->SOCIETE_CODECLIENT_ADDON) ? $conf->global->SOCIETE_CODECLIENT_ADDON : 'mod_codeclient_leopard');
			if (substr($module, 0, 15) == 'mod_codeclient_' && substr($module, -3) == 'php')
			{
				$module = substr($module, 0, dol_strlen($module) - 4);
			}
			$dirsociete = array_merge(array('/core/modules/societe/'), $conf->modules_parts['societe']);
			foreach ($dirsociete as $dirroot)
			{
				$res = dol_include_once($dirroot.$module.'.php');
				if ($res) break;
			}
			$modCodeClient = new $module;
			$object_soc->code_client			= $modCodeClient->getNextValue($object, 0);
			$error=0;
			if($object_soc->phone=="") $error++;
			if($object_soc->email=="") $error++;
			if($object_soc->nom=="") $error++;
			if($object_soc->array_options['ville']=="0") $error++;
			if($error>0){
				setEventmessages('Chmaps Noms, Téléphone, email obligatoires',null,'errors');
				$action='create';
				return;
			}	
			$db->begin();
		
			$prod=$_SESSION['produit'];
			$couleur=get_tarif();
			if($couleur=='b'){
				$bgcolor='lightblue';
				$object_soc->array_options['cara_type_client']=3; //GPB
			}
			elseif($couleur=='j'){
				$bgcolor='yellow';
				$object_soc->array_options['cara_type_client']=2; //PJ
			}
			elseif($couleur=='v'){
				$bgcolor='violet';
				$object_soc->array_options['cara_type_client']=1; //HP v
			}
			elseif($couleur=='r'){
				$bgcolor='pink';
				$object_soc->array_options['cara_type_client']=4; //HP R
			}
			$object_soc->create($user);
		}
		//création du devis
		$object->label=$_SESSION["produit"]; 
		$object->fk_soc=$object_soc->id;
		$object->status_immo=$_SESSION['statut_immo'];
		$object->mode_reglement_code=$_SESSION['financement'][$_SESSION['financement']['type']]['code'];
		$object->mode_reglement_nb=$_SESSION['financement'][$_SESSION['financement']['type']]['nb'];
		$object->acompte=$_SESSION['financement']['acompte'];
		$object->pencharge=$_SESSION['financement']['pencharge'];
		$object->fk_commercial=$user->id;
		
		if($_SESSION['produit']=='toiture'){
			
			include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoit.lib.php',1);
			
	
			$objectLine = new alLine($db);
			$objectLine->qty=1;
			
			$objectLine->label=$tabtarif['forfait']['pv']['previsite']->label;
			$objectLine->description=$tabtarif['forfait']['pv']['previsite']->description;
			$objectLine->fk_unit=$tabtarif['forfait']['pv']['previsite']->fk_unit;
			$objectLine->total_ttc=$tabtarif['forfait']['pv']['previsite']->price_ttc;
			$objectLine->tva_tx=$tabtarif['forfait']['pv']['previsite']->tva_tx;
			$total_lig_ttc=$tabtarif['forfait']['pv']['previsite']->price_ttc;
			$objectLine->fk_product=$tabtarif['forfait']['pv']['previsite']->id;
			//$objectLine->subprice=$total_lig_ttc*(1-1/$objectLine->tva_tx/100); //subprice ht
			$objectLine->position=1;
			$objectLine->total_ht= $objectLine->subprice=$tabtarif['forfait']['pv']['previsite']->price;
			$object->lines[0]=$objectLine;
			$total_ttc +=$total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			
			$tarif=$tabtarif['pv']['lib'];
			$i++;
			//titre tole
			$objectLine = new alLine($db);
			$objectLine->label='<b>Tôles :</b>';
			$objectLine->position=$i;
			$objectLine->description=NULL;
			$objectLine->fk_product=NULL;
			$objectLine->product_type=9;
			$object->lines[$i]=$objectLine;
			
			$i++;
			//toles
			$sous_total=0;
			$id='tole';
			$objectLine = new alLine($db);
			
			$objectLine->qty=$_SESSION['toiture']['metrage'];
			$objectLine->label=$tabtarif['pv'][$id]->label;
			$objectLine->description=$tabtarif['pv'][$id]->description;
			$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
			$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
			$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
			$objectLine->subprice=$tabtarif['pv'][$id]->price;
			
			$objectLine->fk_product=$tabtarif['pv'][$id]->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			$i++;
			
			//livraison tôle
			$objectLine = new alLine($db);
			$objectLine->qty=1;
			
			$objectLine->label=$tabtarif['forfait']['pv']['livraison']->label;
			$objectLine->description=$tabtarif['forfait']['pv']['livraison']->description;
			$total_lig_ttc=(float)$tabtarif['forfait']['pv']['livraison']->price_ttc;
			$objectLine->fk_unit=$tabtarif['forfait']['pv']['livraison']->fk_unit;
			$objectLine->tva_tx=$tabtarif['forfait']['pv']['livraison']->tva_tx;
			$objectLine->subprice=$tabtarif['forfait']['pv']['livraison']->price;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$objectLine->fk_product=$tabtarif['forfait']['pv']['livraison']->id;
			$objectLine->position=$i;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			$i++;

			//Pose Tôle
			$id='posetole';
			$objectLine = new alLine($db);
			
			$objectLine->qty=$_SESSION['toiture']['metrage'];
			$objectLine->label=$tabtarif['pv'][$id]->label;
			$objectLine->description=$tabtarif['pv'][$id]->description;
			$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
			$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
			$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
			$objectLine->subprice=$tabtarif['pv'][$id]->price;
			
			$objectLine->fk_product=$tabtarif['pv'][$id]->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			$i++;
			//Sous total
			$objectLine = new alLine($db);
			$objectLine->label='<i>Sous total:</i>';
			$objectLine->position=$i;
			$objectLine->description=NULL;
			$objectLine->fk_product=NULL;
			$objectLine->product_type=10;
			$objectLine->stotal_ht=$sous_total;
			$object->lines[$i]=$objectLine;
			$sous_total=0;
			$i++;
			if($couleur!='r'){
				//titre 
				$objectLine = new alLine($db);
				$objectLine->label='<b>Protection contre le rayonnement solaire</b>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=9;
				$object->lines[$i]=$objectLine;
				$i++;
				//PRSbar109
				$id='PRSbar109';
				$objectLine = new alLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				//pose PRSbar109
				$id='posePRSbar109';
				$objectLine = new alLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				//Sous total
				$objectLine = new alLine($db);
				$objectLine->label='<i>Sous total:</i>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=10;
				$objectLine->stotal_ht=$sous_total;
				$object->lines[$i]=$objectLine;
				$sous_total=0;
				$i++;

				//titre 
				$objectLine = new alLine($db);
				$objectLine->label='<b>Isolation des rampants de Toiture et plafond de combles</b>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=9;
				$object->lines[$i]=$objectLine;
				$i++;
				//rampants
				$id='isorampantbar10';
				$objectLine = new alLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;

				$id='poseisorampantbar10';
				$objectLine = new alLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				
				//Sous total
				$objectLine = new alLine($db);
				$objectLine->label='<i>Sous total:</i>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=10;
				$objectLine->stotal_ht=$sous_total;
				$object->lines[$i]=$objectLine;
				$sous_total=0;
				$i++;
			}
			else{
				//titre 
				$objectLine = new alLine($db);
				$objectLine->label='<b>Isolation de combles ou de toitures</b>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=9;
				$object->lines[$i]=$objectLine;
				$i++;
				//combles
				$id='isocombles';
				$objectLine = new alLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				
			}
			//options
			$tarif=$tabtarif['option'];
			foreach ($tarif as $id=>$produit){
				
				if($id=='char'){
					$metrage=$_SESSION['toiture']['metragecharpente'];
				}
				elseif($id=='gouttiere'){
					$metrage=$_SESSION['toiture']['metragegouttieres'];
				}
				elseif($id=='fp'){
					$metrage=$_SESSION['toiture']['metragefauxplafond'];
				}
				elseif($id=='chen'){
					$metrage=$_SESSION['toiture']['metragechenaux'];
				}
				$htm.='<td>'.$produit->label.'</td><td>'.$metrage.'</td><td>'.$produit->price_ttc.'</td><td>'.$produit->price_ttc*$metrage.'';
				if($i%2)
					$htm.='</td></tr><tr class="oddeven">';
				else $htm.='</td></tr><tr class="pair">';
				
				$objectLine = new alLine($db);
				$objectLine->qty=$metrage;
				$objectLine->label=$produit->label;
				$objectLine->description=$produit->description;
				$objectLine->fk_unit=$produit->fk_unit;
				$objectLine->tva_tx=$produit->tva_tx;
				$total_lig_ttc=$produit->price_ttc*$objectLine->qty;
				$objectLine->subprice=$produit->price;
				
				$objectLine->fk_product=$produit->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;

				// $objectLine->label=$lib;
				// $total_lig_ttc=(float)$tabtarif['option']['mt'][$id]*$objectLine->qty;
				// $objectLine->fk_unit=$tabtarif['option']['unit'][$id];
				// $objectLine->tva_tx=$tabtarif['option']['tva'][$id];
				// $total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				// $objectLine->fk_product=$tabtarif['option']['fk_product'][$id];;
				// $objectLine->position=$i;
				// $object->lines[$i]=$objectLine;
				// $total_ttc += $total_lig_ttc;
				// $total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

				// $total_tva += $total_lig_tva;
				// $total_ht += $total_lig_ttc-$total_lig_tva;
				// $sous_total+=$$objectLine->total_ht;		
				$i++;
			}
			if(count($tarif)>0){
				//Sous total
				$objectLine = new alLine($db);
				$objectLine->label='<i>Sous total:</i>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=10;
				$objectLine->stotal_ht=$sous_total;
				$object->lines[$i]=$objectLine;
				$sous_total=0;
				$i++;
			}
			if($_SESSION['toiture']['sproduit']=='ces'){
				$objectLine = new alLine($db);
				$objectLine->qty=1;
				
				$objectLine->label=$tabtarifces['pv']['lib'][$_SESSION[$prod]['vol']];
				$total_lig_ttc=(float)$tabtarifces['pv']['mt'][$_SESSION['toiture']['vol']];
				$objectLine->tva_tx=$tabtarifces['pv']['tva'][$_SESSION['toiture']['vol']];
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$objectLine->fk_unit=$tabtarifces['pv']['unit'][$_SESSION['toiture']['vol']];
				
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$objectLine->fk_product='ces';
				$objectLine->position=$i;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				if($objectLine->tva_tx>0)
					$total_lig_tva=$total_lig_ttc/$objectLine->tva_tx/100;
				else $total_lig_tva=0;

				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
			}
			

			$i=0;
			$tarif=$tabtarif[$couleur]['pr']['lib'];
			foreach ($tarif as $id=>$lib){
				$objectPrime = new alPrime($db);
				$objectPrime->qty=$_SESSION['toiture']['metrage'];
				$objectPrime->label=$lib;
				$objectPrime->subprice=(float)$tabtarif[$couleur]['pr']['mt'][$id];
				$objectPrime->fk_unit=(float)$tabtarif[$couleur]['pr']['unit'][$id];
				$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
				$objectPrime->fk_product=$id;
				$objectPrime->type_prime=$tabtarif['pr']['type_prime'][$id];
				$objectPrime->type=2; //produt de type ces
				$objectPrime->position=$i;

				$object->primes[$i]=$objectPrime;
				$total_primes += $objectPrime->total_ht;
				$i++;
			}
			if(count($tabtarif['remise'])>0){
				$id='remise';
				$objectLine = new alLine($db);
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif[$id]->label;
				$objectLine->description=$tabtarif[$id]->description;
				$objectLine->fk_unit=$tabtarif[$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif[$id]->tva_tx;
				
				$total_lig_ttc=(float)$tabtarif[$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif[$id]->price;
				
				$objectLine->fk_product=$tabtarif[$id]->id;
				$objectLine->position=$i;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
			}
			$tarif=$tabtarifces[$couleur]['pr']['lib'];	
			foreach ($tarif as $id=>$lib){
				$objectPrime = new alPrime($db);
				$objectPrime->qty=1;
				$objectPrime->label=$lib;
				$objectPrime->subprice=(float)$tabtarifces[$couleur]['pr']['mt'][$id];
				$objectPrime->fk_unit=(float)$tabtarifces[$couleur]['pr']['unit'][$id];
				$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
				$objectPrime->fk_product=$id;
				$objectPrime->position=$i;

				$object->primes[$i]=$objectPrime;
				$total_primes += $objectPrime->total_ht;
				$i++;
			}
			$object->total_ht=$total_ht;
			$object->total_ttc=$total_ttc;
			$object->total_tva=$total_tva;
			$object->total_rac=$object->total_ttc+$total_primes;
		}
		elseif($_SESSION['produit']=='ces'){
			include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifces.lib.php',1);
			$id=$_SESSION[$prod]['vol'];
			//prévisite
			$objectLine = new alLine($db);
			$objectLine->qty=1;
			$objectLine->label=$tabtarif['prev']->label;
			$objectLine->description=$tabtarif['prev']->description;
			$objectLine->fk_unit=$tabtarif['prev']->fk_unit;
			$objectLine->tva_tx=$tabtarif['prev']->tva_tx;
			$total_lig_ttc=(float)$tabtarif['prev']->price_ttc*$objectLine->qty;
			$objectLine->subprice=$tabtarif['prev']->price;
			
			$objectLine->fk_product=$tabtarif['prev']->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			$i++;
			//produit//
			$objectLine = new alLine($db);
			$objectLine->qty=1;
			$objectLine->label=$tabtarif['pv'][$id]->label;
			$objectLine->description=$tabtarif['pv'][$id]->description;
			$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
			$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
			$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
			$objectLine->subprice=$tabtarif['pv'][$id]->price;
			
			$objectLine->fk_product=$tabtarif['pv'][$id]->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			$i++;

			//livraison
			$objectLine = new alLine($db);
			$objectLine->qty=1;
			$objectLine->label=$tabtarif['liv'][$id]->label;
			$objectLine->description=$tabtarif['liv'][$id]->description;
			$objectLine->fk_unit=$tabtarif['liv'][$id]->fk_unit;
			$objectLine->tva_tx=$tabtarif['liv'][$id]->tva_tx;
			$total_lig_ttc=(float)$tabtarif['liv'][$id]->price_ttc*$objectLine->qty;
			$objectLine->subprice=$tabtarif['liv'][$id]->price;
			
			$objectLine->fk_product=$tabtarif['liv'][$id]->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			$i++;

			$i=0;
			$tarif=$tabtarif['pr']['lib'];
			foreach ($tarif as $id=>$lib){
				$objectPrime = new alPrime($db);
				$objectPrime->qty=1;
				$objectPrime->label=$lib;
				$objectPrime->subprice=(float)$tabtarif[$couleur]['pr']['mt'][$id];
				$objectPrime->fk_unit=(float)$tabtarif[$couleur]['pr']['unit'][$id];
				$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
				$objectPrime->fk_product=$id;
				$objectPrime->type_prime=$tabtarif['pr']['type_prime'][$id];
				$objectPrime->type=2; //produt de type ces
				$objectPrime->position=$i;

				$object->primes[$i]=$objectPrime;
				$total_primes += $objectPrime->total_ht;
				$i++;
			}
			$object->total_ht=$total_ht;
			$object->total_ttc=$total_ttc;
			$object->total_tva=$total_tva;
			$object->total_rac=$object->total_ttc+$total_primes;
		}
		elseif($_SESSION['produit']=='iso'){
			include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifiso.lib.php',1);
			//produit//
			$id='iso';
			$objectLine = new alLine($db);
			$objectLine->qty=$_SESSION['iso']['metrage'];
			$objectLine->label=$tabtarif['pv'][$id]->label;
			$objectLine->description=$tabtarif['pv'][$id]->description;
			$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
			$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
			$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*(float)$objectLine->qty;
			$objectLine->subprice=$tabtarif['pv'][$id]->price;
			
			$objectLine->fk_product=$tabtarif['pv'][$id]->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;

			$i++;
			//remise
			$id='remise';
			$objectLine = new alLine($db);
			$objectLine->qty=1;
			$objectLine->label=$tabtarif['pv'][$id]->label;
			$objectLine->description=$tabtarif['pv'][$id]->description;
			$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
			$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
			$total_lig_ttc=$_SESSION['iso']['totalremise'];
			$objectLine->subprice=$_SESSION['iso']['totalremise'];
			
			$objectLine->fk_product=$tabtarif['pv'][$id]->id;
			$objectLine->position=$i;
			$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
			$object->lines[$i]=$objectLine;
			$total_ttc += $total_lig_ttc;
			$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
			$total_tva += $total_lig_tva;
			$total_ht += $total_lig_ttc-$total_lig_tva;
			$sous_total+=$objectLine->total_ht;
			
			$i=0;
			$tarif=$tabtarif['pr']['lib'];
			foreach ($tarif as $id=>$lib){
				$objectPrime = new alPrime($db);
				$objectPrime->qty=$_SESSION['iso']['metrage'];
				$objectPrime->label=$lib;
				$objectPrime->subprice=(float)$tabtarif[$couleur]['pr']['mt'][$id];
				$objectPrime->fk_unit=(float)$tabtarif[$couleur]['pr']['unit'][$id];
				$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
				$objectPrime->fk_product=$id;
				$objectPrime->position=$i;

				$object->primes[$i]=$objectPrime;
				$total_primes += $objectPrime->total_ht;
				$i++;
			}
			$object->total_ht=$total_ht;
			$object->total_ttc=$total_ttc;
			$object->total_tva=$total_tva;
			$object->total_rac=$object->total_ttc+$total_primes;
		}
		if($object->total_ht>0){
			$result = $object->create($user);
			if($_SESSION['fromid']) //client déjà existant
				$object->link($_SESSION['fromid'],$_SESSION['produit']);
				
			unset($_SESSION['client'],$_SESSION['produit'],$_SESSION[$prod],$_SESSION['toiture'],$_SESSION['ces'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client'],$_SESSION['fromid']);
			//$extrafields_soc->update();
			$db->commit();
		}
		else $db->rollback();
		if ($result > 0)
		{
			// Creation OK
			$urltogo = dol_buildpath('deviscara/al_client.php',1).'?id='.$object->id;
			header("Location: ".$urltogo);
			exit;
		}
		else
		{
			// Creation KO
			if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
			else  setEventMessages($object->error, null, 'errors');
			$action = 'create';
		}
		
	}
	
}