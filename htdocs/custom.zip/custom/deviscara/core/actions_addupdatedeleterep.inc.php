<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}


// Action to add record
if ($action == 'add' || $action=='create')
{
	
	if (!$error)
	{	
		$prod='rep';
		if(GETPOST('reinit')=='re-initialiser'){
			unset($_SESSION['client'],$_SESSION['rep'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);
			$action = 'create';
		}
		else{
			$_SESSION['nbpart']=GETPOST('nbpart');
			$_SESSION['rfr']=GETPOST('rfr');
			$_SESSION['status_immo']=GETPOST('status_immo');
			$_SESSION['client']=GETPOST('client');
			
			$_SESSION['financement']['type']=GETPOST('typefin');
					
			$_SESSION[$prod]['2ans']=GETPOST('2ans');
			$_SESSION[$prod]['ctm']=GETPOST('ctm');
			$_SESSION[$prod]['raccord']=GETPOST('raccord');
			$_SESSION[$prod]['position']=GETPOST('position');
			$_SESSION[$prod]['dalle']=GETPOST('dalle');
			$cuveent=GETPOST('cuveent');
			if($cuveent>0) $_SESSION[$prod]['cuve']=$cuveent;
			else $_SESSION[$prod]['cuve']=GETPOST('cuve');
			$nbrob=GETPOST('robinet','int');
			$_SESSION[$prod]['robinet']=$nbrob===""?0:$nbrob;
			$nbwc1=GETPOST('wc1');
			$_SESSION[$prod]['wc1']=$nbwc1===""?0:$nbwc1;
			$_SESSION[$prod]['wc2']=GETPOST('wc2');
			$_SESSION[$prod]['lampeuv']=GETPOST('lampeuv');
			$_SESSION[$prod]['pompe']=GETPOST('pompe');
			$_SESSION[$prod]['totaleligible']=GETPOST('totaleligible');
			$_SESSION[$prod]['suraceutiletoit']=GETPOST('suraceutiletoit');
			$_SESSION[$prod]['nboccupants']=GETPOST('nboccupants');
			$_SESSION[$prod]['surfacejardin']=GETPOST('surfacejardin');

			if($_SESSION['financement']['type']=='fincma'){
				$totalresteacharge=GETPOST('totalresteacharge');
				unset($_SESSION['financement']['finperso']);
				$choixfin=explode('/',GETPOST('cmanbmois'));
				$_SESSION['financement']['fincma']['report']=(int)$choixfin[0];
				$_SESSION['financement']['fincma']['nbmois']=(int)$choixfin[1];
				$_SESSION['financement']['fincma'][$choixfin[0]]=(int)$choixfin[1];
				$_SESSION['financement']['fincma']['code']='CMA';
				$_SESSION['financement']['fincma']['nb']=(int)$choixfin[1].'|'.(int)$choixfin[0];
				$_SESSION['financement']['totaldevis']=$totalresteacharge;
				$_SESSION['financement']['acompte']=GETPOST('acompte');

			}
			if($_SESSION['financement']['type']=='finperso'){
				unset($_SESSION['financement']['fincma']);
				$totalresteacharge=GETPOST('totalresteacharge');
				$_SESSION['financement']['totaldevis']=$totalresteacharge;
				$nbch=GETPOST('personbch');
				$nbprelev=GETPOST('personbprelev');
				$bq=GETPOST('persobanque');
				$_SESSION['financement']['acompte']=GETPOST('acompte');
				if($nbch>0){
					$_SESSION['financement']['finperso']['nb']=$nbch;
					$_SESSION['financement']['finperso']['code']='CH';
				}
				elseif($nbprelev>0){
					$_SESSION['financement']['finperso']['nb']=$nbprelev;
					$_SESSION['financement']['finperso']['code']='PR';
				}
				elseif($bq=='banque'){
					$_SESSION['financement']['finperso']['banque']=1;
				 	$_SESSION['financement']['finperso']['code'] = 'BQ';
					 $_SESSION['financement']['finperso']['nb'] = '0';
				}
				else {
					unset($_SESSION['financement']['finperso']);
				}

			}
			if ($action == 'add')
				$action="create_client";
		}
		
	}
	else
	{
		$action = 'create';
	}

}
if ($action == 'creerdevis' ){
	$object_soc=new societe($db);
	$object_soc->nom=GETPOST('firstname');
	$object_soc->address=GETPOST('address');

	$object_soc->array_options['ville']=GETPOST('options_ville');
	$object_soc->array_options['nbpart']=$_SESSION['nbpart'];
	$object_soc->array_options['rfr']=$_SESSION['rfr'];
	
	$object_soc->phone=GETPOST('phone');
	$object_soc->fax=GETPOST('fax');
	$object_soc->url=GETPOST('url');
	$object_soc->email=GETPOST('email');
	$object_soc->client=2; //prospect
	$object_soc->status=1; //prospect
	$object_soc->fk_pays=1; //france
	$object_soc->commercial_id=$user->id;
	$module = (!empty($conf->global->SOCIETE_CODECLIENT_ADDON) ? $conf->global->SOCIETE_CODECLIENT_ADDON : 'mod_codeclient_leopard');
	if (substr($module, 0, 15) == 'mod_codeclient_' && substr($module, -3) == 'php')
	{
		$module = substr($module, 0, dol_strlen($module) - 4);
	}
	$dirsociete = array_merge(array('/core/modules/societe/'), $conf->modules_parts['societe']);
	foreach ($dirsociete as $dirroot)
	{
		$res = dol_include_once($dirroot.$module.'.php');
		if ($res) break;
	}
	$modCodeClient = new $module;
	$object_soc->code_client			= $modCodeClient->getNextValue($object_soc, 0);
	$error=0;
	if($object_soc->phone=="") $error++;
	if($object_soc->email=="") $error++;
	if($object_soc->nom=="") $error++;
	if($object_soc->array_options['ville']=="0") $error++;
	if($error>0){
		setEventmessages('Chmaps Noms, Téléphone, email obligatoires',null,'errors');
		$action='create';
		return;
	}
	
	$db->begin();
	
	//création du devis
	//$object = new rep($db);
	$object->label='rep'; 
	
	$object->status_immo=$_SESSION['status_immo'];
	$object->mode_reglement_code=$_SESSION['financement'][$_SESSION['financement']['type']]['code'];
	$object->mode_reglement_nb=$_SESSION['financement'][$_SESSION['financement']['type']]['nb'];
	$object->acompte=$_SESSION['financement']['acompte'];
	$object->pencharge=$_SESSION['financement']['pencharge'];
	$object->fk_commercial=$user->id;
	
	$object->suraceutiletoit=$_SESSION['rep']['suraceutiletoit'];
	$object->nboccupants=$_SESSION['rep']['nboccupants'];
	$object->surfacejardin=$_SESSION['rep']['surfacejardin'];
	$object_soc->array_options['maisonplus2']=$_SESSION['rep']['2ans'];
	$object->raccord=$_SESSION['rep']['raccord'];
	$tabinfo=$object->get_tarif();
	$couleur=$tabinfo[0];
	$plafond=$tabinfo[1];
	if($couleur=='b'){
		$bgcolor='lightblue';
		$object_soc->array_options['cara_type_client_ctm']=3; //GPB
	}
	elseif($couleur=='j'){
		$bgcolor='yellow';
		$object_soc->array_options['cara_type_client_ctm']=2; //PJ
	}
	elseif($couleur=='v'){
		$bgcolor='violet';
		$object_soc->array_options['cara_type_client_ctm']=1; //HP v
	}
	
	
	$object_soc->create($user);
	$object->fk_soc=$object_soc->id;

	$i=0;
	$objectLine = new repLine($db);
	$objectLine->label='<b>FOURNITURES ELIGIBLES SREP</b>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$object->lines[$i]=$objectLine;
	function insert_object(&$objectLine,$prod){
		global $tabtarif;
		$objectLine->label=$tabtarif['pv']['rep'][$prod]->label;
		$objectLine->description=$tabtarif['pv']['rep'][$prod]->description;
		$objectLine->fk_unit=$tabtarif['pv']['rep'][$prod]->fk_unit;
		$objectLine->subprice=$tabtarif['pv']['rep'][$prod]->price; //PU HT
		$objectLine->total_ttc=$tabtarif['pv']['rep'][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->tva_tx=$tabtarif['pv']['rep'][$prod]->tva_tx;
		$objectLine->fk_product=$tabtarif['pv']['rep'][$prod]->id;
		$objectLine->total_ht=$tabtarif['pv']['rep'][$prod]->price*$objectLine->qty; //PTOTAL HT
		$objectLine->type=2;//produit
	}
	//cuve
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'cuve');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;

	//titre2
	$i++;
	$objectLine = new repLine($db);
	$objectLine->label='<b>ELEMENTS DE FILTRATION</b>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$object->lines[$i]=$objectLine;
	//crap
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'crap');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	//fgt
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'fgt');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	//gam
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'gam');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	//fsp
	if($_SESSION['rep']['pompe'] =='pompeoui'){
		$i++;
		$objectLine = new repLine($db);
		$objectLine->qty=1;
		insert_object($objectLine,'fsp');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total_ttc +=$objectLine->total_ttc;
		$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
		$total_tva += $total_lig_tva;
		$total_ht += $objectLine->total_ht;
	}
	//titre3
	$i++;
	$objectLine = new repLine($db);
	$objectLine->label='<b>ELEMENTS DE RACCORDEMENT</b>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$object->lines[$i]=$objectLine;

	//cli
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'cli');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	//deriv
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'deriv');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	if($_SESSION['rep']['wc1']>0){
		$i++;
		$objectLine = new repLine($db);
		$objectLine->qty=1;
		insert_object($objectLine,'surv');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total_ttc +=$objectLine->total_ttc;
		$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
		$total_tva += $total_lig_tva;
		$total_ht += $objectLine->total_ht;
	}
	//titre
	$i++;
	$objectLine = new repLine($db);
	$objectLine->label='<b>DISPOSITIF DE POMPAGE</b>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$object->lines[$i]=$objectLine;

	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=($_SESSION['rep']['pompe']=='pompeoui'?1:0);
	insert_object($objectLine,'pompe');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;

	//titre3
	$i++;
	$objectLine = new repLine($db);
	$objectLine->label='<b>ALIMENTATION EAU DE PLUIE</b>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$object->lines[$i]=$objectLine;

	//rob
	$i++;
	$objectLine = new repLine($db);
	if($_SESSION['rep']['pompe']=='pompenon')
		$objectLine->qty=1;
	else
		$objectLine->qty=$_SESSION['rep']['robinet'];
	insert_object($objectLine,'rob');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;

	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=$_SESSION['rep']['wc1'];
	insert_object($objectLine,'wcpl');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;

	$i++;
	$objectLine = new repLine($db);
	if($_SESSION['rep']['pompe']=='pompenon')
		$objectLine->qty=1;
	else
		$objectLine->qty=$_SESSION['rep']['robinet']+$_SESSION['rep']['wc1'];
	insert_object($objectLine,'signal');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	
	if($_SESSION['rep']['raccord'] =='ttalegout' && $_SESSION['rep']['wc1']>0){
		$i++;
		$objectLine = new repLine($db);
		$objectLine->qty=1;
		insert_object($objectLine,'cpto');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total_ttc +=$objectLine->total_ttc;
		$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
		$total_tva += $total_lig_tva;
		$total_ht += $objectLine->total_ht;
	}

	//titre
	$i++;
	$objectLine = new repLine($db);
	$objectLine->label='<b>INSTALLATION ELIGIBLE SREP</b>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$object->lines[$i]=$objectLine;
	
	if($_SESSION['rep']['position'] =='enterree'){
		$i++;
		$objectLine = new repLine($db);
		$objectLine->qty=1;
		insert_object($objectLine,'cuveent');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total_ttc +=$objectLine->total_ttc;
		$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
		$total_tva += $total_lig_tva;
		$total_ht += $objectLine->total_ht;
	
	}
	else{
		$i++;
		$objectLine = new repLine($db);
		$objectLine->qty=($_SESSION['rep']['dalle']=='dalleoui'?1:0);
		insert_object($objectLine,'dalle');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total_ttc +=$objectLine->total_ttc;
		$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
		$total_tva += $total_lig_tva;
		$total_ht += $objectLine->total_ht;
	}
	
	if($_SESSION['rep']['pompe'] =='pompeoui'){
		$i++;
		$objectLine = new repLine($db);
		$objectLine->qty=1;
		insert_object($objectLine,'inselec');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total_ttc +=$objectLine->total_ttc;
		$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
		$total_tva += $total_lig_tva;
		$total_ht += $objectLine->total_ht;
	}
	$i++;
	$objectLine = new repLine($db);
	if(($_SESSION['rep']['robinet']+$_SESSION['rep']['wc1'])>=3)
		$qty=$_SESSION['rep']['robinet']+$_SESSION['rep']['wc1']-1;
	else
		$qty=$_SESSION['rep']['robinet']+$_SESSION['rep']['wc1'];
	if($_SESSION['rep']['pompe']=='pompenon')
		$qty=1;
	$objectLine->qty=$qty;
	insert_object($objectLine,'lir');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;

	//lampeuv
	$i++;
	$objectLine = new repLine($db);
	$objectLine->qty=($_SESSION['rep']['lampeuv']=='lampeuvoui'?1:0);
	insert_object($objectLine,'lampeuv');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;

	//primes
	$i++;
	//si sans ctm: pas de primes dutout
	if($_SESSION['rep']['ctm']==1){

		//primes %
		$tabinfo=$object->get_tarif();
		$plafond=$tabinfo[1];
		$objectPrime = new repLine($db);
		$objectPrime->qty=1;
		$objectPrime->label=$tabtarif['lib2']['srep']->label;
		if($_SESSION['rep']['lampeuv']=='lampeuvoui'){
			$totaleligible=$total_ht-$tabtarif['pv']['rep']['lampeuv']->price;
			$provprime=$tabtarif['lib2']['srep']->array_options['options_taux_prime']*$totaleligible;
		}
		else{
			$provprime=$tabtarif['lib2']['srep']->array_options['options_taux_prime']*$total_ht;
		}
		$objectPrime->prime_tx=$tabtarif['lib2']['srep']->array_options['options_taux_prime'];
		$prime= (-1)* ($provprime>=$plafond?$plafond:$provprime);
		$objectPrime->subprice=$prime;
		$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
		$objectPrime->type_prime=$tabtarif['lib2']['srep']->array_options['options_type_prime'];
		$objectPrime->fk_product=$tabtarif['lib2']['srep']->id;
		 //prime SREP
		$objectPrime->position=$i;
		$object->lines[$i]=$objectPrime;
		$total_primes += $objectPrime->total_ht;
		$i++;
	}

	$object->total_ht=$total_ht;
	$object->total_ttc=$total_ttc;
	$object->total_tva=$total_tva;
	$object->total_rac=$object->total_ttc+$total_primes;
	$object->totaleligible=$totaleligible;

	//prime lib2
	if($object->total_ht>0){
		$result = $object->create($user);
		unset($_SESSION['client'],$_SESSION['rep'],$_SESSION['financement'],
		$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);
		$db->commit();
	}
	else $db->rollback();
	if ($result > 0)
	{
		// Creation OK
		$urltogo = dol_buildpath('deviscara/rep_card.php',1).'?id='.$object->id;
		header("Location: ".$urltogo);
		exit;
	}
	else
	{
		// Creation KO
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else  setEventMessages($object->error, null, 'errors');
		$action = 'create';
	}
}
if ($action == 'addline')
{
	$objectLine=new repLine($db);
	$objectLine->fk_product=GETPOST('idprod');
	if($objectLine->fk_product > 0 && GETPOST('prod_entry_mode')!='free'){
		$prod=new Product($db);
		$prod->fetch($objectLine->fk_product);
		$objectLine->fk_deviscara=GETPOST('id');
		$objectLine->label=$prod->label;
		$objectLine->qty=GETPOST('qty');
		$objectLine->description=$prod->description;
		$objectLine->fk_unit=$prod->fk_unit;
		$objectLine->subprice=$prod->price; //PU HT
		$objectLine->total_ttc=$prod->price_ttc * GETPOST('qty');
		$objectLine->tva_tx=$prod->tva_tx;
		$objectLine->fk_product=$prod->id;
		$objectLine->total_ht=$prod->price * GETPOST('qty'); //PTOTAL HT
		$objectLine->type=2;//produit
		$objectLine->position=$object->line_max()+1;
		$objectLine->create($user);
	}
	else{
		$objectLine->fk_deviscara=GETPOST('id');
		$objectLine->type=GETPOST('type');
		$objectLine->label=GETPOST('dp_desc');
		$objectLine->tva_tx=GETPOST('tva_tx');
		
		$objectLine->qty=GETPOST('qty');
		$objectLine->subprice=GETPOST('price_ht');
		$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
		$objectLine->fk_unit=GETPOST('units');
		$objectLine->position=$object->line_max()+1;
		$objectLine->create($user);
	}
	$object->update_total($tabtarif);
}
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
			//$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
		$object->update_total($tabtarif);
		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

//update line
if ($action == 'updateline' )
{
	$objectLine=new repLine($db);
	$objectLine->fetch($lineid);
	foreach ($objectLine->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($objectLine->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($objectLine->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($objectLine->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $objectLine->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} 
		elseif (preg_match('/^(varchar)/', $objectLine->fields[$key]['type'])) {
			$value = htmlspecialchars(GETPOST($key));
		}
		else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $objectLine->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($objectLine->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$objectLine->$key = $value;
		if ($val['notnull'] > 0 && $objectLine->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
	$objectLine->update($user);

	$object->update_total($tabtarif);
	
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

if ($action == 'update' && !empty($permissiontoadd))
{
	
	//récupération précarité societe pour update des primes
	$object_soc=new societe($db);
	$object_soc->fetch($object->fk_soc);
	
	//détection cuve 5000
	$idtabcuve5=1;
	foreach($object->lines as $line){
		if (in_array($line->fk_product,array(38,40))){
			$idtabcuve5=2;
			break;
		}
	}
	
	//on update la précarité ctm du client avec le nouveau RFR(car peut être modifié.)
	$object->updatePrecariteCtm($object_soc);
	$citerneenterree=$object->rechercheref(array(39,40));
	$tabinfo=get_tarif(array($object_soc->array_options['options_cara_type_client_ctm'],$idtabcuve5,$object_soc->array_options['options_maisonplus2'],$citerneenterree));
	$couleur=$tabinfo[0];
	$plafond=$tabinfo[1];
	if($couleur=='b'){
		$bgcolor='lightblue';
		$object_soc->array_options['cara_type_client_ctm']=3; //GPB
	}
	elseif($couleur=='j'){
		$bgcolor='yellow';
		$object_soc->array_options['cara_type_client_ctm']=2; //PJ
	}
	elseif($couleur=='v'){
		$bgcolor='violet';
		$object_soc->array_options['cara_type_client_ctm']=1; //HP v
	}
	$i=0;
	$object->primes=array();
	$rfrc=$object_soc->array_options['options_rfr']/$object_soc->array_options['options_nbpart'];//besoin dans l'include
	
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifrep.lib.php',1);
	

	//$object->updateprimes($user);
	$object->update_total($tabtarif);

	$status_avantmaj=$object->status;
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$newstatus=GETPOST('status');
	if($status_avantmaj != $newstatus ){
		$object->{'date_status_'.$newstatus} = dol_now(); //date de changement de statut
		$object->{'date_statusencours'} = dol_now(); 
	}
	if (!$error)
	{
		$result = $object->update($user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
	//mise à jour des primes
	
}
if ($action == 'mop' && !empty($user->rights->deviscara->dev->facturer)){
	//on met le tiers de prospect à client
	//on crée l'affaire
	// on crée l'objet
	//on paramètre l'objet
	//on inscrit l'objet dans les tableaux alternatifs (tableau mpr...) si ça se fait pas tout seul.
	$object_soc->fetch($object->fk_soc);
	$object_soc->client=1;
	$object_soc->entity=1;
	$db->begin();
	$res=$object_soc->update($object_soc->id,$user);
	if($res>0){
		dol_include_once('/carafinance/class/carafinance.class.php');
		$newaffaire=new carafinance($db);
		$newaffaire->fk_soc=$object_soc->id;
		$newaffaire->entity=1;
		$newaffaire->description_pertinente="Affaire du devis ".$object->ref;
		$newaffaire->description="Affaire du devis ".$object->ref;
		$newaffaire->date_creation=dol_now();
		$newaffaire->fk_usercomm=$object->fk_commercial;
		$newaffaire->fk_user_creat=$user->id;
		$newaffaire->pack=4; //pour rep
		if ($object->mode_reglement_code=='CMA'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=4;
		}
		elseif ($object->mode_reglement_code=='CH' || $object->mode_reglement_code=='PRELE' || $object->mode_reglement_code=='BQ' || $object->label=='iso'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_ACCEPTE;
			$newaffaire->mod_financement=1;
		}
		else{ //si pas de mode de règlement
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=1;
		}
		
		$idAffaire=$newaffaire->create($user);
		if ($idAffaire>0){
			$info=$object->getinfo();
			//on récupere l'id pour créer les produits
			$line=new carafinanceLine($db);	
			
			dol_include_once('/deviscararep/class/deviscararep.class.php');
			$prod=new Deviscararep($db);
			if($object->mode_reglement_code=='CMA')
				$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
			else
				$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER
			$prod->fk_soc=$object->fk_soc;
			$prod->fk_usercomm=$object->fk_commercial;
			$prod->label=1;
			$prod->status=Deviscararep::STATUS_DRAFT; //statut brouillon
			$prod->date_creation=$object->date_creation;
			$prod->date_accepte_mpr=$newaffaire->date_creation;
			$prod->status_mpr=1;
			$prod->status_edf2=1;
			if($info['enterree']==1)
				$prod->type_cuve=2;//cuve enterree
			else
				$prod->type_cuve=1;//cuve Hors sol	
			//nb wc
			$prod->nbwc=$info['wc'];
			if($info['cpto']>0)//si compteur eau: raccordement ttegout
				$prod->raccord_reseau=2;
			else
				$prod->raccord_reseau=1;
			$prod->description="Création Devis REP cuve de ".$info['capacitecuve']." via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$object->id,1).">Devis Commercial</a>" ;
			$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
			$prod->capacitecuve=$info['capacitecuve'];
			$idprod=$prod->create($user);
			$line->fk_type=3; //type rep
			if($idprod>0){
				$line->fk_carafinance=$idAffaire;
				$line->amount=$object->total_rac;
				$line->description=$object->description;
				$line->fk_prod=$idprod;
				$res=$line->insert();
				$object->fk_carafinance=$idAffaire;
				$object->status=$object::STATUS_CLIENT;
				$object->update($user);
				$totalracaffaire+=$object->total_rac;
			}
			
			$newaffaire->fetch($idAffaire);
			$newaffaire->date_creation=$object->date_creation;
			$newaffaire->amount=$totalracaffaire;
			$newaffaire->update($user);
		}
		else{
			$error++;
		}
	}
	else{
		$error++;
	}
	if($error>0){
		$db->rollback();
		setEventMessage('Erreur de mise en operation','','errors');
	}
	else
		$db->commit();

}

if ($action == 'facctm' && !empty($user->rights->deviscara->dev->facturer)){
	// creation facture officielle
	$db->begin();
	dol_include_once('/compta/facture/class/facture.class.php');
	$fac=new Facture($db);
	$fac->socid=$object->fk_soc;
	$fac->date_creation=$fac->date=dol_now();
	$fac->type=0;
	$fac->entity=4; //CAREP
	$fac->note_private='Creation Facture via devis <a href="'.dol_buildpath('deviscara/rep_card',1).'?id='.$object->id.'">'.$object->ref.' </a> ';
	$res=$fac->create($user);
	$fac->ref=$fac->getNextNumRef($object->fk_soc);
	$fac->statut=1;
	$res=$fac->update($user);
	if ($res>0){

		//création facture rep ctm
		dol_include_once('/deviscara/class/facrep.class.php');
		$facrep=new facrep($db);
		$facrep->fk_soc=$object->fk_soc;
		$facrep->total_ttc=$object->total_ttc;
		$facrep->total_tva=$object->total_tva;
		$facrep->total_ht=$object->total_ht;
		$facrep->total_rac=$object->total_rac;
		$facrep->description=$object->description;
		$facrep->date_creation=dol_now();
		$facrep->date_f=dol_now();
		$facrep->fk_user_creat=$user->id;
		$facrep->mode_reglement_code=$object->mode_reglement_code;
		$facrep->mode_reglement_nb=$object->mode_reglement_nb;
		$facrep->acompte=$object->acompte;
		$facrep->pencharge=$object->pencharge;
		$facrep->totaleligible=$object->totaleligible;
		$facrep->ref=$fac->ref;//memes numéros de facture
		$facrep->fk_commercial=$object->fk_commercial;
		$facrep->entity=4;
		$facrep->status=$facrep::STATUS_DRAFT; //draft
		foreach ($object->lines as $line){
			$facrepLine=new facrepLine($db);
			$facrepLine->label=$line->label;
			$facrepLine->subprice=$line->subprice;
			$facrepLine->qty=$line->qty;
			$facrepLine->description=$line->description;
			$facrepLine->date_creation=dol_now();
			$facrepLine->fk_user_creat=$line->fk_user_creat;
			$facrepLine->type=$line->type;
			$facrepLine->fk_unit=$line->fk_unit;
			$facrepLine->total_ht=$line->total_ht;
			$facrepLine->tva_tx=$line->tva_tx;
			$facrepLine->position=$line->position;
			$facrepLine->stotal_ht=$line->stotal_ht;
			$facrepLine->fk_product=$line->fk_product;
			$facrepLine->product_type=$line->product_type;
			$facrep->lines[]=$facrepLine;
		}

		$res2=$facrep->create($user);
		if ($res2>0){ 
			$db->commit();
			setEventMessages('Facturation ctm et Standard réussie', '', 'mesgs');
		}
	}
	else{
		setEventMessages('Erreur de création facture', $db->lasterror(), 'errors');
		$db->rollback();
	}	
}