<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}

$prod='toit';
// Action to add record
if ($action == 'add' || $action=='create')
{
	
	if (!$error)
	{	
		if(GETPOST('reinit')=='re-initialiser'){
			unset($_SESSION['client'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['pv']);
			$action = 'create';
		}
		else{
			if(!empty(GETPOST('toiture'))){
				$_SESSION[$prod]['devis_primaire']=1;
			}
			if (GETPOST('create_client'))
				$action="create_client";
			elseif (GETPOST('financement'))
				$action="financement";
			
			else{
				$_SESSION['type_client']=GETPOST('options_type_client');
				$_SESSION['status_immo']=GETPOST('options_status_immo');
				$_SESSION['nbpart']=GETPOST('nbpart');
				$_SESSION['rfr']=GETPOST('rfr');
				$_SESSION[$prod]['surface']=GETPOST('surface');


				$_SESSION[$prod]['isolation']=GETPOST('isolation');
				$_SESSION[$prod]['charpente']=GETPOST('charpente');
				$_SESSION[$prod]['tole']=GETPOST('tole');
				$_SESSION[$prod]['type_primech']=GETPOST('type_primech');
				$_SESSION[$prod]['metragecharpente']=GETPOST('metragecharpente');
				$_SESSION[$prod]['metragegouttieres']=GETPOST('metragegouttieres');
				$_SESSION[$prod]['gouttiere']=GETPOST('gouttiere');
				$_SESSION[$prod]['type_primegouttiere']=GETPOST('type_primegouttiere');
				$_SESSION[$prod]['metragefauxplafond']=GETPOST('metragefauxplafond');
				$_SESSION[$prod]['type_primefp']=GETPOST('type_primefp');
				$_SESSION[$prod]['metragechenaux']=GETPOST('metragechenaux');
				$_SESSION[$prod]['type_primechen']=GETPOST('type_primechen');
				$_SESSION[$prod]['vol']=GETPOST('vol');
				$_SESSION[$prod]['prime']=GETPOST('prime');
				$_SESSION[$prod]['idparts']=GETPOST('idparts');
				$_SESSION[$prod]['chienassisnb']=GETPOST('chienassisnb');
				$_SESSION[$prod]['pvdepose']=GETPOST('pvdepose');
				$_SESSION[$prod]['nbpanneaux']=GETPOST('nbpanneaux');
				$_SESSION[$prod]['cesdeposerepose']=GETPOST('cesdeposerepose');
				$_SESSION[$prod]['cesdepose']=GETPOST('cesdepose');
			}
			
			//$_SESSION['financement']['type']=GETPOST('typefin');
			
		
			
		}
		
	}
	else
	{
		$action = 'create';
	}

}
if ($action == 'financement' ){
	$select_client=GETPOST('select_client');
	if($select_client=='sélectionner Client'){
		//recherche client activée-> on affiche les informations du client pour validation.
		$object_soc=new societe($db);
		$object_soc->fetch(GETPOST('socid'));
		$action="create_client";
	}
	elseif($select_client=='clear'){
		$object_soc=new societe($db);
		$action="create_client";
	}
	else{
		
		if(GETPOST('socid')) //mise à jour du client sinon création
		{
			$object_soc=new societe($db);
			$object_soc->fetch(GETPOST('socid'));
		}
		else{ //création objet société
			$object_soc=new societe($db);
			$module = (!empty($conf->global->SOCIETE_CODECLIENT_ADDON) ? $conf->global->SOCIETE_CODECLIENT_ADDON : 'mod_codeclient_leopard');
			if (substr($module, 0, 15) == 'mod_codeclient_' && substr($module, -3) == 'php')
			{
				$module = substr($module, 0, dol_strlen($module) - 4);
			}
			$dirsociete = array_merge(array('/core/modules/societe/'), $conf->modules_parts['societe']);
			foreach ($dirsociete as $dirroot)
			{
				$res = dol_include_once($dirroot.$module.'.php');
				if ($res) break;
			}
			$modCodeClient = new $module;
			$object_soc->code_client			= $modCodeClient->getNextValue($object_soc, 0);
		}
		$object_soc->nom=GETPOST('firstname');
		$object_soc->address=GETPOST('address');

		$object_soc->array_options['ville']=GETPOST('options_ville');
		$datenaissance=dol_mktime(12, 0, 0, GETPOST('options_datenaissancemonth'),GETPOST('options_datenaissanceday'), GETPOST('options_datenaissanceyear'));
		$object_soc->array_options['options_datenaissance']=$datenaissance;
		$object_soc->array_options['spmo']=GETPOST('options_spmo');
		$object_soc->array_options['nbpart']=$_SESSION['nbpart'];
		$object_soc->array_options['rfr']=$_SESSION['rfr'];
		$object_soc->array_options['type_client']=$_SESSION['type_client'];
		$object_soc->array_options['status_immo']=$_SESSION['status_immo'];
		
		$object_soc->phone=GETPOST('phone');
		$object_soc->fax=GETPOST('fax');
		$object_soc->url=GETPOST('url');
		$object_soc->email=GETPOST('email');
		if($object_soc->id)
			$object_soc->client=1; //client
		else
			$object_soc->client=2; //prospect
		$object_soc->status=1; //prospect
		$object_soc->pays=1; //france
		$object_soc->commercial_id=$user->id;
		
		$error=0;
		
		if($object_soc->phone=="") $error++;
		if($object_soc->email=="") $error++;
		if($object_soc->nom=="") $error++;
		if($object_soc->array_options['ville']=="0") $error++;
		if($error>0){
			setEventmessages('Chmaps Noms, Téléphone, email obligatoires',null,'errors');
			$action='create_client';
			return;
		}
		
		$db->begin();
		
		//création du devis
		$object->label='toit'; 
		
		$tabinfo=get_tarif();
		$couleur=$tabinfo[0];
		$plafond=$tabinfo[1];
		if($couleur=='b'){
			$object_soc->array_options['cara_type_client']=3; //GPB
		}
		elseif($couleur=='j'){
			$object_soc->array_options['cara_type_client']=2; //PJ
		}
		elseif($couleur=='v'){
			$object_soc->array_options['cara_type_client']=1; //HP v
		}
		elseif($couleur=='r'){
			$object_soc->array_options['cara_type_client']=5; //HP v
		}
		if($object_soc->id){//mise à jour si client choisi
			$res=$object_soc->update($object_soc->id,$user);
			if ($res>0){
				$db->commit();
				setEventmessages('Client mis à jour',null,'mesgs');
				$action='financement';
			}
			else{
				$db->rollback();
				setEventmessages('Problème de mise à jour','Vérifier la fiche tiers (code tiers....)','errors');
				$action='create_client';
			}
		}
		else{
			$object_soc->create($user);
			if ($res>0){
				$db->commit();
				setEventmessages('Client mis à jour',null,'mesgs');
				$action='financement';
			}
			else{
				$db->rollback();
				setEventmessages('Problème de mise à jour',null,'errors');
				$action='create_client';
			}
		}
		
	}
		
}

if ($action == 'financement2'){
	if(GETPOST('reset_financement')!=''){
		unset($_SESSION['financement']['stype']);
	}
	if(GETPOST('typefin')=='fincma'){
		$_SESSION['financement']['type']='fincma';
	}
	if(GETPOST('typefin')=='perso'){
		$_SESSION['financement']['type']='perso';
	}
	$_SESSION['financement']['acompte']=(GETPOST('acompte')>0?GETPOST('acompte'):0);
	$action='financement';
	
	if(GETPOST('cmanbmois')!=''){
		$tab=explode('/',GETPOST('cmanbmois'));
		$_SESSION['financement']['stype']['cma']=$tab[0];
		$_SESSION['financement']['stype']['mensualite']=$tab[1];
		$_SESSION['financement']['stype']['cmamontantedf']=$tab[2];
		$_SESSION['financement']['stype']['cmamontantmpr']=$tab[3];
	} 
	elseif (GETPOST('personbch')>0){
		unset($_SESSION['financement']['stype']['pre']);
		unset($_SESSION['financement']['stype']['persobanque']);
		$_SESSION['financement']['stype']['ch']=GETPOST('personbch');
	} 
	elseif(GETPOST('personbprelev')>0){
		unset($_SESSION['financement']['stype']['ch']);
		unset($_SESSION['financement']['stype']['persobanque']);
		$_SESSION['financement']['stype']['pre']=GETPOST('personbprelev');
	}
	elseif(GETPOST('persobanque')!= ''){
		unset($_SESSION['financement']['stype']['pre']);
		unset($_SESSION['financement']['stype']['ch']);
		$_SESSION['financement']['stype']['persobanque']=GETPOST('persobanque');
	}
	if(GETPOST('valid_financement')=='Valider' )
		$action='creationdevis';

}
if ($action == 'creationdevis'){
	$object->label='toiture';
	$object_soc=new societe($db);
	$object_soc->fetch(GETPOST('socid'));
	$object->fk_soc=$object_soc->id;
	$object->fk_commercial=$user->id;
	$object->fk_soc=$object_soc->id;
	$prod='toit';
	$tabinfo=get_tarif();
	$couleur=$tabinfo[0];

	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoit.lib.php',1);

	function insert_object(&$objectLine,$type,$prod){
		global $tabtarif;
		$objectLine->label=$tabtarif[$type][0][$prod]->label;
		$objectLine->ref=$tabtarif[$type][0][$prod]->ref;
		$objectLine->description=$tabtarif[$type][0][$prod]->description;
		$objectLine->fk_unit=$tabtarif[$type][0][$prod]->fk_unit;
		$objectLine->subprice=$tabtarif[$type][0][$prod]->price; //PU HT
		$objectLine->total_ttc=$tabtarif[$type][0][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->tva_tx=$tabtarif[$type][0][$prod]->tva_tx;
		$objectLine->fk_product=$tabtarif[$type][0][$prod]->id;
		$objectLine->total_ht=$tabtarif[$type][0][$prod]->price*$objectLine->qty; //PTOTAL HT
		//edf
		$objectLine->fk_product_edf=$tabtarif[$type][1][$prod]->id;
		$objectLine->subprice_edf=$tabtarif[$type][1][$prod]->price; //PU HT
		$objectLine->tva_tx_edf=$tabtarif[$type][1][$prod]->tva_tx;
		$objectLine->total_ht_edf=$tabtarif[$type][1][$prod]->price*$objectLine->qty; //PTOTAL HT
		$objectLine->total_ttc_edf=$tabtarif[$type][1][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->type=2;//produit
	}
	
	function insert_prime(&$objectLine,$couleur,$type,$prod){
		global $tabtarif;
		$objectLine->label=$tabtarif[$couleur][$type][$prod]->label;
		$objectLine->ref=$tabtarif[$couleur][$type][$prod]->ref;
		$objectLine->description=$tabtarif[$couleur][$type][$prod]->description;
		$objectLine->fk_unit=$tabtarif[$couleur][$type][$prod]->fk_unit;
		$objectLine->subprice=$tabtarif[$couleur][$type][$prod]->price; //PU HT
		$objectLine->total_ttc=$tabtarif[$couleur][$type][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->tva_tx=$tabtarif[$couleur][$type][$prod]->tva_tx;
		$objectLine->fk_product=$tabtarif[$couleur][$type][$prod]->id;
		$objectLine->total_ht=$tabtarif[$couleur][$type][$prod]->price*$objectLine->qty; //PTOTAL HT
		$objectLine->type=2;//produit
	}
	
	$i=0;
	
	$objectLine = new toitLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'forfait','previsite');
	$objectLine->rang=$i;
	$object->lines[$i]=$objectLine;
	// $total_ttc +=$objectLine->total_ttc;
	// $total_edf+=$objectLine->total_ttc_edf;
	// $total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	// $total_lig_tva_edf=$objectLine->total_ttc_edf-$objectLine->total_ht_edf;
	// $total_tva += $total_lig_tva;
	// $total_tva_edf += $total_lig_tva_edf;
	// $total_ht += $objectLine->total_ht;
	// $total_ht_edf += $objectLine->total_ht_edf;
	$total=cumulinsertdevis($total,$objectLine);

	$i++;
	$objectLine = new toitLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'forfait','livraison');
	$objectLine->rang=$i;
	$object->lines[$i]=$objectLine;
	$total=cumulinsertdevis($total,$objectLine);

	//toiture
	$i++;
	$objectLine = new toitLine($db);
	$objectLine->qty=$_SESSION[$prod]['surface'];
	insert_object($objectLine,'pv','tole');
	$objectLine->rang=$i;
	$object->lines[$i]=$objectLine;
	$total=cumulinsertdevis($total,$objectLine);
	
	//mot
	if($tabtarif['pv'][0]['posetole']){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface'];
		insert_object($objectLine,'pv','posetole');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		
		$sous_totalht=$total['ht'];
	}
	$i++;
	//Sous total
	$objectLine = new toitLine($db);
	$objectLine->label='<i>Sous total couverture :</i>';
	$objectLine->rang=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$objectLine->special_code=104777;
	$objectLine->qty=99 ;
	$objectLine->stotal_ht=$sous_totalht;
	$object->lines[$i]=$objectLine;

	$sous_totalht=0;

	//isolation
	$i++;
	$objectLine = new toitLine($db);
	$objectLine->qty=$_SESSION[$prod]['surface'];
	insert_object($objectLine,'pv109','109');
	$objectLine->rang=$i;
	$object->lines[$i]=$objectLine;
	$total=cumulinsertdevis($total,$objectLine);
	$sous_totalht+=$total['ht'];
	
	
	if($tabtarif['pv109'][0]['pose109']){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface'];
		insert_object($objectLine,'pv109','pose109');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$total['ht'];
	}
	
	$i++;
	//Sous total
	$objectLine = new toitLine($db);
	$objectLine->label='<i>Sous total 109 :</i>';
	$objectLine->rang=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$objectLine->special_code=104777;
	$objectLine->qty=99 ;
	$objectLine->stotal_ht=$sous_totalht;
	$object->lines[$i]=$objectLine;

	//remise à 0
	$sous_totalht=0;
	if($tabtarif['pv106'][0]['106']){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface'];
		insert_object($objectLine,'pv106','106');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$total['ht'];
	}
	if($tabtarif['pv106'][0]['pose106']){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface'];
		insert_object($objectLine,'pv106','pose106');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$total['ht'];
	}
	if($tabtarif['pv106'][0]['106']){
		$i++;
		//Sous total
		$objectLine = new toitLine($db);
		$objectLine->label='<i>Sous total 106 :</i>';
		$objectLine->rang=$i;
		$objectLine->description=NULL;
		$objectLine->fk_product=NULL;
		$objectLine->product_type=9;
		$objectLine->special_code=104777;
		$objectLine->qty=99 ;
		$objectLine->stotal_ht=$sous_totalht;
		$object->lines[$i]=$objectLine;
	}
	//options
	if($_SESSION[$prod]['metragecharpente']>0){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragecharpente'];
		insert_object($objectLine,'option','char');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
	}
	if($_SESSION[$prod]['metragegouttieres']>0){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragegouttieres'];
		insert_object($objectLine,'option','gouttiere');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
	}
	if($_SESSION[$prod]['metragefauxplafond']>0){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragefauxplafond'];
		insert_object($objectLine,'option','fp');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		
	}
	if($_SESSION[$prod]['metragechenaux']>0){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragechenaux'];
		insert_object($objectLine,'option','chen');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		
	}
	if($_SESSION[$prod]['chienassisnb']>0){//chien assis
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['chienassisnb']; //forfait
		insert_object($objectLine,'option','chienassis');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
	}
	if($_SESSION[$prod]['nbpanneaux']>0){//dépose et repose panneaux
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['nbpanneaux'];
		insert_object($objectLine,'option','nbpanneaux');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
	}
	if($_SESSION[$prod]['cesdepose']>0){//dépose ces
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=1; //forfait
		insert_object($objectLine,'option','cesdepose');
		$objectLine->rang=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
	}
	//primes
	$total_primes=0;

	foreach($tabtarif[$couleur]['pr'] as $type_prime=>$tabprime){
		$i++;
		$objectLine = new toitLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface'];
		insert_prime($objectLine,$couleur,'pr',$type_prime);
		$objectLine->rang=$i;
		if($tabprime->array_options['options_type_prime']==2){
			$total_primesMPR+=$objectLine->total_ht;
		}
		elseif($tabprime->array_options['options_type_prime']==1){
			$total_primesEDF+=$objectLine->total_ht;
		}
		$object->lines[$i]=$objectLine;
	}
	 $i++;

	//Devis provisoire
	$objectLine = new toitLine($db);
	$objectLine->label='<b>DEVIS PROVISOIRE : la tarification définitive et les détails techniques de votre installation seront précisés suite à la visite technique, sous réserve de validation de vos droits à subventions (dans le corps du devis)</b>';
	$objectLine->rang=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$objectLine->special_code=104777;
	$objectLine->qty=1;
	$object->lines[$i]=$objectLine;


	$object->surfacevendue = $_SESSION[$prod]['surface'];
	$object->total_ht=$total['ht'];
	$object->total_ttc=$total['ttc'];
	$object->total_tva=$total['tva'];
	$object->total_ttc_edf=$total['ttc_edf'];
	$object->total_racedf=$object->total_ttc_edf+$total_primesEDF;
	$object->total_racclient=$object->total_ttc+$total_primesEDF+$total_primesMPR; //après mpr
	$object->acompte=$_SESSION['financement']['acompte'];
	$object->status_comercial=1; //status par défaut à la génération du devis bc.

	//règlement
	if(GETPOST('typefin')=='fincma'){
		$object->mode_reglement_code=1;
		$object->mode_reglement_cmanbbc=$_SESSION['financement']['stype']['mensualite'];
		$object->mode_reglement_montant_edf=$_SESSION['financement']['stype']['cmamontantedf'];
		$object->mode_reglement_montant_client=$_SESSION['financement']['stype']['cmamontantmpr'];
		$object->bc_cma_report=$_SESSION['financement']['stype']['cma'];
		$object->mode_financement=2; //financement cma
	}
	if(GETPOST('typefin')=='perso'){
		$object->mode_financement=1; //financement Perso
		if($_SESSION['financement']['stype']['ch']>0){
			$object->mode_reglement_code=2;
			$object->mode_reglement_nb=$_SESSION['financement']['stype']['ch'];
			$object->mode_reglement_montant_edf=($_SESSION['financement']['totaledf']-$_SESSION['financement']['acompte']);
			$object->mode_reglement_montant_client=($_SESSION['financement']['totalmpr']-$_SESSION['financement']['acompte']);
		}
		if($_SESSION['financement']['stype']['pre']>0){
			$object->mode_reglement_code=2;
			$object->mode_reglement_nb=$_SESSION['financement']['stype']['pre'];
			$object->mode_reglement_montant_edf=($_SESSION['financement']['totaledf']-$_SESSION['financement']['acompte']);
			$object->mode_reglement_montant_client=($_SESSION['financement']['totalmpr']-$_SESSION['financement']['acompte']);
		}
		if($_SESSION['financement']['stype']['persobanque']!=''){
			$object->mode_reglement_code=3;
			$object->mode_reglement_montant_edf=($_SESSION['financement']['totaledf']-$_SESSION['financement']['acompte']);
			$object->mode_reglement_montant_client=($_SESSION['financement']['totalmpr']-$_SESSION['financement']['acompte']);
		}
	}


	if($object->total_ht>0){
		$result = $object->create($user);
		unset($_SESSION['client'],$_SESSION['toit'],$_SESSION['financement'],
		$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);
		$db->commit();
	}
	else $db->rollback();
	if ($result > 0)
	{
		// Creation OK
		$urltogo = dol_buildpath('deviscara/toit_card.php',1).'?id='.$object->id;
		header("Location: ".$urltogo);
		exit;
	}
	else
	{
		// Creation KO
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else  setEventMessages($object->error, null, 'errors');
		$action = 'create';
	}
	
}
if ($action == 'addline')
{
	$objectLine=new toitLine($db);
	$objectLine->fk_product=GETPOST('idprod');
	if($objectLine->fk_product > 0 && GETPOST('prod_entry_mode')!='free'){
		$prod=new Product($db);
		$prod->fetch($objectLine->fk_product);
		$objectLine->fk_deviscara_toit=GETPOST('id');
		$objectLine->label=$prod->label;
		$objectLine->qty=GETPOST('qty');
		$objectLine->description=$prod->description;
		$objectLine->fk_unit=$prod->fk_unit;
		$objectLine->subprice=$prod->price; //PU HT
		$objectLine->total_ttc=$prod->price_ttc * GETPOST('qty');
		$objectLine->tva_tx=$prod->tva_tx;
		$objectLine->fk_product=$prod->id;
		$objectLine->total_ht=$prod->price * GETPOST('qty'); //PTOTAL HT
		$objectLine->type=2;//produit
		$objectLine->rang=$object->line_max()+1;
		$objectLine->create($user);
	}
	else{
		$objectLine->fk_deviscara_toit=GETPOST('id');
		$objectLine->type=GETPOST('type');
		$objectLine->label=GETPOST('dp_desc');
		$objectLine->tva_tx=GETPOST('tva_tx');
		
		$objectLine->qty=GETPOST('qty');
		$objectLine->subprice=GETPOST('price_ht');
		$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
		$objectLine->fk_unit=GETPOST('units');
		$objectLine->rang=$object->line_max()+1;
		$objectLine->create($user);
	}
	$object->update_total($tabtarif);
}
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
			//$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
		$object->update_total($tabtarif);
		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

//update line
if ($action == 'updateline' )
{
	$objectLine= new toitLine($db);
	$objectLine->fetch($lineid);
	foreach ($objectLine->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($objectLine->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($objectLine->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($objectLine->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $objectLine->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} 
		elseif (preg_match('/^(varchar)/', $objectLine->fields[$key]['type'])) {
			$value = htmlspecialchars(GETPOST($key));
		}
		else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $objectLine->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($objectLine->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$objectLine->$key = $value;
		if ($val['notnull'] > 0 && $objectLine->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
	$objectLine->update($user);

	$object->update_total($tabtarif);
	
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

if ($action == 'update' && !empty($permissiontoadd))
{
	
	
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	
	
	if (!$error)
	{
		$result = $object->update($user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
	//mise à jour des primes
	
}
