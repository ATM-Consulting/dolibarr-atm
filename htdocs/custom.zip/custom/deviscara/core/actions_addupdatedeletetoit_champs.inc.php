<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}



if ($action == 'update' && !empty($permissiontoadd))
{
	
	$statusadmin_avantmaj=$object->status_admin;
	$status_avantmaj=$object->status;
	$statuspiecesmanquante_avantmaj=$object->status_piecesmanquantes;
	$statuscma_avantmaj=$object->status_cma;
	$statusperso_avantmaj=$object->status_perso;
	$statusconftechnique_avantmaj=$object->status_conftechnique;
	$noedf106_avantmaj=$object->noedf106;
	$status_edf106_avantmaj=$object->status_edf106;
	$status_edf109_avantmaj=$object->status_edf109;
	$status_mpr_avantmaj=$object->status_mpr;
	$status_soulte_avantmaj=$object->status_soulte;
	$status_previsite_avantmaj=$object->status_previsite;
	$status_control_avantmaj=$object->status_control;
	$status_sav_avantmaj=$object->status_sav;
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	
	$newstatus=GETPOST('status');
	$newstatusadmin=GETPOST('status_admin');
	$newstatuspiecesmanquante=GETPOST('status_piecesmanquantes');
	$newstatuscma=GETPOST('status_cma');
	$newstatusperso=GETPOST('status_perso');
	$newstatusconftechnique=GETPOST('status_conftechnique');

	if($object->fk_devisdefinitif){
		$objectdef=new toitdef($db);
		$objectdef->fetch($object->fk_devisdefinitif);
	}

	if($status_avantmaj != $newstatus && $newstatus!=''){
		$object->{'date_status_'.$newstatus} = dol_now(); //date de changement de statut
		$object->date_statusencours = dol_now();
		if($newstatus==$object::STATUSADMIN_INCOMPLET){
			$object->status_piecesmanquantes=$object::STATUSPMANQUANTE_ACOMPLETER;
		}
	}
	if($statusadmin_avantmaj != $newstatusadmin &&  $newstatusadmin >0){
		$object->{'date_statusadmin_'.$newstatusadmin} = dol_now(); //date de changement de statut
		$object->date_statusadmin_encours = dol_now();
		if($newstatusadmin==$object::STATUSADMIN_INCOMPLET){
			$object->status_piecesmanquantes=$object::STATUSPMANQUANTE_ACOMPLETER;
			if($object->mode_reglement_code == $object::MODEREGLEMENT_CMA){
				$object->status_cma = $object::STATUSCMA_ATRAITER;
				$object->{'date_statuscma_'.$object->status_cma} = dol_now();
				$object->date_statuscma_encours = dol_now();
				
			}
			else{
				$object->status_perso = $object::STATUSPERSO_ATRAITER;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
				
			}
		}
		if($object->status_admin==$object::STATUSADMIN_CONFORME || $object->status_admin==$object::STATUSADMIN_COMPLET){
			if($object->mode_reglement_code == $object::MODEREGLEMENT_CMA){
				$object->status_cma = $object::STATUSCMA_ATRAITER;
				$object->{'date_statuscma_'.$object->status_cma} = dol_now();
				$object->date_statuscma_encours = dol_now();
			}
			else{
				$object->status_perso = $object::STATUSPERSO_ATRAITER;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
			}
			$object->status=$object::STATUS_CLIENT;
			$object->{'date_status_'.$object->status} = dol_now();
			$object->date_statusencours = dol_now();
		}
		if($newstatusadmin==$object::STATUSADMIN_NONCONFORME){
			$object->status_piecesmanquantes=$object::STATUSPMANQUANTE_ACOMPLETER;
		}
		if($newstatusadmin==$object::STATUSADMIN_COMPLET){
			$object->status=$object::STATUS_CLIENT;
			$object->{'date_status_'.$object->status} = dol_now();
			$object->date_statusencours = dol_now();
		}
		if(($object->status_admin == $object::STATUSADMIN_CONFORME || $object->status_admin == $object::STATUSADMIN_COMPLET) && 
			($object->status_cma == $object::STATUSCMA_ACCEPTE || $object->status_cma == $object::STATUSCMA_FAVORABLE || $object->status_perso == $object::STATUSPERSO_1ACOMPTE))
		{
			$object->status_edf106=1;
			$object->date_statusedf106_encours = dol_now();
			$object->{'date_statusedf106_'.$object->status_edf106} = dol_now();
			$object->status_edf109=1;
			$object->date_statusedf109_encours = dol_now();
			$object->{'date_statusedf109_'.$object->status_edf109} = dol_now();
			$object->status_mpr=1;
			$object->date_statusmpr_encours = dol_now();
			$object->{'date_statusmpr_'.$object->status_mpr} = dol_now();
		}
		
	}
	if($statuspiecesmanquante_avantmaj != $newstatuspiecesmanquante && $newstatuspiecesmanquante >0 ){
		if($newstatuspiecesmanquante == $object::STATUSPMANQUANTE_COMPLET){
			$object->status_admin = $object::STATUSADMIN_COMPLET;
			$object->{'date_statusadmin_'.$object->status_admin} = dol_now();
			$object->date_statusadmin_encours = dol_now();
		}
		if($newstatuspiecesmanquante == $object::STATUSPMANQUANTE_CONFORME){
			$object->status_admin = $object::STATUSADMIN_CONFORME;
			$object->{'date_statusadmin_'.$object->status_admin} = dol_now();
			$object->date_statusadmin_encours = dol_now();
			if($object->mode_reglement_code == $object::MODEREGLEMENT_CMA){
				$object->status_cma = $object::STATUSCMA_ATRAITER;
				$object->{'date_statuscma_'.$object->status_cma} = dol_now();
			}
			else{
				$object->status_perso = $object::STATUSPERSO_ATRAITER;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
			}
		}
	}
	if($statuscma_avantmaj != $object->status_cma && $object->status_cma > 0 ){
		$object->{'date_statuscma_'.$object->status_cma} = dol_now(); //date de changement de statut
		$object->date_statuscma_encours = dol_now();
		if($newstatuscma==$object::STATUSCMA_REFUSE){
			$object->status_admin = $object::STATUSADMIN_YONI;
			$object->{'date_statusadmin_'.$object->status_admin} = dol_now();
			$object->date_statusadmin_encours = dol_now();
		}
		if(
			($object->status_cma == $object::STATUSCMA_ACCEPTE || $object->status_cma == $object::STATUSCMA_FAVORABLE) && 
			($object->status_admin==$object::STATUSADMIN_CONFORME || $object->status_admin==$object::STATUSADMIN_COMPLET))
		{
			$object->status_conftechnique = $object::STATUSCONFTECH_ATRAITER;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now();
			$object->date_statustechique_encours = dol_now();
			//etats edf
			$object->status_edf106=1;
			$object->date_statusedf106_encours = dol_now();
			$object->{'date_statusedf106_'.$object->status_edf106} = dol_now();
			$object->status_edf109=1;
			$object->date_statusedf109_encours = dol_now();
			$object->{'date_statusedf109_'.$object->status_edf109} = dol_now();
			$object->status_mpr=1;
			$object->date_statusmpr_encours = dol_now();
			$object->{'date_statusmpr_'.$object->status_mpr} = dol_now();
			$object->status_previsite=$object::STATUSPREVISITE_ATRAITER;
			$object->date_statusprevisite_encours=dol_now();
			$object->{'date_statusprevisite_'.$object->status_previsite} = dol_now(); //date de changement de statut

		}
		if($newstatuscma == $object::STATUSCMA_ENGAGE){
			$object->status_conftechnique = $object::STATUSCONFTECH_AFABRIQUER;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now();
			$object->date_statustechique_encours = dol_now();
		}
	}
	if($object->status_perso > 0 && $statusperso_avantmaj!= $object->status_perso){
		$object->{'date_statusperso_'.$object->status_perso} = dol_now(); //date de changement de statut
		$object->date_statusperso_encours = dol_now();
		if($newstatusperso==$object::STATUSPERSO_REFUSE){
			$object->status_admin = $object::STATUSADMIN_YONI;
			$object->{'date_statusadmin_'.$object->status_admin} = dol_now();
			$object->date_statusadmin_encours = dol_now();
		}
		if($newstatusperso==$object::STATUSPERSO_DEVDEFASIGNER){
			$object->status_cma = $object::STATUSCMA_DEVCONFORME;
			$object->{'date_statuscma_'.$object->status_cma} = dol_now();
			$object->date_statuscma_encours = dol_now();
		}
		if($newstatusperso==$object::STATUSPERSO_1ACOMPTE &&
		 ($newstatusadmin==$object::STATUSADMIN_CONFORME || $newstatusadmin==$object::STATUSADMIN_COMPLET) )
		 {
			$object->status_conftechnique = $object::STATUSCONFTECH_ATRAITER;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now();
			$object->date_statustechique_encours = dol_now();
			//edf et mpr
			$object->status_edf106=1;
			$object->date_statusedf106_encours = dol_now();
			$object->{'date_statusedf106_'.$object->status_edf106} = dol_now();
			$object->status_edf109=1;
			$object->date_statusedf109_encours = dol_now();
			$object->{'date_statusedf109_'.$object->status_edf109} = dol_now();
			$object->status_mpr=1;
			$object->date_statusmpr_encours = dol_now();
			$object->{'date_statusmpr_'.$object->status_mpr} = dol_now();
			$object->status_previsite=$object::STATUSPREVISITE_ATRAITER;
			$object->date_statusprevisite_encours=dol_now();
			$object->{'date_statusprevisite_'.$object->status_previsite} = dol_now(); //date de changement de statut
		}
		if($newstatusperso==$object::STATUSPERSO_2ACOMPTE){
			$object->status_conftechnique = $object::STATUSCONFTECH_AFABRIQUER;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now();
			$object->date_statustechique_encours = dol_now();
		}
		if($newstatusperso==$object::STATUSPERSO_3ACOMPTE){
			$object->status_conftechnique = $object::STATUSCONFTECH_LIVRE;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now();
			$object->date_statustechique_encours = dol_now();
		}
		if($newstatusperso==$object::STATUSPERSO_CLOTURE){
			//calcule le solde de la facture.
			$object->com_solde = $object->total_ttc-$object->acompte50;
			$object->date_solde=dol_now();
		}
	}
	if($status_soulte_avantmaj != $object->status_soulte && $object->status_soulte > 0 ){
		$object->{'date_statussoulte_'.$object->status_soulte} = dol_now(); //date de changement de statut
		$object->date_statussoulte_encours = dol_now();
	}
	if($statusconftechnique_avantmaj != $newstatusconftechnique && $newstatusconftechnique> 0 ){
		$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now(); //date de changement de statut
		$object->date_statustechique_encours = dol_now();
		if($newstatusadmin==$object::STATUSADMIN_INCOMPLET){
			if($newstatusconftechnique == $object::STATUSCONFTECH_DEVCONFORME){
				$object->status_perso = $object::STATUSPERSO_DEVDEFASIGNER;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
			}
		}
		if($newstatusconftechnique == $object::STATUSCONFTECH_ALIVRER){
			if($object->mode_reglement_code != $object::MODEREGLEMENT_CMA){
				$object->status_perso = $object::STATUSPERSO_LIVRE;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
			}
		}
		if($newstatusconftechnique == $object::STATUSCONFTECH_LIVRE){
			if($object->mode_reglement_code != $object::MODEREGLEMENT_CMA){
				$object->status_perso = $object::STATUSPERSO_LIVRE;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
			}
		}
		if($newstatusconftechnique == $object::STATUSCONFTECH_DEVASIGNE){
			if($object->mode_financement == $object::MODE_FINANCEMENT_CMA){
				$object->status_cma = $object::STATUSCMA_DEVCONFORME;
				$object->{'date_statuscma_'.$object->status_cma} = dol_now();
				$object->date_statuscma_encours = dol_now();
			}
			else
				$object->status_perso = $object::STATUSPERSO_DEVDEFASIGNER;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
		}
		if($newstatusconftechnique == $object::STATUSCONFTECH_CLOTURE){
			if($object->mode_financement == $object::MODE_FINANCEMENT_CMA){
				$object->status_cma = $object::STATUSCMA_PVSIGNE;
				$object->{'date_statuscma_'.$object->status_cma} = dol_now();
				$object->date_statuscma_encours = dol_now();
			}
			else{
				$object->status_perso = $object::STATUSPERSO_PVSIGNE;
				$object->{'date_statusperso_'.$object->status_perso} = dol_now();
				$object->date_statusperso_encours = dol_now();
			}
		}
		if($newstatusconftechnique == $object::STATUSCONFTECH_CONTROL){
			$object->status_control = $object::STATUSCONTROL_ATRAITER;
			$object->{'date_statuscontrol_'.$object->status_perso} = dol_now();
			$object->date_statusperso_encours = dol_now();
		}
	}
	if($object->nofacacompte != ''){
		$object->com_paiementacompte=3;// acompte payé
		$object->status_comercial=2;
	}
	if($object->nofacsolde != ''){
		$object->com_paiementsolde=3;// solde payé
		$object->status_comercial=3;
	}
	if($object->noedf106 != '' && $noedf106_avantmaj!= $object->noedf106){
		$object->date_edf106=dol_now();
	}
	if($object->status_edf106 > 0 && $status_edf106_avantmaj!= $object->status_edf106){
		$object->date_statusedf106_encours=dol_now();
		$object->{'date_statusedf106_'.$object->status_edf106} = dol_now(); //date de changement de statut
	}
	if($object->status_edf109 > 0 && $status_edf109_avantmaj!= $object->status_edf109){
		$object->date_statusedf109_encours=dol_now();
		$object->{'date_statusedf109_'.$object->status_edf109} = dol_now(); //date de changement de statut
	}
	if($object->status_mpr > 0 && $status_mpr_avantmaj!= $object->status_mpr){
		$object->date_statusmpr_encours=dol_now();
		$object->{'date_statusmpr_'.$object->status_mpr} = dol_now(); //date de changement de statut
	}
	if($object->status_previsite > 0 && $status_previsite_avantmaj!= $object->status_previsite){
		$object->date_statusprevisite_encours=dol_now();
		$object->{'date_statusprevisite_'.$object->status_previsite} = dol_now(); //date de changement de statut
		if($object->status_previsite==$object::STATUSPREVISITE_PLANOK){
			$object->status_conftechnique=$object::STATUSCONFTECH_PREVISITE;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now(); //date de changement de statut
			$object->date_statustechique_encours = dol_now();
		}
	}
	//mise à jour du status general
	if(in_array($object->status,array($object::STATUS_VALIDATED,$object::STATUS_ACOMPLETER,$object::STATUS_CLIENT))){
		$object->status_general=$object::STATUS_GENERALENCOURS;
	}
	if($object->status_edf106 == 11 && $object->status_edf109 == 11 && $object->status_mpr == 11 && 
	($object->status_cma == $object::STATUSCMA_CLOTURE || $object->status_perso == $object::STATUSPERSO_CLOTURE) ){
		if($object->soulte_mt>0 && $object->status_soulte == 5)
			$object->status_general = $object::STATUS_GENERALCLOTURE;
		elseif($object->soulte_mt==0  || $object->soulte_mt == '')
			$object->status_general = $object::STATUS_GENERALCLOTURE;
	}
	if($object->status_piecesmanquantes > 0 && $statuspiecesmanquantes_avantmaj!= $object->status_piecesmanquantes){
		if($object->status_piecesmanquantes==$object::STATUSPMANQUANTE_COMPLET){
			$object->status_admin=$object::STATUSADMIN_DOCRECU;
			$object->{'date_statusadmin_'.$newstatusadmin} = dol_now(); //date de changement de statut
			$object->date_statusadmin_encours = dol_now();
		}
	}
	$object->mprdelta_montant=$object->mprestime_montant - $object->mprrecu_montant;
	$object->com_solde=$object->com_comreelle - $object->com_retenue - $object->acompte50;

	if($object->status_control > 0 && $status_control_avantmaj!= $object->status_control){
		$object->date_statuscontrol_encours=dol_now();
		$object->{'date_statuscontrol_'.$object->status_control} = dol_now(); //date de changement de statut
		if($object->status_control==$object::STATUSCONTROL_SANSRESERVE || $object->status_control==$object::STATUSCONTROL_PVSIGNE){
			$object->status_conftechnique=$object::STATUSCONFTECH_CLOTURE;
			$object->{'date_statustechique_'.$object->status_conftechnique} = dol_now(); //date de changement de statut
			$object->date_statustechique_encours = dol_now();
		}
		if($object->status_control==$object::STATUSCONTROL_AVECRESERVE ){
			$object->status_sav=1;
		}
	}
	if($object->status_sav > 0 && $status_sav_avantmaj!= $object->status_sav){
		if($object->status_sav==4){//sav ok
			$object->status_control=$object::STATUSCONTROL_VERIFICATION;
			$object->date_statuscontrol_encours=dol_now();
			$object->{'date_statuscontrol_'.$object->status_control} = dol_now(); //date de changement de statut
		}
 	}

	//mise à jour des champs du tiers
	$options_soc=array('tiersedf','tiersmpr','adressetf');
	foreach($options_soc as $key_soc){
		$object_soc->array_options['options_'.$key_soc]= GETPOST('options_'.$key_soc);
	}
	
	//bypass de la regression des droits
	if($user->rights->deviscara->etats->write !=1 ){
		//test regression status
		$array_status=array('status_admin'=>'statusadmin_avantmaj','status'=>'status_avantmaj','status_piecesmanquantes'=>'statuspiecesmanquante_avantmaj',
						'status_cma'=>'statuscma_avantmaj','status_perso'=>'statusperso_avantmaj','status_conftechnique'=>'statusconftechnique_avantmaj',
						'status_edf106'=>'status_edf106_avantmaj','status_edf109'=>'status_edf109_avantmaj','status_mpr'=>'status_mpr_avantmaj',
						'status_soulte'=>'status_soulte_avantmaj','status_previsite'=>'status_previsite_avantmaj');
		foreach($array_status as $key_status=>$statusavmaj){
			$fliparray_status=array_flip($object->fields[$key_status]['orderkey'] );
			$rang_ancienne_valeur=$fliparray_status[${$statusavmaj}];
			foreach ($object->fields[$key_status]['orderkey'] as $key=> $newval){
				if ($object->$key_status == $newval && $key < $rang_ancienne_valeur){
					$object->$key_status=${$statusavmaj};
					setEventMessages('Maj impossible des etats: pas de regression possible', 'champ'.$key_status,'errors');
					break;
				}
			}
		}
	}
	if (!$error)
	{
		$result = $object->update($user);
		$res2= $object_soc->update($object->fk_soc,$user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
}