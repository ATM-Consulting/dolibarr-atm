<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}

if( $_SESSION['fromid'] > 0 )
	goto clientexit;

// Action to add record
if ($action == 'add' && !empty($permissiontoadd))
{
	foreach ($object->fields as $key => $val)
	{
		if ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour') == '' && GETPOST($key.'min') == '') continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'date_creation', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to insert
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month', 'int'), GETPOST($key.'day', 'int'), GETPOST($key.'year', 'int'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour', 'int'), GETPOST($key.'min', 'int'), 0, GETPOST($key.'month', 'int'), GETPOST($key.'day', 'int'), GETPOST($key.'year', 'int'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
			$value = price2num(GETPOST($key, 'none')); // To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		//var_dump($key.' '.$value.' '.$object->fields[$key]['type']);
		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && !is_null($val['default']) && $val['default'] == '(PROV)')
		{
		    $object->$key = '(PROV)';
		}
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}

	if (!$error)
	{	
		
		if(GETPOST('devis')){
			clientexit:
			if($_SESSION['fromid']){//client déjà existant
				$object_soc->fetch($_SESSION['fk_soc']);
				$couleur=get_tarif();
				$db->begin();
			}
			else{
			
				//création client
				
				$object_soc->nom=GETPOST('firstname');
				$object_soc->address=GETPOST('address');

				$object_soc->array_options['ville']=GETPOST('options_ville');
				$object_soc->array_options['nbpart']=$_SESSION['nbpart'];
				$object_soc->array_options['rfr']=$_SESSION['rfr'];
				
				$object_soc->phone=GETPOST('phone');
				$object_soc->fax=GETPOST('fax');
				$object_soc->url=GETPOST('url');
				$object_soc->email=GETPOST('email');
				$object_soc->client=2; //prospect
				$object_soc->status=1; //prospect
				$object_soc->pays=1; //france
				$object_soc->commercial_id=$user->id;
				$module = (!empty($conf->global->SOCIETE_CODECLIENT_ADDON) ? $conf->global->SOCIETE_CODECLIENT_ADDON : 'mod_codeclient_leopard');
				if (substr($module, 0, 15) == 'mod_codeclient_' && substr($module, -3) == 'php')
				{
					$module = substr($module, 0, dol_strlen($module) - 4);
				}
				$dirsociete = array_merge(array('/core/modules/societe/'), $conf->modules_parts['societe']);
				foreach ($dirsociete as $dirroot)
				{
					$res = dol_include_once($dirroot.$module.'.php');
					if ($res) break;
				}
				$modCodeClient = new $module;
				$object_soc->code_client			= $modCodeClient->getNextValue($object_soc, 0);
				$error=0;
				if($object_soc->phone=="") $error++;
				if($object_soc->email=="") $error++;
				if($object_soc->nom=="") $error++;
				if($object_soc->array_options['ville']=="0") $error++;
				if($error>0){
					setEventmessages('Chmaps Noms, Téléphone, email obligatoires',null,'errors');
					$action='create';
					return;
				}	
				$db->begin();
			
				$prod=$_SESSION['produit'];
				$couleur=get_tarif();
				if($couleur=='b'){
					$bgcolor='lightblue';
					$object_soc->array_options['cara_type_client']=3; //GPB
				}
				elseif($couleur=='j'){
					$bgcolor='yellow';
					$object_soc->array_options['cara_type_client']=2; //PJ
				}
				elseif($couleur=='v'){
					$bgcolor='violet';
					$object_soc->array_options['cara_type_client']=1; //HP v
				}
				elseif($couleur=='r'){
					$bgcolor='pink';
					$object_soc->array_options['cara_type_client']=5; //HP R
				}
				$object_soc->create($user);
			}
			//création du devis
			$object->label=$_SESSION["produit"]; 
			$object->fk_soc=$object_soc->id;
			$object->status_immo=$_SESSION['statut_immo'];
			$object->mode_reglement_code=$_SESSION['financement'][$_SESSION['financement']['type']]['code'];
			$object->mode_reglement_nb=$_SESSION['financement'][$_SESSION['financement']['type']]['nb'];
			$object->mode_reglement_montant=$_SESSION['financement'][$_SESSION['financement']['type']]['montant'];
			$object->acompte=$_SESSION['financement']['acompte'];
			$object->pencharge=$_SESSION['financement']['pencharge'];
			$object->fk_commercial=$user->id;
			$object->commentaire=$_SESSION[$object->label]['idparts'];
			
			if($_SESSION['produit']=='toiture'){
				
				include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoit.lib.php',1);
				
		
				$objectLine = new devLine($db);
				$objectLine->qty=1;
				
				$objectLine->label=$tabtarif['forfait']['pv']['previsite']->label;
				$objectLine->description=$tabtarif['forfait']['pv']['previsite']->description;
				$objectLine->fk_unit=$tabtarif['forfait']['pv']['previsite']->fk_unit;
				$objectLine->total_ttc=$tabtarif['forfait']['pv']['previsite']->price_ttc;
				$objectLine->tva_tx=$tabtarif['forfait']['pv']['previsite']->tva_tx;
				$total_lig_ttc=$tabtarif['forfait']['pv']['previsite']->price_ttc;
				$objectLine->fk_product=$tabtarif['forfait']['pv']['previsite']->id;
				//$objectLine->subprice=$total_lig_ttc*(1-1/$objectLine->tva_tx/100); //subprice ht
				$objectLine->position=1;
				$objectLine->type=2;//produit
				$objectLine->total_ht= $objectLine->subprice=$tabtarif['forfait']['pv']['previsite']->price;
				$object->lines[0]=$objectLine;
				$total_ttc +=$total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				
				$tarif=$tabtarif['pv']['lib'];
				$i++;
				//titre tole
				$objectLine = new devLine($db);
				$objectLine->label='<b>Tôles :</b>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=9;
				$objectLine->special_code=104777;
				$objectLine->qty=1;
				$object->lines[$i]=$objectLine;
				
				$i++;
				//toles
				$sous_total=0;
				$id='tole';
				$objectLine = new devLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				
				//livraison tôle
				$objectLine = new devLine($db);
				$objectLine->qty=1;
				
				$objectLine->label=$tabtarif['forfait']['pv']['livraison']->label;
				$objectLine->description=$tabtarif['forfait']['pv']['livraison']->description;
				$total_lig_ttc=(float)$tabtarif['forfait']['pv']['livraison']->price_ttc;
				$objectLine->fk_unit=$tabtarif['forfait']['pv']['livraison']->fk_unit;
				$objectLine->tva_tx=$tabtarif['forfait']['pv']['livraison']->tva_tx;
				$objectLine->subprice=$tabtarif['forfait']['pv']['livraison']->price;
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$objectLine->fk_product=$tabtarif['forfait']['pv']['livraison']->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;

				//Pose Tôle
				$id='posetole';
				$objectLine = new devLine($db);
				
				$objectLine->qty=$_SESSION['toiture']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				if(count($tabtarif['remise'])>0){
					$id='remise';
					$objectLine = new devLine($db);
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$tabtarif[$id]->label;
					$objectLine->description=$tabtarif[$id]->description;
					$objectLine->fk_unit=$tabtarif[$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif[$id]->tva_tx;
					
					$total_lig_ttc=(float)$tabtarif[$id]->price_ttc*$objectLine->qty;
					$objectLine->subprice=$tabtarif[$id]->price;
					
					$objectLine->fk_product=$tabtarif[$id]->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
				}
				//Sous total
				$objectLine = new devLine($db);
				$objectLine->label='<i>Sous total:</i>';
				$objectLine->position=$i;
				$objectLine->description=NULL;
				$objectLine->fk_product=NULL;
				$objectLine->product_type=9;
				$objectLine->special_code=104777;
				$objectLine->qty=99 ;
				$objectLine->stotal_ht=$sous_total;
				$object->lines[$i]=$objectLine;
				
				$sous_total=0;
				$i++;
				if($couleur!='r'){
					//titre 
					$objectLine = new devLine($db);
					$objectLine->label='<b>Installation d\'une Sur toiture ventilée - Protection de toiture</b>';
					$objectLine->position=$i;
					$objectLine->description=NULL;
					$objectLine->fk_product=NULL;
					$objectLine->product_type=9;
					$objectLine->special_code=104777;
					$objectLine->qty=1;
					$object->lines[$i]=$objectLine;
					$i++;
					//PRSbar109
					$id='PRSbar109';
					$objectLine = new devLine($db);
					
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$tabtarif['pv'][$id]->label;
					$objectLine->description=$tabtarif['pv'][$id]->description;
					$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
					$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
					$objectLine->subprice=$tabtarif['pv'][$id]->price;
					
					$objectLine->fk_product=$tabtarif['pv'][$id]->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
					
					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
					//pose PRSbar109
					$id='posePRSbar109';
					$objectLine = new devLine($db);
					
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$tabtarif['pv'][$id]->label;
					$objectLine->description=$tabtarif['pv'][$id]->description;
					$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
					$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
					$objectLine->subprice=$tabtarif['pv'][$id]->price;
					
					$objectLine->fk_product=$tabtarif['pv'][$id]->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
					//Sous total
					$objectLine = new devLine($db);
					$objectLine->label='<i>Sous total:</i>';
					$objectLine->position=$i;
					$objectLine->description=NULL;
					$objectLine->fk_product=NULL;
					$objectLine->product_type=9;
					$objectLine->special_code=104777;
					$objectLine->qty=99 ;
					$objectLine->stotal_ht=$sous_total;
					$object->lines[$i]=$objectLine;
					$sous_total=0;
					$i++;

					//titre 
					$objectLine = new devLine($db);
					$objectLine->label='<b>Isolation de la toiture en pente. Plafonds de combles aménageables</b>';
					$objectLine->position=$i;
					$objectLine->description=NULL;
					$objectLine->fk_product=NULL;
					$objectLine->product_type=9;
					$objectLine->special_code=104777;
					$objectLine->qty=1;
					$object->lines[$i]=$objectLine;
					$i++;
					//rampants
					$id='isorampantbar10';
					$objectLine = new devLine($db);
					
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$tabtarif['pv'][$id]->label;
					$objectLine->description=$tabtarif['pv'][$id]->description;
					$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
					$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
					$objectLine->subprice=$tabtarif['pv'][$id]->price;
					
					$objectLine->fk_product=$tabtarif['pv'][$id]->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;

					$id='poseisorampantbar10';
					$objectLine = new devLine($db);
					
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$tabtarif['pv'][$id]->label;
					$objectLine->description=$tabtarif['pv'][$id]->description;
					$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
					$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
					$objectLine->subprice=$tabtarif['pv'][$id]->price;
					
					$objectLine->fk_product=$tabtarif['pv'][$id]->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
					
					//Sous total
					$objectLine = new devLine($db);
					$objectLine->label='<i>Sous total:</i>';
					$objectLine->position=$i;
					$objectLine->description=NULL;
					$objectLine->fk_product=NULL;
					$objectLine->product_type=9;
					$objectLine->special_code=104777;
					$objectLine->qty=99 ;
					$objectLine->stotal_ht=$sous_total;
					$object->lines[$i]=$objectLine;
					$sous_total=0;
					$i++;
				}
				else{
					//titre 
					$objectLine = new devLine($db);
					$objectLine->label='<b>Isolation de combles ou de toitures</b>';
					$objectLine->position=$i;
					$objectLine->description=NULL;
					$objectLine->fk_product=NULL;
					$objectLine->product_type=9;
					$objectLine->special_code=104777;
					$objectLine->qty=1;
					$object->lines[$i]=$objectLine;
					$i++;
					//combles
					$id='isocombles';
					$objectLine = new devLine($db);
					
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$tabtarif['pv'][$id]->label;
					$objectLine->description=$tabtarif['pv'][$id]->description;
					$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
					$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
					$objectLine->subprice=$tabtarif['pv'][$id]->price;
					
					$objectLine->fk_product=$tabtarif['pv'][$id]->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;

					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
					
				}
				//options
				$tarif=$tabtarif['option'];
				foreach ($tarif as $id=>$produit){
					
					if($id=='char'){
						$metrage=$_SESSION['toiture']['metragecharpente'];
					}
					elseif($id=='gouttiere'){
						$metrage=$_SESSION['toiture']['metragegouttieres'];
					}
					elseif($id=='fp'){
						$metrage=$_SESSION['toiture']['metragefauxplafond'];
					}
					elseif($id=='chen'){
						$metrage=$_SESSION['toiture']['metragechenaux'];
					}
					$htm.='<td>'.$produit->label.'</td><td>'.$metrage.'</td><td>'.$produit->price_ttc.'</td><td>'.$produit->price_ttc*$metrage.'';
					if($i%2)
						$htm.='</td></tr><tr class="oddeven">';
					else $htm.='</td></tr><tr class="pair">';
					
					$objectLine = new devLine($db);
					$objectLine->qty=$metrage;
					$objectLine->label=$produit->label;
					$objectLine->description=$produit->description;
					$objectLine->fk_unit=$produit->fk_unit;
					$objectLine->tva_tx=$produit->tva_tx;
					$total_lig_ttc=$produit->price_ttc*$objectLine->qty;
					$objectLine->subprice=$produit->price;
					
					$objectLine->fk_product=$produit->id;
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
				}
				if(count($tarif)>0){
					//Sous total
					$objectLine = new devLine($db);
					$objectLine->label='<i>Sous total:</i>';
					$objectLine->position=$i;
					$objectLine->description=NULL;
					$objectLine->fk_product=NULL;
					$objectLine->product_type=9;
					$objectLine->special_code=104777;
					$objectLine->qty=99 ;
					$objectLine->stotal_ht=$sous_total;
					$object->lines[$i]=$objectLine;
					$sous_total=0;
					$i++;
				}
				if($_SESSION['toiture']['sproduit']=='ces'){
					$objectLine = new devLine($db);
					$objectLine->qty=1;
					
					$objectLine->label=$tabtarifces['pv']['lib'][$_SESSION[$prod]['vol']];
					$total_lig_ttc=(float)$tabtarifces['pv']['mt'][$_SESSION['toiture']['vol']];
					$objectLine->tva_tx=$tabtarifces['pv']['tva'][$_SESSION['toiture']['vol']];
					$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
					$objectLine->fk_unit=$tabtarifces['pv']['unit'][$_SESSION['toiture']['vol']];
					
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$objectLine->fk_product='ces';
					$objectLine->position=$i;
					$objectLine->type=2;//produit
					$object->lines[$i]=$objectLine;
					$total_ttc += $total_lig_ttc;
					if($objectLine->tva_tx>0)
						$total_lig_tva=$total_lig_ttc/$objectLine->tva_tx/100;
					else $total_lig_tva=0;

					$total_tva += $total_lig_tva;
					$total_ht += $total_lig_ttc-$total_lig_tva;
					$sous_total+=$objectLine->total_ht;
					$i++;
				}

				$tarif=$tabtarif[$couleur]['pr']['lib'];//on rajoute les primes à la fin du devis
				foreach ($tarif as $id=>$lib){
					$objectLine = new devLine($db);
					$objectLine->qty=$_SESSION['toiture']['metrage'];
					$objectLine->label=$lib->label;
					$objectLine->description=$lib->description;
					$objectLine->fk_unit=$lib->fk_unit;
					$objectLine->tva_tx=$lib->tva_tx;
					$total_lig_ttc=(float)$lib->price*$objectLine->qty;
					$objectLine->type=2;//produit
					$objectLine->fk_product=$lib->id;
					$objectLine->subprice=(float)$lib->price;
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$objectLine->position=$i;
					if($objectLine->total_ht != 0){
						$object->lines[$i]=$objectLine;
						$total_primes += $objectLine->total_ht;
						$i++;
					}
				}
			
				$object->total_ht=$total_ht;
				$object->total_ttc=$total_ttc;
				$object->total_tva=$total_tva;
				$object->total_rac=$object->total_ttc+$total_primes;
			}
			elseif($_SESSION['produit']=='ces'){
				include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifces.lib.php',1);
				$id=$_SESSION['ces']['vol'];
				//prévisite
				$objectLine = new devLine($db);
				$objectLine->qty=1;
				$objectLine->label=$tabtarif['prev']->label;
				$objectLine->description=$tabtarif['prev']->description;
				$objectLine->fk_unit=$tabtarif['prev']->fk_unit;
				$objectLine->tva_tx=$tabtarif['prev']->tva_tx;
				$total_lig_ttc=(float)$tabtarif['prev']->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['prev']->price;
				
				$objectLine->fk_product=$tabtarif['prev']->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;
				//produit//
				$objectLine = new devLine($db);
				$objectLine->qty=1;
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;

				//livraison
				$objectLine = new devLine($db);
				$objectLine->qty=1;
				$objectLine->label=$tabtarif['liv'][$id]->label;
				$objectLine->description=$tabtarif['liv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['liv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['liv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['liv'][$id]->price_ttc*$objectLine->qty;
				$objectLine->subprice=$tabtarif['liv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['liv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				$i++;

				$tarif=$tabtarif['pr']['lib'];
				//
				//on rajoute les primes à la fin du devis
				foreach ($tarif as $id=>$lib){
					$objectLine = new devLine($db);
					$objectLine->qty=1;
					$objectLine->label=$tabtarif['pr']['lib'][$id]->label;
					$objectLine->description=$tabtarif['pr']['lib'][$id]->description;
					$objectLine->fk_unit=$tabtarif['pr']['lib'][$id]->fk_unit;
					$objectLine->tva_tx=$tabtarif['pr']['lib'][$id]->tva_tx;
					$total_lig_ttc=(float)$tabtarif[$couleur]['pr']['mt'][$id]*$objectLine->qty;
					$objectLine->type=2;//produit
					$objectLine->fk_product=$tabtarif['pr']['lib'][$id]->id;
					$objectLine->subprice=(float)$tabtarif[$couleur]['pr']['mt'][$id];
					$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
					$objectLine->position=$i;
					if($objectLine->total_ht != 0){
						$object->lines[$i]=$objectLine;
						$total_primes += $objectLine->total_ht;
						$i++;
					}
				}
				$object->total_ht=$total_ht;
				$object->total_ttc=$total_ttc;
				$object->total_tva=$total_tva;
				$object->total_rac=$object->total_ttc+$total_primes;
			}
			elseif($_SESSION['produit']=='iso'){
				include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifiso.lib.php',1);
				//produit//
				$id='iso';
				$objectLine = new devLine($db);
				$objectLine->qty=$_SESSION['iso']['metrage'];
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=(float)$tabtarif['pv'][$id]->price_ttc*(float)$objectLine->qty;
				$objectLine->subprice=$tabtarif['pv'][$id]->price;
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;

				$i++;
				//remise
				$id='remise';
				$objectLine = new devLine($db);
				$objectLine->qty=1;
				$objectLine->label=$tabtarif['pv'][$id]->label;
				$objectLine->description=$tabtarif['pv'][$id]->description;
				$objectLine->fk_unit=$tabtarif['pv'][$id]->fk_unit;
				$objectLine->tva_tx=$tabtarif['pv'][$id]->tva_tx;
				$total_lig_ttc=$_SESSION['iso']['totalremise'];
				$objectLine->subprice=$_SESSION['iso']['totalremise'];
				
				$objectLine->fk_product=$tabtarif['pv'][$id]->id;
				$objectLine->position=$i;
				$objectLine->type=2;//produit
				$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
				$object->lines[$i]=$objectLine;
				$total_ttc += $total_lig_ttc;
				$total_lig_tva=$total_lig_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $total_lig_ttc-$total_lig_tva;
				$sous_total+=$objectLine->total_ht;
				
				$i=0;
				$tarif=$tabtarif['pr']['lib'];
				foreach ($tarif as $id=>$lib){
					$objectPrime = new devPrime($db);
					$objectPrime->qty=$_SESSION['iso']['metrage'];
					$objectPrime->label=$lib;
					$objectPrime->subprice=(float)$tabtarif[$couleur]['pr']['mt'][$id];
					$objectPrime->fk_unit=(float)$tabtarif[$couleur]['pr']['unit'][$id];
					$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
					$objectPrime->fk_product=$id;
					$objectPrime->position=$i;
					if($objectPrime->total_ht != 0){
						$object->primes[$i]=$objectPrime;
						$total_primes += $objectPrime->total_ht;
						$i++;
					}
				}
				$object->total_ht=$total_ht;
				$object->total_ttc=$total_ttc;
				$object->total_tva=$total_tva;
				$object->total_rac=$object->total_ttc+$total_primes;
			}
			if($object->total_ht>0){
				$result = $object->create($user);
				if($_SESSION['fromid']) //client déjà existant
					$object->link($_SESSION['fromid'],$_SESSION['produit']);
					
				unset($_SESSION['client'],$_SESSION['produit'],$_SESSION[$prod],$_SESSION['toiture'],$_SESSION['ces'],$_SESSION['financement'],$_SESSION[$prod],
				$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client'],$_SESSION['fromid']);
				//$extrafields_soc->update();
				$db->commit();
			}
			else $db->rollback();
			if ($result > 0)
			{
				// Creation OK
				$urltogo = dol_buildpath('deviscara/dev_client.php',1).'?id='.$object->id;
				header("Location: ".$urltogo);
				exit;
			}
			else
			{
				// Creation KO
				if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
				else  setEventMessages($object->error, null, 'errors');
				$action = 'create';
			}
			
		}
	}
	else
	{
		$action = 'create';
	}
}
