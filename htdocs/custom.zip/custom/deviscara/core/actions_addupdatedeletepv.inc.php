<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *    \file            htdocs/core/actions_addupdatedelete.inc.php
 *  \brief            Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel) {
    /*var_dump($cancel);
    var_dump($backtopage);exit;*/
    if (!empty($backtopageforcancel)) {
        header("Location: " . $backtopageforcancel);
        exit;
    } elseif (!empty($backtopage)) {
        header("Location: " . $backtopage);
        exit;
    }
    $action = '';
}


// Action to add record
if ($action == 'add' || $action == 'create') {
    if (GETPOST('vnb_batiments' == "valider") || GETPOST('vbatiments' == "valider")) $action = "create";
    if (GETPOST('type_projet') == 4) {
        $action = "create_client";
//        $action = "affichgraph";
        $_SESSION[$prod]['type_projet'] = GETPOST('type_projet');
    }
    if (!$error) {
        $prod = 'pv';
        if (GETPOST('reinit') == 're-initialiser') {
            unset($_SESSION['client'], $_SESSION['financement'], $_SESSION[$prod],
                $_SESSION['nbpart'], $_SESSION['rfr'], $_SESSION['status_immo'], $_SESSION['client']);
            $action = 'create';
        } else {
            $_SESSION['nbpart'] = GETPOST('nbpart');
            $_SESSION['rfr'] = GETPOST('rfr');
            $_SESSION['status_immo'] = GETPOST('status_immo');


            $_SESSION[$prod]['nb_batiments'] = GETPOST('nb_batiments');
            $_SESSION[$prod]['type_projet'] = GETPOST('type_projet');

            for ($nbbat = 1; $nbbat <= $_SESSION[$prod]['nb_batiments']; $nbbat++) {
                $_SESSION[$prod]['bat' . $nbbat . 'l1'] = GETPOST('bat' . $nbbat . 'l1');
                $_SESSION[$prod]['bat' . $nbbat . 'l2'] = GETPOST('bat' . $nbbat . 'l2');
                $surface += $_SESSION[$prod]['bat' . $nbbat . 'l1'] * $_SESSION[$prod]['bat' . $nbbat . 'l2'];
            }

            $_SESSION[$prod]['type_toiture'] = GETPOST('type_toiture');
            if ($_SESSION[$prod]['type_toiture'] > 0) {
                //calcul du résultat estimé
                $_SESSION[$prod]['surface_utile'] = $arraytoit[$_SESSION[$prod]['type_toiture']] * $surface;
                foreach ($puissance as $key => $p) {
                    $_SESSION[$prod]['puissance_estimee'] = $p;
                    if ($_SESSION[$prod]['surface_utile'] < $key) break;
                }
                foreach ($loyer as $key => $l) {
                    $_SESSION[$prod]['loyer_estime'] = $l;
                    if ($_SESSION[$prod]['surface_utile'] < $key) break;

                }
                foreach ($soulte as $key => $s) {
                    $_SESSION[$prod]['soulte_estime'] = $s;
                    if ($_SESSION[$prod]['surface_utile'] < $key) break;
                }
            }
            if (GETPOST('poursuivre'))
                $action = "create_client";
        }

    } else {
        $action = 'create';
    }
}
if ($action == 'affichgraph') {
    $_SESSION["pv"]['ombrage'] = GETPOST('ombrage');
    $_SESSION["pv"]['age_tole'] = GETPOST('age_tole');
    $_SESSION["pv"]['fuite'] = GETPOST('fuite');
    $_SESSION["pv"]['categorie'] = GETPOST('categorie');
    $_SESSION["pv"]['kwhan'] = GETPOST('kwhan');
    $categorie = GETPOST('categorie', 'int');
    $kwhan = GETPOST('kwhan');
    if ($kwhan > 0) {

        foreach ($production_annuelle as $formule => $prod)
            $taux_autonomie[$formule] = ($prod * $taux_conso[$categorie][$formule]) / $kwhan * 100;
    }
    $_SESSION['pv']['taux_autonomie']=$taux_autonomie;
    if (GETPOST('type_autoconso') > 0) {
        $_SESSION['pv']['type_autoconso'] = GETPOST('type_autoconso');
        $actionbis = 'affichgraph';
    }
    if (GETPOST('type_autoconso2') > 0) {
        $_SESSION['pv']['type_autoconso2'] = GETPOST('type_autoconso2');
        $actionbis = 'affichgraph';
    }

    $action = 'create_technique';
}


if ($action == 'enregistrer_demande') {

    $prod = 'pv';
    $db->begin();

    if ($_SESSION['pv']['type_projet'] == 3 && ($_SESSION['pv']['type_autoconso'] == '' || $_SESSION['pv']['type_autoconso'] == 0)) {
        $error++;
        $msg = "Champ Type autoconso Obligatoire";
    }
    if ($_SESSION['pv']['type_projet'] == 4 && ($_SESSION['pv']['type_autoconso2'] == '' || $_SESSION['pv']['type_autoconso2'] == 0)) {
        $error++;
        $msg = "Champ Type autoconso seule Obligatoire";
    }
    if ($error > 0) {
        $message = 'Les elements suivants sont obligatoires :';
        setEventMessages($message, $msg, 'errors');
        $action = 'create_technique';

    } else {
        $object_soc = new Societe($db);
        $object_soc->nom = $_SESSION['pv']['client']['nom'];
        $object_soc->address = $_SESSION['pv']['client']['address'];
        $object_soc->array_options['ville'] = $_SESSION['pv']['client']['ville'];
        $object_soc->phone = $_SESSION['pv']['client']['phone'];
        $object_soc->fax = $_SESSION['pv']['client']['fax'];
        $object_soc->url = $_SESSION['pv']['client']['url'];
        $object_soc->email = $_SESSION['pv']['client']['email'];
        $object_soc->array_options['spmo'] = $_SESSION['pv']['client']['spmo'];
        $object_soc->array_options['spma'] = $_SESSION['pv']['client']['spma'];
        $object_soc->array_options['nbpart'] = $_SESSION['nbpart'];
        $object_soc->array_options['rfr'] = $_SESSION['rfr'];
        $object_soc->array_options['status_immo'] = $_SESSION['status_immo'];
        $object_soc->client = 2; //prospect
        $object_soc->status = 1; //prospect
        $object_soc->pays = 1; //france
        $object_soc->commercial_id = $user->id;

        $module = (!empty($conf->global->SOCIETE_CODECLIENT_ADDON) ? $conf->global->SOCIETE_CODECLIENT_ADDON : 'mod_codeclient_leopard');
        if (substr($module, 0, 15) == 'mod_codeclient_' && substr($module, -3) == 'php') {
            $module = substr($module, 0, dol_strlen($module) - 4);
        }
        $dirsociete = array_merge(array('/core/modules/societe/'), $conf->modules_parts['societe']);
        foreach ($dirsociete as $dirroot) {
            $res = dol_include_once($dirroot . $module . '.php');
            if ($res) break;
        }
        $modCodeClient = new $module;
        $object_soc->code_client = $modCodeClient->getNextValue($object_soc, 0);
        $ressoc = $object_soc->create($user);
        $error = 0;

        $object_soc = new Societe($db);
        $object_soc->nom = $_SESSION['pv']['client']['nom'];
        $object_soc->address = $_SESSION['pv']['client']['address'];
        $object_soc->array_options['ville'] = $_SESSION['pv']['client']['ville'];
        $object_soc->phone = $_SESSION['pv']['client']['phone'];
        $object_soc->fax = $_SESSION['pv']['client']['fax'];
        $object_soc->url = $_SESSION['pv']['client']['url'];
        $object_soc->email = $_SESSION['pv']['client']['email'];
        $object_soc->array_options['spmo'] = $_SESSION['pv']['client']['spmo'];
        $object_soc->array_options['spma'] = $_SESSION['pv']['client']['spma'];
        $object_soc->array_options['profession'] = $_SESSION['pv']['client']['profession'];
        $object_soc->array_options['professionmme'] = $_SESSION['pv']['client']['professionmme'];
        $object_soc->array_options['nbpart'] = $_SESSION['nbpart'];
        $object_soc->array_options['rfr'] = $_SESSION['rfr'];
        $object_soc->array_options['status_immo'] = $_SESSION['status_immo'];
        $object_soc->client = 2; //prospect
        $object_soc->status = 1; //prospect
        $object_soc->pays = 1; //france
        $object_soc->commercial_id = $user->id;
        $module = (!empty($conf->global->SOCIETE_CODECLIENT_ADDON) ? $conf->global->SOCIETE_CODECLIENT_ADDON : 'mod_codeclient_leopard');
        if (substr($module, 0, 15) == 'mod_codeclient_' && substr($module, -3) == 'php') {
            $module = substr($module, 0, dol_strlen($module) - 4);
        }
        $dirsociete = array_merge(array('/core/modules/societe/'), $conf->modules_parts['societe']);
        foreach ($dirsociete as $dirroot) {
            $res = dol_include_once($dirroot . $module . '.php');
            if ($res) break;
        }
        $modCodeClient = new $module;
        $object_soc->code_client = $modCodeClient->getNextValue($object_soc, 0);
        $ressoc = $object_soc->create($user);
        $error = 0;

        $pv = new pv($db);
        $pv->date_creation = dol_now();
        $pv->ref = $pv->getNextNumRef();
        $pv->fk_soc = $ressoc;
        $pv->fk_user_com = $user->id;

        $pv->status = 1;
        $pv->nb_batiments = $_SESSION[$prod]['nb_batiments'];
        for ($nbbat = 1; $nbbat <= $_SESSION[$prod]['nb_batiments']; $nbbat++) {
            $pv->{'bat' . $nbbat . 'l1'} = $_SESSION[$prod]['bat' . $nbbat . 'l1'];
            $pv->{'bat' . $nbbat . 'l2'} = $_SESSION[$prod]['bat' . $nbbat . 'l2'];
        }


        $pv->ville_projet = $_SESSION['pv']['client']['ville_projet'];
        $pv->adresse_projet = $_SESSION['pv']['client']['address_projet'];
        $pv->type_projet = $_SESSION[$prod]['type_projet'];
        $pv->surface_utile = $_SESSION[$prod]['surface_utile'];
        $pv->puissance_estimee = $_SESSION[$prod]['puissance_estimee'];
        $pv->loyer_estime = $_SESSION[$prod]['loyer_estime'];
        $pv->soulte_estime = $_SESSION[$prod]['soulte_estime'];
        $pv->type_toiture = $_SESSION[$prod]['type_toiture'];
        $pv->type_autoconso = GETPOST('type_autoconso');
        $pv->type_autoconso2 = GETPOST('type_autoconso2');
        $pv->age_tole = GETPOST('age_tole');
        $pv->ombrage = GETPOST('ombrage');
        $pv->fuite = GETPOST('fuite');
        $pv->commentaire_projet=GETPOST('description');

        if ($pv->type_autoconso > 0) {
            $pv->taux_autonomie = $_SESSION['pv']['taux_autonomie'][$pv->type_autoconso];
            $pv->economie_sur_20_ans = $_SESSION['pv']['economie'][$pv->type_autoconso];
            $pv->temps_de_roi = $_SESSION['pv']['roi'][$pv->type_autoconso];
        } elseif ($pv->type_autoconso2 > 0) {
            $pv->taux_autonomie = $_SESSION['pv']['taux_autonomie'][$pv->type_autoconso2];
            $pv->economie_sur_20_ans = $_SESSION['pv']['economie'][$pv->type_autoconso2];
            $pv->temps_de_roi = $_SESSION['pv']['roi'][$pv->type_autoconso2];
        }
        // dediée à l'autoconso seule
        $pv->consommation_annuelle_elec_kwh = $_SESSION["pv"]['kwhan'];
        $pv->puissance_pvkwc = $_SESSION["pv"]['kwhan'] / 1500;
        $pv->capacite_stockage_kwh = $_SESSION["pv"]['kwhan'] / 730;

        $mode_reglement = GETPOST('mode_reglement_perso');
        if ($mode_reglement > 0) {
            $pv->mode_reglement_code = 2;//perso
            $pv->mode_reglement_perso = GETPOST('mode_reglement_perso');
        } else {
            $pv->mode_reglement_code = 1; //cma
            $tab_cma = explode('/', GETPOST('mode_reglement_cma'));
            $pv->mode_reglement_cma_mois = $tab_cma[1];
            $pv->mode_reglement_cma_montant = $tab_cma[2];

        }

        $date_changement = new datetime($conf->global->CARASUN_DATE_MISENEPLACE_DEVIS);
        if (!empty($pv->table_element_line) && dol_now() > $date_changement->getTimestamp()) {
            //on crée les lignes à partir d'un devis existant: cloneage du devis type. fonction du type autoconso et type autoconso2
            $formule = ($pv->type_autoconso > 0 ? $pv->type_autoconso : $pv->type_autoconso2);
            $res = $pv->copyFromPropale($user, $pv_devistype[$_SESSION[$prod]['type_projet']][$formule]);
        }

        $res = $pv->create($user);
        if ($res > 1) {
            $db->commit();
            unset($_SESSION['client'], $_SESSION['financement'], $_SESSION[$prod],
                $_SESSION['nbpart'], $_SESSION['rfr'], $_SESSION['status_immo'], $_SESSION['client']);
            header('Location: ' . dol_buildpath('carasun/pv_cardcomm.php', 1) . '?id=' . $res);
        } else
            $db->rollback();
    }

}
if ($action == 'creerdevis') {
    $error = 0;
    if (GETPOST('firstname') != '')
        $_SESSION['pv']['client']['nom'] = GETPOST('firstname');
    else {
        $error++;
        $msg = "Nom ,";
    }
    if (GETPOST('address') != '')
        $_SESSION['pv']['client']['address'] = GETPOST('address');
    else {
        $error++;
        $msg = ' Adresse ,';
    }
    if (GETPOST('address_projet') != '')
        $_SESSION['pv']['client']['address_projet'] = GETPOST('address_projet');
    else {
        $error++;
        $msg = ' Adresse Projet,';
    }
    if (GETPOST('ville_projet') != '')
        $_SESSION['pv']['client']['ville_projet'] = GETPOST('ville_projet');
    else {
        $error++;
        $msg = ' Ville Projet,';
    }

    if (GETPOST('options_profession') != '')
        $_SESSION['pv']['client']['profession'] = GETPOST('options_profession');
    // else {
    //     $error++;
    //     $msg = ' Profession ,';
    // }
    if (GETPOST('options_ville') != 0)
        $_SESSION['pv']['client']['ville'] = GETPOST('options_ville');

    else {
        $error++;
        $msg = 'ville /code postal';
    }
    if (GETPOST('phone') != '')
        $_SESSION['pv']['client']['phone'] = GETPOST('phone');

    else {
        $error++;
        $msg = 'phone';
    }
    if(GETPOST('email')!='')
        $_SESSION['pv']['client']['email']=GETPOST('email');
    else{
        $error++;
        $msg='mail';
    }

    $_SESSION['pv']['client']['fax'] = GETPOST('fax');
    $_SESSION['pv']['client']['url'] = GETPOST('url');
    $_SESSION['pv']['client']['email'] = GETPOST('email');
    $_SESSION['pv']['client']['smpo'] = GETPOST('spmo');
    $_SESSION['pv']['client']['spma'] = GETPOST('spma');
    $_SESSION['pv']['client']['professionmme'] = GETPOST('options_professionmme');

    if($error>0){
        $message='Les elements suivants sont obligatoires :';
        setEventMessages($message, $msg, 'errors');
        $action="create_client";

    }
    else
    $action = 'create_technique';
}

if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd)) {
    $result = $object->deleteline($user, $lineid);
    if ($result > 0) {
        // Define output language
        $outputlangs = $langs;
        $newlang = '';
        if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) {
            $newlang = GETPOST('lang_id', 'aZ09');
        }
        if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty)) {
            $newlang = $object->thirdparty->default_lang;
        }
        if (!empty($newlang)) {
            $outputlangs = new Translate("", $conf);
            $outputlangs->setDefaultLang($newlang);
        }
        if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
            $ret = $object->fetch($object->id); // Reload to get new records
            //$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
        }
        $object->update_total($tabtarif);
        setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
        header('Location: ' . $_SERVER["PHP_SELF"] . '?id=' . $object->id);
        exit;
    } else {
        setEventMessages($object->error, $object->errors, 'errors');
    }
}

//update line
if ($action == 'updateline') {
    $objectLine = new repLine($db);
    $objectLine->fetch($lineid);
    foreach ($objectLine->fields as $key => $val) {
        // Check if field was submited to be edited
        if ($objectLine->fields[$key]['type'] == 'duration') {
            if (!GETPOSTISSET($key . 'hour') || !GETPOSTISSET($key . 'min')) continue; // The field was not submited to be edited
        } else {
            if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
        }
        // Ignore special fields
        if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

        // Set value to update
        if (in_array($objectLine->fields[$key]['type'], array('text', 'html'))) {
            $value = GETPOST($key, 'none');
        } elseif ($objectLine->fields[$key]['type'] == 'date') {
            $value = dol_mktime(12, 0, 0, GETPOST($key . 'month'), GETPOST($key . 'day'), GETPOST($key . 'year'));
        } elseif ($objectLine->fields[$key]['type'] == 'datetime') {
            $value = dol_mktime(GETPOST($key . 'hour'), GETPOST($key . 'min'), 0, GETPOST($key . 'month'), GETPOST($key . 'day'), GETPOST($key . 'year'));
        } elseif ($objectLine->fields[$key]['type'] == 'duration') {
            if (GETPOST($key . 'hour', 'int') != '' || GETPOST($key . 'min', 'int') != '') {
                $value = 60 * 60 * GETPOST($key . 'hour', 'int') + 60 * GETPOST($key . 'min', 'int');
            } else {
                $value = '';
            }
        } elseif (preg_match('/^(integer|price|real|double)/', $objectLine->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));    // To fix decimal separator according to lang setup
        } elseif (preg_match('/^(varchar)/', $objectLine->fields[$key]['type'])) {
            $value = htmlspecialchars(GETPOST($key));
        } else {
            $value = GETPOST($key, 'alpha');
        }
        if (preg_match('/^integer:/i', $objectLine->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
        if (!empty($objectLine->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

        $objectLine->$key = $value;
        if ($val['notnull'] > 0 && $objectLine->$key == '' && is_null($val['default'])) {
            $error++;
            setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
        }
    }
    $objectLine->total_ht = $objectLine->subprice * $objectLine->qty;
    $objectLine->update($user);

    $object->update_total($tabtarif);

}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete)) {
    if (!($object->id > 0)) {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

    $result = $object->delete($user);
    if ($result > 0) {
        // Delete OK
        setEventMessages("RecordDeleted", null, 'mesgs');
        header("Location: " . $backurlforlist);
        exit;
    } else {
        if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
        else setEventMessages($object->error, null, 'errors');
    }
}

if ($action == 'facturer' && !empty($user->rights->carasun->pv->facturer)) {

    dol_include_once('/compta/facture/class/facture.class.php');
    $fac = new Facture($db);
    $fac->socid = $object->fk_soc;
    $fac->date_creation = $fac->date = dol_now();
    $fac->type = 0; //facture standard 1=facture de remplacement...
    $fac->entity = 6; //CARASUN
    $fac->note_private = 'Creation Facture via devis <a href="' . dol_buildpath('carasun/pv_cardcomm.php', 1) . '?id=' . $object->id . '">' . $object->ref . ' </a> ';
    $fac->ref = $fac->getNextNumRef($object->fk_soc);
    $fac->total_ht = $object->total_ht;
    $fac->total_tva = $object->total_tva;
    $fac->total_ttc = $object->total_ttc;
    $fac->status = $fac::STATUS_DRAFT; //draft
    $fac->fk_commercial = $object->fk_commercial;
    $fac->total_rac = $object->total_rac;
    $fac->ref_int = $object->label;
    $i = 0;
    foreach ($object->lines as $line) {
        $facline = new FactureLigne($db);
        $facline->label = $line->label;
        $facline->subprice = $line->subprice;
        if ($line->qty == null) $line->qty = 0;
        $facline->qty = $line->qty;
        $facline->desc = $line->description;
        $facline->date_creation = dol_now();
        $facline->fk_product = $line->fk_product;
        $facline->rang = $line->position;
        $facline->type = $line->type;
        $facline->fk_unit = $line->fk_unit;
        if ($line->total_ht == null) $line->total_ht = 0;
        $facline->total_ht = $line->total_ht;
        $facline->total_tva = $line->total_ht * $line->tva_tx / 100;
        $facline->total_ttc = $line->total_ht + $facline->total_tva;
        $facline->tva_tx = $line->tva_tx;
        $facline->product_type = $line->product_type;
        $facline->special_code = $line->special_code;
        $facline->rang = $line->position;
        $facline->fk_product = $line->fk_product;
        $facline->stotal_ht = $line->stotal_ht;
        $fac->lines[$i] = $facline;
        $i++;
    }

    //on translate les primes en article de prime


// Tentative de redirection vers la facture fraichement créée.
    {
        $result = $fac->create($user);
        if ($result > 0) {
            setEventMessages($langs->trans('Facture créée'), null, 'mesgs');
            $url = dol_buildpath('compta/facture/card.php', 1);
            header('Location: ' . $url . '?facid=' . $fac->id);
        }
    }
}

if ($action == 'update' && !empty($permissiontoadd)) {

    //récupération précarité societe pour update des primes
    $object_soc = new societe($db);
    $object_soc->fetch($object->fk_soc);

    //détection cuve 5000
    $idtabcuve5 = 1;
    foreach ($object->lines as $line) {
        if (in_array($line->fk_product, array(38, 40))) {
            $idtabcuve5 = 2;
            break;
        }
    }

    //on update la précarité ctm du client avec le nouveau RFR(car peut être modifié.)
    $object->updatePrecariteCtm($object_soc);
    $tabinfo = get_tarif(array($object_soc->array_options['options_cara_type_client_ctm'], $idtabcuve5));
    $couleur = $tabinfo[0];
    $plafond = $tabinfo[1];
    if ($couleur == 'b') {
        $bgcolor = 'lightblue';
        $object_soc->array_options['cara_type_client_ctm'] = 3; //GPB
    } elseif ($couleur == 'j') {
        $bgcolor = 'yellow';
        $object_soc->array_options['cara_type_client_ctm'] = 2; //PJ
    } elseif ($couleur == 'v') {
        $bgcolor = 'violet';
        $object_soc->array_options['cara_type_client_ctm'] = 1; //HP v
    }
    $i = 0;
    $object->primes = array();
    $rfrc = $object_soc->array_options['options_rfr'] / $object_soc->array_options['options_nbpart'];//besoin dans l'include
    $citerneenterree = $object->rechercheref(array(39, 40));
    include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/lib/deviscara_tarifrep.lib.php', 1);
    $tarif = $tabtarif['lib'];
    foreach ($tarif as $id => $lib) {
        $objectPrime = new repPrime($db);
        $objectPrime->qty = 1;
        $objectPrime->label = $lib;
        $objectPrime->subprice = (float)$tabtarif[$couleur]['pr']['mt'][$id];
        $objectPrime->fk_unit = (float)$tabtarif[$couleur]['pr']['unit'][$id];
        $objectPrime->total_ht = $objectPrime->subprice * $objectPrime->qty;
        $objectPrime->fk_product = $id;
        $objectPrime->type_prime = $tabtarif['pr']['type_prime'][$id];
        $objectPrime->type = 3; //produt de type rep
        $objectPrime->position = $i;
        $objectPrime->type_prime = 1; //prime CTM
        $object->primes[$i] = $objectPrime;
        $total_primes += $objectPrime->total_ht;
        $i++;
    }
    //primes %
    $objectPrime = new repPrime($db);
    $objectPrime->qty = 1;
    $objectPrime->label = $tabtarif['lib2']['srep']['lib'];
    //recherche si existance lampe Uv dans le devis.
    $lampeuv = $object->rechercheref(array(58));

    if ($lampeuv) {
        $totaleligible = $object->total_ht - $tabtarif['pv']['rep']['lampeuv']->price;
        $provprime = $tabtarif['lib2']['srep']['mt'] * $totaleligible;
    } else {
        $provprime = $tabtarif['lib2']['srep']['mt'] * $total_ht;
    }
    $objectPrime->prime_tx = $tabtarif['lib2']['srep']['mt'];
    $prime = (-1) * ($provprime >= $plafond ? $plafond : $provprime);
    $objectPrime->subprice = $prime;
    $objectPrime->total_ht = $objectPrime->subprice * $objectPrime->qty;
    $objectPrime->type_prime = 1; //prime SREP
    $objectPrime->position = $i;
    $object->primes[$i] = $objectPrime;
    $total_primes += $objectPrime->total_ht;

    $object->updateprimes($user);
    $object->update_total($tabtarif);

    $status_avantmaj = $object->status;
    foreach ($object->fields as $key => $val) {
        // Check if field was submited to be edited
        if ($object->fields[$key]['type'] == 'duration') {
            if (!GETPOSTISSET($key . 'hour') || !GETPOSTISSET($key . 'min')) continue; // The field was not submited to be edited
        } else {
            if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
        }
        // Ignore special fields
        if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

        // Set value to update
        if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
            $value = GETPOST($key, 'none');
        } elseif ($object->fields[$key]['type'] == 'date') {
            $value = dol_mktime(12, 0, 0, GETPOST($key . 'month'), GETPOST($key . 'day'), GETPOST($key . 'year'));
        } elseif ($object->fields[$key]['type'] == 'datetime') {
            $value = dol_mktime(GETPOST($key . 'hour'), GETPOST($key . 'min'), 0, GETPOST($key . 'month'), GETPOST($key . 'day'), GETPOST($key . 'year'));
        } elseif ($object->fields[$key]['type'] == 'duration') {
            if (GETPOST($key . 'hour', 'int') != '' || GETPOST($key . 'min', 'int') != '') {
                $value = 60 * 60 * GETPOST($key . 'hour', 'int') + 60 * GETPOST($key . 'min', 'int');
            } else {
                $value = '';
            }
        } elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));    // To fix decimal separator according to lang setup
        } else {
            $value = GETPOST($key, 'alpha');
        }
        if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
        if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

        $object->$key = $value;
        if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default'])) {
            $error++;
            setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
        }
    }
    $newstatus = GETPOST('status');
    if ($status_avantmaj != $newstatus) {
        $object->{'date_status_' . $newstatus} = dol_now(); //date de changement de statut
    }
    if (!$error) {
        $result = $object->update($user);
        if ($result > 0) {
            $action = 'view';
        } else {
            // Creation KO
            setEventMessages($object->error, $object->errors, 'errors');
            $action = 'edit';
        }
    } else {
        $action = 'edit';
    }
    //mise à jour des primes

}
