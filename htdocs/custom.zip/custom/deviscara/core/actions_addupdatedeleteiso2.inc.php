<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}


// Action to add record
if ($action == 'add' || $action=='create')
{
	
	if (!$error)
	{	
		$prod='iso2';
		//location.href = \'/comm/action/index.php?idmenu=618&mainmenu=agenda&leftmenu=\';
		if(GETPOST('postidevent')>0 && GETPOST('difficulte')==3) {//onn vient de l'agenda pour créer un devis
			require_once DOL_DOCUMENT_ROOT . "/custom/agendaplus/class/etat_actioncomm.class.php";
			$event=new ActionComm($db);
			$event->fetch(GETPOST('postidevent'));
			$evtetat=new EtatActioncomm($db);
			$evtetat->fetchByEvent(GETPOST('postidevent'));
			$evtetat->etat_id=4;
			$res=$evtetat->update($user);
			//majstatus prévisite du rendez vous
			dol_include_once('/carardv/class/rdv_prev.class.php');
			$rdv = new rdv($db);
			
			//vérifier si l'evennement existe déjà pour ce client là
			$res=$event->getActions($db,$event->fk_soc,$event->fk_element,$event->elementtype);
			$rdv->fetch($event->fk_element);
			$rdv->status=$rdv::STATUS_IMPOSSIBLE;
			$rdv->update($user);
			$urltogo = '/comm/action/index.php?idmenu=618&mainmenu=agenda&leftmenu=';
			header("Location: ".$urltogo);
			exit;
		}
		if(GETPOST('idevent')>0) {//onn vient de l'agenda pour créer un devis
			//on change la couleur du rendez vous
			require_once DOL_DOCUMENT_ROOT . "/custom/agendaplus/class/etat_actioncomm.class.php";
			$event=new ActionComm($db);
			$event->fetch(GETPOST('idevent'));
			$evtetat=new EtatActioncomm($db);
			$evtetat->fetchByEvent(GETPOST('idevent'));
			$evtetat->etat_id=3;
			$res=$evtetat->update($user);
			//majstatus prévisite du rendez vous
			dol_include_once('/carardv/class/rdv_prev.class.php');
			$rdv = new rdv($db);
			
			//vérifier si l'evennement existe déjà pour ce client là
			$res=$event->getActions($db,$event->fk_soc,$event->fk_element,$event->elementtype);
			$rdv->fetch($event->fk_element);
			$rdv->status=$rdv::STATUS_PREVISITEOK;
			$rdv->update($user);
		}
		if(GETPOST('reinit')=='re-initialiser' || GETPOST('idevent')>0 ){
			unset($_SESSION['client'],$_SESSION['iso2'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);
			$action = 'create';
		}
		else{
			$_SESSION['nbpart']=GETPOST('nbpart');
			$_SESSION['rfr']=GETPOST('options_rfr');
			$_SESSION['status_immo']=GETPOST('status_immo');
			
			$_SESSION['financement']['type']=GETPOST('typefin');
					
			$_SESSION[$prod]['maisonplus2']=GETPOST('maisonplus2');
			$_SESSION[$prod]['isocomble']=GETPOST('isocomble');
			$_SESSION[$prod]['metrageiso']=GETPOST('metrageiso');
			$_SESSION[$prod]['difficulte']=GETPOST('difficulte');
			$_SESSION[$prod]['duree']=GETPOST('duree');
			
			if($_SESSION[$prod]['isocomble']>0){
				$_SESSION[$prod]['choix']=1;
			}
			if(!empty(GETPOST('create'))){
				$_SESSION[$prod]['devis_primaire']=1;
				$_SESSION[$prod]['couleur']=GETPOST('couleur');
				$mprod=GETPOST("m",'array');
				foreach($mprod as $id_prod=>$metrage){
					if( $metrage>0)
						$_SESSION[$prod]['prod'][$id_prod]=$metrage;
				}
				//mettre à jour les infos société pour les infos saisies.
				$object_soc=new societe($db);
				$object_soc->fetch($fk_soc);
				$object_soc->array_options['options_rfr']=$_SESSION['rfr'];
				$object_soc->array_options['options_nbpart']=$_SESSION['nbpart'];
				$object_soc->array_options['options_maison2plus']=$_SESSION[$prod]['maisonplus2'];
				$object_soc->array_options['options_status_immo']=$_SESSION['status_immo'];
				$object_soc->array_options['options_isocombles']=$_SESSION[$prod]['isocomble'];
				$object_soc->update(0,$user);
			}
			if (GETPOST('create_client'))
				$action="create_client";
		}
		
	}
	else
	{
		$action = 'create';
	}

}
if ($action == 'creerdevis' ){
	$object_soc=new societe($db);
	$object_soc->fetch(GETPOST('fk_soc'));
	$object_soc->name=GETPOST('firstname');
	$object_soc->address=GETPOST('address');

	$object_soc->array_options['ville']=GETPOST('options_ville');

	$object_soc->phone=GETPOST('phone');
	$object_soc->fax=GETPOST('fax');
	$object_soc->url=GETPOST('url');
	$object_soc->email=GETPOST('email');

	//$object_soc->commercial_id=$user->id;
	
	$error=0;
	if($object_soc->email=="") $error++;
	if($object_soc->array_options['ville']=="0") $error++;
	if($error > 0){
		setEventmessages('Champ email obligatoires',null,'errors');
		$action='create_client';
		return;
	}
	
	$db->begin();
	
	//création du devis
	$object->label='iso';
	$object->difficulte=$_SESSION['iso2']['difficulte'];
	$object->duree=$_SESSION['iso2']['duree'];
	
	$object->fk_commercial=56; //Vente direction
	$couleur=$_SESSION['iso2']['couleur'];
	if($couleur=='b'){
		$bgcolor='lightblue';
		$object_soc->array_options['cara_type_client_ctm']=3; //GPB
	}
	elseif($couleur=='j'){
		$bgcolor='yellow';
		$object_soc->array_options['cara_type_client_ctm']=2; //PJ
	}
	elseif($couleur=='v'){
		$bgcolor='violet';
		$object_soc->array_options['cara_type_client_ctm']=1; //HP v
	}
	
	$object_soc->update(0,$user);
	$object->fk_soc=$object_soc->id;

	function insert_object(&$objectLine,$idproduit){
		global $db;
		$iso= new Product($db);
		$iso->fetch($idproduit);
		$objectLine->label=$iso->label;
		$objectLine->description=$iso->description;
		$objectLine->fk_unit=$iso->fk_unit;
		$objectLine->subprice=$iso->price; //PU HT
		$objectLine->total_ttc=$iso->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->tva_tx=$iso->tva_tx;
		$objectLine->fk_product=$iso->id;
		$objectLine->total_ht=$iso->price*$objectLine->qty; //PTOTAL HT
		$objectLine->type=2;//produit
	}
	
	$i=0;
	$j=0;
	//prévisite
	$objectLine = new iso2Line($db);
	$objectLine->qty=1;
	insert_object($objectLine,$previsite->id);
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total_ttc +=$objectLine->total_ttc;
	$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
	$total_tva += $total_lig_tva;
	$total_ht += $objectLine->total_ht;
	$i++;
	//Isolation
	$tarif=$tabproduct[$_SESSION['status_immo']][$_SESSION['iso2']['maisonplus2']][$_SESSION['iso2']['isocomble']][$couleur];
	$total=$previsite->price_ttc;
	$total_ht=$previsite->price;
	$tab_productdejaaffiches=array();
	foreach ($tarif as $key=>$product){
		if(is_object($product) && !in_array($product->id,$tab_productdejaaffiches)){
			$metrage=$_SESSION['iso2']['prod'][$product->id];
			if($metrage>0){
				array_push($tab_productdejaaffiches,$product->id);
				$objectLine = new iso2Line($db);
				$objectLine->qty=$metrage;
				insert_object($objectLine,$product->id);
				$objectLine->position=$i;
				$object->lines[$i]=$objectLine;
				$total_ttc +=$objectLine->total_ttc;
				$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
				$total_tva += $total_lig_tva;
				$total_ht += $objectLine->total_ht;
				$i++;
				//MO associée
				if($tabmo[$key]){
					$objectLine = new iso2Line($db);
					$objectLine->qty=$metrage;
					insert_object($objectLine,$tabmo[$key]->id);
					$objectLine->position=$i;
					$object->lines[$i]=$objectLine;
					$total_ttc +=$objectLine->total_ttc;
					$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
					$total_tva += $total_lig_tva;
					$total_ht += $objectLine->total_ht;
					$i++;
				}
				//prime
				foreach ($prime[$couleur][$product->id] as $keyp=>$mtprime){
					$objectPrime = new iso2Line($db);
					$objectPrime->qty=$metrage;
					$objectPrime->label=$mtprime->label;
					$objectPrime->subprice=(float)$mtprime->price;
					$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
					$objectPrime->type_prime=$mtprime->array_options['options_type_prime'];
					$objectPrime->fk_product=$mtprime->id;
					$objectPrime->position=$i;
					if($objectPrime->total_ht != 0){
						$object->lines[$i]=$objectPrime;
						$total_primes += $objectPrime->total_ht;
						$i++;
					}
				}
			}
		}
		
		elseif(is_array($product) ){
			foreach($product as $key2=>$multi){
				if(is_object($multi) && !in_array($multi->id,$tab_productdejaaffiches) ){
					$metrage=$_SESSION['iso2']['prod'][$multi->id];
					if($metrage>0){
						array_push($tab_productdejaaffiches,$multi->id);
						$objectLine = new iso2Line($db);
						$objectLine->qty=$metrage;
						insert_object($objectLine,$multi->id);
						$objectLine->position=$i;
						$object->lines[$i]=$objectLine;
						$total_ttc +=$objectLine->total_ttc;
						$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
						$total_tva += $total_lig_tva;
						$total_ht += $objectLine->total_ht;
						$i++;
						if($tabmo[$key2]){
							$objectLine = new iso2Line($db);
							$objectLine->qty=$metrage;
							insert_object($objectLine,$tabmo[$key2]->id);
							$objectLine->position=$i;
							$object->lines[$i]=$objectLine;
							$total_ttc +=$objectLine->total_ttc;
							$total_lig_tva=$objectLine->total_ttc-$objectLine->total_ht;
							$total_tva += $total_lig_tva;
							$total_ht += $objectLine->total_ht;
							$i++;
						}
						//prime
						foreach ($prime[$couleur][$multi->id] as $keyp=>$mtprime){
							$objectPrime = new iso2Line($db);
							$objectPrime->qty=$metrage;
							$objectPrime->label=$mtprime->label;
							$objectPrime->subprice=(float)$mtprime->price;
							$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
							$objectPrime->type_prime=$mtprime->array_options['options_type_prime'];
							$objectPrime->fk_product=$mtprime->id;
							$objectPrime->position=$i;
							if($objectPrime->total_ht != 0){
								$object->lines[$i]=$objectPrime;
								$total_primes += $objectPrime->total_ht;
								$i++;
							}
						}
					}
				}
			}
		}
	}
	
	$object->total_ht=$total_ht;
	$object->total_ttc=$total_ttc;
	$object->total_tva=$total_tva;
	$object->total_rac=$object->total_ttc+$total_primes;
	$object->pencharge=1; //pour la société qui prend en charge
	$object->totaleligible=$object->total_ht;
	
	//prime lib2
	if($object->total_ht>0){
		$result = $object->create($user);
		unset($_SESSION['client'],$_SESSION['iso2'],$_SESSION['financement'],$_SESSION[$prod],
			$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);
		$db->commit();
	}
	else $db->rollback();
	if ($result > 0)
	{
		// Creation OK
		$urltogo = dol_buildpath('deviscara/dev_client.php',1).'?id='.$object->id;
		header("Location: ".$urltogo);
		exit;
	}
	else
	{
		// Creation KO
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else  setEventMessages($object->error, null, 'errors');
		$action = 'create';
	}
}
if ($action == 'addline')
{
	$objectLine=new iso2Line($db);
	$objectLine->fk_product=GETPOST('idprod');
	if($objectLine->fk_product > 0 && GETPOST('prod_entry_mode')!='free'){
		$prod=new Product($db);
		$prod->fetch($objectLine->fk_product);
		$objectLine->fk_deviscara=GETPOST('id');
		$objectLine->label=$prod->label;
		$objectLine->qty=GETPOST('qty');
		$objectLine->description=$prod->description;
		$objectLine->fk_unit=$prod->fk_unit;
		$objectLine->subprice=$prod->price; //PU HT
		$objectLine->total_ttc=$prod->price_ttc * GETPOST('qty');
		$objectLine->tva_tx=$prod->tva_tx;
		$objectLine->fk_product=$prod->id;
		$objectLine->total_ht=$prod->price * GETPOST('qty'); //PTOTAL HT
		$objectLine->type=2;//produit
		$objectLine->position=$object->line_max()+1;
		$objectLine->create($user);
	}
	else{
		$objectLine->fk_deviscara=GETPOST('id');
		$objectLine->type=GETPOST('type');
		$objectLine->label=GETPOST('dp_desc');
		$objectLine->tva_tx=GETPOST('tva_tx');
		
		$objectLine->qty=GETPOST('qty');
		$objectLine->subprice=GETPOST('price_ht');
		$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
		$objectLine->fk_unit=GETPOST('units');
		$objectLine->position=$object->line_max()+1;
		$objectLine->create($user);
	}
	$object->update_total($tabtarif);
}
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
			//$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
		$object->update_total($tabtarif);
		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

//update line
if ($action == 'updateline' )
{
	$objectLine=new iso2Line($db);
	$objectLine->fetch($lineid);
	foreach ($objectLine->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($objectLine->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($objectLine->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($objectLine->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $objectLine->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} 
		elseif (preg_match('/^(varchar)/', $objectLine->fields[$key]['type'])) {
			$value = htmlspecialchars(GETPOST($key));
		}
		else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $objectLine->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($objectLine->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$objectLine->$key = $value;
		if ($val['notnull'] > 0 && $objectLine->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
	$objectLine->update($user);

	$object->update_total($tabtarif);
	
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

if ($action == 'update' && !empty($permissiontoadd))
{
	
	//récupération précarité societe pour update des primes
	$object_soc=new societe($db);
	$object_soc->fetch($object->fk_soc);
	
	//détection cuve 5000
	$idtabcuve5=1;
	foreach($object->lines as $line){
		if (in_array($line->fk_product,array(38,40))){
			$idtabcuve5=2;
			break;
		}
	}
	
	//on update la précarité ctm du client avec le nouveau RFR(car peut être modifié.)
	$object->updatePrecariteCtm($object_soc);
	$tabinfo=get_tarif(array($object_soc->array_options['options_cara_type_client_ctm'],$idtabcuve5));
	$couleur=$tabinfo[0];
	$plafond=$tabinfo[1];
	if($couleur=='b'){
		$bgcolor='lightblue';
		$object_soc->array_options['cara_type_client_ctm']=3; //GPB
	}
	elseif($couleur=='j'){
		$bgcolor='yellow';
		$object_soc->array_options['cara_type_client_ctm']=2; //PJ
	}
	elseif($couleur=='v'){
		$bgcolor='violet';
		$object_soc->array_options['cara_type_client_ctm']=1; //HP v
	}
	$i=0;
	$object->primes=array();
	$rfrc=$object_soc->array_options['options_rfr']/$object_soc->array_options['options_nbpart'];//besoin dans l'include
	$citerneenterree=$object->rechercheref(array(39,40));
	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tarifrep.lib.php',1);
	$tarif=$tabtarif['lib'];
	foreach ($tarif as $id=>$lib){
		$objectPrime = new repPrime($db);
		$objectPrime->qty=1;
		$objectPrime->label=$lib;
		$objectPrime->subprice=(float)$tabtarif[$couleur]['pr']['mt'][$id];
		$objectPrime->fk_unit=(float)$tabtarif[$couleur]['pr']['unit'][$id];
		$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
		$objectPrime->fk_product=$id;
		$objectPrime->type_prime=$tabtarif['pr']['type_prime'][$id];
		$objectPrime->type=3; //produt de type rep
		$objectPrime->position=$i;
		$objectPrime->type_prime=1; //prime CTM
		$object->primes[$i]=$objectPrime;
		$total_primes += $objectPrime->total_ht;
		$i++;
	}
	//primes %
	$objectPrime = new iso2Prime($db);
	$objectPrime->qty=1;
	$objectPrime->label=$tabtarif['lib2']['srep']['lib'];
	//recherche si existance lampe Uv dans le devis.
	$lampeuv=$object->rechercheref(array(58));
	
	if($lampeuv){
		$totaleligible=$object->total_ht-$tabtarif['pv']['rep']['lampeuv']->price;
		$provprime=$tabtarif['lib2']['srep']['mt']*$totaleligible;
	}
	else{
		$provprime=$tabtarif['lib2']['srep']['mt']*$total_ht;
	}
	$objectPrime->prime_tx=$tabtarif['lib2']['srep']['mt'];
	$prime= (-1)* ($provprime>=$plafond?$plafond:$provprime);
	$objectPrime->subprice=$prime;
	$objectPrime->total_ht=$objectPrime->subprice*$objectPrime->qty;
	$objectPrime->type_prime=1; //prime SREP
	$objectPrime->position=$i;
	$object->primes[$i]=$objectPrime;
	$total_primes += $objectPrime->total_ht;

	$object->updateprimes($user);
	$object->update_total($tabtarif);

	$status_avantmaj=$object->status;
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$newstatus=GETPOST('status');
	if($status_avantmaj != $newstatus ){
		$object->{'date_status_'.$newstatus} = dol_now(); //date de changement de statut
	}
	if (!$error)
	{
		$result = $object->update($user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
	//mise à jour des primes
	
}
if ($action == 'mop' && !empty($user->rights->deviscara->dev->facturer)){
	//on met le tiers de prospect à client
	//on crée l'affaire
	// on crée l'objet
	//on paramètre l'objet
	//on inscrit l'objet dans les tableaux alternatifs (tableau mpr...) si ça se fait pas tout seul.
	$object_soc->fetch($object->fk_soc);
	$object_soc->client=1;
	$object_soc->entity=1;
	$db->begin();
	$res=$object_soc->update($object_soc->id,$user);
	if($res>0){
		dol_include_once('/carafinance/class/carafinance.class.php');
		$newaffaire=new carafinance($db);
		$newaffaire->fk_soc=$object_soc->id;
		$newaffaire->entity=1;
		$newaffaire->description_pertinente="Affaire du devis ".$object->ref;
		$newaffaire->description="Affaire du devis ".$object->ref;
		$newaffaire->date_creation=dol_now();
		$newaffaire->fk_usercomm=$object->fk_commercial;
		$newaffaire->fk_user_creat=$user->id;
		$newaffaire->pack=4; //pour rep
		if ($object->mode_reglement_code=='CMA'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=4;
		}
		elseif ($object->mode_reglement_code=='CH' || $object->mode_reglement_code=='PRELE' || $object->mode_reglement_code=='BQ' || $object->label=='iso'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_ACCEPTE;
			$newaffaire->mod_financement=1;
		}
		else{ //si pas de mode de règlement
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=1;
		}
		
		$idAffaire=$newaffaire->create($user);
		if ($idAffaire>0){
			$info=$object->getinfo();
			//on récupere l'id pour créer les produits
			$line=new carafinanceLine($db);	
			
			dol_include_once('/deviscararep/class/deviscararep.class.php');
			$prod=new Deviscararep($db);
			if($object->mode_reglement_code=='CMA')
				$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
			else
				$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER
			$prod->fk_soc=$object->fk_soc;
			$prod->fk_usercomm=$object->fk_commercial;
			$prod->label=1;
			$prod->status=Deviscararep::STATUS_DRAFT; //statut brouillon
			$prod->date_creation=$object->date_creation;
			$prod->date_accepte_mpr=$newaffaire->date_creation;
			$prod->status_mpr=1;
			$prod->status_edf2=1;
			if($info['enterree']==1)
				$prod->type_cuve=2;//cuve enterree
			else
				$prod->type_cuve=1;//cuve Hors sol	
			//nb wc
			$prod->nbwc=$info['wc'];
			if($info['cpto']>0)//si compteur eau: raccordement ttegout
				$prod->raccord_reseau=2;
			else
				$prod->raccord_reseau=1;
			$prod->description="Création Devis REP cuve de ".$info['capacitecuve']." via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$object->id,1).">Devis Commercial</a>" ;
			$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
			$prod->capacitecuve=$info['capacitecuve'];
			$idprod=$prod->create($user);
			$line->fk_type=3; //type rep
			if($idprod>0){
				$line->fk_carafinance=$idAffaire;
				$line->amount=$object->total_rac;
				$line->description=$object->description;
				$line->fk_prod=$idprod;
				$res=$line->insert();

				$object->status=$object::STATUS_CLIENT;
				$object->update($user);
				$totalracaffaire+=$object->total_rac;
			}
			
			$newaffaire->fetch($idAffaire);
			$newaffaire->date_creation=$object->date_creation;
			$newaffaire->amount=$totalracaffaire;
			$newaffaire->update($user);
		}
		else{
			$error++;
		}
	}
	else{
		$error++;
	}
	if($error>0){
		$db->rollback();
		setEventMessage('Erreur de mise en operation','','errors');
	}
	else
		$db->commit();

}