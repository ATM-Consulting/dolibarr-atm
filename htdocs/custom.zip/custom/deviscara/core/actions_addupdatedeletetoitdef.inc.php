<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}

$prod='toitdef';
if(GETPOST('reinit')=='re-initialiser'){
	unset($_SESSION['client'],$_SESSION['financement'],$_SESSION[$prod]);
	$urltogo = dol_buildpath('deviscara/toitdef_card.php',1).'?fromid='.$fromid.'&socid='.$socid.'&action=create';
	header("Location: ".$urltogo);
	exit;
}
// Action to add record
if ($action == 'add' || $action=='create')
{
	
	if (!$error)
	{	
		
	
	}
	else
	{
		$action = 'create';
	}

}
if ($action=='create2'){

	if(!empty(GETPOST('toiture'))){
		$_SESSION[$prod]['charpente']=GETPOST('charpente');
		$_SESSION[$prod]['type_primech']=GETPOST('type_primech');
		$_SESSION[$prod]['metragecharpente']=GETPOST('metragecharpente');
		$_SESSION[$prod]['metragegouttieres']=GETPOST('metragegouttieres');
		$_SESSION[$prod]['gouttiere']=GETPOST('gouttiere');
		$_SESSION[$prod]['type_primegouttiere']=GETPOST('type_primegouttiere');
		$_SESSION[$prod]['metragefauxplafond']=GETPOST('metragefauxplafond');
		$_SESSION[$prod]['type_primefp']=GETPOST('type_primefp');
		$_SESSION[$prod]['metragechenaux']=GETPOST('metragechenaux');
		$_SESSION[$prod]['type_primechen']=GETPOST('type_primechen');
		$_SESSION[$prod]['chienassisnb']=GETPOST('chienassisnb');
		$_SESSION[$prod]['pvdepose']=GETPOST('pvdepose');
		$_SESSION[$prod]['nbpanneaux']=GETPOST('nbpanneaux');
		$_SESSION[$prod]['cesdeposerepose']=GETPOST('cesdeposerepose');
		$_SESSION[$prod]['cesdepose']=GETPOST('cesdepose');
		$_SESSION[$prod]['109']=GETPOST('109');
		$_SESSION[$prod]['106']=GETPOST('106');
		$_SESSION[$prod]['surface109']=GETPOST('surface109');
		$_SESSION[$prod]['surface106']=GETPOST('surface106');
		$_SESSION[$prod]["pvtypedepose"]=GETPOST('pvtypedepose');
		$_SESSION['toitdef']["nbces"]=GETPOST('nbces');

		if(GETPOST('cesdeposerepose')=='oui' && GETPOST('nbces')=="" ) {
			setEventMessages('il faut saisir un nombre de CES', null, 'errors');
			$action='create';
		}
		else
			$action="affichdevis";
	}
	else{
		$_SESSION['client']['cara_type_client']=GETPOST('options_cara_type_client');
		$_SESSION['client']['eligibilite_mpr']=GETPOST('options_eligibilite_mpr');
		$_SESSION['client']['mpr']=GETPOST('mpr');
		$_SESSION[$prod]['surface']=GETPOST('surface');


		$_SESSION['client']['isolation']=GETPOST('isocombles');
		
		$_SESSION[$prod]['tole']=GETPOST('tole');
		$_SESSION[$prod]['type_tole']=GETPOST('type_tole');
		$_SESSION[$prod]['couleur_tole']=GETPOST('couleur_tole');
		
		$action='create2';
	}
}

if ($action == 'financement2'){
	if(GETPOST('reset_financement')!=''){
		unset($_SESSION['financement']['stype']);
	}
	if(GETPOST('typefin')=='fincma'){
		$_SESSION['financement']['type']='fincma';
	}
	if(GETPOST('typefin')=='perso'){
		$_SESSION['financement']['type']='perso';
	}
	$_SESSION['financement']['acompte']=GETPOST('acompte');
	$action='affichfinancement';
	
	if(GETPOST('cmanbmois')!=''){
		$tab=explode('/',GETPOST('cmanbmois'));
		$_SESSION['financement']['stype']['cma']=$tab[0];
		$_SESSION['financement']['stype']['mensualite']=$tab[1];
		$_SESSION['financement']['stype']['cmamontant']=$tab[2];
	} 
	elseif (GETPOST('personbch')>0){
		unset($_SESSION['financement']['stype']['pre']);
		unset($_SESSION['financement']['stype']['persobanque']);
		$_SESSION['financement']['stype']['ch']=GETPOST('personbch');
	} 
	elseif(GETPOST('personbprelev')>0){
		unset($_SESSION['financement']['stype']['ch']);
		unset($_SESSION['financement']['stype']['persobanque']);
		$_SESSION['financement']['stype']['pre']=GETPOST('personbprelev');
	}
	elseif(GETPOST('persobanque')!= ''){
		unset($_SESSION['financement']['stype']['pre']);
		unset($_SESSION['financement']['stype']['ch']);
		$_SESSION['financement']['stype']['persobanque']=GETPOST('persobanque');
	}
	if(GETPOST('valid_financement')=='Création devis' )
		$action='creationdevis';

}
if ($action == 'creationdevis'){
	$object->label='toiture';
	$object_soc=new societe($db);
	$object_soc->fetch(GETPOST('socid'));
	$object->fk_soc=$object_soc->id;
	
	$object->fk_soc=$object_soc->id;
	$object_soc->array_options['eligibilite_mpr']=$_SESSION['client']['eligibilite_mpr'];
	$object->couleur_tole=$_SESSION['toitdef']['couleur_tole'];
	$object->type_tole=$_SESSION['toitdef']['type_tole'];
	$object->fk_devis=GETPOST('fromid');
	$prod='toitdef';
	
	$couleur=$object_soc->array_options['options_cara_type_client'];

	include DOL_DOCUMENT_ROOT.dol_buildpath('/deviscara/lib/deviscara_tariftoitdef.lib.php',1);
	dol_include_once('/deviscara/class/toit.class.php');

	if($_SESSION['client']['mpr']==1)//avec mpr
		$idaffich=0;
	if($_SESSION['client']['mpr']==2)//sans mpr
		$idaffich=1;

	function insert_object(&$objectLine,$type,$prod){
		global $tabtarif,$idaffich;
		$objectLine->label=$tabtarif[$type][$idaffich][$prod]->label;
		$objectLine->ref=$tabtarif[$type][$idaffich][$prod]->ref;
		$objectLine->description=$tabtarif[$type][$idaffich][$prod]->description;
		$objectLine->fk_unit=$tabtarif[$type][$idaffich][$prod]->fk_unit;
		$objectLine->subprice=$tabtarif[$type][$idaffich][$prod]->price; //PU HT
		$objectLine->total_ttc=$tabtarif[$type][$idaffich][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->tva_tx=$tabtarif[$type][$idaffich][$prod]->tva_tx;
		$objectLine->fk_product=$tabtarif[$type][$idaffich][$prod]->id;
		$objectLine->total_ht=$tabtarif[$type][$idaffich][$prod]->price*$objectLine->qty; //PTOTAL HT
		//edf
		// $objectLine->fk_product_edf=$tabtarif[$type][1][$prod]->id;
		// $objectLine->subprice_edf=$tabtarif[$type][1][$prod]->price; //PU HT
		// $objectLine->tva_tx_edf=$tabtarif[$type][1][$prod]->tva_tx;
		// $objectLine->total_ht_edf=$tabtarif[$type][1][$prod]->price*$objectLine->qty; //PTOTAL HT
		// $objectLine->total_ttc_edf=$tabtarif[$type][1][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		// $objectLine->type=2;//produit
	}
	
	function insert_prime(&$objectLine,$couleur,$type,$prod){
		global $tabtarif;
		$objectLine->label=$tabtarif[$couleur][$type][$prod]->label;
		$objectLine->ref=$tabtarif[$couleur][$type][$prod]->ref;
		$objectLine->description=$tabtarif[$couleur][$type][$prod]->description;
		$objectLine->fk_unit=$tabtarif[$couleur][$type][$prod]->fk_unit;
		$objectLine->subprice=$tabtarif[$couleur][$type][$prod]->price; //PU HT
		$objectLine->total_ttc=$tabtarif[$couleur][$type][$prod]->price_ttc*$objectLine->qty;//PTOTAL TTC
		$objectLine->tva_tx=$tabtarif[$couleur][$type][$prod]->tva_tx;
		$objectLine->fk_product=$tabtarif[$couleur][$type][$prod]->id;
		$objectLine->total_ht=$tabtarif[$couleur][$type][$prod]->price*$objectLine->qty; //PTOTAL HT
		$objectLine->type=2;//produit
	}
	
	$i=0;
	
	$object_bc=new toit($db);
	$object_bc->fetch($fromid);
	
	$objectLine = new toitdefLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'forfait','previsite');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total=cumulinsertdevis($total,$objectLine);

	$i++;
	$objectLine = new toitdefLine($db);
	$objectLine->qty=1;
	insert_object($objectLine,'forfait','livraison');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total=cumulinsertdevis($total,$objectLine);

	//toiture
	$i++;
	$objectLine = new toitdefLine($db);
	$objectLine->qty=$_SESSION[$prod]['surface'];
	insert_object($objectLine,'pv','tole');
	$objectLine->position=$i;
	$object->lines[$i]=$objectLine;
	$total=cumulinsertdevis($total,$objectLine);
	//maj BC
	$object_bc->surfacereel = $_SESSION[$prod]['surface'];
	$object->type_tole2=$objectLine->fk_product; //id product dans le type de tole2
	//mot
	if($tabtarif['pv'][$idaffich]['posetole']){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface'];
		insert_object($objectLine,'pv','posetole');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		
	}
	$i++;
	//Sous total
	$objectLine = new toitdefLine($db);
	$objectLine->label='<i>Sous total couverture :</i>';
	$objectLine->position=$i;
	$objectLine->description=NULL;
	$objectLine->fk_product=NULL;
	$objectLine->product_type=9;
	$objectLine->special_code=104777;
	$objectLine->qty=99 ;
	$objectLine->stotal_ht=$total['ht']; //pour le premier
	$object->lines[$i]=$objectLine;

	$sous_totalht=0;

	//isolation
	if($tabtarif['pv109'][$idaffich]['109']){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface109'];
		insert_object($objectLine,'pv109','109');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$objectLine->total_ht;
		//maj BC
		$object_bc->iso109=$objectLine->fk_product;
		$object_bc->rouleaux109estime=$_SESSION[$prod]['surface109']/31;
	}
	
	if($tabtarif['pv109'][$idaffich]['pose109']){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface109'];
		insert_object($objectLine,'pv109','pose109');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$objectLine->total_ht;
	}
	if($sous_totalht>0){
		$i++;
		//Sous total
		$objectLine = new toitdefLine($db);
		$objectLine->label='<i>Sous total 109 :</i>';
		$objectLine->position=$i;
		$objectLine->description=NULL;
		$objectLine->fk_product=NULL;
		$objectLine->product_type=9;
		$objectLine->special_code=104777;
		$objectLine->qty=99 ;
		$objectLine->stotal_ht=$sous_totalht;
		$object->lines[$i]=$objectLine;
	}
	//remise à 0
	$sous_totalht=0;

	if($tabtarif['pv106'][$idaffich]['106']){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface106'];
		insert_object($objectLine,'pv106','106');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$objectLine->total_ht;
		//maj BC
		$object_bc->iso106=$objectLine->fk_product;
		if($objectLine->fk_product==29)
			$object_bc->rouleaux106estime=$_SESSION[$prod]['surface106']/17;
		else
			$object_bc->rouleaux106estime=$_SESSION[$prod]['surface106']/12;
	}
	if($tabtarif['pv106'][$idaffich]['pose106']){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['surface106'];
		insert_object($objectLine,'pv106','pose106');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$sous_totalht+=$objectLine->total_ht;
	}
	if($tabtarif['pv106'][$idaffich]['106']){
		$i++;
		//Sous total
		$objectLine = new toitdefLine($db);
		$objectLine->label='<i>Sous total 106 :</i>';
		$objectLine->position=$i;
		$objectLine->description=NULL;
		$objectLine->fk_product=NULL;
		$objectLine->product_type=9;
		$objectLine->special_code=104777;
		$objectLine->qty=99 ;
		$objectLine->stotal_ht=$sous_totalht;
		$object->lines[$i]=$objectLine;
	}
	//options
	//pour les options on prend idaffich=0
	$idaffich=0;
	if($_SESSION[$prod]['metragecharpente']>0){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragecharpente'];
		insert_object($objectLine,'option','char');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		//maj object 
		$object->charpente_montant=$objectLine->total_ttc;
	}
	if($_SESSION[$prod]['metragegouttieres']>0){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragegouttieres'];
		insert_object($objectLine,'option','gouttiere');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$object->gouttiere=$objectLine->qty;
		$object->devisgouttieres_montant=$objectLine->total_ttc;
	}
	if($_SESSION[$prod]['metragefauxplafond']>0){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragefauxplafond'];
		insert_object($objectLine,'option','fp');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		
	}
	if($_SESSION[$prod]['metragechenaux']>0){
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['metragechenaux'];
		insert_object($objectLine,'option','chen');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		//maj object
		$object->chenaux_ml=$objectLine->qty;
		$object->chenaux_montant=$objectLine->total_ttc;
		
	}
	if($_SESSION[$prod]['chienassisnb']>0){//chien assis
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['chienassisnb']; //forfait
		insert_object($objectLine,'option','chienassis');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		//maj object
		$object->chienassis_nb=$objectLine->qty;
	}
	if($_SESSION[$prod]['nbpanneaux']>0){//dépose et repose panneaux
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]['nbpanneaux'];
		insert_object($objectLine,'option','nbpanneaux');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		//maj object
		$object->pv_nb=$objectLine->qty;
		$object->pv_montant=$objectLine->total_ttc;
	}
	if($_SESSION[$prod]['cesdepose']>0){//dépose ces
		$i++;
		$objectLine = new toitdefLine($db);
		$objectLine->qty=$_SESSION[$prod]["nbces"];
		insert_object($objectLine,'option','cesdepose');
		$objectLine->position=$i;
		$object->lines[$i]=$objectLine;
		$total=cumulinsertdevis($total,$objectLine);
		$object->ces_nb=($_SESSION[$prod]["nbces"]>0?$_SESSION[$prod]["nbces"]:0);
		$object->ces_montant=$objectLine->total_ttc;
		
	}
	
	//primes
	$total_primes=0;

	foreach($tabtarif[$couleur]['pr'] as $type_prime=>$tabprime){
		if($_SESSION['client']['mpr']==1 && $tabprime->array_options['options_type_prime']==2){
			$i++;
			$objectLine = new toitdefLine($db);
			$objectLine->qty=$_SESSION[$prod]['surface109'];
			insert_prime($objectLine,$couleur,'pr',$type_prime);
			$objectLine->position=$i;
			$total_primesMPR+=$objectLine->total_ht;
		}
		elseif($tabprime->array_options['options_type_prime']==1){
			$i++;
			$objectLine = new toitdefLine($db);
			$objectLine->qty=$_SESSION[$prod]['surface106'];
			insert_prime($objectLine,$couleur,'pr',$type_prime);
			$objectLine->position=$i;
			$total_primesEDF+=$objectLine->total_ht;
			$primeEDF[$type_prime]=+$objectLine->total_ht;
		
		}
		$object->lines[$i]=$objectLine;
	}
	$object->total_ht=$total['ht'];
	$object->total_ttc=$total['ttc'];
	$object->total_tva=$total['tva'];
	$object->total_ttc_edf=$total['ttc_edf'];
	$object->couleur_tole=$_SESSION[$prod]['couleur_tole'];
	$object->type_tole=($_SESSION[$prod]['type_tole']>0?$_SESSION[$prod]['type_tole']:0);
	$object->type_charpente=($_SESSION[$prod]["type_primech"]>0?$_SESSION[$prod]["type_primech"]:0);
	$object->chenaux=($_SESSION[$prod]["type_primechen"]>0?$_SESSION[$prod]["type_primechen"]:0);
	$object->pv=($_SESSION[$prod]['pvdepose']>0?$_SESSION[$prod]['pvdepose']:0);
	$object->pv_typedepose=($_SESSION[$prod]["pvtypedepose"]>0?$_SESSION[$prod]["pvtypedepose"]:0);
	

	$object->ces=($_SESSION[$prod]['cesdepose']>0?$_SESSION[$prod]['cesdepose']:0);
	$object_bc->primeedf106_montant=abs($primeEDF['EDF106']);
	$object_bc->primeedf109_montant=abs($primeEDF['EDF109']);
	$object_bc->mprestime_montant=abs($total_primesMPR);
	$object->total_rac=$object->total_ttc+$total_primesEDF+$total_primesMPR; //après mpr
	$object->acompte=$_SESSION['financement']['acompte'];
	$object_bc->status_general=1; //le status général passe à en cours à la génération du devis
	$object->fk_commercial=$object_bc->fk_commercial;
	
	if($object_bc->status_admin==$object::STATUSADMIN_CONFORME){
		$object_bc->com_prct=2; //Si conforme 15%
		$object_bc->com_comestimee=$object->total_rac*0.15;
		$object_bc->acompte50 =$object_bc->com_comestimee/2;
		$object_bc->com_paiementacompte=2;
		$object_bc->date_acompte =dol_now();
	}
	if($object_bc->status_admin==$object::STATUSADMIN_COMPLET){
		$object_bc->com_prct=1;
		$object_bc->com_comestimee=$object->total_rac*0.10;
		$object_bc->acompte50 =$object_bc->com_comestimee/2;
		$object_bc->com_paiementacompte=2;
		$object_bc->date_acompte =dol_now();
	}

	//règlement
	if(GETPOST('typefin')=='fincma'){
		$object->mode_reglement_code=1;
		$object->mode_reglement_cmanb=$_SESSION['financement']['stype']['mensualite'];
		$object->mode_reglement_cmamontant=$_SESSION['financement']['stype']['cmamontant'];
		$object->cma_mensualite=$object->mode_reglement_montant;
		$object->cma_report=($_SESSION['financement']['stype']['cma']=='30'?1:2); //1 pour report de 30, 2 pour 90j
	}
	if(GETPOST('typefin')=='perso'){
		
		if($_SESSION['financement']['stype']['ch']>0){
			$object->mode_reglement_code=2;
			$object->mode_reglement_nb=$_SESSION['financement']['stype']['ch'];
			$object->mode_reglement_montant=($_SESSION['financement']['total']-$_SESSION['financement']['acompte']);
		}	
		if($_SESSION['financement']['stype']['pre']>0){
			$object->mode_reglement_code=2;
			$object->mode_reglement_nb=$_SESSION['financement']['stype']['pre'];
			$object->mode_reglement_montant=($_SESSION['financement']['total']-$_SESSION['financement']['acompte']);
			
		}
		if($_SESSION['financement']['stype']['persobanque']!=''){
			$object->mode_reglement_code=3;
			$object->mode_reglement_montant=($_SESSION['financement']['total']-$_SESSION['financement']['acompte']);
		}
	}

	if($object->total_ht>0){
		$result = $object->create($user);
		unset($_SESSION['client'],$_SESSION['toit'],$_SESSION['financement'],
		$_SESSION['nbpart'],$_SESSION['rfr'],$_SESSION['status_immo'],$_SESSION['client']);
		$db->commit();

	}
	else $db->rollback();
	if ($result > 0)
	{
		//mise à jour de l'objet bc après création.

		$object_bc->fk_devisdefinitif=$result;
		$object_bc->update($user);
		// Creation OK
		$urltogo = dol_buildpath('deviscara/toitdef_card.php',1).'?id='.$object->id;
		header("Location: ".$urltogo);
		exit;
	}
	else
	{
		// Creation KO
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else  setEventMessages($object->error, null, 'errors');
		$action = 'create';
	}
	
}
if ($action == 'addline')
{
	$objectLine=new toitdefLine($db);
	$objectLine->fk_product=GETPOST('idprod');
	if($objectLine->fk_product > 0 && GETPOST('prod_entry_mode')!='free'){
		$prod=new Product($db);
		$prod->fetch($objectLine->fk_product);
		$objectLine->fk_deviscara_toitdef=GETPOST('id');
		$objectLine->label=$prod->label;
		$objectLine->qty=GETPOST('qty');
		$objectLine->description=$prod->description;
		$objectLine->fk_unit=$prod->fk_unit;
		$objectLine->subprice=$prod->price; //PU HT
		$objectLine->total_ttc=$prod->price_ttc * GETPOST('qty');
		$objectLine->tva_tx=$prod->tva_tx;
		$objectLine->fk_product=$prod->id;
		$objectLine->total_ht=$prod->price * GETPOST('qty'); //PTOTAL HT
		$objectLine->type=2;//produit
		$objectLine->rang=$object->line_max()+1;
		$objectLine->create($user);
	}
	else{
		$objectLine->fk_deviscara_toitdef=GETPOST('id');
		$objectLine->type=GETPOST('type');
		$objectLine->label=GETPOST('dp_desc');
		$objectLine->tva_tx=GETPOST('tva_tx');
		
		$objectLine->qty=GETPOST('qty');
		$objectLine->subprice=GETPOST('price_ht');
		$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
		$objectLine->fk_unit=GETPOST('units');
		$objectLine->rang=$object->line_max()+1;
		$objectLine->create($user);
	}
	$object->update_total($tabtarif);
}
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
			//$object->generateDocument($object->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
		$object->update_total($tabtarif);
		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

//update line
if ($action == 'updateline' )
{
	$objectLine= new toitdefLine($db);
	$objectLine->fetch($lineid);
	foreach ($objectLine->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($objectLine->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($objectLine->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($objectLine->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $objectLine->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} 
		elseif (preg_match('/^(varchar)/', $objectLine->fields[$key]['type'])) {
			$value = htmlspecialchars(GETPOST($key));
		}
		else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $objectLine->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($objectLine->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$objectLine->$key = $value;
		if ($val['notnull'] > 0 && $objectLine->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
	$objectLine->update($user);

	$object->update_total($tabtarif);
	
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

if ($action == 'update' && !empty($permissiontoadd))
{
	
	$statusadmin_avantmaj=$object->status_admin;
	$status_avantmaj=$object->status;
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	
	$newstatus=GETPOST('status');
	$newstatusadmin=GETPOST('status_admin');
	if($status_avantmaj != $newstatus && $newstatus!=''){
		$object->{'date_status_'.$newstatus} = dol_now(); //date de changement de statut
		$object->date_statusencours = dol_now(); 
	}
	if($statusadmin_avantmaj != $newstatusadmin ){
		$object->{'date_statusadmin_'.$newstatusadmin} = dol_now(); //date de changement de statut
	}
	if (!$error)
	{
		$result = $object->update($user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
	//mise à jour des primes
	
}
if ($action == 'facturer' && !empty($user->rights->deviscara->dev->facturer))
{
	$object_bc=new toit($db);
	$object_bc->fetch($object->fk_devis);

	dol_include_once('/compta/facture/class/facture.class.php');
	$fac=new Facture($db);
	$fac->socid=$object->fk_soc;
	$fac->date_creation=$fac->date=dol_now();
	$fac->type=0; //facture standard 1=facture de remplacement...
	$fac->entity=2; //CARAENERGIE
	$fac->note_private='Creation Facture via devisdéfinitif <a href="'.dol_buildpath('deviscara/toitdef_card',1).'?id='.$object->id.'">'.$object->ref.' </a> ';
	$facrep->status=$fac::STATUS_DRAFT; //draft
	$fac->fk_commercial=$object->fk_commercial;
	$fac->total_rac=$object->total_rac;
	$fac->ref_int=$object->label;
	$i=0;
	foreach($object->lines as $line){
		$facline=new FactureLigne($db);
		$facline->desc=$line->label;
		$facline->subprice=$line->subprice;
		if($line->qty==null) $line->qty=0;
		$facline->qty=$line->qty;
    	$facline->desc=$line->description;
		//$facline->description=$line->description;
		$facline->date_creation=dol_now();
		$facline->fk_product=$line->fk_product;
		$facline->rang=$line->position;
		$facline->type=$line->type;
		$facline->fk_unit=$line->fk_unit;
		if($line->total_ht==null) $line->total_ht=0;
		$facline->total_ht=$line->total_ht;
		$facline->total_tva=$line->total_ht*$line->tva_tx/100;
		$facline->total_ttc=$line->total_ht+$facline->total_tva;
		$facline->tva_tx=$line->tva_tx;
		$facline->product_type=$line->product_type;
		$facline->special_code=$line->special_code;
		$facrepLine->position=$line->position;
		$facrepLine->fk_product=$line->fk_product;
		$facline->stotal_ht=$line->stotal_ht;
		$fac->lines[$i]=$facline;
		$i++;
	}
	
	//calcul de la comission réelle.
	if($object_bc->status_admin==$object::STATUSADMIN_CONFORME){
		$object_bc->com_prct=2; //Si conforme 15%
		$object_bc->com_comreelle=$object->total_rac*0.15;
	}
	if($object_bc->status_admin==$object::STATUSADMIN_COMPLET){
		$object_bc->com_prct=1;
		$object_bc->com_comreelle=$object->total_rac*0.10;
	}
	//on translate les primes en article de prime
	

	{
		$result = $fac->create($user);
		$fac->update_total_rac();
		if ($result > 0)
		{
			$object->fk_facture=$result;
			$object_bc->fk_facture=$result;
			$object->update($user);
			
			$object_bc->update($user);
			setEventMessages($langs->trans('Facture créée'), null, 'mesgs');
			$url=dol_buildpath('compta/facture/card.php',1);
			header('Location: '.$url.'?facid='.$fac->id);
		}

	}
}

if ($action == 'factureracompte' && !empty($user->rights->deviscara->dev->facturer))
{
    $object_bc=new toit($db);
    $object_bc->fetch($object->fk_devis);

    dol_include_once('/compta/facture/class/facture.class.php');
    $fac=new Facture($db);
    $fac->socid=$object->fk_soc;
    $fac->date_creation=$fac->date=dol_now();
    $fac->type=3; //facture standard 1=facture de remplacement...
    $fac->entity=2; //CARAENERGIE
    $fac->note_private='Creation Facture via devisdéfinitif <a href="'.dol_buildpath('deviscara/toitdef_card',1).'?id='.$object->id.'">'.$object->ref.' </a> ';
    $facrep->status=$fac::STATUS_DRAFT; //draft
    $fac->fk_commercial=$object->fk_commercial;
    //$fac->total_rac=$object->total_rac;
    //$fac->ref_int=$object->label;
    //$i=0;
   // foreach($object->lines as $line){
     //   $facline=new FactureLigne($db);
       // $facline->label=$line->label;
       // $facline->subprice=$line->subprice;
       // if($line->qty==null) $line->qty=0;
       // $facline->qty=$line->qty;
       // $facline->description=$line->description;
       // $facline->date_creation=dol_now();
       // $facline->fk_product=$line->fk_product;
       // $facline->rang=$line->position;
       // $facline->type=$line->type;
       // $facline->fk_unit=$line->fk_unit;
       // if($line->total_ht==null) $line->total_ht=0;
       // $facline->total_ht=$line->total_ht;
       // $facline->total_tva=$line->total_ht*$line->tva_tx/100;
       // $facline->total_ttc=$line->total_ht+$facline->total_tva;
       // $facline->tva_tx=$line->tva_tx;
       // $facline->product_type=$line->product_type;
       // $facline->special_code=$line->special_code;
       // $facrepLine->position=$line->position;
       // $facrepLine->fk_product=$line->fk_product;
       // $facline->stotal_ht=$line->stotal_ht;
       // $fac->lines[$i]=$facline;
       // $i++;
    //}

    //calcul de la comission réelle.
    if($object_bc->status_admin==$object::STATUSADMIN_CONFORME){
        $object_bc->com_prct=2; //Si conforme 15%
        $object_bc->com_comreelle=$object->total_rac*0.15;
    }
    if($object_bc->status_admin==$object::STATUSADMIN_COMPLET){
        $object_bc->com_prct=1;
        $object_bc->com_comreelle=$object->total_rac*0.10;
    }
    //on translate les primes en article de prime


    {
        $result = $fac->create($user);
        $fac->update_total_rac();
        if ($result > 0)
        {
            $object->fk_facture=$result;
            $object_bc->fk_facture=$result;
            $object->update($user);

            $object_bc->update($user);
            setEventMessages($langs->trans('Facture créée'), null, 'mesgs');
            $url=dol_buildpath('compta/facture/card.php',1);
            header('Location: '.$url.'?facid='.$fac->id);
        }

    }
}