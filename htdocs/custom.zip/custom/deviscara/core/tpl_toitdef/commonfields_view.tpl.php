<?php
/* Copyright (C) 2017  Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $action
 * $conf
 * $langs
 *
 * $keyforbreak may be defined to key to switch on second column
 */

// Protection to avoid direct call of template
if (empty($conf) || !is_object($conf))
{
	print "Error, template page can't be called as URL";
	exit;
}
if (!is_object($form)) $form = new Form($db);

?>
<!-- BEGIN PHP TEMPLATE commonfields_view.tpl.php -->
<?php

$object->fields = dol_sort_array($object->fields, 'position');
if($object->fk_devis>0){
	$objectbc = new toit($db);
	$objectbc->fetch($object->fk_devis);
	$url_devisbc = dol_buildpath('/deviscara/toit_card.php', 1).'?id='.$object->fk_devis;
	$linkdevisbc='<a href="'.$url_devisbc.'">'.$objectbc->ref.'</a>';
}
if($object->fk_facture>0){
	$objectfac = new facture($db);
	$objectfac->fetch($object->fk_facture);
	$url_facture = dol_buildpath('/compta/facture/card.php', 1).'?id='.$object->fk_facture;
	$linkfacture='<a href="'.$url_facture.'">'.$objectfac->ref.'</a>';
}
foreach ($object->fields as $key => $val)
{
	if (!empty($keyforbreak) && $key == $keyforbreak) break; // key used for break on second column

	// Discard if extrafield is a hidden field on form
	if (abs($val['visible']) != 1 && abs($val['visible']) != 3 && abs($val['visible']) != 4 && abs($val['visible']) != 5) continue;

	if (array_key_exists('enabled', $val) && isset($val['enabled']) && !verifCond($val['enabled'])) continue; // We don't want this field
	if (in_array($key, array('ref', 'status'))) continue; // Ref and status are already in dol_banner

	$value = $object->$key;

	print '<tr><td';
	print ' class="titlefield fieldname_'.$key;
	//if ($val['notnull'] > 0) print ' fieldrequired';     // No fieldrequired on the view output
	if ($val['type'] == 'text' || $val['type'] == 'html') print ' tdtop';
	print '">';
	if (!empty($val['help'])) print $form->textwithpicto($langs->trans($val['label']), $langs->trans($val['help']));
	else print $langs->trans($val['label']);
	print '</td>';
	print '<td class="valuefield fieldname_'.$key;
	if ($val['type'] == 'text') print ' wordbreak';
	print '">';

	if($key=='fk_devis')
		print $linkdevisbc;
	elseif($key=='fk_facture')
		print $linkfacture;
	else
		print $object->showOutputField($val, $key, $value, '', '', '', 0);
	//print dol_escape_htmltag($object->$key, 1, 1);
	print '</td>';
	print '</tr>';
}

print '</table>';

// We close div and reopen for second column
print '</div>';
print '<div class="fichehalfright">';

print '<div class="underbanner clearboth"></div>';
print '<table class="border centpercent tableforfield">';

$alreadyoutput = 1;
print'<tr><td>Total HT</td><td>'.price($object->total_ht,0,'',1,2,2).'</td></tr>';
print'<tr><td>Total TVA</td><td>'.price($object->total_tva,0,'',1,2,2).'</td></tr>';
print'<tr><td>Total Eligible (HT)</td><td>'.price($object->totaleligible,0,'',1,2,2).'</td></tr>';
print'<tr><td>Total TTC</td><td>'.price($object->total_ttc,0,'',1,2,2).'</td></tr>';
foreach($object->lines as $line){
	$prod=new product($db);
	if($line->fk_product>0)
		$prod->fetch_optionals($line->fk_product);
	if($prod->array_options['options_prime']==1)
		print'<tr><td>'.$line->label.'</td><td>'.price($line->total_ht,'',1,2,2).'</td></tr>';
}
print'<tr><td>Reste à charge</td><td>'.number_format($object->total_rac, 2, ',', ' ').'</td></tr>';
	
?>
<!-- END PHP TEMPLATE commonfields_view.tpl.php -->
