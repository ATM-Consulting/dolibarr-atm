<?php
/* Copyright (C) 2017-2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_addupdatedelete.inc.php
 *  \brief			Code for common actions cancel / add / update / update_extras / delete / deleteline / validate / cancel / reopen / clone
 */


// $action or $cancel must be defined
// $object must be defined
// $permissiontoadd must be defined
// $permissiontodelete must be defined
// $backurlforlist must be defined
// $backtopage may be defined
// $triggermodname may be defined

if (!empty($permissionedit) && empty($permissiontoadd)) $permissiontoadd = $permissionedit; // For backward compatibility

if ($cancel)
{
	/*var_dump($cancel);
	var_dump($backtopage);exit;*/
	if (!empty($backtopageforcancel))
	{
		header("Location: ".$backtopageforcancel);
		exit;
	}
	elseif (!empty($backtopage))
	{
		header("Location: ".$backtopage);
		exit;
	}
	$action = '';
}




// Action to update record
if ($action == 'update' && !empty($permissiontoadd))
{
	$status_avantmaj=$object->status;
	foreach ($object->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($object->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($object->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($object->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($object->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $object->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $object->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($object->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$object->$key = $value;
		if ($val['notnull'] > 0 && $object->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$tab_prime=GETPOST('prime','array');
	if($tab_prime){
		foreach ($object->primes as $id=>$prime){
			foreach($tab_prime as $id_prime=>$mtprime){
				if($prime->id ==$id_prime ){
					$prime->total_ht=$mtprime;
					$prime->update($user);
					$totalprime+=$mtprime;
				}
			}
		}
		//update le reste à charge
		$object->total_rac=$object->total_ttc+$totalprime;
	}
	$newstatus=GETPOST('status');
	if($status_avantmaj != $newstatus ){
		$object->{'date_status_'.$newstatus} = dol_now(); //date de changement de statut
	}
	if (!$error)
	{
		$result = $object->update($user);
		if ($result > 0)
		{
			$action = 'view';
		}
		else
		{
			// Creation KO
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'edit';
		}
	}
	else
	{
		$action = 'edit';
	}
	//mise à jour des primes
	
}

// Action to update one extrafield
if ($action == "update_extras" && !empty($permissiontoadd))
{
	$object->fetch(GETPOST('id', 'int'));

	$attributekey = GETPOST('attribute', 'alpha');
	$attributekeylong = 'options_'.$attributekey;
	$object->array_options['options_'.$attributekey] = GETPOST($attributekeylong, ' alpha');

	$result = $object->insertExtraFields(empty($triggermodname) ? '' : $triggermodname, $user);
	if ($result > 0)
	{
		setEventMessages($langs->trans('RecordSaved'), null, 'mesgs');
		$action = 'view';
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
		$action = 'edit_extras';
	}
}

// Action to delete
if ($action == 'confirm_delete' && !empty($permissiontodelete))
{
    if (!($object->id > 0))
    {
        dol_print_error('', 'Error, object must be fetched before being deleted');
        exit;
    }

	$result = $object->delete($user);
	if ($result > 0)
	{
		// Delete OK
		setEventMessages("RecordDeleted", null, 'mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}
	else
	{
		if (!empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
		else setEventMessages($object->error, null, 'errors');
	}
}

// Remove a line
if ($action == 'confirm_deleteline' && $confirm == 'yes' && !empty($permissiontoadd))
{
	$result = $object->deleteline($user, $lineid);
	if ($result > 0)
	{
		// Define output language
		$outputlangs = $langs;
		$newlang = '';
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09'))
		{
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if ($conf->global->MAIN_MULTILANGS && empty($newlang) && is_object($object->thirdparty))
		{
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE)) {
			$ret = $object->fetch($object->id); // Reload to get new records
		}
		$object->update_total();
		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
		exit;
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action validate object
if ($action == 'confirm_validate' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->validate($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action close object
if ($action == 'confirm_close' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->cancel($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action setdraft object
if ($action == 'confirm_setdraft' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->setDraft($user);
	if ($result >= 0)
	{
		// Nothing else done
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

// Action reopen object
if ($action == 'confirm_reopen' && $confirm == 'yes' && $permissiontoadd)
{
	$result = $object->reopen($user);
	if ($result >= 0)
	{
		// Define output language
		if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
		{
			$outputlangs = $langs;
			$newlang = '';
			if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id', 'aZ09')) $newlang = GETPOST('lang_id', 'aZ09');
			if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $object->thirdparty->default_lang;
			if (!empty($newlang)) {
				$outputlangs = new Translate("", $conf);
				$outputlangs->setDefaultLang($newlang);
			}
			$model = $object->modelpdf;
			$ret = $object->fetch($id); // Reload to get new records

			$object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
		}
	}
	else
	{
		setEventMessages($object->error, $object->errors, 'errors');
	}
}

//update line
if ($action == 'updateline' )
{
	$objectLine=new devLine($db);
	$objectLine->fetch($lineid);
	foreach ($objectLine->fields as $key => $val)
	{
		// Check if field was submited to be edited
		if ($objectLine->fields[$key]['type'] == 'duration') {
			if (!GETPOSTISSET($key.'hour') || !GETPOSTISSET($key.'min')) continue; // The field was not submited to be edited
		}
		else {
			if (!GETPOSTISSET($key)) continue; // The field was not submited to be edited
		}
		// Ignore special fields
		if (in_array($key, array('rowid', 'entity', 'tms', 'fk_user_creat', 'fk_user_modif', 'import_key'))) continue;

		// Set value to update
		if (in_array($objectLine->fields[$key]['type'], array('text', 'html'))) {
			$value = GETPOST($key, 'none');
		} elseif ($objectLine->fields[$key]['type'] == 'date') {
			$value = dol_mktime(12, 0, 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'datetime') {
			$value = dol_mktime(GETPOST($key.'hour'), GETPOST($key.'min'), 0, GETPOST($key.'month'), GETPOST($key.'day'), GETPOST($key.'year'));
		} elseif ($objectLine->fields[$key]['type'] == 'duration') {
			if (GETPOST($key.'hour', 'int') != '' || GETPOST($key.'min', 'int') != '') {
				$value = 60 * 60 * GETPOST($key.'hour', 'int') + 60 * GETPOST($key.'min', 'int');
			} else {
				$value = '';
			}
		} elseif (preg_match('/^(integer|price|real|double)/', $objectLine->fields[$key]['type'])) {
            $value = price2num(GETPOST($key, 'none'));	// To fix decimal separator according to lang setup
		} 
		elseif (preg_match('/^(varchar)/', $objectLine->fields[$key]['type'])) {
			$value = htmlspecialchars(GETPOST($key));
		}
		else {
			$value = GETPOST($key, 'alpha');
		}
		if (preg_match('/^integer:/i', $objectLine->fields[$key]['type']) && $value == '-1') $value = ''; // This is an implicit foreign key field
		if (!empty($objectLine->fields[$key]['foreignkey']) && $value == '-1') $value = ''; // This is an explicit foreign key field

		$objectLine->$key = $value;
		if ($val['notnull'] > 0 && $objectLine->$key == '' && is_null($val['default']))
		{
			$error++;
			setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv($val['label'])), null, 'errors');
		}
	}
	$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
	$objectLine->update($user);

	$object->update_total($tabtarif);
	
}

//ajout ligne supp
if ($action == 'addline')
{
	$objectLine=new devLine($db);
	$objectLine->fk_product=GETPOST('idprod');
	if($objectLine->fk_product > 0 && GETPOST('prod_entry_mode')!='free'){
		$prod=new Product($db);
		$prod->fetch($objectLine->fk_product);
		$objectLine->fk_deviscara=GETPOST('id');
		$objectLine->label=$prod->label;
		$objectLine->qty=GETPOST('qty');
		$objectLine->description=$prod->description;
		$objectLine->fk_unit=$prod->fk_unit;
		$objectLine->subprice=$prod->price; //PU HT
		$objectLine->total_ttc=$prod->price_ttc * GETPOST('qty');
		$objectLine->tva_tx=$prod->tva_tx;
		$objectLine->fk_product=$prod->id;
		$objectLine->total_ht=$prod->price * GETPOST('qty'); //PTOTAL HT
		$objectLine->type=2;//produit
		$objectLine->position=$object->line_max()+1;
		$objectLine->create($user);
	}
	else{
		$objectLine->fk_deviscara=GETPOST('id');
		$objectLine->type=GETPOST('type');
		$objectLine->label=GETPOST('dp_desc');
		$objectLine->tva_tx=GETPOST('tva_tx');
		
		$objectLine->qty=GETPOST('qty');
		$objectLine->subprice=GETPOST('price_ht');
		$objectLine->total_ht=$objectLine->subprice*$objectLine->qty;
		$objectLine->fk_unit=GETPOST('units');
		$objectLine->position=$object->line_max()+1;
		$objectLine->create($user);
	}
	$object->update_total($tabtarif);
}
// Action clone object
if ($action == 'confirm_clone' && $confirm == 'yes' && !empty($permissiontoadd))
{
	if (1 == 0 && !GETPOST('clone_content') && !GETPOST('clone_receivers'))
	{
		setEventMessages($langs->trans("NoCloneOptionsSpecified"), null, 'errors');
	}
	else
	{
	    $objectutil = dol_clone($object, 1); // To avoid to denaturate loaded object when setting some properties for clone or if createFromClone modifies the object. We use native clone to keep this->db valid.
		//$objectutil->date = dol_mktime(12, 0, 0, GETPOST('newdatemonth', 'int'), GETPOST('newdateday', 'int'), GETPOST('newdateyear', 'int'));
        // ...
	    $result = $objectutil->createFromClone($user, (($object->id > 0) ? $object->id : $id));
	    if (is_object($result) || $result > 0)
		{
			$newid = 0;
			if (is_object($result)) $newid = $result->id;
			else $newid = $result;
			header("Location: ".$_SERVER['PHP_SELF'].'?id='.$newid); // Open record of new object
			exit;
		}
		else
		{
		    setEventMessages($objectutil->error, $objectutil->errors, 'errors');
			$action = '';
		}
	}
}
if ($action == 'facturer' && !empty($user->rights->deviscara->dev->facturer))
{
	
	dol_include_once('/compta/facture/class/facture.class.php');
	$fac=new Facture($db);
	$fac->socid=$object->fk_soc;
	$fac->date_creation=$fac->date=dol_now();
	$fac->type=0; //facture standard 1=facture de remplacement...
	$fac->entity=2; //CARAENERGIE
	$fac->note_private='Creation Facture via devis <a href="'.dol_buildpath('deviscara/rep_card',1).'?id='.$object->id.'">'.$object->ref.' </a> ';
	$fac->ref=$fac->getNextNumRef($object->fk_soc);
	$fac->total_ht=$object->total_ht;
	$fac->total_tva=$object->total_tva;
	$fac->total_ttc=$object->total_ttc;
	$facrep->status=$fac::STATUS_DRAFT; //draft
	$fac->fk_commercial=$object->fk_commercial;
	$fac->total_rac=$object->total_rac;
	$fac->ref_int=$object->label;
	$i=0;
	foreach($object->lines as $line){
		$facline=new FactureLigne($db);
		$facline->label=$line->label;
		$facline->subprice=$line->subprice;
		if($line->qty==null) $line->qty=0;
		$facline->qty=$line->qty;
		$facline->desc=$line->description;
		$facline->date_creation=dol_now();
		$facline->fk_product=$line->fk_product;
		$facline->rang=$line->position;
		$facline->type=$line->type;
		$facline->fk_unit=$line->fk_unit;
		if($line->total_ht==null) $line->total_ht=0;
		$facline->total_ht=$line->total_ht;
		$facline->total_tva=$line->total_ht*$line->tva_tx/100;
		$facline->total_ttc=$line->total_ht+$facline->total_tva;
		$facline->tva_tx=$line->tva_tx;
		$facline->product_type=$line->product_type;
		$facline->special_code=$line->special_code;
		$facline->position=$line->position;
		$facline->fk_product=$line->fk_product;
		$facline->stotal_ht=$line->stotal_ht;
		$fac->lines[$i]=$facline;
		$i++;
	}

	//on translate les primes en article de prime
	

	{
		$result = $fac->create($user);
		if ($result > 0)
		{
			setEventMessages($langs->trans('Facture créée'), null, 'mesgs');
			$url=dol_buildpath('compta/facture/card.php',1);
			header('Location: '.$url.'?facid='.$fac->id);
		}
	}
}
// Mise en opération automatique
if ($action == 'mop' && !empty($user->rights->deviscara->dev->facturer)){
	//on met le tiers de prospect à client
	//on crée l'affaire
	// on crée l'objet
	//on paramètre l'objet
	//on inscrit l'objet dans les tableaux alternatifs (tableau mpr...) si ça se fait pas tout seul.
	$object_soc->fetch($object->fk_soc);
	$object_soc->client=1;
	$object_soc->entity=1;
	$db->begin();
	$res=$object_soc->update($object_soc->id,$user);
	if($res>0){
		dol_include_once('/carafinance/class/carafinance.class.php');
		$newaffaire=new carafinance($db);
		$newaffaire->fk_soc=$object_soc->id;
		$newaffaire->entity=1;
		$newaffaire->description_pertinente="Affaire du devis ".$object->ref;
		$newaffaire->description="Affaire du devis ".$object->ref;
		$newaffaire->date_creation=dol_now();
		$newaffaire->fk_usercomm=$object->fk_commercial;
		$newaffaire->fk_user_creat=$user->id;
		if ($object->label=='iso')
			$newaffaire->pack=5; //pour l'iso
		if ($object->label=='ces')
			$newaffaire->pack=6; //pour l'ces
		if ($object->label=='toiture')
			$newaffaire->pack=1; //pour toiture
		if ($object->mode_reglement_code=='CMA'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=4;
		}
		elseif ($object->mode_reglement_code=='CH' || $object->mode_reglement_code=='PRELE' || $object->mode_reglement_code=='BQ' || $object->label=='iso'){
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_ACCEPTE;
			$newaffaire->mod_financement=1;
		}
		else{ //si pas de mode de règlement
			$newaffaire->suivi_financement=$newaffaire::STATUSFIN_DRAFT;
			$newaffaire->mod_financement=1;
		}
		
		$idAffaire=$newaffaire->create($user);
		if ($idAffaire>0){
			$info=$object->getinfo();
			//on récupere l'id pour créer les produits
			$line=new carafinanceLine($db);	
			$tabdevisacreer=$object->getlink();	
			if(count($tabdevisacreer)==0) $tabdevisacreer[0]=$object->id;
			foreach($tabdevisacreer as $id_devis){
				$obj=new dev($db);
				$obj->fetch($id_devis);
				if ($obj->label=='iso'){
					//tableau correspondance sous type et produits pour la mop
					$tab_soustype=array(
						6=>4, //ISOA
						8=>6, //ISOR IBR
						29=>1, //ISO LV
						63=>2, //ISO LR
						67=>7, //ISO T
					);
					dol_include_once('/deviscaraiso/class/deviscaraiso.class.php');
					foreach($object->lines as $object_line){ // pour chaque ligne du devis iso
						if (array_key_exists($object_line->fk_product,$tab_soustype)){
							$prod=new Deviscaraiso($db);
							if($obj->mode_reglement_code=='CMA')
								$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
							else
								$prod->planificatiaon=$prod::STATUSPLANIF_ATTENTE; //A TRAITER
							$prod->fk_soc=$obj->fk_soc;
							$prod->fk_usercomm=$obj->fk_commercial;
							$prod->label=1;
							$prod->status=Deviscaraiso::STATUS_DRAFT; //statut brouillon
							$prod->date_creation=$obj->date_creation;;
							$prod->date_accepte_mpr=$newaffaire->date_creation;
							$prod->status_mpr=1;
							$prod->status_edf2=1;
							$prod->s_type=$tab_soustype[$object_line->fk_product];
							$prod->difficulte=$obj->difficulte;
							$prod->duree=$obj->duree;
							$prod->description="Création Devis ISO via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$object->id,1).">Devis Commercial</a>" ;
							$prod->fk_devis=$object->id;
							$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
							$prod->surfaceiso=$info['surfaceiso'];
							$idprod=$prod->create($user);
							$line->fk_type=1;
							if($idprod>0){
								$line->fk_carafinance=$idAffaire;
								$line->amount=1;
								$line->description=$obj->description;
								$line->fk_prod=$idprod;
								$res=$line->insert();
							}
						}
					}
					$obj->fk_carafinance=$idAffaire;
					$obj->status=dev::STATUS_CLIENT;
					$obj->update($user);
					$totalracaffaire+=1;//iso à un euro
				}
				elseif ($obj->label=='ces'){
					dol_include_once('/deviscaraces/class/deviscaraces.class.php');
					$prod= new deviscaraces($db);
					$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER

					$prod->fk_soc=$obj->fk_soc;
					$prod->fk_usercomm=$obj->fk_commercial;
					$prod->label=2;
					$prod->status=Deviscaraces::STATUS_DRAFT; //statut brouillon
					$prod->date_creation=$newaffaire->date_creation;
					$prod->date_accepte_mpr=$newaffaire->date_creation;
					$prod->status_mpr=1;
					$prod->status_edf2=1;
					$prod->status_edf=NULL;
					$prod->status_cee=$info['status_cee'];
					$prod->typeces=$info;
					$prod->description="Création Devis CES via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$object->id,1).">Devis Commercial</a>" ;
					$prod->fk_devis=$object->id;
					$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
					$idprod=$prod->create($user);
					$line->fk_type=2;
					if($idprod>0){
						$line->fk_carafinance=$idAffaire;
						if($object->pencharge>0)
							$line->amount=$obj->pencharge;
						else
							$line->amount=$obj->total_rac;
						$line->description=$obj->description;
						$line->fk_prod=$idprod;
						$res=$line->insert();
						$obj->fk_carafinance=$idAffaire;
						$obj->status=dev::STATUS_CLIENT;
						$obj->update($user);
						$totalracaffaire+=$obj->total_rac;
					}
				}
				elseif ($obj->label=='toiture'){
					dol_include_once('/deviscaratoit/class/deviscaratoitbis.class.php');
					$prod= new Deviscaratoit($db);
					if($obj->mode_reglement_code=='CMA')
						$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
					else
						$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER

					$prod->fk_soc=$obj->fk_soc;
					$prod->fk_usercomm=$obj->fk_commercial;
					$prod->label=4;
					$prod->status=Deviscaratoit::STATUS_DRAFT; //statut brouillon
					$prod->date_creation=$obj->date_creation;;
					$prod->date_accepte_mpr=$obj->date_creation;;
					$prod->status_mpr=1;
					$prod->status_edf2=1;
					$prod->typetoit=$info;
					$prod->description="Création Devis TOITURE via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$obj->id,1).">Devis Commercial</a>" ;
					$prod->fk_devis=$object->id;
					$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
					$idprod=$prod->create($user);
					$line->fk_type=4;
					if($idprod>0){
						$line->fk_carafinance=$idAffaire;
						$line->amount=$obj->total_rac;
						$line->description=$obj->description;
						$line->fk_prod=$idprod;
						$res=$line->insert();
						$totalracaffaire+=$obj->total_rac;
					}
					//ajout objet iso
					dol_include_once('/deviscaraiso/class/deviscaraisotoit.class.php');
					foreach($info['listIsoToiture'] as $fk_isotoiture) {
						$prod=new Deviscaraisotoit($db);
						if($obj->mode_reglement_code=='CMA')
							$prod->planification=$prod::STATUSPLANIF_PACK; //ATF
						else
							$prod->planification=$prod::STATUSPLANIF_ATTENTE; //A TRAITER
						
						if($fk_isotoiture==6) $prod->s_type=4; //ISOA
						elseif($fk_isotoiture==8) $prod->s_type=6; //ISOR
						elseif($fk_isotoiture==29) $prod->s_type=1; //ISO LV
						
						$prod->status_edf=$info['status_edf'];
						$prod->status_cee=$info['status_cee'];
						$prod->fk_soc=$obj->fk_soc;
						$prod->fk_usercomm=56; //seulement vente direction
						$prod->label=7;
						$prod->status=Deviscaraisotoit::STATUS_DRAFT; //statut brouillon
						$prod->date_creation=$obj->date_creation;;
						$prod->date_mpr_1=$obj->date_creation;;
						$prod->status_mpr=1;
						$prod->status_edf2=1;
						
						$prod->description="Création Devis ISO Toiture via le <a href=".dol_buildpath('deviscara/dev_card.php?id='.$obj->id,1).">Devis Commercial</a>" ;
						$prod->fk_devis=$object->id;
						$prod->description.="Création RENO via le <a href=".dol_buildpath('carafinance/carafinance_card.php?id=2'.$idAffaire,1).">Affaire</a>" ;
						$prod->surfaceiso=$info['surfaceiso'];
						$idprodisotoit=$prod->create($user);
						$line->fk_type=7;
						if($idprodisotoit>0){
							$line->fk_carafinance=$idAffaire;
							$line->amount=1;
							$line->qty=$prod->surfaceiso;
							$line->description=$obj->description;
							$line->fk_prod=$idprodisotoit;
							$res=$line->insert();
							$totalracaffaire+=1;//iso=1 euro
						}
					}
					$obj->fk_carafinance=$idAffaire;
					$obj->status=dev::STATUS_CLIENT;
					$obj->update($user);
				}
				
				else{
					$error++;
				}
			}
			$newaffaire->fetch($idAffaire);
			$newaffaire->date_creation=$obj->date_creation;
			$newaffaire->amount=$totalracaffaire;
			$newaffaire->comission_montant=$newaffaire->amount*0.1;
			$newaffaire->update($user);
		}
		else{
			$error++;
		}
	}
	else{
		$error++;
	}
	if($error>0){
		$db->rollback();
		setEventMessage('Erreur de mise en operation','','errors');
	}
	else{
		$db->commit();
		setEventMessage('Mise en opération réussie','','mesgs');
		header("Location: ".$backurlforlist);
		exit;
	}

}