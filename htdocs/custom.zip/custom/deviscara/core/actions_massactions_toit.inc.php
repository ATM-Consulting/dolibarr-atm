<?php
/* Copyright (C) 2015-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2018	   Nicolas ZABOURI	<info@inovea-conseil.com>
 * Copyright (C) 2018 	   Juanjo Menent  <jmenent@2byte.es>
 * Copyright (C) 2019 	   Ferran Marcet  <fmarcet@2byte.es>
 * Copyright (C) 2019       Frédéric France         <frederic.france@netlogic.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_massactions.inc.php
 *  \brief			Code for actions done with massaction button (send by email, merge pdf, delete, ...)
 */


// $massaction must be defined
// $objectclass and $objectlabel must be defined
// $parameters, $object, $action must be defined for the hook.

// $permissiontoread, $permissiontoadd, $permissiontodelete, $permissiontoclose may be defined
// $uploaddir may be defined (example to $conf->projet->dir_output."/";)
// $toselect may be defined
// $diroutputmassaction may be defined


// Protection
if (empty($objectclass) || empty($uploaddir))
{
	dol_print_error(null, 'include of actions_massactions.inc.php is done but var $objectclass or $uploaddir was not defined');
	exit;
}

// For backward compatibility
if (!empty($permtoread) && empty($permissiontoread)) $permissiontoread = $permtoread;
if (!empty($permtocreate) && empty($permissiontoadd)) $permissiontoadd = $permtocreate;
if (!empty($permtodelete) && empty($permissiontodelete)) $permissiontoread = $permtodelete;


// Mass actions. Controls on number of lines checked.
$maxformassaction = (empty($conf->global->MAIN_LIMIT_FOR_MASS_ACTIONS) ? 1000 : $conf->global->MAIN_LIMIT_FOR_MASS_ACTIONS);
if (!empty($massaction) && is_array($toselect) && count($toselect) < 1)
{
	$error++;
	setEventMessages($langs->trans("NoRecordSelected"), null, "warnings");
}


if (!$error && $massaction == 'confirm_presend')
{
	$resaction = '';
	$nbsent = 0;
	$nbignored = 0;
	$langs->load("mails");
	include_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

	$listofobjectid = array();
	$listofobjectthirdparties = array();
	$listofobjectcontacts = array();
	$listofobjectref = array();
	$contactidtosend = array();
	$attachedfilesThirdpartyObj = array();
	$oneemailperrecipient = (GETPOST('oneemailperrecipient') == 'on' ? 1 : 0);

	if (!$error)
	{
		$thirdparty = new Societe($db);

		$objecttmp = new $objectclass($db);
		if ($objecttmp->element == 'expensereport') $thirdparty = new User($db);
		if ($objecttmp->element == 'holiday')       $thirdparty = new User($db);

		foreach ($toselect as $toselectid)
		{
			$objecttmp = new $objectclass($db); // we must create new instance because instance is saved into $listofobjectref array for future use
			$result = $objecttmp->fetch($toselectid);
			if ($result > 0)
			{
				$listofobjectid[$toselectid] = $toselectid;

				$thirdpartyid = ($objecttmp->fk_soc ? $objecttmp->fk_soc : $objecttmp->socid);
				if ($objecttmp->element == 'societe') $thirdpartyid = $objecttmp->id;
				if ($objecttmp->element == 'expensereport') $thirdpartyid = $objecttmp->fk_user_author;
				if ($objecttmp->element == 'holiday')       $thirdpartyid = $objecttmp->fk_user;
				if (empty($thirdpartyid)) $thirdpartyid = 0;

				if ($objectclass == 'Facture') {
					$tmparraycontact = array();
					$tmparraycontact = $objecttmp->liste_contact(-1, 'external', 0, 'BILLING');
					if (is_array($tmparraycontact) && count($tmparraycontact) > 0) {
						foreach ($tmparraycontact as $data_email) {
							$listofobjectcontacts[$toselectid][$data_email['id']] = $data_email['email'];
						}
					}
				}

                $listofobjectthirdparties[$thirdpartyid] = $thirdpartyid;
                $listofobjectref[$thirdpartyid][$toselectid] = $objecttmp;
            }
        }
    }

	// Check mandatory parameters
	if (GETPOST('fromtype', 'alpha') === 'user' && empty($user->email))
	{
		$error++;
		setEventMessages($langs->trans("NoSenderEmailDefined"), null, 'warnings');
		$massaction = 'presend';
	}

	$receiver = $_POST['receiver'];
	if (!is_array($receiver))
	{
		if (empty($receiver) || $receiver == '-1') $receiver = array();
		else $receiver = array($receiver);
	}
	if (!trim($_POST['sendto']) && count($receiver) == 0 && count($listofobjectthirdparties) == 1)	// if only one recipient, receiver is mandatory
	{
	 	$error++;
	   	setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("Recipient")), null, 'warnings');
	   	$massaction = 'presend';
	}

	if (!GETPOST('subject', 'none'))
	{
		$error++;
		setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("MailTopic")), null, 'warnings');
		$massaction = 'presend';
	}

	// Loop on each recipient/thirdparty
	if (!$error)
	{
		foreach ($listofobjectthirdparties as $thirdpartyid)
		{
			$result = $thirdparty->fetch($thirdpartyid);
			if ($result < 0)
			{
				dol_print_error($db);
				exit;
			}

			$sendto = '';
			$sendtocc = '';
			$sendtobcc = '';
			$sendtoid = array();

			// Define $sendto
			$tmparray = array();
			if (trim($_POST['sendto']))
			{
				// Recipients are provided into free text
				$tmparray[] = trim($_POST['sendto']);
			}
			if (count($receiver) > 0)
			{
				foreach ($receiver as $key=>$val)
				{
					// Recipient was provided from combo list
					if ($val == 'thirdparty') // Id of third party or user
					{
						$tmparray[] = $thirdparty->name.' <'.$thirdparty->email.'>';
					}
					elseif ($val && method_exists($thirdparty, 'contact_get_property'))		// Id of contact
					{
						$tmparray[] = $thirdparty->contact_get_property((int) $val, 'email');
						$sendtoid[] = $val;
					}
				}
			}
			$sendto = implode(',', $tmparray);

			// Define $sendtocc
			$receivercc = $_POST['receivercc'];
			if (!is_array($receivercc))
			{
				if ($receivercc == '-1') $receivercc = array();
				else $receivercc = array($receivercc);
			}
			$tmparray = array();
			if (trim($_POST['sendtocc']))
			{
				$tmparray[] = trim($_POST['sendtocc']);
			}
			if (count($receivercc) > 0)
			{
				foreach ($receivercc as $key=>$val)
				{
					// Recipient was provided from combo list
					if ($val == 'thirdparty') // Id of third party
					{
						$tmparray[] = $thirdparty->name.' <'.$thirdparty->email.'>';
					}
					elseif ($val)	// Id du contact
					{
						$tmparray[] = $thirdparty->contact_get_property((int) $val, 'email');
						//$sendtoid[] = $val;  TODO Add also id of contact in CC ?
					}
				}
			}
			$sendtocc = implode(',', $tmparray);

			//var_dump($listofobjectref);exit;
			$listofqualifiedobj = array();
			$listofqualifiedref = array();
			$thirdpartywithoutemail = array();

			foreach ($listofobjectref[$thirdpartyid] as $objectid => $objectobj)
			{
				//var_dump($thirdpartyid.' - '.$objectid.' - '.$objectobj->statut);
				if ($objectclass == 'Propal' && $objectobj->statut == Propal::STATUS_DRAFT)
				{
					$langs->load("errors");
					$nbignored++;
					$resaction .= '<div class="error">'.$langs->trans('ErrorOnlyProposalNotDraftCanBeSentInMassAction', $objectobj->ref).'</div><br>';
					continue; // Payment done or started or canceled
				}
				if ($objectclass == 'Commande' && $objectobj->statut == Commande::STATUS_DRAFT)
				{
					$langs->load("errors");
					$nbignored++;
					$resaction .= '<div class="error">'.$langs->trans('ErrorOnlyOrderNotDraftCanBeSentInMassAction', $objectobj->ref).'</div><br>';
					continue;
				}
				if ($objectclass == 'Facture' && $objectobj->statut == Facture::STATUS_DRAFT)
				{
					$langs->load("errors");
					$nbignored++;
					$resaction .= '<div class="error">'.$langs->trans('ErrorOnlyInvoiceValidatedCanBeSentInMassAction', $objectobj->ref).'</div><br>';
					continue; // Payment done or started or canceled
				}

				// Test recipient
				if (empty($sendto)) 	// For the case, no recipient were set (multi thirdparties send)
				{
					if ($objectobj->element == 'expensereport')
					{
						$fuser = new User($db);
						$fuser->fetch($objectobj->fk_user_author);
						$sendto = $fuser->email;
					}
					elseif ($objectobj->element == 'holiday')
					{
					    $fuser = new User($db);
					    $fuser->fetch($objectobj->fk_user);
					    $sendto = $fuser->email;
					}
					elseif ($objectobj->element == 'facture' && !empty($listofobjectcontacts[$objectid]))
					{
						$emails_to_sends = array();
						$objectobj->fetch_thirdparty();
						$contactidtosend = array();
						foreach ($listofobjectcontacts[$objectid] as $contactemailid => $contactemailemail) {
							$emails_to_sends[] = $objectobj->thirdparty->contact_get_property($contactemailid, 'email');
							if (!in_array($contactemailid, $contactidtosend)) {
								$contactidtosend[] = $contactemailid;
							}
						}
						if (count($emails_to_sends) > 0) {
							$sendto = implode(',', $emails_to_sends);
						}
					}
					else
					{
						$objectobj->fetch_thirdparty();
						$sendto = $objectobj->thirdparty->email;
					}
				}

				if (empty($sendto))
				{
				   	//print "No recipient for thirdparty ".$objectobj->thirdparty->name;
				   	$nbignored++;
				   	if (empty($thirdpartywithoutemail[$objectobj->thirdparty->id]))
					{
						$resaction .= '<div class="error">'.$langs->trans('NoRecipientEmail', $objectobj->thirdparty->name).'</div><br>';
					}
					dol_syslog('No recipient for thirdparty: '.$objectobj->thirdparty->name, LOG_WARNING);
					$thirdpartywithoutemail[$objectobj->thirdparty->id] = 1;
				   	continue;
				}

				if ($_POST['addmaindocfile'])
				{
					// TODO Use future field $objectobj->fullpathdoc to know where is stored default file
					// TODO If not defined, use $objectobj->modelpdf (or defaut invoice config) to know what is template to use to regenerate doc.
					$filename = dol_sanitizeFileName($objectobj->ref).'.pdf';
					$subdir = '';
					// TODO Set subdir to be compatible with multi levels dir trees
					// $subdir = get_exdir($objectobj->id, 2, 0, 0, $objectobj, $objectobj->element)
					$filedir = $uploaddir.'/'.$subdir.dol_sanitizeFileName($objectobj->ref);
					$file = $filedir.'/'.$filename;

					// For supplier invoices, we use the file provided by supplier, not the one we generate
					if ($objectobj->element == 'invoice_supplier')
					{
						$fileparams = dol_most_recent_file($uploaddir.'/'.get_exdir($objectobj->id, 2, 0, 0, $objectobj, $objectobj->element).$objectobj->ref, preg_quote($objectobj->ref, '/').'([^\-])+');
						$file = $fileparams['fullname'];
					}

					$mime = dol_mimetype($file);

	   				if (dol_is_file($file))
					{
						// Create form object
						$attachedfilesThirdpartyObj[$thirdpartyid][$objectid] = array(
							'paths'=>array($file),
							'names'=>array($filename),
							'mimes'=>array($mime)
						);
					}
					else
					{
							$nbignored++;
							$langs->load("errors");
							$resaction .= '<div class="error">'.$langs->trans('ErrorCantReadFile', $file).'</div><br>';
							dol_syslog('Failed to read file: '.$file, LOG_WARNING);
							continue;
					}
				}

				// Object of thirdparty qualified, we add it
				$listofqualifiedobj[$objectid] = $objectobj;
				$listofqualifiedref[$objectid] = $objectobj->ref;


				//var_dump($listofqualifiedref);
			}

			// Send email if there is at least one qualified object for current thirdparty
			if (count($listofqualifiedobj) > 0)
			{
				$langs->load("commercial");

				$reg = array();
				$fromtype = GETPOST('fromtype');
				if ($fromtype === 'user') {
					$from = $user->getFullName($langs).' <'.$user->email.'>';
				}
				elseif ($fromtype === 'company') {
					$from = $conf->global->MAIN_INFO_SOCIETE_NOM.' <'.$conf->global->MAIN_INFO_SOCIETE_MAIL.'>';
				}
				elseif (preg_match('/user_aliases_(\d+)/', $fromtype, $reg)) {
					$tmp = explode(',', $user->email_aliases);
					$from = trim($tmp[($reg[1] - 1)]);
				}
				elseif (preg_match('/global_aliases_(\d+)/', $fromtype, $reg)) {
					$tmp = explode(',', $conf->global->MAIN_INFO_SOCIETE_MAIL_ALIASES);
					$from = trim($tmp[($reg[1] - 1)]);
				}
				elseif (preg_match('/senderprofile_(\d+)_(\d+)/', $fromtype, $reg)) {
					$sql = 'SELECT rowid, label, email FROM '.MAIN_DB_PREFIX.'c_email_senderprofile WHERE rowid = '.(int) $reg[1];
					$resql = $db->query($sql);
					$obj = $db->fetch_object($resql);
					if ($obj)
					{
						$from = $obj->label.' <'.$obj->email.'>';
					}
				}
				else {
					$from = $_POST['fromname'].' <'.$_POST['frommail'].'>';
				}

				$replyto = $from;
				$subject = GETPOST('subject', 'none');
				$message = GETPOST('message', 'none');

				$sendtobcc = GETPOST('sendtoccc');
				if ($objectclass == 'Propal') 				$sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_PROPOSAL_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_PROPOSAL_TO));
				if ($objectclass == 'Commande') 			$sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_ORDER_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_ORDER_TO));
				if ($objectclass == 'Facture') 				$sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_INVOICE_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_INVOICE_TO));
				if ($objectclass == 'Supplier_Proposal') 	$sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_SUPPLIER_PROPOSAL_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_SUPPLIER_PROPOSAL_TO));
				if ($objectclass == 'CommandeFournisseur')	$sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_SUPPLIER_ORDER_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_SUPPLIER_ORDER_TO));
				if ($objectclass == 'FactureFournisseur')	$sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_SUPPLIER_INVOICE_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_SUPPLIER_INVOICE_TO));
				if ($objectclass == 'Project') 			    $sendtobcc .= (empty($conf->global->MAIN_MAIL_AUTOCOPY_PROJECT_TO) ? '' : (($sendtobcc ? ", " : "").$conf->global->MAIN_MAIL_AUTOCOPY_PROJECT_TO));

				// $listofqualifiedobj is array with key = object id and value is instance of qualified objects, for the current thirdparty (but thirdparty property is not loaded yet)
				// $looparray will be an array with number of email to send for the current thirdparty (so 1 or n if n object for same thirdparty)
				$looparray = array();
				if (!$oneemailperrecipient)
				{
					$looparray = $listofqualifiedobj;
					foreach ($looparray as $key => $objecttmp)
					{
					    $looparray[$key]->thirdparty = $thirdparty; // Force thirdparty on object
					}
				}
				else
				{
					$objectforloop = new $objectclass($db);
					$objectforloop->thirdparty = $thirdparty; // Force thirdparty on object (even if object was not loaded)
					$looparray[0] = $objectforloop;
				}
				//var_dump($looparray);exit;
                dol_syslog("We have set an array of ".count($looparray)." emails to send. oneemailperrecipient=".$oneemailperrecipient);
                //var_dump($oneemailperrecipient); var_dump($listofqualifiedobj); var_dump($listofqualifiedref);
                foreach ($looparray as $objectid => $objecttmp)		// $objecttmp is a real object or an empty object if we choose to send one email per thirdparty instead of one per object
				{
					// Make substitution in email content
					if (!empty($conf->projet->enabled) && method_exists($objecttmp, 'fetch_projet') && is_null($objecttmp->project))
					{
						$objecttmp->fetch_projet();
					}
					$substitutionarray = getCommonSubstitutionArray($langs, 0, null, $objecttmp);
					$substitutionarray['__ID__']    = ($oneemailperrecipient ? join(', ', array_keys($listofqualifiedobj)) : $objecttmp->id);
					$substitutionarray['__REF__']   = ($oneemailperrecipient ? join(', ', $listofqualifiedref) : $objecttmp->ref);
					$substitutionarray['__EMAIL__'] = $thirdparty->email;
					$substitutionarray['__CHECK_READ__'] = '<img src="'.DOL_MAIN_URL_ROOT.'/public/emailing/mailing-read.php?tag='.$thirdparty->tag.'&securitykey='.urlencode($conf->global->MAILING_EMAIL_UNSUBSCRIBE_KEY).'" width="1" height="1" style="width:1px;height:1px" border="0"/>';

					$parameters = array('mode'=>'formemail');

					if (!empty($listofobjectthirdparties)) {
						$parameters['listofobjectthirdparties'] = $listofobjectthirdparties;
					}
					if (!empty($listofobjectref)) {
						$parameters['listofobjectref'] = $listofobjectref;
					}

					complete_substitutions_array($substitutionarray, $langs, $objecttmp, $parameters);

                    $subjectreplaced = make_substitutions($subject, $substitutionarray);
                    $messagereplaced = make_substitutions($message, $substitutionarray);

                    $attachedfiles = array('paths'=>array(), 'names'=>array(), 'mimes'=>array());
					if ($oneemailperrecipient)
					{
						// if "one email per recipient" is check we must collate $attachedfiles by thirdparty
						if (is_array($attachedfilesThirdpartyObj[$thirdparty->id]) && count($attachedfilesThirdpartyObj[$thirdparty->id]))
						{
							foreach ($attachedfilesThirdpartyObj[$thirdparty->id] as $keyObjId =>  $objAttachedFiles) {
								// Create form object
								$attachedfiles = array(
									'paths'=>array_merge($attachedfiles['paths'], $objAttachedFiles['paths']),
									'names'=>array_merge($attachedfiles['names'], $objAttachedFiles['names']),
									'mimes'=>array_merge($attachedfiles['mimes'], $objAttachedFiles['mimes'])
								);
							}
						}
					}
					elseif (!empty($attachedfilesThirdpartyObj[$thirdparty->id][$objectid])) {
						// Create form object
						// if "one email per recipient" isn't check we must separate $attachedfiles by object
						$attachedfiles = $attachedfilesThirdpartyObj[$thirdparty->id][$objectid];
					}

					$filepath = $attachedfiles['paths'];
					$filename = $attachedfiles['names'];
					$mimetype = $attachedfiles['mimes'];

					// Define the trackid when emails sent from the mass action
					if ($oneemailperrecipient)
					{
					    $trackid = 'thi'.$thirdparty->id;
					    if ($objecttmp->element == 'expensereport') $trackid = 'use'.$thirdparty->id;
					    if ($objecttmp->element == 'holiday') $trackid = 'use'.$thirdparty->id;
					}
					else
					{
					    $trackid = strtolower(get_class($objecttmp));
					    if (get_class($objecttmp) == 'Contrat')  $trackid = 'con';
					    if (get_class($objecttmp) == 'Propal')   $trackid = 'pro';
					    if (get_class($objecttmp) == 'Commande') $trackid = 'ord';
					    if (get_class($objecttmp) == 'Facture')  $trackid = 'inv';
					    if (get_class($objecttmp) == 'Supplier_Proposal')   $trackid = 'spr';
					    if (get_class($objecttmp) == 'CommandeFournisseur') $trackid = 'sor';
					    if (get_class($objecttmp) == 'FactureFournisseur')  $trackid = 'sin';

					    $trackid .= $objecttmp->id;
					}
					//var_dump($filepath);
					//var_dump($trackid);exit;
					//var_dump($subjectreplaced);

					// Send mail (substitutionarray must be done just before this)
                    require_once DOL_DOCUMENT_ROOT.'/core/class/CMailFile.class.php';
                    $mailfile = new CMailFile($subjectreplaced, $sendto, $from, $messagereplaced, $filepath, $mimetype, $filename, $sendtocc, $sendtobcc, $deliveryreceipt, -1, '', '', $trackid);
					if ($mailfile->error)
					{
						$resaction .= '<div class="error">'.$mailfile->error.'</div>';
					}
					else
					{
						$result = $mailfile->sendfile();
						if ($result)
						{
							$resaction .= $langs->trans('MailSuccessfulySent', $mailfile->getValidAddress($from, 2), $mailfile->getValidAddress($sendto, 2)).'<br>'; // Must not contain "

							$error = 0;

							// Insert logs into agenda
                            foreach ($listofqualifiedobj as $objid2 => $objectobj2)
							{
                                if ((!$oneemailperrecipient) && $objid2 != $objectid) continue; // We discard this pass to avoid duplicate with other pass in looparray at higher level

                                dol_syslog("Try to insert email event into agenda for objid=".$objid2." => objectobj=".get_class($objectobj2));

								/*if ($objectclass == 'Propale') $actiontypecode='AC_PROP';
	                            if ($objectclass == 'Commande') $actiontypecode='AC_COM';
	                            if ($objectclass == 'Facture') $actiontypecode='AC_FAC';
	                            if ($objectclass == 'Supplier_Proposal') $actiontypecode='AC_SUP_PRO';
	                            if ($objectclass == 'CommandeFournisseur') $actiontypecode='AC_SUP_ORD';
	                            if ($objectclass == 'FactureFournisseur') $actiontypecode='AC_SUP_INV';*/

								$actionmsg = $langs->transnoentities('MailSentBy').' '.$from.' '.$langs->transnoentities('To').' '.$sendto;
								if ($message)
								{
									if ($sendtocc) $actionmsg = dol_concatdesc($actionmsg, $langs->transnoentities('Bcc').": ".$sendtocc);
                                    $actionmsg = dol_concatdesc($actionmsg, $langs->transnoentities('MailTopic').": ".$subjectreplaced);
									$actionmsg = dol_concatdesc($actionmsg, $langs->transnoentities('TextUsedInTheMessageBody').":");
                                    $actionmsg = dol_concatdesc($actionmsg, $messagereplaced);
								}
								$actionmsg2 = '';

                                // Initialisation donnees
                                $objectobj2->sendtoid = (empty($contactidtosend) ? 0 : $contactidtosend);
                                $objectobj2->actionmsg = $actionmsg; // Long text
                                $objectobj2->actionmsg2		= $actionmsg2; // Short text
                                $objectobj2->fk_element		= $objid2;
                                $objectobj2->elementtype	= $objectobj2->element;

								$triggername = strtoupper(get_class($objectobj2)).'_SENTBYMAIL';
								if ($triggername == 'SOCIETE_SENTBYMAIL')    $triggername = 'COMPANY_SENTBYMAIL';
								if ($triggername == 'CONTRAT_SENTBYMAIL')    $triggername = 'CONTRACT_SENTBYMAIL';
								if ($triggername == 'COMMANDE_SENTBYMAIL')   $triggername = 'ORDER_SENTBYMAIL';
								if ($triggername == 'FACTURE_SENTBYMAIL')    $triggername = 'BILL_SENTBYMAIL';
								if ($triggername == 'EXPEDITION_SENTBYMAIL') $triggername = 'SHIPPING_SENTBYMAIL';
								if ($triggername == 'COMMANDEFOURNISSEUR_SENTBYMAIL') $triggername = 'ORDER_SUPPLIER_SENTBYMAIL';
								if ($triggername == 'FACTUREFOURNISSEUR_SENTBYMAIL') $triggername = 'BILL_SUPPLIER_SENTBYMAIL';
								if ($triggername == 'SUPPLIERPROPOSAL_SENTBYMAIL') $triggername = 'PROPOSAL_SUPPLIER_SENTBYMAIL';

								if (!empty($triggername))
								{
									// Appel des triggers
                                    include_once DOL_DOCUMENT_ROOT."/core/class/interfaces.class.php";
									$interface = new Interfaces($db);
                                    $result = $interface->run_triggers($triggername, $objectobj2, $user, $langs, $conf);
									if ($result < 0) { $error++; $errors = $interface->errors; }
									// Fin appel triggers

									if ($error)
									{
										setEventMessages($db->lasterror(), $errors, 'errors');
										dol_syslog("Error in trigger ".$triggername.' '.$db->lasterror(), LOG_ERR);
									}
								}

								$nbsent++; // Nb of object sent
							}
						}
						else
						{
							$langs->load("other");
							if ($mailfile->error)
							{
								$resaction .= $langs->trans('ErrorFailedToSendMail', $from, $sendto);
								$resaction .= '<br><div class="error">'.$mailfile->error.'</div>';
							}
							else
							{
								$resaction .= '<div class="warning">No mail sent. Feature is disabled by option MAIN_DISABLE_ALL_MAILS</div>';
							}
						}
					}
				}
			}
		}

		$resaction .= ($resaction ? '<br>' : $resaction);
		$resaction .= '<strong>'.$langs->trans("ResultOfMailSending").':</strong><br>'."\n";
		$resaction .= $langs->trans("NbSelected").': '.count($toselect)."\n<br>";
		$resaction .= $langs->trans("NbIgnored").': '.($nbignored ? $nbignored : 0)."\n<br>";
		$resaction .= $langs->trans("NbSent").': '.($nbsent ? $nbsent : 0)."\n<br>";

		if ($nbsent)
		{
			$action = ''; // Do not show form post if there was at least one successfull sent
			//setEventMessages($langs->trans("EMailSentToNRecipients", $nbsent.'/'.count($toselect)), null, 'mesgs');
			setEventMessages($langs->trans("EMailSentForNElements", $nbsent.'/'.count($toselect)), null, 'mesgs');
			setEventMessages($resaction, null, 'mesgs');
		}
		else
		{
			//setEventMessages($langs->trans("EMailSentToNRecipients", 0), null, 'warnings');  // May be object has no generated PDF file
			setEventMessages($resaction, null, 'warnings');
		}

		$action = 'list';
		$massaction = '';
	}
}

if ($massaction == 'archiver')   // Create bills from orders
{
	$orders = GETPOST('toselect', 'array');
	
	$db->begin();

	foreach ($orders as $id_order)
	{
		$cmd = new toit($db);
		if ($cmd->fetch($id_order) <= 0) continue;

		$cmd->status=$cmd::STATUS_ARCHIVE;
		$cmd->date_status_7=dol_now();
		$cmd->{'date_statusencours'} = dol_now(); 
		$error=$cmd->update($user);
	}
	if($error>0){
		$db->commit();
		setEventMessages($langs->trans('Archivage réussi', ''), null, 'mesgs');
	}
	else{
		$db->rollback();
		setEventMessages($langs->trans('Erreurs de mise à jour',''), null, 'erros');
	}
}
