<?php
/* Copyright (C) 2015-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2018	   Nicolas ZABOURI	<info@inovea-conseil.com>
 * Copyright (C) 2018 	   Juanjo Menent  <jmenent@2byte.es>
 * Copyright (C) 2019 	   Ferran Marcet  <fmarcet@2byte.es>
 * Copyright (C) 2019       Frédéric France         <frederic.france@netlogic.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file			htdocs/core/actions_massactions.inc.php
 *  \brief			Code for actions done with massaction button (send by email, merge pdf, delete, ...)
 */


// $massaction must be defined
// $objectclass and $objectlabel must be defined
// $parameters, $object, $action must be defined for the hook.

// $permissiontoread, $permissiontoadd, $permissiontodelete, $permissiontoclose may be defined
// $uploaddir may be defined (example to $conf->projet->dir_output."/";)
// $toselect may be defined
// $diroutputmassaction may be defined


// Protection
if (empty($objectclass) || empty($uploaddir))
{
	dol_print_error(null, 'include of actions_massactions.inc.php is done but var $objectclass or $uploaddir was not defined');
	exit;
}

// For backward compatibility
if (!empty($permtoread) && empty($permissiontoread)) $permissiontoread = $permtoread;
if (!empty($permtocreate) && empty($permissiontoadd)) $permissiontoadd = $permtocreate;
if (!empty($permtodelete) && empty($permissiontodelete)) $permissiontoread = $permtodelete;


// Mass actions. Controls on number of lines checked.
$maxformassaction = (empty($conf->global->MAIN_LIMIT_FOR_MASS_ACTIONS) ? 1000 : $conf->global->MAIN_LIMIT_FOR_MASS_ACTIONS);
if (!empty($massaction) && is_array($toselect) && count($toselect) < 1)
{
	$error++;
	setEventMessages($langs->trans("NoRecordSelected"), null, "warnings");
}


if ($massaction == 'archiver')   // Create bills from orders
{
	$orders = GETPOST('toselect', 'array');
	
	$db->begin();

	foreach ($orders as $id_order)
	{
		$cmd = new dev($db);
		if ($cmd->fetch($id_order) <= 0) continue;

		$cmd->status=$cmd::STATUS_ARCHIVE;
		$cmd->date_status_7=dol_now();
		$cmd->{'date_statusencours'} = dol_now(); 
		$error=$cmd->update($user);
	}
	if($error>0){
		$db->commit();
		setEventMessages($langs->trans('Archivage réussi', ''), null, 'mesgs');
	}
	else{
		$db->rollback();
		setEventMessages($langs->trans('Erreurs de mise à jour',''), null, 'erros');
	}
}
