<?php
/* Copyright (C) 2007-2017 Laurent Destailleur <eldy@users.sourceforge.net>
* Copyright (C) ---Put here your own copyright and developer email---
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * \file rep_list.php
 * \ingroup deviscara
 * \brief List page for rep
 */

//if (! defined('NOREQUIREDB')) define('NOREQUIREDB', '1'); // Do not create database handler $db
//if (! defined('NOREQUIREUSER')) define('NOREQUIREUSER', '1'); // Do not load object $user
//if (! defined('NOREQUIRESOC')) define('NOREQUIRESOC', '1'); // Do not load object $mysoc
//if (! defined('NOREQUIRETRAN')) define('NOREQUIRETRAN', '1'); // Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION')) define('NOSCANGETFORINJECTION', '1'); // Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION')) define('NOSCANPOSTFORINJECTION', '1'); // Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK')) define('NOCSRFCHECK', '1'); // Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL')) define('NOTOKENRENEWAL', '1'); // Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK')) define('NOSTYLECHECK', '1'); // Do not check style html tag into posted data
//if (! defined('NOIPCHECK')) define('NOIPCHECK', '1'); // Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined('NOREQUIREMENU')) define('NOREQUIREMENU', '1'); // If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML')) define('NOREQUIREHTML', '1'); // If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX')) define('NOREQUIREAJAX', '1'); // Do not load ajax.lib.php library
//if (! defined("NOLOGIN")) define("NOLOGIN", '1'); // If this page is public (can be called outside logged session)
//if (! defined("MAIN_LANG_DEFAULT")) define('MAIN_LANG_DEFAULT', 'auto'); // Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule'); // Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN")) define('NOREDIRECTBYMAINTOLOGIN', '1'); // The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("XFRAMEOPTIONS_ALLOWALL")) define('XFRAMEOPTIONS_ALLOWALL', '1'); // Do not add the HTTP header 'X-Frame-Options: SAMEORIGIN' but 'X-Frame-Options: ALLOWALL'

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
    $i--;
    $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT . '/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/company.lib.php';

// load deviscara libraries
require_once __DIR__ . '/class/toit.class.php';
require_once __DIR__ . '/class/toitdefinitif.class.php';
require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';

// for other modules
//dol_include_once('/othermodule/class/otherobject.class.php');

// Load translation files required by the page
$langs->loadLangs(array("deviscara@deviscara", "other"));

$action = GETPOST('action', 'aZ09') ? GETPOST('action', 'aZ09') : 'view'; // The action 'add', 'create', 'edit', 'update', 'view', ...
$massaction = GETPOST('massaction', 'alpha'); // The bulk action (combo box choice into lists)
$show_files = GETPOST('show_files', 'int'); // Show files area generated by bulk actions ?
$confirm = GETPOST('confirm', 'alpha'); // Result of a confirmation
$cancel = GETPOST('cancel', 'alpha'); // We click on a Cancel button
$toselect = GETPOST('toselect', 'array'); // Array of ids of elements selected into a list
$contextpage = GETPOST('contextpage', 'aZ') ? GETPOST('contextpage', 'aZ') : 'toit_list'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha'); // Go back to a dedicated page
$optioncss = GETPOST('optioncss', 'aZ'); // Option for the css output (always '' except when 'print')

$id = GETPOST('id', 'int');

// Load variable for pagination
$limit = GETPOST('limit', 'int') ? GETPOST('limit', 'int') : $conf->liste_limit;
$sortfield = GETPOST('sortfield', 'alpha');
$sortorder = GETPOST('sortorder', 'alpha');
$page = GETPOST('page', 'int');
if (empty($page) || $page == -1 || GETPOST('button_search', 'alpha') || GETPOST('button_removefilter', 'alpha') || (empty($toselect) && $massaction === '0')) {
    $page = 0;
} // If $page is not defined, or '' or -1 or if we click on clear filters or if we select empty mass action
$offset = $limit * $page;
$pageprev = $page - 1;
$pagenext = $page + 1;

// Initialize technical objects
$object = new toit($db);
$extrafields = new ExtraFields($db);
$object_soc = new societe($db);
$extrafields_soc = new ExtraFields($db);
$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
$diroutputmassaction = $conf->deviscara->dir_output . '/temp/massgeneration/' . $user->id;
$hookmanager->initHooks(array('replist')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);
//$extrafields->fetch_name_optionals_label($object->table_element_line);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Default sort order (if not yet defined by previous GETPOST)
if (!$sortfield) $sortfield = "t." . key($object->fields); // Set here default search field. By default 1st field in definition.
if (!$sortorder) $sortorder = "DESC";

// Security check
if (empty($conf->deviscara->enabled)) accessforbidden('Module not enabled');
$socid = 0;
if ($user->socid > 0) // Protection if external user
{
//$socid = $user->socid;
    accessforbidden();
}
//$result = restrictedArea($user, 'deviscara', $id, '');
// Definition of fields for list
$arrayfields = array();
$tab = $object->getFieldSupp();
$object->fields = array_merge($object->fields, $tab);
// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val) {
    if (GETPOST('search_' . $key, 'alpha') !== '') $search[$key] = GETPOST('search_' . $key, 'alpha');
}
//ville
if (GETPOST('search_ville', 'alpha') !== '') $search['ville'] = GETPOST('search_ville', 'alpha');

// List of fields to search into when doing a "search in all"
$fieldstosearchall = array();
foreach ($object->fields as $key => $val) {
    if ($val['searchall']) $fieldstosearchall['t.' . $key] = $val['label'];
}

if ($action == 'confirm_validate') {
    $object->id = $id;
    include DOL_DOCUMENT_ROOT . '/core/actions_fetchobject.inc.php';
    if ($object->status == $object::STATUS_INCOMPLET) {
        $object->setStatut($object::STATUS_RETOURSATRAITER, $object->id);
        $object->setDate('status_' . $object::STATUS_RETOURSATRAITER);
    } elseif ($object->status == $object::STATUS_DRAFT) {
        $object->setStatut($object::STATUS_VALIDATED, $object->id);
        $object->setDate('status_' . $object::STATUS_VALIDATED);
    }

}


foreach ($object->fields as $key => $val) {
// If $val['visible']==0, then we never show the field
    if (!empty($val['visible'])) $arrayfields['t.' . $key] = array('label' => $val['label'], 'checked' => (($val['visible'] < 0) ? 0 : 1), 'enabled' => ($val['enabled'] && ($val['visible'] != 3)), 'position' => $val['position']);
}
// Extra fields
if (is_array($extrafields->attributes[$object->table_element]['label']) && count($extrafields->attributes[$object->table_element]['label']) > 0) {
    foreach ($extrafields->attributes[$object->table_element]['label'] as $key => $val) {
        if (!empty($extrafields->attributes[$object->table_element]['list'][$key])) {
            $arrayfields["ef." . $key] = array(
                'label' => $extrafields->attributes[$object->table_element]['label'][$key],
                'checked' => (($extrafields->attributes[$object->table_element]['list'][$key] < 0) ? 0 : 1),
                'position' => $extrafields->attributes[$object->table_element]['pos'][$key],
                'enabled' => (abs($extrafields->attributes[$object->table_element]['list'][$key]) != 3 && $extrafields->attributes[$object->table_element]['perms'][$key])
            );
        }
    }
}
$object->fields = dol_sort_array($object->fields, 'position');
$arrayfields = dol_sort_array($arrayfields, 'position');

$permissiontoread = $user->rights->deviscara->rep->read;
$permissiontoadd = $user->rights->deviscara->rep->write;
$permissiontodelete = $user->rights->deviscara->rep->delete;

$usergroup = new UserGroup($db);
$tab_group = $usergroup->listGroupsForUser($user->id);
$commercial = false;
if (in_array(1, array_keys($tab_group))) {
    $commercial = true;
}

/*
* Actions
*/

if (GETPOST('cancel', 'alpha')) {
    $action = 'list';
    $massaction = '';
}
if (!GETPOST('confirmmassaction', 'alpha') && $massaction != 'presend' && $massaction != 'confirm_presend') {
    $massaction = '';
}

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook)) {
// Selection of new fields
    include DOL_DOCUMENT_ROOT . '/core/actions_changeselectedfields.inc.php';

// Purge search criteria
    if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')) // All tests are required to be compatible with all browsers
    {
        foreach ($object->fields as $key => $val) {
            $search[$key] = '';
        }
        $toselect = '';
        $search_array_options = array();
    }
    if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')
        || GETPOST('button_search_x', 'alpha') || GETPOST('button_search.x', 'alpha') || GETPOST('button_search', 'alpha')) {
        $massaction = ''; // Protection to avoid mass action if we force a new search during a mass action confirmation
    }

// Mass actions
    $objectclass = 'toit';
    $objectlabel = 'toit';
    $uploaddir = $conf->deviscara->dir_output;
    include DOL_DOCUMENT_ROOT . '/core/actions_massactions.inc.php';
    require_once __DIR__ . '/core/actions_massactions_toit.inc.php';


}


/*
* View
*/

$form = new Form($db);

$now = dol_now();

//$help_url="EN:Module_rep|FR:Module_rep_FR|ES:Módulo_rep";
$help_url = '';
$title = $langs->trans('ListOf', $langs->transnoentitiesnoconv("suivi des BC Toiture"));


// Build and execute select
// --------------------------------------------------------------------
$sql = 'SELECT ';
$sql_fields = ' t.rowid, t.ref,t.label, t.date_creation, t.entity, t.label, t.total_ttc, t.acompte, t.total_tva, t.pencharge, t.total_ht, t.total_racclient,t.total_racedf, t.qty, t.fk_commercial, t.description, t.status, t.commentaire,t.acompte,t.date_statusadmin_encours ';
$sql_fields_soc .= ' , cpv.rowid as ville, concat(COALESCE(s.phone,""),";",COALESCE(s.fax,""),";",COALESCE(s.url,"")) as phone,cpv.cp ,s.address,s.code_compta,s.email';
$sql_fields .= ' ,t.date_statusencours,t.date_status_0,t.date_status_1,t.date_status_2,t.date_status_3,t.date_status_4,t.date_status_5,t.date_status_6,t.date_status_7,t.date_status_9,t.date_statusencours ';
$sql_fields .= ' ,t.status_admin,t.date_statusadmin_0,t.date_statusadmin_1,t.date_statusadmin_2,t.date_statusadmin_3,t.date_statusadmin_4,t.date_statusadmin_5,t.date_statusadmin_6 ';
$sql_fields .= ' ,t.date_statustechique_encours,t.charpentier,t.surfacevendue,t.surfacereel,t.acceschantier,t.rouleaux109pose,t.rouleaux106pose,t.borddemer,t.vdp,t.vdp_montant,t.vcr,t.vcr_montant,t.vfr,t.vfr_montant,t.noavoir,t.noavoir_montant,t.facturelivtole,t.facturelivtole_montant,t.facturecharpentier,t.facturecharpentier_montant,t.ces_nb,t.ces_montant';
$sql_fields .= ' ,t.facturebois,t.facturebois_montant,t.facturelivbois,t.facturelivbois_montant,t.devisgouttieres,t.facgouttieres,t.facgouttieres_montant';
$sql_fields .= ' ,t.array_liste_pieces,t.fk_devisdefinitif,t.commentaire_piecemanquantes,t.status_piecesmanquantes,t.status_conftechnique,t.facturechenaux,t.facturechenaux_montant,t.commentaire_confadmin,t.date_statuspm_encours,t.action_piecesmanquantes,t.date_prevuereceptiondoc,t.date_statusactionpm_encours,t.pm_coursier,t.nofactureedf106,t.status_edf106,t.mode_financement';
$sql_fields .= ' ,t.rouleaux109estime,rouleaux106estime,t.iso106,t.iso109,t.status_general,t.rac_fk_facture,t.status_control,t.status_previsite,t.status_sav';
$sql_fields_edf106 .= ' ,t.noedf106,t.date_edf106,t.nofactureedf106,t.primeedf106_montant,t.primeedf106_montant_recu,t.commentaireedf106,t.status_edf106';
$sql_fields_dateedf106 .= ' ,t.date_statusedf106_1,t.date_statusedf106_2,t.date_statusedf106_3,t.date_statusedf106_4,t.date_statusedf106_4,t.date_statusedf106_6,t.date_statusedf106_7,t.date_statusedf106_8,t.date_statusedf106_9,t.date_statusedf106_10,t.date_statusedf106_encours ';
$sql_fields_edf109 .= ' ,t.noedf109,t.date_edf109,t.nofactureedf109,t.primeedf109_montant,t.primeedf109_montant_recu,t.commentaireedf109,t.status_edf109';
$sql_fields_dateedf109 .= ' ,t.date_statusedf109_1,t.date_statusedf109_2,t.date_statusedf109_3,t.date_statusedf109_4,t.date_statusedf109_4,t.date_statusedf109_6,t.date_statusedf109_7,t.date_statusedf109_8,t.date_statusedf109_9,t.date_statusedf109_10,t.date_statusedf109_encours ';
$sql_fields_mpr .= ' ,t.conf_edf,t.conf_mpr,t.nompr,status_mpr,t.status_cma,date_statusmpr_encours,date_statusmpr_1,date_statusmpr_2,date_statusmpr_3,date_statusmpr_4,date_statusmpr_5,date_statusmpr_6,date_statusmpr_7,date_statusmpr_8,date_statusmpr_9,date_statusmpr_10,date_statusmpr_11,date_statusmpr_12,date_statusmpr_13,consentement,t.date_consentement,t.alerte_consentement,t.mprestime_montant,t.mprrecu_montant,t.mprdelta_montant,t.commentairempr,t.mpraccorde_montant';
$sql_fields_perso .= ' ,t.fk_soc,t.mode_reglement_nb, t.mode_reglement_code,t.status_perso,t.date_statusperso_encours,t.commentaireperso';
$sql_fields_cma .= ' ,t.status_cma,t.date_statuscma_encours,t.commentairecma';
$sql_fields_toitdef .= ' ,toitdef.total_ttc as totalttcdef,toitdef.total_rac as totalracdef, toitdef.fk_facture,toitdef.date_creation as date_devisdef,toitdef.couleur_tole,toitdef.type_tole,toitdef.type_tole2,toitdef.type_charpente,toitdef.charpente_montant,toitdef.chienassis_nb,toitdef.chenaux,toitdef.chenaux_ml,toitdef.chenaux_montant,toitdef.gouttiere,toitdef.ces,toitdef.pv,toitdef.pv_nb,toitdef.devisgouttieres_montant,toitdef.mode_reglement_cmanb,toitdef.cma_report,toitdef.pv_typedepose,toitdef.pv_montant,toitdef.ces_nb,toitdef.ces_montant';
$sql_fields_tiers .= ' ,se.spmo, se.datenaissance,se.emailmpr,se.activationmailmpr,se.cara_type_client,se.status_immo';
$sql_fields_facture .= ' ,fac.datef as date_fk_facture,fac.total_ttc as ttc_fk_facture,fac.total_rac as rac_fk_facture';
$sql_fields_facture_paiement .= ',(select sum(facp.amount) from llx_paiement_facture facp where facp.fk_facture=fac.rowid) as rap_fk_facture ';
$sql_commercial .= ' ,t.com_prct,t.com_comestimee,t.com_comreelle,t.acompte50,t.date_acompte,t.com_paiementacompte,t.nofacacompte,t.com_solde,t.date_solde,t.com_paiementsolde,t.nofacsolde,t.status_comercial,t.com_retenue';
$sql .= $sql_fields . $sql_fields_dateedf106 . $sql_fields_dateedf109 . $sql_fields_edf109 . $sql_fields_mpr . $sql_fields_tiers . $sql_fields_perso . $sql_commercial . $sql_fields_toitdef . $sql_fields_facture . $sql_fields_cma . $sql_fields_edf106 . $sql_fields_facture_paiement . $sql_fields_soc;

// Add fields from extrafields
if (!empty($extrafields->attributes[$object->table_element]['label'])) {
    foreach ($extrafields->attributes[$object->table_element]['label'] as $key => $val) $sql .= ($extrafields->attributes[$object->table_element]['type'][$key] != 'separate' ? "ef." . $key . ' as options_' . $key . ', ' : '');
}
// Add fields from hooks
$parameters = array();
$reshook = $hookmanager->executeHooks('printFieldListSelect', $parameters, $object); // Note that $action and $object may have been modified by hook
$sql .= preg_replace('/^,/', '', $hookmanager->resPrint);
$sql = preg_replace('/,\s*$/', '', $sql);
$sql .= " FROM " . MAIN_DB_PREFIX . $object->table_element . " as t";
$sql .= " left join " . MAIN_DB_PREFIX . "societe s on s.rowid=t.fk_soc";
$sql .= ' left join ' . MAIN_DB_PREFIX . 'societe_extrafields se on fk_object=s.rowid';
$sql .= ' left join ' . MAIN_DB_PREFIX . 'cara_cpville cpv on cpv.rowid=se.ville';
$sql .= ' left join ' . MAIN_DB_PREFIX . 'deviscara_toitdef toitdef on t.fk_devisdefinitif=toitdef.rowid';
$sql .= ' left join ' . MAIN_DB_PREFIX . 'facture fac on toitdef.fk_facture=fac.rowid';

if (is_array($extrafields->attributes[$object->table_element]['label']) && count($extrafields->attributes[$object->table_element]['label'])) $sql .= " LEFT JOIN " . MAIN_DB_PREFIX . $object->table_element . "_extrafields as ef on (t.rowid = ef.fk_object)";
if ($object->ismultientitymanaged == 1) $sql .= " WHERE t.entity IN (" . getEntity($object->element) . ")";
else $sql .= " WHERE 1 = 1";
$sql .= ' and t.status = 4 '; // uniquement les projets qui sont passés en client.
//$sql .= ' and t.status_conftechnique = 5'; // uniquement les projets en DEF à signer.

foreach ($search as $key => $val) {
    if (in_array($search[$key], array('-1', '0', '')))
        continue;
    elseif ($key == 'status' && is_numeric($search[$key]) && $search[$key] >= 0) {
        $sql .= ' and t.status =' . $val;
        continue;
    }
    if ($key == 'label' && $search[$key] == -1) continue;
    if ($key == 'ville' && $search[$key] == -1) continue;
    $mode_search = (($object->isInt($object->fields[$key]) || $object->isFloat($object->fields[$key])) ? 1 : 0);
    if (strpos($object->fields[$key]['type'], 'integer:') === 0) {
        if ($search[$key] == '-1') $search[$key] = '';
        $mode_search = 2;
    }
    if ($key == 'ville' && ($search[$key] != -1 && $search[$key] != '')) {
        $sql .= ' and (cpv.rowid = "' . $search['ville'] . '" )';
        continue;
    }
// filtre pour commerical
    if ($key == 'fk_commercial' && ($search[$key] != -1 && $search[$key] != '')) {
        $sql .= ' and (t.fk_commercial = "' . $search['fk_commercial'] . '" )';
        continue;
    }
    if (in_array($key, array('code_compta')) && ($search[$key] != -1 && $search[$key] != '')) {
        $sql .= ' and (s.' . $key . ' = "' . $search[$key] . '" )';
        continue;
    }
    if (stristr($sql_fields_perso, $key)) {
        $sql .= natural_search('t.' . $key, $search[$key], (($key == 'status') ? 2 : $mode_search));
        continue;
    }
    if (stristr($sql_fields_tiers, $key)) {
        $sql .= natural_search('se.' . $key, $search[$key], (($key == 'status') ? 2 : $mode_search));
        continue;
    }
    if (stristr($sql_fields_toitdef, $key)) {
        if ($key == 'totalracdef') {
            $sql .= natural_search('toitdef.total_rac', $search[$key], (($key == 'status') ? 2 : $mode_search));
        } elseif ($key == 'totalttcdef') {
            $sql .= natural_search('toitdef.total_ttc', $search[$key], (($key == 'status') ? 2 : $mode_search));
        } else
            $sql .= natural_search('toitdef.' . $key, $search[$key], (($key == 'status') ? 2 : $mode_search));
        continue;
    }
    if ($search[$key] != '')
        $sql .= natural_search($key, $search[$key], (($key == 'status') ? 2 : $mode_search));
}
// désactivé le 23/11/2022
if ($commercial == true)
    $sql .= ' and fk_commercial=' . $user->id;

$searchlibvialoupe = GETPOST('search_search_fk_soc');
if ($searchlibvialoupe && ($search['fk_soc'] == "")) {
    $searchlibvialoupe = trim($searchlibvialoupe);
    $sql .= ' and (s.nom like "%' . $searchlibvialoupe . '%" )';
}
if ($search_all) $sql .= natural_search(array_keys($fieldstosearchall), $search_all);
//$sql.= dolSqlDateFilter("t.field", $search_xxxday, $search_xxxmonth, $search_xxxyear);
// Add where from extra fields
include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_list_search_sql.tpl.php';
// Add where from hooks
$parameters = array();
$reshook = $hookmanager->executeHooks('printFieldListWhere', $parameters, $object); // Note that $action and $object may have been modified by hook
$sql .= $hookmanager->resPrint;

$sql .= $db->order($sortfield, $sortorder);
print "<!-- $sql --->";
// Count total nb of records
$nbtotalofrecords = '';
if (empty($conf->global->MAIN_DISABLE_FULL_SCANLIST)) {
    $resql = $db->query($sql);
    $nbtotalofrecords = $db->num_rows($resql);
    if (($page * $limit) > $nbtotalofrecords) // if total of record found is smaller than page * limit, goto and load page 0
    {
        $page = 0;
        $offset = 0;
    }
}
// if total of record found is smaller than limit, no need to do paging and to restart another select with limits set.
if (is_numeric($nbtotalofrecords) && ($limit > $nbtotalofrecords || empty($limit))) {
    $num = $nbtotalofrecords;
} else {
    if ($limit) $sql .= $db->plimit($limit + 1, $offset);

    $resql = $db->query($sql);
    if (!$resql) {
        dol_print_error($db);
        exit;
    }

    $num = $db->num_rows($resql);
}

// Direct jump if only one record found
if ($num == 1 && !empty($conf->global->MAIN_SEARCH_DIRECT_OPEN_IF_ONLY_ONE) && $search_all && !$page) {
    $obj = $db->fetch_object($resql);
    $id = $obj->rowid;
    header("Location: " . dol_buildpath('/deviscara/rep_card.php', 1) . '?id=' . $id);
    exit;
}


// Output page
// --------------------------------------------------------------------

llxHeader('', $title, $help_url);

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
function init_myfunc()
{
jQuery("#myid").removeAttr(\'disabled\');
jQuery("#myid").attr(\'disabled\',\'disabled\');
}
init_myfunc();
jQuery("#mybutton").click(function() {
init_myfunc();
});
});
</script>';

$arrayofselected = is_array($toselect) ? $toselect : array();

$param = '';
if (!empty($contextpage) && $contextpage != $_SERVER["PHP_SELF"]) $param .= '&contextpage=' . urlencode($contextpage);
if ($limit > 0 && $limit != $conf->liste_limit) $param .= '&limit=' . urlencode($limit);
foreach ($search as $key => $val) {
    if (is_array($search[$key]) && count($search[$key])) foreach ($search[$key] as $skey) $param .= '&search_' . $key . '[]=' . urlencode($skey);
    else $param .= '&search_' . $key . '=' . urlencode($search[$key]);
}
if ($optioncss != '') $param .= '&optioncss=' . urlencode($optioncss);
// Add $param from extra fields
include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_list_search_param.tpl.php';

// List of mass actions available
$arrayofmassactions = array(
    'archiver' => $langs->trans("Archiver"),
//'generate_doc'=>$langs->trans("ReGeneratePDF"),
//'builddoc'=>$langs->trans("PDFMerge"),
//'presend'=>$langs->trans("SendByMail"),
);
if ($permissiontodelete) $arrayofmassactions['predelete'] = '<span class="fa fa-trash paddingrightonly"></span>' . $langs->trans("Delete");
if (GETPOST('nomassaction', 'int') || in_array($massaction, array('presend', 'predelete'))) $arrayofmassactions = array();
$massactionbutton = $form->selectMassAction('', $arrayofmassactions);

print '<form method="POST" id="searchFormList" action="' . $_SERVER["PHP_SELF"] . '">' . "\n";
if ($optioncss != '') print '<input type="hidden" name="optioncss" value="' . $optioncss . '">';
print '<input type="hidden" name="token" value="' . newToken() . '">';
print '<input type="hidden" name="formfilteraction" id="formfilteraction" value="list">';
print '<input type="hidden" name="action" value="list">';
print '<input type="hidden" name="sortfield" value="' . $sortfield . '">';
print '<input type="hidden" name="sortorder" value="' . $sortorder . '">';
print '<input type="hidden" name="page" value="' . $page . '">';
print '<input type="hidden" name="contextpage" value="' . $contextpage . '">';

$newcardbutton = dolGetButtonTitle($langs->trans('New'), '', 'fa fa-plus-circle', dol_buildpath('/deviscara/rep_card.php', 1) . '?action=create&backtopage=' . urlencode($_SERVER['PHP_SELF']), '', $permissiontoadd);

print_barre_liste($title, $page, $_SERVER["PHP_SELF"], $param, $sortfield, $sortorder, $massactionbutton, $num, $nbtotalofrecords, 'title_companies', 0, $newcardbutton, '', $limit);

// Add code for pre mass action (confirmation or email presend form)
$topicmail = "SendrepRef";
$modelmail = "rep";
$objecttmp = new toit($db);
$trackid = 'xxxx' . $object->id;
include DOL_DOCUMENT_ROOT . '/core/tpl/massactions_pre.tpl.php';

if ($search_all) {
    foreach ($fieldstosearchall as $key => $val) $fieldstosearchall[$key] = $langs->trans($val);
    print '<div class="divsearchfieldfilter">' . $langs->trans("FilterOnInto", $search_all) . join(', ', $fieldstosearchall) . '</div>';
}

$moreforfilter = '';
/*$moreforfilter.='<div class="divsearchfield">';
$moreforfilter.= $langs->trans('MyFilter') . ': <input type="text" name="search_myfield" value="'.dol_escape_htmltag($search_myfield).'">';
$moreforfilter.= '</div>';*/

$parameters = array();
$reshook = $hookmanager->executeHooks('printFieldPreListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
if (empty($reshook)) $moreforfilter .= $hookmanager->resPrint;
else $moreforfilter = $hookmanager->resPrint;

if (!empty($moreforfilter)) {
    print '<div class="liste_titre liste_titre_bydiv centpercent">';
    print $moreforfilter;
    print '</div>';
}

$varpage = empty($contextpage) ? $_SERVER["PHP_SELF"] : $contextpage;
$selectedfields = $form->multiSelectArrayWithCheckbox('selectedfields', $arrayfields, $varpage); // This also change content of $arrayfields
$selectedfields .= (count($arrayofmassactions) ? $form->showCheckAddButtons('checkforselect', 1) : '');

print '<div class="div-table-responsive">'; // You can use div-table-responsive-no-min if you dont need reserved height for your table
print '<table class="tagtable liste' . ($moreforfilter ? " listwithfilterbefore" : "") . '">' . "\n";


// Fields title search
// --------------------------------------------------------------------
print '<tr class="liste_titre">';
print '<td></td>';
foreach ($object->fields as $key => $val) {
    $cssforfield = (empty($val['css']) ? '' : $val['css']);
    if ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '') . 'center';
    elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'center';
    elseif (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';
    elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $val['label'] != 'TechnicalID') $cssforfield .= ($cssforfield ? ' ' : '') . 'right';
    if (in_array($key, array('fk_soc', 'suivi_financement'))) $cssforfield = ($cssforfield ? ' ' : '') . 'center nowrap';
    if (!empty($arrayfields['t.' . $key]['checked'])) {
        print '<td class="liste_titre' . ($cssforfield ? ' ' . $cssforfield : '') . '">';
        if (is_array($val['arrayofkeyval'])) print $form->selectarray('search_' . $key, $val['arrayofkeyval'], $search[$key], $val['notnull'], 0, 0, '', 1, 0, 0, '', 'maxwidth75');

        elseif (strpos($val['type'], 'integer:') === 0) {
            $out = $object->showInputField($val, $key, $search[$key], '', '', 'search_', 'maxwidth150', 1);
//loupe à côté du champ rechercher
            if ($key == 'fk_soc') {
                $out .= '<button type="submit" class="liste_titre button_search" name="button_search_x" value="x"><span class="fa fa-search"></span></button>';
                $out .= '<button type="submit" class="liste_titre button_removefilter" name="button_removefilter_x" value="x"><span class="fa fa-remove"></span></button>';
            }
            print $out;
        } elseif (!preg_match('/^(date|timestamp)/', $val['type'])) print '<input type="text" class="flat maxwidth75" name="search_' . $key . '" value="' . dol_escape_htmltag($search[$key]) . '">';
        print '</td>';
    }
}
// Extra fields
include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_list_search_input.tpl.php';

// Fields from hook
$parameters = array('arrayfields' => $arrayfields);
$reshook = $hookmanager->executeHooks('printFieldListOption', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;
// Action column
print '<td class="liste_titre maxwidthsearch">';
$searchpicto = $form->showFilterButtons();
print $searchpicto;
print '</td>';
print '</tr>' . "\n";


// Fields title label
// --------------------------------------------------------------------
print '<tr class="liste_titre">';
print '<td>Doc</td>';
foreach ($object->fields as $key => $val) {
    $cssforfield = (empty($val['css']) ? '' : $val['css']);
    if ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '') . 'center';
    elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'center';
    elseif (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';
    elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $val['label'] != 'TechnicalID') $cssforfield .= ($cssforfield ? ' ' : '') . 'right';
    if (!empty($arrayfields['t.' . $key]['checked'])) {
        print getTitleFieldOfList($arrayfields['t.' . $key]['label'], 0, $_SERVER['PHP_SELF'], 't.' . $key, '', $param, ($cssforfield ? 'class="' . $cssforfield . '"' : ''), $sortfield, $sortorder, ($cssforfield ? $cssforfield . ' ' : '')) . "\n";
    }
}
// Extra fields
include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_list_search_title.tpl.php';
// Hook fields
$parameters = array('arrayfields' => $arrayfields, 'param' => $param, 'sortfield' => $sortfield, 'sortorder' => $sortorder);
$reshook = $hookmanager->executeHooks('printFieldListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;
// Action column
print getTitleFieldOfList($selectedfields, 0, $_SERVER["PHP_SELF"], '', '', '', '', $sortfield, $sortorder, 'center maxwidthsearch ') . "\n";
print '</tr>' . "\n";


// Detect if we need a fetch on each output line
$needToFetchEachLine = 0;
if (is_array($extrafields->attributes[$object->table_element]['computed']) && count($extrafields->attributes[$object->table_element]['computed']) > 0) {
    foreach ($extrafields->attributes[$object->table_element]['computed'] as $key => $val) {
        if (preg_match('/\$object/', $val)) $needToFetchEachLine++; // There is at least one compute field that use $object
    }
}


// Loop on record
// --------------------------------------------------------------------
$i = 0;
$totalarray = array();
while ($i < ($limit ? min($num, $limit) : $num)) {
    $obj = $db->fetch_object($resql);
    if (empty($obj)) break; // Should not happen

    // Store properties in $object
    $object->setVarsFromFetchObj($obj);

    // Show here line of result
    print '<tr class="oddeven">';
    print '<td >';
    $url_doc = dol_buildpath("deviscaraiso/card_doc.php", 1);
    $url_docmanquant = dol_buildpath('deviscara/card_docmanquant.php', 1);
    $url_fichecommercial = dol_buildpath('deviscara/card_modifstatuscommercial.php', 1);
    // Ajout d'une variable pour identifier le lien de la zone admin.
    $url_zoneadmin = dol_buildpath('deviscara/toit_card_modifchamps.php', 1);
    $linkdevisdefinitif = $linkfacture = '';
    if ($object->fk_devisdefinitif > 0) {
        $objectdef = new toitdef($db);
        $objectdef->fetch($object->fk_devisdefinitif);
        $url_devisdefinitif = dol_buildpath('/deviscara/toitdef_card.php', 1) . '?id=' . $object->fk_devisdefinitif;
        $linkdevisdefinitif = '<a href="' . $url_devisdefinitif . '">' . $objectdef->ref . '</a>';
    }
    if ($object->fk_facture > 0) {
        $objectfac = new facture($db);
        $objectfac->fetch($object->fk_facture);
        $url_fac = dol_buildpath('/compta/facture/card.php', 1) . '?id=' . $object->fk_facture;
        $linkfacture = '<a href="' . $url_fac . '">' . $objectfac->ref . '</a>';
    }
    $url_modifchamps = dol_buildpath('deviscara/toit_card_modifchamps.php', 1);
    print'<a href="' . $url_doc . '?action=create_documents&fk_soc=' . $object->fk_soc . '&type=1&fk_object=deviscara_rep&fk_objectid=' . $object->id . '"><i class="fas fa-camera"></i></a>';
    print '</td>';
    $dateschgtstatus = $dateschgtstatusadmin = $datesshgtstatusedf106 = $datesshgtstatusedf109 = $datesshgtstatusmpr = '';

    foreach ($object->fields as $key2 => $val2) {
        if (strstr($key2, 'date_status_')) {
            $dateschgtstatus .= '<b>' . $val2['label'] . ' : </b>' . ($object->$key2 > 0 ? dol_print_date($object->$key2, '%d/%m/%Y') : '') . '<br>';
        } elseif (strstr($key2, 'date_statusadmin_')) {
            $dateschgtstatusadmin .= '<b>' . $val2['label'] . ' : </b>' . ($object->$key2 ? dol_print_date($object->$key2, '%d/%m/%Y') : '') . '<br>';
        } elseif (strstr($key2, 'date_statusedf106_')) {
            $datesshgtstatusedf106 .= '<b>' . $val2['label'] . ' : </b>' . ($object->$key2 ? dol_print_date($object->$key2, '%d/%m/%Y') : '') . '<br>';
        } elseif (strstr($key2, 'date_statusedf109_')) {
            $datesshgtstatusedf109 .= '<b>' . $val2['label'] . ' : </b>' . ($object->$key2 ? dol_print_date($object->$key2, '%d/%m/%Y') : '') . '<br>';
        } elseif (strstr($key2, 'date_statusmpr_')) {
            $datesshgtstatusmpr .= '<b>' . $val2['label'] . ' : </b>' . ($object->$key2 ? dol_print_date($object->$key2, '%d/%m/%Y') : '') . '<br>';
        } elseif (strstr($key2, 'date_statuscma_')) {
            $datesshgtstatuscma .= '<b>' . $val2['label'] . ' : </b>' . ($object->$key2 ? dol_print_date($object->$key2, '%d/%m/%Y') : '') . '<br>';
        }
    }
    $array_liste_pieces = explode('|', $obj->array_liste_pieces);
    $docsmanquants = '';
    foreach ($array_liste_pieces as $pieces) {
        $docsmanquants .= $object::groupe_famille['Documents A récuperer'][$pieces] . '<br>';
    }
    foreach ($object->fields as $key => $val) {
        $cssforfield = (empty($val['css']) ? '' : $val['css']);
        if (in_array($val['type'], array('date', 'datetime', 'timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'center';
        elseif ($key == 'status') $cssforfield .= ($cssforfield ? ' ' : '') . 'center';

        if (in_array($val['type'], array('timestamp'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';
        elseif ($key == 'ref') $cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';

        if (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $key != 'status') $cssforfield .= ($cssforfield ? ' ' : '') . 'right';
        if (in_array($key, array('planification', 'ville', 'phone', 'status'))) $cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';
        if (!empty($arrayfields['t.' . $key]['checked'])) {
            print '<td' . ($cssforfield ? ' class="' . $cssforfield . '"' : '') . '>';
            if ($key == 'status') {
                $out = '<a title="<div class=\'centpercent\'>
<b><u>Dates Modification status</u></b><br>' . $dateschgtstatus;
                $out .= '<br></div>" class="classfortooltip refurl">*';
                if ($object->status == $object::STATUS_DRAFT || $object->status == $object::STATUS_ACOMPLETER)
                    $out .= '<a href=' . $url_fichecommercial . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '>' . $object->getLibStatut(5) . '</a>';
                elseif ($object->status == $object::STATUS_ACOMPLETER) {
                    $out .= '<a href=' . $_SERVER['PHP_SELF'] . '?id=' . $object->id . '&action=confirm_validate&confirm=yes">' . $object->getLibStatut(5) . '</a>';
                } else
                    $out .= $object->getLibStatut(5);

                print $out;
            } elseif ($key == 'date_statusedf106_encours') {
                $out = '<a title="<div class=\'centpercent\'>
<b><u>Dates Modification status EDF 106</u></b><br>' . $datesshgtstatusedf106;
                $out .= '<br></div>" class="classfortooltip refurl">';
                $out .= $object->showOutputField($val, $key, $object->$key, '');

                print $out;
            } elseif ($key == 'date_statusedf109_encours') {
                $out = '<a title="<div class=\'centpercent\'>
<b><u>Dates Modification status EDF 109</u></b><br>' . $datesshgtstatusedf109;
                $out .= '<br></div>" class="classfortooltip refurl">';
                $out .= $object->showOutputField($val, $key, $object->$key, '');

                print $out;
            } elseif ($key == 'date_statusmpr_encours') {
                $out = '<a title="<div class=\'centpercent\'><b><u>Dates Modification status MPR</u></b><br>' . $datesshgtstatusmpr . '<br></div>" class="classfortooltip refurl">';
                $out .= $object->showOutputField($val, $key, $object->$key, '');

                print $out;
            } elseif ($key == 'status_admin') {
                $out = '<a title="<div class=\'centpercent\'><b><u>Dates Modification status</u></b><br>' . $dateschgtstatusadmin . '<br></div>" class="classfortooltip refurl">*';
                $out .= $object->getLibStatutAdmin(5);
                print $out;
            } elseif ($key == 'date_statuscma_encours') {
                $out = '<a title="<div class=\'centpercent\'><b><u>Dates Modification status</u></b><br>' . $datesshgtstatuscma . '<br></div>" class="classfortooltip refurl">*';
                $out .= $object->showOutputField($val, $key, $object->$key, '');
                print $out;
            } elseif ($key == 'fk_devisdefinitif') {
                print $linkdevisdefinitif;
            } elseif ($key == 'fk_facture') {
                print $linkfacture;
            } elseif ($key == 'array_liste_pieces') {

                $out = '<a href="' . $url_docmanquant . '?fk_object=' . $object->id . '&object_type=' . $object->label . '&object_ref=' . $object->ref . '" >MODIDIER</a><br>';
                $out .= $docsmanquants;
                print $out;
            } // Commentaire Commercial
            elseif ($key == 'commentaire') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_fichecommercial . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire Conf-A
            elseif ($key == 'commentaire_confadmin') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire EDF-106
            elseif ($key == 'commentaireedf106') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire EDF-109
            elseif ($key == 'commentaireedf109') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire MPR
            elseif ($key == 'commentairempr') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire PERSO
            elseif ($key == 'commentaireperso') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire RECOUVREMENT
            elseif ($key == 'commentairerecouvrement') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire CMA
            elseif ($key == 'commentairecma') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } // Commentaire COMMERCIAL
            elseif ($key == 'commentairecommission') {
                if ($object->$key != '') $message = '...';
                else $message = '';
                print '<a href="' . $url_zoneadmin . '?id=' . $object->id . '&object_ref=' . $object->ref . '&backtopage=' . urlencode($_SERVER['PHP_SELF']) . '" title="<div class=\'centpercent\'>' . $object->showOutputField($val, $key, $object->$key, '') . '<br></div>" class="classfortooltip refurl"><i class="fas fa-comment"></i>' . $message . '</a>';
            } elseif ($key == 'ref') {
                $url = dol_buildpath('deviscara/toit_card.php', 1) . '?id=' . $object->id;
                print '<a href="' . $url . '" >' . $object->showOutputField($val, $key, $object->$key, '') . '</a>';
            } elseif ($key == 'code_compta') {
                $url = $url_modifchamps . '?id=' . $object->id;
                print '<a href="' . $url . '" >' . $object->showOutputField($val, $key, $object->$key, '') . '</a>';
            } elseif ($key == 'phone') {
                $tab_phone = explode(';', $object->$key);
                foreach ($tab_phone as $phone) {
                    $tel = preg_replace('/(\d{4})(\d{2})(\d{2})(\d{2})/', '\1 \2 \3 \4', $phone);
                    if ($tel)
                        print $tel . '<br>';
                }
            } elseif (in_array($key, array("spmo", 'cara_type_client'))) {
                print $extrafields_soc->showOutputField($key, $object->$key, '', 'societe');
            } elseif ($key == 'rap_fk_facture') {
                if ($object->ttc_fk_facture > 0) {
                    $val = $object->ttc_fk_facture - $object->rap_fk_facture;
                    print number_format($val, 2, ',', ' ');
                }
            } elseif (is_numeric($object->$key) && in_array($val['type'], array('double(24,8)', 'double(6,3)', 'real', 'price'))) {
                print number_format($object->$key, 2, ',', ' ');
            } else
                print $object->showOutputField($val, $key, $object->$key, '');

            print '</td>';
            if (!$i) $totalarray['nbfield']++;
            if (!empty($val['isameasure'])) {
                if (!$i) $totalarray['pos'][$totalarray['nbfield']] = 't.' . $key;
                $totalarray['val']['t.' . $key] += $object->$key;
            }
        }
    }
// Extra fields
    include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_list_print_fields.tpl.php';
// Fields from hook
    $parameters = array('arrayfields' => $arrayfields, 'object' => $object, 'obj' => $obj, 'i' => $i, 'totalarray' => &$totalarray);
    $reshook = $hookmanager->executeHooks('printFieldListValue', $parameters, $object); // Note that $action and $object may have been modified by hook
    print $hookmanager->resPrint;
// Action column
    print '<td class="nowrap center">';
    if ($massactionbutton || $massaction) // If we are in select mode (massactionbutton defined) or if we have already selected and sent an action ($massaction) defined
    {
        $selected = 0;
        if (in_array($object->id, $arrayofselected)) $selected = 1;
        print '<input id="cb' . $object->id . '" class="flat checkforselect" type="checkbox" name="toselect[]" value="' . $object->id . '"' . ($selected ? ' checked="checked"' : '') . '>';
    }
    print '</td>';
    if (!$i) $totalarray['nbfield']++;

    print '</tr>' . "\n";

    $i++;
}

// Show total line
include DOL_DOCUMENT_ROOT . dol_buildpath('/deviscara/core/tpl/list_print_total.tpl.php', 1);

// If no record found
if ($num == 0) {
    $colspan = 1;
    foreach ($arrayfields as $key => $val) {
        if (!empty($val['checked'])) $colspan++;
    }
    print '<tr><td colspan="' . $colspan . '" class="opacitymedium">' . $langs->trans("NoRecordFound") . '</td></tr>';
}


$db->free($resql);

$parameters = array('arrayfields' => $arrayfields, 'sql' => $sql);
$reshook = $hookmanager->executeHooks('printFieldListFooter', $parameters, $object); // Note that $action and $object may have been modified by hook
print $hookmanager->resPrint;

print '</table>' . "\n";
print '</div>' . "\n";

print '</form>' . "\n";

if (in_array('builddoc', $arrayofmassactions) && ($nbtotalofrecords === '' || $nbtotalofrecords)) {
    $hidegeneratedfilelistifempty = 1;
    if ($massaction == 'builddoc' || $action == 'remove_file' || $show_files) $hidegeneratedfilelistifempty = 0;

    require_once DOL_DOCUMENT_ROOT . '/core/class/html.formfile.class.php';
    $formfile = new FormFile($db);

// Show list of available documents
    $urlsource = $_SERVER['PHP_SELF'] . '?sortfield=' . $sortfield . '&sortorder=' . $sortorder;
    $urlsource .= str_replace('&amp;', '&', $param);

    $filedir = $diroutputmassaction;
    $genallowed = $permissiontoread;
    $delallowed = $permissiontoadd;

    print $formfile->showdocuments('massfilesarea_deviscara', '', $filedir, $urlsource, 0, $delallowed, '', 1, 1, 0, 48, 1, $param, $title, '', '', '', null, $hidegeneratedfilelistifempty);
}

// End of page
llxFooter();
$db->close();
