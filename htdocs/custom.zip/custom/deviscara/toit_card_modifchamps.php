<?php
/* Copyright (C) 2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       iso1_card.php
 *		\ingroup    deviscara
 *		\brief      Page to create/edit/view rep
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB','1');					// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER','1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC','1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN','1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION','1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION','1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK','1');					// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL','1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK','1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU','1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML','1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX','1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN",'1');						// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK','1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT','auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE','aloginmodule');		// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN',1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP','none');					// Disable all Content Security Policies

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/deviscara/class/toit.class.php');
dol_include_once('/deviscara/lib/deviscara_toit.lib.php');
dol_include_once('/product/class/product.class.php');
dol_include_once('/deviscara/class/toitdefinitif.class.php');

// Load translation files required by the page
$langs->loadLangs(array("deviscara@deviscara", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'toitcard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
$lineid   = GETPOST('lineid', 'int');
$socid   = GETPOST('socid', 'int');

// Initialize technical objects

$object = new toit($db);
$extrafields = new ExtraFields($db);
$object_soc=new societe($db);

$extrafields_soc = new ExtraFields($db);
$extrafields_soc->fetch_name_optionals_label($object_soc->table_element);
$diroutputmassaction = $conf->deviscara->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('toitcard', 'globalcard','devcard')); // Note that conf->hooks_modules contains array

// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

$search_array_options = $extrafields->getOptionalsFromPost($object->table_element, '', 'search_');

// Initialize array of search criterias
$search_all = trim(GETPOST("search_all", 'alpha'));
$search = array();
foreach ($object->fields as $key => $val)
{
	if (GETPOST('search_'.$key, 'alpha')) $search[$key] = GETPOST('search_'.$key, 'alpha');
}

if (empty($action) && empty($id) && empty($ref)) $action = 'view';

// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.
$object_soc->fetch($object->fk_soc);
// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->statut == $object::STATUS_DRAFT) ? 1 : 0);
//$result = restrictedArea($user, 'deviscara', $object->id, '', '', 'fk_soc', 'rowid', $isdraft);

$permissiontoread = $user->rights->deviscara->rep->read;
$permissiontoadd = $user->rights->deviscara->rep->write; // Used by the include of actions_addupdatedelete.inc.php and actions_lineupdown.inc.php
$permissiontodelete = $user->rights->deviscara->rep->delete || ($permissiontoadd && isset($object->status) && $object->status == $object::STATUS_DRAFT);
$permissionnote = $user->rights->deviscara->rep->write; // Used by the include of actions_setnotes.inc.php
$permissiondellink = $user->rights->deviscara->rep->write; // Used by the include of actions_dellink.inc.php
$upload_dir = $conf->deviscara->multidir_output[isset($object->entity) ? $object->entity : 1];


/*
 * Actions
 */

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

if (empty($reshook))
{
    $error = 0;

    $backurlforlist = dol_buildpath('/deviscara/toit_list.php', 1);

    // Actions cancel, add, update, update_extras, confirm_validate, confirm_delete, confirm_deleteline, confirm_clone, confirm_close, confirm_setdraft, confirm_reopen
	include DOL_DOCUMENT_ROOT.dol_buildpath('deviscara/core/actions_addupdatedeletetoit_champs.inc.php',1);
    
  

}
//include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.



/*
 * View
 *
 * Put here all code to build page
 */

$form = new Form($db);
$formfile = new FormFile($db);

llxHeader('', $langs->trans('Modification champs Toiture'), '');

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_myfunc();
	});
});

</script>';




$url_docmanquant=dol_buildpath('deviscara/card_docmanquant.php',1);
// Part to edit record

print load_fiche_titre($langs->trans("Devis Toiture"));

print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="update">';
print '<input type="hidden" name="id" value="'.$object->id.'">';
if ($backtopage) print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
if ($backtopageforcancel) print '<input type="hidden" name="backtopageforcancel" value="'.$backtopageforcancel.'">';

dol_fiche_head();
print '<table class="border centpercent tableforfieldedit">' . "\n";
// Etat du dossier.
print'<tr><td colspan=10 bgcolor="#D3D3D3">Etat du dossier</td></tr>';
$lst = array(1 => array('status_general',),
);
foreach ($lst as $zeline) {
    print'<tr>';
    foreach ($zeline as $zeitem) {
        print'<td >' . $object->fields[$zeitem]['label'] . ' : </td><td>' . $object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0, 'maxwidth5') . '</td>';
    }
    print '</tr>';
}
print'<tr><td colspan=10 bgcolor="#FFBE33">Zone TIERS</td></tr>';
print'<tr>
		<td >Fiche Tiers : </td><td>'.$object->showOutputField($object->fields['fk_soc'], 'fk_soc', $object->fk_soc, '', '', '', 0,'maxwidth5').'</td>
		</tr>';

print'<tr><td colspan=10 bgcolor="#FFF033">Zone ADMIN</td></tr>';
$lst=array( 1=>array('status_admin','status_piecesmanquantes'),
2=>array('conf_edf','conf_mpr'),
3=>array('commentaire_confadmin'),
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}
print'<tr><td><a href="'.$url_docmanquant.'?fk_object='.$object->id.'&object_type='.$object->label.'&object_ref='.$object->ref.'&backtopage=gestionchamp" >Fiche Doc manquant</a><br></td></tr>';


print'<tr><td colspan=10 bgcolor="#33FF36">Zone CONF-T</td></tr>';
$lst=array( 1=>array('status_conftechnique','charpentier','acceschantier','rouleaux109pose'),
			2=>array('rouleaux106pose','borddemer'),3=>array('vdp','vdp_montant'),4=>array('vcr','vcr_montant'),5=>array('vfr','vfr_montant'),
			6=>array('noavoir','noavoir_montant'),
			7=>array('facturelivtole','facturelivtole_montant','facturecharpentier','facturecharpentier_montant'),
			8=>array('charpente_exist'),
			9=>array('facturebois','facturebois_montant','facturelivbois','facturelivbois_montant'),
			10=>array('facturechenaux','facturechenaux_montant'),
            14=>array('facgouttieres','facgouttieres_montant'),
			11=>array('devisgouttieres','devisgouttieres_montant','facgouttieres','facgouttieres_montant'),
			11=>array('ces_nb','ces_montant','ces_facdeposeces'),
			12=>array('pv_facturedepose','pv_facturedeposemontant'),
			13=>array('commentaire_conftech'),
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap" >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}
print'<tr><td colspan=10 bgcolor="#A498A2">Zone CONTROL-T</td></tr>';
$lst=array( 1=>array('status_control','fk_user_control','date_rdvcontrol',),
			2=>array('commentaire_control'),
			
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap" >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}
print'<tr><td colspan=10 bgcolor="#B631BC">Zone EDF</td></tr>';

$lst=array( 1=>array('status_edf106','status_edf109'),
			2=>array('noedf106','noedf109'),3=>array('nofactureedf106','nofactureedf109'),
			4=>array('primeedf106_montant_recu','primeedf109_montant_recu'),
			5=>array('commentaireedf106','commentaireedf109'),
			
		);
$lstreadonly=array('primeedf106_montant_recu','primeedf109_montant_recu');
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		if (in_array($zeitem,$lstreadonly)) $readonly='readonly'; else $readonly='';
		print'<td class="nowrap">'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, $readonly, '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
	
}
print'<tr>
		<td >Tiers EDF : </td><td>'.$extrafields_soc->showInputField('tiersedf', $object_soc->array_options['options_tiersedf'], '', '', '', 0, $object_soc->id, 'societe').'</td>';
print '</tr>';
print'<tr><td colspan=10 bgcolor="#E5AC63">Zone MPR</td></tr>';

$lst=array( 1=>array('status_mpr','consentement'),
			2=>array('nompr','date_consentement','alerte_consentement'),
			3=>array('mprestime_montant'),
			4=>array('mpraccorde_montant'),
			5=>array('mprrecu_montant','commentairempr'),
		);
$lstreadonly=array('mprrecu_montant');
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		if (in_array($zeitem,$lstreadonly)) $readonly='readonly'; else $readonly='';
		print'<td class="nowrap">'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, $readonly, '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}
print'<tr>
		<td >Email MPR: </td><td>'.$extrafields_soc->showInputField('emailmpr', $object_soc->array_options['options_emailmpr'], '', '', '', 0, $object_soc->id, 'societe').'</td>
		<td >Activation Email MPR : </td><td>'.$extrafields_soc->showInputField('activationmailmpr', $object_soc->array_options['options_activationmailmpr'], '', '', '', 0, $object_soc->id, 'societe').'</td>
		<td >Adresse TF : </td><td>'.$extrafields_soc->showInputField('adressetf', $object_soc->array_options['options_adressetf'], '', '', '', 0, $object_soc->id, 'societe').'</td>';
print '</tr>';
print'<tr>
		<td >Tiers MPR : </td><td>'.$extrafields_soc->showInputField('tiersmpr', $object_soc->array_options['options_tiersmpr'], '', '', '', 0, $object_soc->id, 'societe').'</td>';
print '</tr>';

print'<tr><td colspan=10 bgcolor="#35CD3C">Zone PERSO</td></tr>';
$lst=array( 1=>array('status_perso'),
			4=>array('commentaireperso'),
			5=>array('relance_recouvrement','status_recouvrement','commentairerecouvrement')
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap">'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}

print'<tr><td colspan=10 bgcolor="#0F6913">Zone CMA</td></tr>';
$lst=array( 1=>array('status_cma'),4=>array('commentairecma'),
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap" >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}
// Zone Commercialle
print'<tr><td colspan=10 bgcolor="#0B92C4">Zone COMMERCIAL</td></tr>';
$lst=array( 0 =>array('status'),
	1=>array('com_comestimee','com_comreelle','acompte50','date_acompte'),
	4=>array('nofacacompte','com_solde','date_solde','nofacsolde','com_paiementsolde'),
	5 => array('com_retenue', 'status_comercial'),
    6 => array('commentairecommission'));
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap" >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}
print'<tr><td colspan=10 bgcolor="#FF336E">Zone PREVI-T</td></tr>';
$lst=array( 1=>array('status_previsite','date_rdvprevisite'),
			2=>array('fk_user_previsite','commentaire_previsite')
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap" >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}

print'<tr><td colspan=10 bgcolor="#C40BB3">Zone SAV</td></tr>';
$lst=array( 1=>array('status_sav','date_rdvsav,','fk_user_sav','relance Sav'),4=>array('commentaire_sav'),
		);
foreach($lst as $zeline){
	print'<tr>';
	foreach($zeline as $zeitem){
		print'<td class="nowrap" >'.$object->fields[$zeitem]['label'].' : </td><td>'.$object->showInputField($object->fields[$zeitem], $zeitem, $object->$zeitem, '', '', '', 0,'maxwidth5').'</td>';
	}
	print '</tr>';
}

//
print '</table>';
dol_fiche_end();

print '<div class="center"><input type="submit" class="button" name="save" value="'.$langs->trans("Save").'">';
print '   <input type="submit" class="button" name="cancel" value="'.$langs->trans("Cancel").'">';
print '</div>';

print '</form>';


// End of page
llxFooter();
$db->close();