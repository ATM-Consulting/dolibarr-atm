<?php
// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
    $i--;
    $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

$script_file = basename(__FILE__);
$path = __DIR__ . '/';

require_once $path . "../../master.inc.php";

global $conf, $object;

// Vérifiez que la requête est de type POST et qu'elle contient des données

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dataUrl'])) {
    $dataUrl = $_POST['dataUrl'];
    $data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $dataUrl));
    // Spécifiez le chemin et le nom du fichier où l'image sera sauvegardée
    $dir = $conf->deviscara->multidir_output[$conf->entity] . "/temp";
    $objref = dol_sanitizeFileName($object->ref);
    $file = "_courbe.png";
    $fileName = "_courbe.png";
    $filePath = $dir . '/' . $fileName;

    // Assurez-vous que le répertoire est accessible en écriture
    if (!is_writable($dir)) {
        http_response_code(500);
        echo 'Erreur : le répertoire ' . $dir . ' n\'est pas accessible en écriture.';
        exit;
    }

    // Sauvegardez l'image sur le serveur
    if (file_put_contents($filePath, $data)) {
        http_response_code(200);
        echo 'Image sauvegardée avec succès.';
    } else {
        http_response_code(500);
        echo 'Erreur lors de la sauvegarde de l\'image.';
    }
} else {
    http_response_code(400);
    echo 'Requête invalide.';
}
?>
