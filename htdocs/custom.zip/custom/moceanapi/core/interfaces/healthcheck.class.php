<?php

interface IHealthcheck {

	public function healthcheck();
}
