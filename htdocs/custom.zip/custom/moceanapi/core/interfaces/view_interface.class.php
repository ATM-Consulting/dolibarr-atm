<?php


interface ViewInterface {

	public function render();
}
