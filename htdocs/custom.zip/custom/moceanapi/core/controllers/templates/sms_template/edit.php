<?php

extract($template_variables);

?>

<div style="display:flex;gap:20px;">
	<h2>Edit SMS Template</h2>
	<!-- <a href="<?php echo $_SERVER['PHP_SELF'] . "?action=create_sms_template"; ?>" style="margin:20px;">
		<button type="button" id="add_sms_templates">Add New</button>
	</a> -->
</div>

<form method="POST" action="<?php echo $_SERVER["PHP_SELF"] ?>">
	<input type="hidden" name="token" value="<?php echo newToken(); ?>">
	<input type="hidden" name="action" value="<?php echo "save_sms_template" ?>">
	<input type="hidden" name="sms_template_id" value="<?php echo $sms_template['id'] ?>">

	<table class="border mocean-table">
		<!-- SMS Template Title -->

		<tr>
			<td width="200px"><?php echo $langs->trans("moceanapi_sms_template_title") ?></td>
			<td>
				<input type="text" name="sms_template_title" value="<?php echo $sms_template['title']; ?>">
			</td>
		</tr>

		<!-- SMS Template message -->

		<tr>
			<td width="200px"><?php echo $langs->trans("moceanapi_sms_template_message") ?></td>
				<td>
					<label for="sms_template_message">
						<textarea id="sms_template_message" name="sms_template_message" cols="40" rows="4"><?php echo $sms_template['message']; ?></textarea>
					</label>
					<p>Customize your SMS with keywords
						<button type="button" class="moceanapi_open_keyword" data-attr-target="sms_template_message">
							Keywords
						</button>
					</p>
				</td>
		</tr>
	</table>
	<!-- Submit -->
	<center>
		<input class="button" type="submit" name="submit" value="<?php echo $langs->trans("moceanapi_sms_template_save") ?>">
	</center>
</form>
