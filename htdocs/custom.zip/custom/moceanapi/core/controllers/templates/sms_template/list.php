<?php

// $first_page = $template_variables['first_page'];
// $last_page = $template_variables['last_page'];
// $previous_page = $template_variables['previous_page'];
// $next_page = $template_variables['next_page'];
// $start_page = $template_variables['start_page'];
// $end_page = $template_variables['end_page'];
// $current_page = $template_variables['current_page'];
// $pageno = $template_variables['pageno'];
// $sms_templates_list = $template_variables['sms_templates_list'];
extract($template_variables);
?>

<div style="display:flex;gap:20px;">
	<h2>SMS Template</h2>
	<a href="<?php echo $_SERVER['PHP_SELF'] . "?action=create_sms_template"; ?>" style="margin:20px;">
		<button type="button" id="add_sms_templates">Add New</button>
	</a>
</div>

<!-- List SMS Template -->

<div class="bootstrap-wrapper">
	<nav aria-label="Page navigation example">
		<ul class="pagination">
			<li class="page-item"><a class="page-link" href="<?php echo $_SERVER['PHP_SELF'].'?pageno='.$first_page ?>">First</a></li>
			<li class="page-item"><a class="page-link" href="<?php echo $_SERVER['PHP_SELF'].'?pageno='.$previous_page ?>">Previous</a></li>
			<?php for($i=$start_page; $i<=$end_page; $i++) { ?>
				<li class="page-item"><a class="page-link" href="<?php echo $_SERVER['PHP_SELF'].'?pageno='.$i ?>"><?php echo $i; ?></a></li>
			<?php } ?>
			<li class="page-item"><a class="page-link" href="<?php echo $_SERVER['PHP_SELF'].'?pageno='.$next_page ?>">Next</a></li>
			<li class="page-item"><a class="page-link" href="<?php echo $_SERVER['PHP_SELF'].'?pageno='.$last_page ?>">Last</a></li>
		</ul>
	</nav>
</div>

<span>Page : <?php echo $current_page; ?></span>

<table id="sms-template-table" class="sms-generic-table">
	<tr>
		<th>Title</th>
		<th>Message</th>
		<th>Action</th>
	</tr>

	<?php foreach ($sms_templates_list as $sms_template) { ?>
		<tr>
			<td><?php echo $sms_template['title'] ?></td>
			<td><?php echo $sms_template['message'] ?></td>
			<td>
				<a href="<?php echo $_SERVER['PHP_SELF'] . "?action=edit_sms_template&sms_template_id={$sms_template['id']}"; ?>">Edit</a>
				<a onclick="deleteSMSTemplate('<?php echo $sms_template['id'] ?>')" href="#">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
