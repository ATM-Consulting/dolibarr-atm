<?php
dol_include_once("/moceanapi/core/helpers/helpers.php");
dol_include_once("/moceanapi/core/class/moceanapi_logger.class.php");
dol_include_once("/moceanapi/core/controllers/contact.class.php");
dol_include_once("/moceanapi/core/controllers/settings/mocean.controller.setting.php");
dol_include_once("/moceanapi/core/controllers/settings/third_party.setting.php");
dol_include_once("/moceanapi/core/controllers/settings/contact.setting.php");
dol_include_once("/moceanapi/core/controllers/settings/sms_template.setting.php");

class SMS_SendSMS_Setting extends MoceanBaseSettingController
{

	private $form;
	private $errors;
	private $log;
	private $page_name;
	private $db;
	private $context;
	private $thirdparty;

	function __construct($db)
	{
		$this->form = new Form($db);
		$this->log = new MoceanAPI_Logger();
		$this->errors = array();
		$this->context = 'send_sms';
		$this->page_name = 'send_sms_page_title';
		$this->thirdparty = new Societe($db);
	}

	public function validate_sms_form($data)
	{
		$error = false;
		if( empty($data['sms_from'])) {
			$this->add_error("Sender field is required");
			$error = true;
		}
		if( empty($data['sms_message']) )
		{
			$this->add_error("Message is required");
			$error = true;
		}

		return $error;
	}

	public function handle_send_sms_form()
	{
		global $db, $user;

		if(!empty($_POST) && !empty($_POST['action'])) {

			if ( !$user->rights->moceanapi->permission->write ) {
				accessforbidden();
			}

			$action=GETPOST('action');
			if($action == 'send_sms') {

				$sms_from       				= GETPOST("sms_from");
				$sms_contact_ids 				= GETPOST("sms_contact_ids");
				$sms_thirdparty_id 				= GETPOST("sms_thirdparty_id");
				$send_sms_to_thirdparty_flag	= GETPOST("send_sms_to_thirdparty_flag") == "on" ? true : false;
				$sms_message    				= GETPOST('sms_message');

				$post_data = array();
				$post_data['sms_contact_ids']				= $sms_contact_ids;
				$post_data['sms_thirdparty_id']				= $sms_thirdparty_id;
				$post_data['send_sms_to_thirdparty_flag']	= $send_sms_to_thirdparty_flag;
				$post_data['sms_from']						= $sms_from;
				$post_data['sms_message']					= $sms_message;

				$error = $this->validate_sms_form($post_data);

				if($error) {
					return;
				}

				$total_sms_responses = array();

				if(!empty($sms_thirdparty_id)) {
					if(empty($sms_contact_ids)) {
						$tp_obj = new ThirdPartyController($sms_thirdparty_id);
						$tp_phone_no = $tp_obj->get_thirdparty_mobile_number();

						$tp_setting_obj = new SMS_ThirdParty_Setting($db);
						$dol_tp_obj = new Societe($db);
						$dol_tp_obj->fetch($sms_thirdparty_id);

						$message = $tp_setting_obj->replace_keywords_with_value($dol_tp_obj, $sms_message);
						$total_sms_responses[] = moceanapi_send_sms($sms_from, $tp_phone_no, $message, "Send SMS");
					}
					else if(!empty($sms_contact_ids) && $send_sms_to_thirdparty_flag) {
						$tp_obj = new ThirdPartyController($sms_thirdparty_id);
						$tp_phone_no = $tp_obj->get_thirdparty_mobile_number();

						$tp_setting_obj = new SMS_ThirdParty_Setting($db);
						$dol_tp_obj = new Societe($db);
						$dol_tp_obj->fetch($sms_thirdparty_id);

						$message = $tp_setting_obj->replace_keywords_with_value($dol_tp_obj, $sms_message);
						$total_sms_responses[] = moceanapi_send_sms($sms_from, $tp_phone_no, $message, "Send SMS");
					}
				}

				if(isset($sms_contact_ids) && !empty($sms_contact_ids)) {
					foreach($sms_contact_ids as $sms_contact_id) {
						$contact = new ContactController($sms_contact_id);
						$sms_to = $contact->get_contact_mobile_number($sms_contact_id);

						$contact_setting_obj = new SMS_Contact_Setting($db);
						$dol_contact_obj = new Contact($db);
						$dol_contact_obj->fetch($sms_contact_id);

						$message = $contact_setting_obj->replace_keywords_with_value($dol_contact_obj, $sms_message);
						$total_sms_responses[] = moceanapi_send_sms($sms_from, $sms_to, $message, "Send SMS");
					}
				}
				$success_sms = 0;
				$total_sms = count($total_sms_responses);
				foreach($total_sms_responses as $sms_response) {
					if($sms_response['messages'][0]['status'] == 0) {
						$success_sms++;
					}
				}

				$response = array();
				$response['success'] = $success_sms;
				$response['failed'] = $total_sms - $success_sms;

				try {
					if(is_array($response)) {
						$this->add_notification_message("SMS sent successfully: {$response['success']}, Failed: {$response['failed']}");
					}
					else {
						$this->add_notification_message("Failed to send SMS", 'error');
					}

				} catch (Exception $e) {
					$this->add_notification_message("Critical error...", 'error');
					$this->log->add("MoceanAPI", "Error: " . $e->getMessage());
				}

			}

		}
	}

	public function get_keywords()
	{
		$keywords = array(
			'contact' => array(
				'id',
				'firstname',
				'lastname',
				'salutation',
				'job_title',
				'address',
				'zip',
				'town',
				'country',
				'country_code',
				'email',
				'note_private',
				'note_public',
			),
			'company' => array(
				'company_id',
				'company_name',
				'company_alias_name',
				'company_address',
				'company_zip',
				'company_town',
				'company_phone',
				'company_fax',
				'company_email',
				'company_url',
				'company_capital',
			),
		);
		return $keywords;
	}

	private function add_error($error)
	{
		$this->errors[] = $error;
	}

	private function get_errors(){
		return $this->errors;
	}

	public function render()
	{
		global $conf, $user, $langs, $db;
		$this->thirdparty->id = !empty($this->thirdparty->id) ? $this->thirdparty->id : 0;

		$sms_templates = array();
		$sms_templates[0] = "Select a template to use";

		$sms_template_obj = new SMS_Template_Setting($db);
		$sms_template_in_kv = $sms_template_obj->get_all_sms_templates_as_array();
		foreach($sms_template_in_kv as $id => $title) {
			$sms_templates[$id] = $title;
		}

		$sms_templates_obj = $sms_template_obj->get_all_sms_templates();
		$sms_template_full_data = array();
		foreach($sms_templates_obj as $sms_t_obj) {
			$sms_template_full_data[$sms_t_obj['id']] = $sms_t_obj;
		}

		if(isset($_GET) && !empty($_GET)) {
			if(!empty($_GET["thirdparty_id"])) {
				$tp_id = intval($_GET["thirdparty_id"]);
				$this->thirdparty->fetch($tp_id);
			}
		}

?>
		<!-- Begin form SMS -->
		<?php
		llxHeader('', $langs->trans($this->page_name));
		print load_fiche_titre($langs->trans($this->page_name), '', 'title_setup');
		$head = moceanapiAdminPrepareHead();
		print dol_get_fiche_head($head, $this->context, $langs->trans($this->page_name), -1);

		if(!empty($this->notification_messages)) {
			foreach($this->notification_messages as $notification_message) {
				dol_htmloutput_mesg($notification_message['message'], [], $notification_message['style']);
			}
		}

		?>
		<form method="POST" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"] ?>" style="max-width: 500px">
			<?php if(! empty($this->get_errors()) ) { ?>
				<?php foreach($this->get_errors() as $error) { ?>
					<div class="error"><?php echo $error ?></div>
				<?php } ?>
			<?php } ?>
			<input type="hidden" name="action" value="send_sms">
			<input type="hidden" name="token" value="<?php echo newToken(); ?>">
			<!-- Balance -->

			<table class="border" width="100%">
				<!-- From -->

				<tr>
					<td width="200px"><?php echo $this->form->textwithpicto($langs->trans("MOCEAN_FROM"), "Your business name"); ?>*</td>
					<td>
						<input type="text" name="sms_from" size="30" value="<?php echo !empty($conf->global->MOCEAN_FROM) ? $conf->global->MOCEAN_FROM : ""; ?>">
					</td>
				</tr>

				<!-- To -->
				<tr>
					<td width="200px">
						<?php echo $this->form->textwithpicto($langs->trans("SmsTo"), "The contact mobile you want to send SMS to"); ?>*
					</td>
					<td>
						<?php echo $this->form->select_thirdparty_list($this->thirdparty->id, 'sms_thirdparty_id') ?>
					</td>
				</tr>

				<tr>
					<td width="200px">
					</td>
					<td>
						<?php echo $this->form->selectcontacts($this->thirdparty->id, '', 'sms_contact_ids', 1, '', '', 1, '', false, 0, 0, [], '', '', true) ?>
					</td>
				</tr>

				<!-- SMS Template -->
				<tr>
					<td width="200px">
						<?php echo $this->form->textwithpicto($langs->trans("SmsTemplate"), "The SMS template you want to use"); ?>
					</td>
					<td>
						<?php echo $this->form->selectarray('sms_template_id', $sms_templates ) ?>
					</td>
				</tr>

				<tr>
					<td width="200px" valign="top"><?php echo $langs->trans("Sms_To_Thirdparty_Flag") ?></td>
						<td>
							<input id="send_sms_to_thirdparty_flag" type="checkbox" name="send_sms_to_thirdparty_flag"></input>
						</td>
					</td>
				</tr>



				<!-- SMS Calculator -->
				<tr>
					<td width="200px" valign="top"><?php echo $langs->trans("SmsText") ?>*</td>
						<td>
							<textarea cols="40" name="sms_message" id="message" rows="4"></textarea>
							<div>
								<p id="sms_keyword_paragraph">Customize your SMS with keywords
									<button type="button" class="moceanapi_open_keyword" data-attr-target="message">
										Keywords
									</button>
								</p>
								<a href="https://dashboard.moceanapi.com/sms-calculator" target="_blank">
									<?php echo $langs->trans("SmsCounterLinkText") ?>
								</a>
							</div>
						</td>
					</td>
				</tr>
			</table>
			<!-- Submit -->
			<input style="float:right;" class="button" type="submit" name="submit" value="<?php echo $langs->trans("SendSMSButtonTitle") ?>">
		</form>
		<!-- End form SMS -->

		<script>
			const entity_keywords = <?php echo json_encode($this->get_keywords()); ?>;
			const sms_templates = <?php echo json_encode($sms_template_full_data); ?>;

			var div = $('<div />').appendTo('body');
			div.attr('id', `keyword-modal`);
			div.attr('class', "modal");
			div.attr('style', "display: none;");

			jQuery(document).ready(function () {
				$("#send_sms_to_thirdparty_flag").closest("tr").hide();
				$("#sms_contact_ids").on("change", function () {
					var sms_contact_id = $("#sms_contact_ids").val();
					var thirdpartyTree = $("#sms_thirdparty_id");
					// if the tree exists
					if(thirdpartyTree.length > 0) {
						if(sms_contact_id.length > 0) {
							$("#send_sms_to_thirdparty_flag").closest("tr").show();
						}
						else {
							$("#send_sms_to_thirdparty_flag").closest("tr").hide();
						}
					}
				});
				$("#sms_thirdparty_id").on("change", function () {
					let chosen_tp_id = $(this).val();
					urlParams = new URLSearchParams(window.location.search);

					urlParams.set("thirdparty_id", chosen_tp_id);

					let baseURL = window.location.href.split('?')[0];
					let url = baseURL + "?" + urlParams.toString();
					window.location = url;
				});

				$('.moceanapi_open_keyword').click(function(e) {
					const target = $(e.target).attr('data-attr-target');
					caretPosition = document.getElementById(target).selectionStart;

					const buildTable = function(keywords) {
						const chunkedKeywords = keywords.array_chunk(3);

						let tableCode = '';
						chunkedKeywords.forEach(function(row, rowIndex) {
							if (rowIndex === 0) {
								tableCode += '<table class="widefat fixed striped"><tbody>';
							}

							tableCode += '<tr>';
							row.forEach(function(col) {
								tableCode += `<td class="column"><button class="button-link" onclick="moceansms_bind_text_to_field('${target}', '[${col}]')">[${col}]</button></td>`;
							});
							tableCode += '</tr>';

							if (rowIndex === chunkedKeywords.length - 1) {
								tableCode += '</tbody></table>';
							}
						});

						return tableCode;
					};

					$('#keyword-modal').off();
					$('#keyword-modal').on($.modal.AFTER_CLOSE, function() {
						document.getElementById(target).focus();
						document.getElementById(target).setSelectionRange(caretPosition, caretPosition);
					});

					let mainTable = '';
					for (let [key, value] of Object.entries(entity_keywords)) {
						mainTable += `<h3>${capitalize_first_letter(key.replaceAll('_', ' '))}</h3>`;
						mainTable += buildTable(value);
					}

					mainTable += '<div style="margin-top: 10px"><small>*Press on keyword to add to sms template</small></div>';

					$('#keyword-modal').html(mainTable);
					$('#keyword-modal').modal();
				});

				$('#sms_template_id').on("change", function() {
					let selected_template_id = this.value;
					const sms_template_data = sms_templates[selected_template_id];
					$("#message").val(sms_template_data.message);
				});
			})

			function moceansms_bind_text_to_field(target, keyword) {
				const startStr = document.getElementById(target).value.substring(0, caretPosition);
				const endStr = document.getElementById(target).value.substring(caretPosition);
				document.getElementById(target).value = startStr + keyword + endStr;
				caretPosition += keyword.length;
			}

		</script>

		<?php
		// Page end
		print dol_get_fiche_end();

		llxFooter();
		?>
<?php
	}
}
