<?php
dol_include_once("./moceanapi_logger.class.php");
dol_include_once("/moceanapi/core/interfaces/healthcheck.class.php");

class MoceanSMSTemplateDatabase implements IHealthcheck {

	public $db;
	private $log;

	public $table_name = MAIN_DB_PREFIX . 'moceanapi_sms_template';

	public function __construct( DoliDBMysqli $db) {
		$this->db = $db;
		$this->log = new MoceanAPI_Logger();
	}

	public function healthcheck()
	{
		/*
			Check if SMS reminder table is created
			Return @boolean true on success
		*/
		$sql = sprintf("SELECT table_name FROM information_schema.tables WHERE table_schema = '%s' AND table_name = '%s'",
			$this->db->database_name,
			$this->table_name
		);
		$result = $this->db->num_rows($this->db->query($sql));
		return ($result) ? true : false;
	}

	public function insert($title, $message)
	{
		$this->log->add("MoceanAPI", "Adding SMS Template.");
		$sql = "INSERT INTO `{$this->table_name}` (`title`, `message`, `created_at`)";
		$sql .= sprintf(' VALUES ("%s", "%s", UTC_TIMESTAMP() )',
			$this->db->escape($title),
			$this->db->escape($message),
		);

		$result = $this->db->query($sql);
		if($result) {
			$this->log->add("MoceanAPI", "Successfully added to SMS template.");
			return true;
		} else {
			$this->log->add("MoceanAPI", "Failed to add into SMS template.");
			return false;
		}
	}

	public function update($query, $usesavepoint = 0, $type = 'auto', $result_mode = 0)
	{
		/*
			Proxy the $query to $this->db->query() so we can do logging.
		*/
		return $this->db->query($query, $usesavepoint = 0, $type = 'auto', $result_mode = 0);
	}

	public function delete($query, $usesavepoint = 0, $type = 'auto', $result_mode = 0)
	{
		/*
			Proxy the $query to $this->db->query() so we can do logging.
		*/
		return $this->db->query($query, $usesavepoint = 0, $type = 'auto', $result_mode = 0);
	}

	public function deleteAll()
	{
		$sql = "DELETE FROM `{$this->table_name}`;";
		$result = $this->db->query($sql);
		if($result) {
			$this->log->add("MoceanAPI", "Successfully cleared SMS templates");
			return true;
		} else {
			$this->log->add("MoceanAPI", "Failed to clear SMS templates");
			return false;
		}
	}

	public function getAll()
	{
		$sql = "SELECT `id`, `title`, `message`, `created_at` FROM `{$this->table_name}` ORDER BY `id` DESC";
		$result = $this->db->query($sql);
		return $result ? $result : [];
	}

	public function getAllWhere($key, $operator, $value)
	{
		$sql = "SELECT `id`, `title`, `message`, `created_at` FROM `{$this->table_name}`";
		$sql .= sprintf(' WHERE `%s` %s "%s"',
			$this->db->escape($key),
			$this->db->escape($operator),
			$this->db->escape($value)
		);
		$result = $this->db->query($sql);
		return $result ? $result : [];
	}

	public function get($id)
	{
		$sql = "SELECT `id`, `title`, `message`, `created_at` FROM `{$this->table_name}`";
		$sql .= sprintf(" WHERE `id` = %d", $id);
		$result = $this->db->query($sql);
		return $result ? $result : [];
	}

	function updateById($id, $title, $message) {

		$sql = "UPDATE {$this->table_name}";
		$sql .= sprintf(' SET `title` = "%s", `message` = "%s" ',
			$this->db->escape($title),
			$this->db->escape($message)
		);
		$sql .= "WHERE `id` = $id";
		return $this->update($sql);
	}

	function deleteById($id) {
		$sql = "DELETE FROM {$this->table_name}";
		$sql .= " WHERE id = $id";
		return $this->delete($sql);
	}

}
