<?php
/* Copyright (C) 2005-2011 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2011 Regis Houssin        <regis.houssin@capnetworks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \file       htdocs/core/triggers/interface_90_all_Demo.class.php
 *  \ingroup    core
 *  \brief      Fichier de demo de personalisation des actions du workflow
 *  \remarks    Son propre fichier d'actions peut etre cree par recopie de celui-ci:
 *              - Le nom du fichier doit etre: interface_99_modMymodule_Mytrigger.class.php
 *				                           ou: interface_99_all_Mytrigger.class.php
 *              - Le fichier doit rester stocke dans core/triggers
 *              - Le nom de la classe doit etre InterfaceMytrigger
 *              - Le nom de la methode constructeur doit etre InterfaceMytrigger
 *              - Le nom de la propriete name doit etre Mytrigger
 */


/**
 *  Class of triggers for demo module
 */
class Interfacenotifevent
{
    var $db;

    /**
     *   Constructor
     *
     *   @param		DoliDB		$db      Database handler
     */
    function __construct($db)
    {
        $this->db = $db;

        $this->name = preg_replace('/^Interface/i','',get_class($this));
        $this->family = "notification";
        $this->description = "Triggers of this module are empty functions. They have no effect. They are provided for tutorial purpose only.";
        $this->version = 'dolibarr';            // 'development', 'experimental', 'dolibarr' or version
        $this->picto = 'email';
    }


    /**
     *   Return name of trigger file
     *
     *   @return     string      Name of trigger file
     */
    function getName()
    {
        return $this->name;
    }

    /**
     *   Return description of trigger file
     *
     *   @return     string      Description of trigger file
     */
    function getDesc()
    {
        return $this->description;
    }

    /**
     *   Return version of trigger file
     *
     *   @return     string      Version of trigger file
     */
    function getVersion()
    {
        global $langs;
        $langs->load("admin");
        $langs->load("notifevent@notifevent");

        if ($this->version == 'development') return $langs->trans("Development");
        elseif ($this->version == 'experimental') return $langs->trans("Experimental");
        elseif ($this->version == 'dolibarr') return DOL_VERSION;
        elseif ($this->version) return $this->version;
        else return $langs->trans("Unknown");
    }

    /**
     *      Function called when a Dolibarrr business event is done.
     *      All functions "run_trigger" are triggered if file is inside directory htdocs/core/triggers
     *
     *      @param	string		$action		Event action code
     *      @param  Object		$object     Object
     *      @param  User		$user       Object user
     *      @param  Translate	$langs      Object langs
     *      @param  conf		$conf       Object conf
     *      @return int         			<0 if KO, 0 if no triggered ran, >0 if OK
     */
	function run_trigger($action,$object,$user,$langs,$conf)
    {
        // Put here code you want to execute when a Dolibarr business events occurs.
        // Data and type of action are stored into $object and $action

        // Project tasks
        if ($action == 'ACTION_CREATE' || $action == 'ACTION_MODIFY')
        {
            global $db, $conf, $langs;
            dol_syslog("Trigger '".$this->name."' for action '$action' launched by ".__FILE__.". id=".$object->id);


            include_once(DOL_DOCUMENT_ROOT."/core/class/CMailFile.class.php");
            $langs->load("notifevent@notifevent");

            //Busquem la informació de l'esdeveniment
            $sql_event = $this->db->query("SELECT datep, fk_soc, label, note, code FROM ".MAIN_DB_PREFIX."actioncomm WHERE id = '".$object->id."' ");
            while ( $event = $this->db->fetch_array($sql_event) ) {

                $time_temp = explode(" ", $event['datep']);

                $date = dol_print_date($event['datep']);
                $time = $time_temp[1];
                $soc = $event['fk_soc'];
                $title = $event['label'];
                $desc = $event['note'];
                $code = $event['code'];
            }

            //Busquem l'e-mail de tots els usuaris assignats a l'esdeveniment
            $emails = "";
            $query = "SELECT u.email FROM ".MAIN_DB_PREFIX."user u, ".MAIN_DB_PREFIX."actioncomm_resources ar WHERE u.rowid = ar.fk_element AND ar.fk_actioncomm = '".$object->id."' AND u.email != ''";
            $sql_email = $this->db->query($query);
            while ( $row = $this->db->fetch_array($sql_email) ) {

                $emails .= $row['email'].",";
            }
            $emails =  substr($emails, 0, strlen($emails) -1); //Eliminem la coma

            $file = "";

            switch ($action) {
                case "ACTION_CREATE": $subject = $langs->trans("subject_notifevent");break;
                case "ACTION_MODIFY": $subject = $langs->trans("subject_notifevent_modify");break;
            }
            
            $to = $emails;

            //Remitent
            $from = ''.$user->email.' <'.$user->email.'>';

            //Construïm el cos del missatge
            $message = "<strong>".$title."</strong><br /><br />";

            //Mirem si aquest esdeveniment té un tercer assignat i en busquem la informació
            if ( $soc != '' ) {

                $sql_thirdparty = $this->db->query("SELECT nom, address, town, phone, zip FROM ".MAIN_DB_PREFIX."societe WHERE rowid = '$soc' ");
                while ( $thrd = $this->db->fetch_array($sql_thirdparty) ) {

                    $company = $thrd['nom'];
                    $address = $thrd['address'];
                    $town = $thrd['town'];
                    $phone = $thrd['phone'];
                    $zip = $thrd['zip'];
                }

                if ( $company != '' ) { $message .= '<br/><strong>'.$langs->trans("company").':</strong> '.$company; }
                if ( $address != '' ) { $message .= '<br/><strong>'.$langs->trans("address").':</strong> '.$address; }
                if ( $town != '' ) { $message .= '<br/><strong>'.$langs->trans("town").':</strong> '.$town; }
                if ( $phone != '' ) { $message .= '<br/><strong>'.$langs->trans("phone").':</strong> '.$phone; }
                if ( $zip != '' ) { $message .= '<br/><strong>'.$langs->trans("zip").':</strong> '.$zip; }
            }
            $message .= '<br/><strong>'.$langs->trans("date").':</strong> '.$date;
            $message .= '<br/><strong>'.$langs->trans("time").':</strong> '.$time;
            $message .= '<br/><br/><strong>'.$langs->trans("desc").':</strong> '.$desc.'<br />';

            //Busquem els extrafields
            include_once(DOL_DOCUMENT_ROOT."/core/lib/json.lib.php");

            $sql_extrafields = $this->db->query("SELECT name, label, type, param FROM ".MAIN_DB_PREFIX."extrafields WHERE elementtype = 'actioncomm' AND type != 'separate' ORDER BY pos ASC");
            while ( $ext = $this->db->fetch_array($sql_extrafields) ) {

                $extrafields_name[] = $ext['name'];
                $extrafields_label[] = $ext['label'];
                $type[] = $ext['type'];
                $param[] = $ext['param'];
            }

            for ( $i = 0; $i < count($extrafields_name); $i++ ) {

                //Busquem el valor dels extrafields
                $sql_ext_value = $this->db->query("SELECT ".$extrafields_name[$i]." FROM ".MAIN_DB_PREFIX."actioncomm_extrafields ");
                while ( $value = $this->db->fetch_array($sql_ext_value) ) {

                    $ext_value = $value[0];
                }

                //Si és un combo, checkbox o radiobutton, busquem les opcions definides al camp llx_extrafields.param
                if ( $type[$i] == 'checkbox' || $type[$i] == 'select' || $type[$i] == 'radio') {

                    $result = unserialize($param[$i]);
                    foreach ( $result as $key ) {
                        $ext_value =  $key[$ext_value];
                    }
                }

                if ( $ext_value != '' || $type[$i] == 'separate') {

                    $message .= '<br/><strong>'.$extrafields_label[$i].':</strong> '.$ext_value;
                }

            }

            //Només enviarem l'e-mail si es tracta d'un esdeveniment de l'agenda. Els que es creen automàticament no els enviarem

            if ( $code != 'AC_OTH_AUTO') {

                $langs->load("notifevent@notifevent");
                $mailfile = new CMailFile($subject,$to,$from,$message,array($file),'','','', '', 0, -1,'','');
                $mailfile->sendfile();
                setEventMessage($langs->trans("missatgenotifevent").' '.$to, 'mesgs');
            }
        }
		return 0;
    }

}
?>
