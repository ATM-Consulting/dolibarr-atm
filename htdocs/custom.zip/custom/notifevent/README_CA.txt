*****************************************************

  M�dul notifevent - Dolibarr 3.9

*****************************************************

FUNCIONS

Quan es crea un nou esdeveniment a l'agenda s'envia un e-mail de notificaci� a l'usuari al que se li ha assignat aquell esdeveniment. El remitent de l'e-mail ser� el de l'usuari que ha creat l'esdeveniment. 

La informaci� que inclou l'e-mail �s:

- T�tol esdeveniment
- Nom i dades de l'empresa (si s'ha especificat)
- Data i hora de l'esdeveniment
- Descripci�
- Camps adicionals

Quan es fa una modificaci� tamb� s'envia notificaci� per e-mail.


INSTAL�LACI�

Copiar la carpeta notifevent dins d'htpdocs.


----------------------

ADQA 
www.adqa.com
dolibarr@adqa.com
