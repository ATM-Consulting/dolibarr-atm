*****************************************************

  M�dulo notifevent - Dolibarr 3.9

*****************************************************

FUNCIONES

Cuando se crea un nuevo evento en la agenda se envia un e-mail de notificaci�n al usuario al que se le ha asignado ese evento. El remitente del e-mail ser� el del usuario que ha creado el evento. 

La informaci�n que incluye el e-mail es:

- T�tulo evento
- Nombre y datos de la empresa (si se ha especificado)
- Fecha y hora del evento
- Descripci�n
- Campos adicionales

Cuando se hace una modificaci�n tambi�n se envia notificaci�n por e-mail.

INSTALACI�N

Copiar la carpeta notifevent dentro de htpdocs.


----------------------

ADQA 
www.adqa.com
dolibarr@adqa.com
