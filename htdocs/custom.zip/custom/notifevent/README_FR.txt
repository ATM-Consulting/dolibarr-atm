*****************************************************

  Module notifevent - Dolibarr 3.9

*****************************************************

LES FONCTIONS

Quand un �v�nement de calendrier est cr��, une notification par e-mail sera envoy� � l'utilisateur affect� � cet �v�nement. L'exp�diteur e-mail sera l'utilisateur qui a cr�� l'�v�nement.

E-mail inclut cette information:

- �v�nement Titre
- Le nom et les donn�es Soci�t� (si a �t� sp�cifi�)
- Heure et les donn�es �v�nement
- La description
- Les champs suppl�mentaires

En outre, un e-mail sera envoy� s'il y a quelques modifications sur l'�v�nement.

INSTALLATION

Copiez le dossier notifevent dans le dossier htdocs.


----------------------

ADQA 
www.adqa.com
dolibarr@adqa.com
