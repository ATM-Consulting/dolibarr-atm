*****************************************************

  Notifevent module - Dolibarr 3.9

*****************************************************

FUNCTIONS

When a calendar event is created, an e-mail notification will be sent to the user assigned to this event. The e-mail sender will be the user who created the event.

E-mail includes this information:

- Title event
- Company name and data (if was specified)
- Hour and data event
- Description
- Extrafields

Also, an e-mail will be sent if there are some modification on the event.

INSTALLATION

Copy the notifevent folder inside htdocs folder.


----------------------

ADQA 
www.adqa.com
dolibarr@adqa.com
