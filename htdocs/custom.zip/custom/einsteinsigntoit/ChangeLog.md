# CHANGELOG SOLEILSIGN FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## From 1.0.0 to 1.1.0
- New: management of the warning in mobile mode

- Improvement: if the user does not have permission to use the module, the model does not appear in the list

- New: some hidden parameters

- New: upgrade for Dolibarr 10.0. *

- BugFix: force the creation of the temp directory

- BugFix: force the deletion of the image file of the signature after its integration in the pdf

- BugFix: show / hide the warning

- BugFix: FileNotFound problem in pdf under certain conditions

## 1.0
Initial version

