//
// si on est dans la fiche ficheinter,
// on essaie de charger le script soleilsign.js
// qui contient toute la logique de signature
//

var EINSTEINSIGN_URL_ROOT = '';

if (document.URL.indexOf('/fichinter/card.php') > 0) {
// on essaie de trouver l'url d'origin du présent script
// ce qui nous permettra de trouver les urls des autres ficier js/css
  var getScriptURL = (function () {
    var scripts = document.getElementsByTagName('script');
//    var index = scripts.length - 1;
//    var myScript = scripts[index];
    for (var i = 0; i < scripts.length; i++) {
      if (scripts[i].src.indexOf('/einsteinsign/js/global.js') > 0) {
// on a trouvé
        return function () {
          return scripts[i].src;
        };
      }
    }
// si non trouvé
    return function () {
      return 'ScriptNotFound';
    };
  })();
  EINSTEINSIGN_URL_ROOT = getScriptURL().replace('/js/global.js', '');
  var fileToLoad = '';
  // chargement effectif du script si trouvé
  if (EINSTEINSIGN_URL_ROOT !== 'ScriptNotFound') {
// ---------- chargement dynamique des fichier js/css sf ainsi que soleilsign.js
// Attention : ne pas utiliser ej.web.all.min.css car le navigateur ne reconnait pa le caractère @
// --- /lib/sf/css/webej.widgets.core.min.css
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/css/web/ej.widgets.core.min.css';
//    loadJsOrCss(fileToLoad, 'css', function () {
//      console.log('ej.widgets.core.min.css' + '... loaded')
//    });
    // --- /lib/sf/css/web/default-theme/ej.theme.min.css
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/css/web/default-theme/ej.theme.min.css';
//    loadJsOrCss(fileToLoad, 'css', function () {
//      console.log('ej.theme.min.css' + '... loaded')
//    });

    // --- /lib/sf/scripts/common/ej.core.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/common/ej.core.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.core.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/common/ej.scroller.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/common/ej.scroller.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.scroller.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/common/ej.draggable.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/common/ej.draggable.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.draggable.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/common/ej.touch.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/common/ej.touch.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.touch.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/common/ej.globalize.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/common/ej.globalize.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.globalize.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/web/ej.button.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/web/ej.button.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.button.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/web/ej.dialog.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/web/ej.dialog.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.dialog.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/web/ej.signature.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/web/ej.signature.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.signature.min.js' + '... loaded')
//    });

    // --- /lib/sf/external/ej.web.all.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/external/jsrender.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('jsrender.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/web/ej.web.all.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/web/ej.web.all.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.web.all.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/i18n/ej.culture.en-US.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/i18n/ej.culture.en-US.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.culture.en-US.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/i18n/ej.culture.fr-FR.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/i18n/ej.culture.fr-FR.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.culture.fr-FR.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/l10n/ej.localetexts.en-US.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/l10n/ej.localetexts.en-US.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.localetexts.en-US.min.js' + '... loaded')
//    });

    // --- /lib/sf/scripts/l10n/ej.localetexts.fr-FR.min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/sf/scripts/l10n/ej.localetexts.fr-FR.min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('ej.localetexts.fr-FR.min.js' + '... loaded')
//    });

    // --- /lib/rloader1.5.4_min.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/lib/rloader1.5.4_min.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('rloader1.5.4_min.js' + '... loaded')
//    });

    // --- /js/soleilsign.js
//    fileToLoad = SOLEILSIGN_URL_ROOT + '/js/soleilsign.js';
//    loadJsOrCss(fileToLoad, 'js', function () {
//      console.log('soleilsign.js' + '... loaded')
//    });

  }
  else {
    console.log('Script non trouvé : ' + '/js/global.js');
  }
}

//
// charge dynamiquement un script js
// et exécute une fonction de callback quand le chargement est fini
//
function loadJsOrCss(url, type, callback) {

  var tag = null;

  if (type = 'js') {
    tag = document.createElement("script")
    tag.type = "text/javascript";
    tag.src = url;
  }
  else {
    tag = document.createElement("link")
    tag.rel = "stylesheet";
    tag.type = "text/css";
    tag.href = url;
  }

  document.getElementsByTagName("head")[0].appendChild(tag);

  if (tag.readyState) {  //IE
    tag.onreadystatechange = function () {
      if (tag.readyState == "loaded" || tag.readyState == "complete") {
        tag.onreadystatechange = null;
        callback();
      }
    };
  }
  else {  //Others
    tag.onload = function () {
      callback();
    };
  }

}