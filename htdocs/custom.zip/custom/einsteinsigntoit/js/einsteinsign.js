var t = '<div id="einsteinsigntoit-warning" style="display: inline-block;" title="' + ssData.langsTrans_EINSTEINSIGN_Warning_CommandeNotInStatusValidated + '"><span class="fa fa-warning"></span></div>',
    n = '<div id="einsteinsigntoit-warning" style="display: inline-block;" title="' + ssData.langsTrans_EINSTEINSIGN_Warning_NotEnoughPermissions + '"><span class="fa fa-warning"></span></div>',
    e = 1,
    i = "975baec1f0",
    a = ssData.parent1,
    s = ssData.parent2,
    r = "deviscaratoit",
    d = ssData.mytitle,
    u = "6058109884",
    o = document.URL,
    f = "NER",
    l = 1,
    c = 2,
    g = 3,
    b = 4,
    D = 5;


function v() {
    //if (o.indexOf(r) < 0) throw f + " - (code: " + c + ")";
    console.log('aa' + $("#model").val());

    $("#builddoc_form").on("submit", function(t)

        {
            if ($("#model").val() == 'einsteintoit') {
                document.getElementById("builddoc_form").submit();
                exit;
            }


            //if ("einsteinsign" !== (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ? $("#model option:selected").text() : $("#select2-model-container").text())) return !0;
            if (t.preventDefault(), t.stopPropagation(), void 0 !== $("#fisDlgSignature").data("ejDialog") && null !== $("#fisDlgSignature").data("ejDialog") && $("#fisDlgSignature").data("ejDialog").destroy(), $("#fisDlgSignature").ejDialog({ enableModal: !0, enableResize: !1, enableAnimation: !0, animation: { show: { effect: "slide", duration: 500 }, hide: { effect: "fade", duration: 800 } }, locale: ssData.sfLocale, title: ssData.dlgTitle, width: ssData.confGlobal_EINSTEINSIGN_DIALOG_WIDTH }), $("#fisSignatureIntervenant").ejSignature({ strokeColor: ssData.confGlobal_EINSTEINSIGN_SIGNATURE_COLOR, strokeWidth: parseInt(ssData.confGlobal_EINSTEINSIGN_SIGNATURE_LINE_WIDTH), locale: ssData.sfLocale, height: "140px", width: "100%", change: function(t) { $("#fisIntervenantBtnErase").ejButton().data("ejButton").option("enabled", !0), 0 < $("#fisSignatureClient").data("ejSignature").storeSnap.length && $("#fisBtnValidate").ejButton().data("ejButton").option("enabled", !0) } }), $("#fisSignatureIntervenant").data("ejSignature").storeSnap = [], $("#fisSignatureClient").ejSignature({ strokeColor: ssData.confGlobal_EINSTEINSIGN_SIGNATURE_COLOR, strokeWidth: parseInt(ssData.confGlobal_EINSTEINSIGN_SIGNATURE_LINE_WIDTH), locale: ssData.sfLocale, height: "140px", width: "100%", change: function(t) { $("#fisClientBtnErase").ejButton().data("ejButton").option("enabled", !0), 0 < $("#fisSignatureIntervenant").data("ejSignature").storeSnap.length && $("#fisBtnValidate").ejButton().data("ejButton").option("enabled", !0) } }), $("#fisSignatureClient").data("ejSignature").storeSnap = [], $("#fisIntervenantBtnErase").ejButton({
                    enabled: !1,
                    click: function(t) {
                        //if (p(a).indexOf(i) < 0) throw f + " - (code: " + g + ")";
                        $("#fisSignatureIntervenant").data("ejSignature").clear(), $("#fisSignatureIntervenant").data("ejSignature").storeSnap = [], $("#fisIntervenantBtnErase").ejButton().data("ejButton").option("enabled", !1), $("#fisBtnValidate").ejButton().data("ejButton").option("enabled", !1)
                    }
                }), $("#fisClientBtnErase").ejButton({
                    enabled: !1,
                    click: function(t) {
                        //if (p(a).indexOf(i) < 0) throw f + " - (code: " + g + ")";
                        $("#fisSignatureClient").data("ejSignature").clear(), $("#fisSignatureClient").data("ejSignature").storeSnap = [], $("#fisClientBtnErase").ejButton().data("ejButton").option("enabled", !1), $("#fisBtnValidate").ejButton().data("ejButton").option("enabled", !1)
                    }
                }), $("#fisBtnValidate").ejButton({
                    enabled: !1,
                    click: function(t) {

                        //if (p(d).indexOf(u) < 0) throw f + " - (code: " + b + ")";
                        var n = $("#fisSignatureIntervenant").data("ejSignature"),
                            e = $("#fisSignatureIntervenant > canvas:nth-child(1)")[0],
                            i = $("#fisSignatureClient").data("ejSignature"),
                            a = $("#fisSignatureClient > canvas:nth-child(1)")[0];
                        if (!ej.isNullOrUndefined(n.storeSnap) && 0 !== n.storeSnap.length && !ej.isNullOrUndefined(i.storeSnap) && 0 !== i.storeSnap.length) {
                            $("#waitingPopup").ejWaitingPopup().data("ejWaitingPopup").show(), $("#fisDlgSignature").ejDialog().data("ejDialog").close();
                            var s = e.toDataURL(),
                                r = a.toDataURL(),
                                o = ssData.EINSTEINSIGNTOIT_URL_ROOT + "/lib/einsteinsign.php",
                                l = "action=createImage&objectRef=" + ssData.objectRef + "&objectEntity=" + ssData.objectEntity + "&strokesIntervenant=" + JSON.stringify(s) + "&strokesClient=" + JSON.stringify(r);

                            $.ajax({ method: "POST", url: o, dataType: "json", data: l, async: !0, success: function(t, n) { "OK" === t.status ? document.getElementById("builddoc_form").submit() : t.status = "NOK" } })
                                //console.log("error : ", t) },  error: function(t, n, e) { console.log("error : ", t, n, e), alert(e) }, complete: function(t, n) { $("#waitingPopup").ejWaitingPopup().data("ejWaitingPopup").hide() } })
                        }
                    }
                }), $("#fisBtnCancel").ejButton({ click: function(t) { $("#fisDlgSignature").data("ejDialog").close() } }), o.indexOf(r) < 0) throw f + " - (code: " + D + ")";
            return !1
        })
}

function p(t) { return result = h(j(w(S(t), 8 * t.length))), result.toLowerCase() }

function h(t) { for (var n, e = "0123456789ABCDEF", i = "", a = 0; a < t.length; a++) n = t.charCodeAt(a), i += e.charAt(n >>> 4 & 15) + e.charAt(15 & n); return i }

function S(t) { for (var n = Array(t.length >> 2), e = 0; e < n.length; e++) n[e] = 0; for (e = 0; e < 8 * t.length; e += 8) n[e >> 5] |= (255 & t.charCodeAt(e / 8)) << e % 32; return n }

function j(t) { for (var n = "", e = 0; e < 32 * t.length; e += 8) n += String.fromCharCode(t[e >> 5] >>> e % 32 & 255); return n }

function w(t, n) {
    t[n >> 5] |= 128 << n % 32, t[14 + (n + 64 >>> 9 << 4)] = n;
    for (var e = 1732584193, i = -271733879, a = -1732584194, s = 271733878, r = 0; r < t.length; r += 16) {
        var o = e,
            l = i,
            d = a,
            u = s;
        i = C(i = C(i = C(i = C(i = I(i = I(i = I(i = I(i = m(i = m(i = m(i = m(i = B(i = B(i = B(i = B(i, a = B(a, s = B(s, e = B(e, i, a, s, t[r + 0], 7, -680876936), i, a, t[r + 1], 12, -389564586), e, i, t[r + 2], 17, 606105819), s, e, t[r + 3], 22, -1044525330), a = B(a, s = B(s, e = B(e, i, a, s, t[r + 4], 7, -176418897), i, a, t[r + 5], 12, 1200080426), e, i, t[r + 6], 17, -1473231341), s, e, t[r + 7], 22, -45705983), a = B(a, s = B(s, e = B(e, i, a, s, t[r + 8], 7, 1770035416), i, a, t[r + 9], 12, -1958414417), e, i, t[r + 10], 17, -42063), s, e, t[r + 11], 22, -1990404162), a = B(a, s = B(s, e = B(e, i, a, s, t[r + 12], 7, 1804603682), i, a, t[r + 13], 12, -40341101), e, i, t[r + 14], 17, -1502002290), s, e, t[r + 15], 22, 1236535329), a = m(a, s = m(s, e = m(e, i, a, s, t[r + 1], 5, -165796510), i, a, t[r + 6], 9, -1069501632), e, i, t[r + 11], 14, 643717713), s, e, t[r + 0], 20, -373897302), a = m(a, s = m(s, e = m(e, i, a, s, t[r + 5], 5, -701558691), i, a, t[r + 10], 9, 38016083), e, i, t[r + 15], 14, -660478335), s, e, t[r + 4], 20, -405537848), a = m(a, s = m(s, e = m(e, i, a, s, t[r + 9], 5, 568446438), i, a, t[r + 14], 9, -1019803690), e, i, t[r + 3], 14, -187363961), s, e, t[r + 8], 20, 1163531501), a = m(a, s = m(s, e = m(e, i, a, s, t[r + 13], 5, -1444681467), i, a, t[r + 2], 9, -51403784), e, i, t[r + 7], 14, 1735328473), s, e, t[r + 12], 20, -1926607734), a = I(a, s = I(s, e = I(e, i, a, s, t[r + 5], 4, -378558), i, a, t[r + 8], 11, -2022574463), e, i, t[r + 11], 16, 1839030562), s, e, t[r + 14], 23, -35309556), a = I(a, s = I(s, e = I(e, i, a, s, t[r + 1], 4, -1530992060), i, a, t[r + 4], 11, 1272893353), e, i, t[r + 7], 16, -155497632), s, e, t[r + 10], 23, -1094730640), a = I(a, s = I(s, e = I(e, i, a, s, t[r + 13], 4, 681279174), i, a, t[r + 0], 11, -358537222), e, i, t[r + 3], 16, -722521979), s, e, t[r + 6], 23, 76029189), a = I(a, s = I(s, e = I(e, i, a, s, t[r + 9], 4, -640364487), i, a, t[r + 12], 11, -421815835), e, i, t[r + 15], 16, 530742520), s, e, t[r + 2], 23, -995338651), a = C(a, s = C(s, e = C(e, i, a, s, t[r + 0], 6, -198630844), i, a, t[r + 7], 10, 1126891415), e, i, t[r + 14], 15, -1416354905), s, e, t[r + 5], 21, -57434055), a = C(a, s = C(s, e = C(e, i, a, s, t[r + 12], 6, 1700485571), i, a, t[r + 3], 10, -1894986606), e, i, t[r + 10], 15, -1051523), s, e, t[r + 1], 21, -2054922799), a = C(a, s = C(s, e = C(e, i, a, s, t[r + 8], 6, 1873313359), i, a, t[r + 15], 10, -30611744), e, i, t[r + 6], 15, -1560198380), s, e, t[r + 13], 21, 1309151649), a = C(a, s = C(s, e = C(e, i, a, s, t[r + 4], 6, -145523070), i, a, t[r + 11], 10, -1120210379), e, i, t[r + 2], 15, 718787259), s, e, t[r + 9], 21, -343485551), e = k(e, o), i = k(i, l), a = k(a, d), s = k(s, u)
    }
    return Array(e, i, a, s)
}

function y(t, n, e, i, a, s) { return k(E(k(k(n, t), k(i, s)), a), e) }

function B(t, n, e, i, a, s, r) { return y(n & e | ~n & i, t, n, a, s, r) }

function m(t, n, e, i, a, s, r) { return y(n & i | e & ~i, t, n, a, s, r) }

function I(t, n, e, i, a, s, r) { return y(n ^ e ^ i, t, n, a, s, r) }

function C(t, n, e, i, a, s, r) { return y(e ^ (n | ~i), t, n, a, s, r) }

function k(t, n) { var e = (65535 & t) + (65535 & n); return (t >> 16) + (n >> 16) + (e >> 16) << 16 | 65535 & e }

function E(t, n) { return t << n | t >>> 32 - n }
$(function() {

    //if (console.log(ssData), o.indexOf(r) < 0) throw f + " - (code : " + l + ")";
    console.log('cc' + ssData.EINSTEINSIGNTOIT_URL_ROOT + "/lib/sf/css/web/ej.widgets.core.min.css");
    $.rloader([{ src: ssData.EINSTEINSIGNTOIT_URL_ROOT + "/lib/sf/css/web/ej.widgets.core.min.css" }, {
            src: ssData.EINSTEINSIGNTOIT_URL_ROOT + "/lib/sf/css/web/default-theme/ej.theme.min.css"
        }, {
            event: "onready",
            func: v,
            arg: null
        }]),
        $("body").append('<div id="fisDlgSignature" style="display: none;" ><div><table style="width: 100%;" ><tbody><tr><td style="width: 80%;">' + ssData.langsTrans_EINSTEINSIGN_InterveningSignLabel + ' : </td><td align="right" style="width: 20%;"><button id="fisIntervenantBtnErase">' + ssData.btnErase + '</button></td></tr></tbody></table><div id="fisSignatureIntervenant"></div></div><div><table style="width: 100%; padding-top: 5px;"><tbody><tr><td style="width: 80%;">' + ssData.langsTrans_EINSTEINSIGN_CustomerSignLabel + ' : </td><td align="right" style="width: 20%;"><button id="fisClientBtnErase">' + ssData.btnErase + '</button></td></tr></tbody></table><div id="fisSignatureClient"></div></div><div id="fisActions" style="width: 100%; margin-top: 10px; margin-left: 2px; border-top: 2px solid grey;"><button id="fisBtnValidate" style="margin: 10px;">' + ssData.btnValidate + '</button><button id="fisBtnCancel" style="margin: 10px; float: right;">' + ssData.btnCancel + "</button></div></div>"),
        $("body").append($("#signatureScripts")),
        $("#model").change(function() {
            console.log('model' + $("#model").val());
            "einsteinsigntoit" !== $("#model").val() ? $("#einsteinsigntoit-warning").hide() : 1 !== parseInt(ssData.objectStatut) && 0 == ssData.confGlobal_EINSTEINSIGN_ALWAYS_ALLOW_SIGNING ? $("#builddoc_generatebutton").after(t) : e || $("#builddoc_generatebutton").after(n)
        }),
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) && $("body").on("taphold", "#einsteinsigntoit-warning", function(t) { alert($("#einsteinsigntoit-warning").attr("title")) }), e || ($("#einsteinsigntoit-warning").hide())
});