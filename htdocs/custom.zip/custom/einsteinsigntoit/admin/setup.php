<?php

/* Copyright (C) 2004-2017	Laurent Destailleur		<eldy@users.sourceforge.net>
 * Copyright (C) 2019				ProgSI								< contact@progsi.ma >
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file    soleilsign/admin/setup.php
 * \ingroup soleilsign
 * \brief   SoleilSign setup page.
 */
// Load Dolibarr environment
$res	 = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"]))
	$res	 = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp	 = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2	 = realpath(__FILE__);
$i		 = strlen($tmp) - 1;
$j		 = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php"))
	$res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php"))
	$res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php"))
	$res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php"))
	$res = @include "../../../main.inc.php";
if (!$res)
	die("Include of main fails");

global $langs, $user;

// Libraries
require_once DOL_DOCUMENT_ROOT . "/core/lib/admin.lib.php";
// require_once '../lib/soleilsign.lib.php';
//require_once "../class/myclass.class.php";
// Translations
$langs->loadLangs(array("admin", "soleilsign@soleilsign"));

// Access control
if (!$user->admin)
	accessforbidden();

// Parameters
$action			 = GETPOST('action', 'alpha');
$backtopage	 = GETPOST('backtopage', 'alpha');

$arrayofparameters = array(
//	'SOLEILSIGN_MYPARAM1'=>array('css'=>'minwidth200','enabled'=>1),
//	'SOLEILSIGN_MYPARAM2'=>array('css'=>'minwidth500','enabled'=>1),
		'EINSTEINSIGN_MARK_COMMANDE_AS_SIGNED' => array('css' => 'minwidth100', 'enabled' => 1),
		'EINSTEINSIGN_DIALOG_WIDTH'							 => array('css' => 'minwidth200', 'enabled' => 1),
);


/*
 * --------------------------------------------- Actions
 */
//if ((float) DOL_VERSION >= 6) {
//	include DOL_DOCUMENT_ROOT . '/core/actions_setmoduleoptions.inc.php';
//}
// $action must be defined
// $arrayofparameters must be set for action 'update'
// $nomessageinupdate can be set to 1
// $nomessageinsetmoduleoptions can be set to 1

if ($action == 'update' && is_array($arrayofparameters)) {
	$db->begin();

	$ok = true;
	foreach ($arrayofparameters as $key => $val) {
		$result = dolibarr_set_const($db, $key, GETPOST($key, 'alpha'), 'chaine', 0, '', $conf->entity);
		if ($result < 0) {
			$ok = false;
			break;
		}
	}

	if ($ok) {
		$db->commit();
		if (empty($nomessageinupdate))
			setEventMessages($langs->trans("SetupSaved"), null, 'mesgs');
	}
	else {
		$db->rollback();
		if (empty($nomessageinupdate))
			setEventMessages($langs->trans("SetupNotSaved"), null, 'errors');
	}
}


/*
 * --------------------------------------------- View
 */

$page_name = "SoleilSignSetup";
llxHeader('', $langs->trans($page_name));

// Subheader
$linkback = '<a href="' . ($backtopage ? $backtopage : DOL_URL_ROOT . '/admin/modules.php?restore_lastsearch_values=1') . '">' . $langs->trans("BackToModuleList") . '</a>';

print load_fiche_titre($langs->trans($page_name), $linkback, 'object_soleilsign@soleilsign');

// Configuration header
$head = []; // soleilsignAdminPrepareHead();
dol_fiche_head($head, 'settings', '', -1, "soleilsign@soleilsign");

// Setup page goes here
echo $langs->trans("SoleilSignSetupPage") . '<br><br>';

if ($action == 'edit') {
	print '<form method="POST" action="' . $_SERVER["PHP_SELF"] . '">';
	print '<input type="hidden" name="token" value="' . $_SESSION['newtoken'] . '">';
	print '<input type="hidden" name="action" value="update">';

	print '<table class="noborder" width="100%">';
	print '<tr class="liste_titre"><td class="titlefield">' . $langs->trans("Parameter") . '</td><td>' . $langs->trans("Value") . '</td></tr>';

	foreach ($arrayofparameters as $key => $val) {
		print '<tr class="oddeven"><td>';
		print $form->textwithpicto($langs->trans($key), $langs->trans($key . 'Tooltip'));
		print '</td><td>';
		// print '<input name="' . $key . '"  class="flat ' . (empty($val['css']) ? 'minwidth200' : $val['css']) . '" value="' . $conf->global->$key . '">';
		switch ($key) {
			case 'EINSTEINSIGN_MARK_COMMANDE_AS_SIGNED':
				print '
						<select id="' . $key . '" name="' . $key . '">
							<option value="1" ' . ($conf->global->$key == 1 ? 'selected' : '') . '>' . $langs->trans('OUI') . '</option>
							<option value="0" ' . ($conf->global->$key == 0 ? 'selected' : '') . '>' . $langs->trans('NON') . '</option>
						</select>
					';
				break;
			case 'EINSTEINSIGN_DIALOG_WIDTH':
				print '
						<select id="' . $key . '" name="' . $key . '">
							<option value="280px" ' . ($conf->global->$key == '280px' ? 'selected' : '') . '>' . $langs->trans('DialogWidthSmall') . ' (280px)' . '</option>
							<option value="380px" ' . ($conf->global->$key == '380px' ? 'selected' : '') . '>' . $langs->trans('DialogWidthNormal') . ' (380px)' . '</option>
							<option value="480px" ' . ($conf->global->$key == '480px' ? 'selected' : '') . '>' . $langs->trans('DialogWidthLarge') . ' (480px)' . '</option>
							<option value="540px" ' . ($conf->global->$key == '540px' ? 'selected' : '') . '>' . $langs->trans('DialogWidthExtraLarge') . ' (540px)' . '</option>
						</select>
					';
				break;
			default:
				print '<input name="' . $key . '"  class="flat ' . (empty($val['css']) ? 'minwidth200' : $val['css']) . '" value="' . $conf->global->$key . '">';
		}


		print '</td></tr>';
	}
	print '</table>';

	print '<br><div class="center">';
	print '<input class="button" type="submit" value="' . $langs->trans("Save") . '">';
	print '</div>';

	print '</form>';
	print '<br>';
} else {
	if (!empty($arrayofparameters)) {
		print '<table class="noborder" width="100%">';
		print '<tr class="liste_titre"><td class="titlefield">' . $langs->trans("Parameter") . '</td><td>' . $langs->trans("Value") . '</td></tr>';

		foreach ($arrayofparameters as $key => $val) {
			print '<tr class="oddeven"><td>';
			print $form->textwithpicto($langs->trans($key), $langs->trans($key . 'Tooltip'));
			print '</td><td>';

			switch ($key) {
				case 'EINSTEINSIGN_MARK_COMMANDE_AS_SIGNED':
					print (!isset($conf->global->$key) || $conf->global->$key == 1 ? $langs->trans('OUI') : $langs->trans('NON'));
					break;
				case 'EINSTEINSIGN_DIALOG_WIDTH':
					print (!empty($conf->global->$key) ? $conf->global->$key : '380px');
					break;
				default:
					print '';
			}
			print '</td></tr>';
		}

		print '</table>';

		print '<div class="tabsAction">';
		print '<a class="butAction" href="' . $_SERVER["PHP_SELF"] . '?action=edit">' . $langs->trans("Modify") . '</a>';
		print '</div>';
	} else {
		print '<br>' . $langs->trans("NothingToSetup");
	}
}


// Page end
dol_fiche_end();

llxFooter();
$db->close();

