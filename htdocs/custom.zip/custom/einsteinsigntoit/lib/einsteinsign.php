<?php

/* Copyright (C) 2019  ProgSI    <contact@progsi.ma>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

$res = 0;
$res = @include_once dirname(dirname(__DIR__)) . '/master.inc.php';
if ($res) {
	define('EINSTEINSIGNTOIT_DOCUMENT_ROOT', DOL_DOCUMENT_ROOT . '/einsteinsigntoit');
	define('EINSTEINSIGNTOIT_URL_ROOT', DOL_URL_ROOT . '/einsteinsigntoit');
}
else {
	$res = @include_once dirname(dirname(dirname(__DIR__))) . '/master.inc.php';
	if ($res) {
		define('EINSTEINSIGNTOIT_DOCUMENT_ROOT', $conf->file->dol_document_root['alt0'] . '/einsteinsigntoit');
		define('EINSTEINSIGNTOIT_URL_ROOT', DOL_URL_ROOT . $conf->file->dol_url_root['alt0'] . '/einsteinsigntoit');
	}
	else {
		die("Include of master file fails." . "\n" . "L'inclusion du fichier master a échoué.");
	}
}
include_once EINSTEINSIGNTOIT_DOCUMENT_ROOT . '/init.inc.php';
include_once EINSTEINSIGNTOIT_DOCUMENT_ROOT . '/lib/einsteinsign.lib.php';

$compareVersionTo800 = compareVersions(DOL_VERSION, '8.0.0');
$compareVersionTo700 = compareVersions(DOL_VERSION, '7.0.0');

$action									 = GETPOST('action', '', 2);
$objectRef							 = GETPOST('objectRef', '', 2);
$objectEntity						 = GETPOST('objectEntity', '', 2);
$strokesIntervenantJson	 = GETPOST('strokesIntervenant', '', 2);
$strokesIntervenant			 = json_decode($strokesIntervenantJson);
$strokesClientJson			 = GETPOST('strokesClient', '', 2);
$strokesClient					 = json_decode($strokesClientJson);

$objectEntity = (!empty($objectEntity) ? $objectEntity : 0);

$response = ['status' => 'OK', 'message' => 'Success', 'data' => ''];

if ($action === 'createImage' && !empty($strokesIntervenant) && !empty($strokesClient) && !empty($objectRef)) {

	// on doit créer l'image de la signature
	$response = createSignatureImageFile($strokesIntervenant, $objectRef, $objectEntity, 'intervenant');
	if ($response['status'] === 'OK') {
		$response = createSignatureImageFile($strokesClient, $objectRef, $objectEntity, 'client');
	}

//	$error									 = 0;
//	$data64OriginIntervenant = $strokesIntervenant;
//	$data64OriginClient			 = $strokesClient;
//
//	if (preg_match('/^data:image\/(\w+);base64,/', $data64OriginIntervenant, $type)) {
//		// recherche du type
//		$type = strtolower($type[1]); // jpg, png, gif
//		if (!in_array($type, ['jpg', 'png'])) {
//			$response = ['status' => 'KO', 'message' => 'Invalid image type', 'data' => $type];
//			$error++;
//		}
//
//		// on parcours les "morceaux" de la signature pour :
//		// - supprimer le début spécifique au html
//		// - remettre les "+" à la place des espaces
//		// - concaténer les morceaux
//		$signature64Intervenant = '';
//
//		// $data	 = substr($data, strpos($data, ',') + 1);
//		$data64Intervenant			 = substr($strokesIntervenant, 22); // on supprime la chaine "data:image/png;base64," qui est spécifique à la représentation html de l'image
//		// les signes "+" dans les données en base 64 peuvent avoir été remplacés par un espace lors du transfert par http,
//		// ici, on remet les "+" à la place des espaces pour avoir un format base 64 correct
//		$data64Intervenant			 = str_replace(' ', '+', $data64Intervenant);
//		$signature64Intervenant	 = $data64Intervenant;
//
//		$signatureBinIntervenant = base64_decode($signature64Intervenant, true);
//		if ($signatureBinIntervenant === false) {
//			$response = ['status' => 'KO', 'message' => 'base64_decode failed', 'data' => $data64OriginIntervenant];
//			$error++;
//		}
//	} else {
//		$response = ['status' => 'KO', 'message' => 'Did not match data URI with image data', 'data' => $data64OriginIntervenant];
//		$error++;
//	}
//
//	if (empty($error)) {
//		// --- on crée le fichier image de la signature
//		$objectRef = dol_sanitizeFileName($objectRef);
//		if ($compareVersionTo800 === -1) { // < 8.0.0
//			$dir = $conf->ficheinter->dir_output . "/temp"; // le multidir n'est pas bien géré pour les versions 7.0.*
//		} else { // >= 8.0.0
//			$dir = $conf->ficheinter->multidir_output[$objectEntity] . "/temp";
//		}
//
//		$signatureFileIntervenant	 = $dir . "/" . $objectRef . "-signature-intervenant." . $type;
//		$res											 = @file_put_contents($signatureFileIntervenant, $signatureBinIntervenant);
//		if ($res !== false) {
//			$response = ['status' => 'OK', 'message' => 'Success', 'data' => $data64OriginIntervenant];
//		} else {
//			$response = ['status' => 'KO', 'message' => error_get_last()['message'], 'data' => json_encode($conf->ficheinter->multidir_output[1])];
//		}
//	}
}
else {
	$response = ['status' => 'KO', 'message' => $langs->transnoentities('EINSTEINSIGN_IncompleteDataReceived'), 'data' => ''];
}

echo json_encode($response);

// ----------------------------------------------------------------------------------------------
//
//                                    createSignatureImageFile()
//                                    Crée le fichier image de la signature sous format objectRef-signature-suffix.png
//
//
function createSignatureImageFile($strokes, $objectRef, $objectEntity, $fileSuffix) {
	global $conf;

	$response = ['status' => 'KO', 'message' => 'ERROR', 'data' => ''];

	// on doit créer l'image de la signature
	$data64Origin = $strokes;

	if (preg_match('/^data:image\/(\w+);base64,/', $data64Origin, $type)) {
		// recherche du type
		$type = strtolower($type[1]); // jpg, png, gif
		if (!in_array($type, ['jpg', 'png'])) {
			$response = ['status' => 'KO', 'message' => $langs->transnoentities('EINSTEINSIGN_InvalidImageType'), 'data' => $type];
			return $response;
		}

		// on parcours les "morceaux" de la signature pour :
		// - supprimer le début spécifique au html
		// - remettre les "+" à la place des espaces
		// - concaténer les morceaux
		$signature64 = '';

		// $data	 = substr($data, strpos($data, ',') + 1);
		$data64			 = substr($strokes, 22); // on supprime la chaine "data:image/png;base64," qui est spécifique à la représentation html de l'image
		// les signes "+" dans les données en base 64 peuvent avoir été remplacés par un espace lors du transfert par http,
		// ici, on remet les "+" à la place des espaces pour avoir un format base 64 correct
		$data64			 = str_replace(' ', '+', $data64);
		$signature64 = $data64;

		$signatureBin = base64_decode($signature64, true);
		if ($signatureBin === false) {
			$response = ['status' => 'KO', 'message' => $langs->transnoentities('EINSTEINSIGN_Base64DecodeFailed'), 'data' => $data64Origin];
			return $response;
		}
	}
	else {
		$response = ['status' => 'KO', 'message' => $langs->transnoentities('EINSTEINSIGN_ImageDataError'), 'data' => $data64Origin];
		return $response;
	}

	// --- on crée le fichier image de la signature
	$objectRef = dol_sanitizeFileName($objectRef);
	if ($compareVersionTo800 === -1) { // < 8.0.0
		$dir = $conf->deviscaratoit->dir_output . "/temp"; // le multidir n'est pas bien géré pour les versions 7.0.*
	}
	else { // >= 8.0.0
		$dir = $conf->deviscaratoit->multidir_output[$objectEntity] . "/temp";
	}

	// si le répertoire temp n'existe pas, on essaie de le créer
	if (!file_exists($dir)) {
		@mkdir($dir, 0777, true);
	}

	if (file_exists($dir)) {
		$signatureFile = $dir . "/" . $objectRef . "-signature" . (!empty($fileSuffix) ? "-" . $fileSuffix : "") . "." . $type;
		$res					 = @file_put_contents($signatureFile, $signatureBin);
		if ($res !== false) {
			$response = ['status' => 'OK', 'message' => 'Success', 'data' => ''];
			return $response;
		}
		else {
			$response = ['status' => 'KO', 'message' => error_get_last()['message'], 'data' => ''];
			return $response;
		}
	}
	else {
		$response = ['status' => 'KO', 'message' => $langs->transnoentities('EINSTEINSIGN_DirectoryDosntExists') . ' : ' . $dir, 'data' => ''];
		return $response;
	}

	return $response;
}
