<?php

/* Copyright (C) 2019				ProgSI								< contact@progsi.ma >
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

$res = 0;
$res = @include_once dirname(dirname(__DIR__)) . '/master.inc.php';
if ($res) {
	define('EINSTEINSIGNTOIT_DOCUMENT_ROOT', DOL_DOCUMENT_ROOT . '/einsteinsigntoit');
	define('EINSTEINSIGNTOIT_URL_ROOT', DOL_URL_ROOT . '/einsteinsigntoit');
}
else {
	$res = @include_once dirname(dirname(dirname(__DIR__))) . '/master.inc.php';
	if ($res) {
		define('EINSTEINSIGNTOIT_DOCUMENT_ROOT', $conf->file->dol_document_root['alt0'] . '/einsteinsigntoit');
		define('EINSTEINSIGNTOIT_URL_ROOT', DOL_URL_ROOT . $conf->file->dol_url_root['alt0'] . '/einsteinsigntoit');
	}
	else {
		die("Include of master file fails." . "\n" . "L'inclusion du fichier master a échoué.");
	}
}
include_once EINSTEINSIGNTOIT_DOCUMENT_ROOT . '/init.inc.php';

class ActionsEinsteinSigntoit {

	public function __construct($db)
	{
	    $this->db = $db;
	}

	//function printObjectLine($parameters, &$object, &$action, $hookmanager) {//addMoreActionsButtons //doActions
		function doActions($parameters, &$object, &$action, $hookmanager){
		/* acton to insert new line into the report if shipped*/
	}
	/**
	 * Overloading the doActions function : replacing the parent's function with the one below
	 *
	 * @param   array()         $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    &$object        The object to process (an invoice if you are in invoice module, a intervention in ficheinter's module, etc...)
	 * @param   string          &$action        Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             < 0 on error, 0 on success, 1 to replace standard code
	 */
	function addMoreActionsButtons($parameters, &$object, &$action, $hookmanager) {
		global $langs, $conf, $user;
		$model=GETPOST('model');
		include_once dirname(__DIR__) . '/lib/einsteinsign.lib.php';

		$compareVersionTo800 = compareVersions(DOL_VERSION, '8.0.0');
		$compareVersionTo700 = compareVersions(DOL_VERSION, '7.0.0');

		$error		 = 0; // Error counter
		$container = 'einsteinsigntoit';
		// --- on supprime d'abord le fichier image de la signature si existant
		$objectRef = dol_sanitizeFileName($object->ref);
		if ($compareVersionTo800 === -1) { // < 8.0.0
			$dir = $conf->deviscaratoit->dir_output . "/temp"; // le multidir dans les version 7.0.* n'est pas bien géré
		} else {
			$dir = $conf->deviscaratoit->multidir_output[1] . "/temp";
		}
		$signatureFile = $dir . "/" . $objectRef . "-signature." . 'png';
		if (is_writable($signatureFile)) {
			unlink($signatureFile);
		}

		// --- on charge ensuite les données et les scripts nécessaires pour la gestion de la signature
		$langs->load('einsteinsign@einsteinsign');
//'objectEntity'																								 => (!empty($object->entity) ? $object->entity : $conf->entity),
		$ssData = [
				'EINSTEINSIGNTOIT_URL_ROOT'	=> trim(EINSTEINSIGNTOIT_URL_ROOT),
				'objectRef'	 => $object->ref,
				'objectEntity'	 => 1,
				'objectStatut'	 => $object->statut,
				'userRightsCommandeCreer' => $user->rights->deviscaratoit->creer,
				'parent1'			 => trim('einsteinsigntoit'),
				'parent2'			 => trim($container),
				'mytitle'			 => "EinsteinSign",
				'userRightsCommandeCloturer'			 => null,
				'userRightsEinsteinSignCanUse'	=> 1,
				'confSineteinSignEnabled'	 => $conf->einsteinsigntoit->enabled,
				'sfLocale'					 => trim(str_replace('_', '-', $langs->defaultlang)),
				'confGlobal_EINSTEINSIGN_MARK_FICHEINTER_AS_SIGNED'	 => $conf->global->EINSTEINSIGN_MARK_FICHEINTER_AS_SIGNED,
				'confGlobal_EINSTEINSIGN_DIALOG_WIDTH'		=> (!empty($conf->global->EINSTEINSIGN_DIALOG_WIDTH) ? $conf->global->EINSTEINSIGN_DIALOG_WIDTH : '380px'),
				'confGlobal_EINSTEINSIGN_ALWAYS_ALLOW_SIGNING' => (isset($conf->global->EINSTEINSIGN_ALWAYS_ALLOW_SIGNING) ? intval($conf->global->EINSTEINSIGN_ALWAYS_ALLOW_SIGNING) : 0),
				'confGlobal_EINSTEINSIGN_SIGNATURE_COLOR'	 => (isset($conf->global->EINSTEINSIGN_SIGNATURE_COLOR) ? $conf->global->EINSTEINSIGN_SIGNATURE_COLOR : '#000000'),
				'confGlobal_EINSTEINSIGN_SIGNATURE_LINE_WIDTH'	 => (isset($conf->global->EINSTEINSIGN_SIGNATURE_LINE_WIDTH) ? intval($conf->global->EINSTEINSIGN_SIGNATURE_LINE_WIDTH) : 1),
				'confGlobal_EINSTEINSIGN_ALLOW_SIGN_SUFFIX'	=> (isset($conf->global->EINSTEINSIGN_ALLOW_SIGN_SUFFIX) ? intval($conf->global->EINSTEINSIGN_ALLOW_SIGN_SUFFIX) : 1),
				'dlgTitle'									 => trim($langs->transnoentities('EINSTEINSIGN_dlgTitle')),
				'btnErase'									 => trim($langs->transnoentities('EINSTEINSIGN_btnErase')),
				'btnValidate'								 => trim($langs->transnoentities('EINSTEINSIGN_btnValidate')),
				'btnCancel'									 => trim($langs->transnoentities('EINSTEINSIGN_btnCancel')),
				'langsTrans_EINSTEINSIGN_Warning_FicheinterNotInStatusValidated' => trim($langs->transnoentities('EINSTEINSIGN_Warning_FicheinterNotInStatusValidated')),
				'langsTrans_EINSTEINSIGN_Warning_NotEnoughPermissions' => trim($langs->transnoentities('EINSTEINSIGN_Warning_NotEnoughPermissions')),
				'langsTrans_EINSTEINSIGN_InterveningSignLabel'	 => trim($langs->transnoentities('EINSTEINSIGN_InterveningSignLabel')),
				'langsTrans_EINSTEINSIGN_CustomerSignLabel'	 => trim($langs->transnoentities('EINSTEINSIGN_CustomerSignLabel')),
		];

		// waitingpopup
		echo '<div id="waitingPopup"></div>';
		// scripts
		echo '<div id="signatureScripts">'; // début scripts
		// widgets sf
		$p= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/common/ej.core.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/common/ej.scroller.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/common/ej.draggable.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/common/ej.touch.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/common/ej.globalize.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/web/ej.button.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/web/ej.dialog.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/web/ej.signature.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		$p.= '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/web/ej.waitingpopup.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		print $p;
		// traductions
		if ($langs->defaultlang === 'fr_FR') {
			echo '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/l10n/ej.localetexts.fr-FR.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		} else {
			echo '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/sf/scripts/l10n/ej.localetexts.en-US.min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';
		}

		// pour charger des .css par js
		echo '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/lib/rloader1.5.4_min.js?v=' . EINSTEINSIGNTOIT_VERSION . '"></script>';

		// on fournit à js quelques données
		echo '<script type="text/javascript">var ssData = ' . trim(json_encode($ssData)) . ';</script>';

		// initialisation des widgets et traitements métier
		echo '<script src="' . EINSTEINSIGNTOIT_URL_ROOT . '/js/einsteinsign.js?v=' . EINSTEINSIGNTOIT_VERSION . '" type="text/javascript"></script>';

		echo '</div>'; /// fin scripts

		return 0;
	}

}
