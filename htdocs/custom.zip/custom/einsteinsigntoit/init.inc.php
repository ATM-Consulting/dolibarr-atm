<?php

/* Copyright (C) 2019  ProgSI    <contact@progsi.ma>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

if (!defined('EINSTEINSIGNTOIT_VERSION'))
	define('EINSTEINSIGNTOIT_VERSION', '1.1.0');

$res = 0;
$res = @include_once dirname(__DIR__) . '/master.inc.php';
if ($res) {
	define('EINSTEINSIGNTOIT_DOCUMENT_ROOT', DOL_DOCUMENT_ROOT . '/EINSTEINSIGNTOIT');
	define('EINSTEINSIGNTOIT_URL_ROOT', DOL_URL_ROOT . '/EINSTEINSIGNTOIT');
} else {
	$res = @include_once dirname(dirname(__DIR__)) . '/master.inc.php';
	if ($res) {
		define('EINSTEINSIGNTOIT_DOCUMENT_ROOT', $conf->file->dol_document_root['alt0'] . '/EINSTEINSIGNTOIT');
		define('EINSTEINSIGNTOIT_URL_ROOT', DOL_URL_ROOT . $conf->file->dol_url_root['alt0'] . '/EINSTEINSIGNTOIT');
	} else {
		die("Include of master file fails." . "\n" . "L'inclusion du fichier master a échoué.");
	}
}

define('EINSTEINSIGNTOIT_DOCUMENT_ROOT_RELATIVE', str_replace(DOL_DOCUMENT_ROOT . '/', '', 'EINSTEINSIGNTOIT_DOCUMENT_ROOT'));
if (!empty(DOL_URL_ROOT)) {
	define('EINSTEINSIGNTOIT_URL_ROOT_RELATIVE', str_replace(DOL_URL_ROOT . '/', '', EINSTEINSIGN_URL_ROOT));
}
else {
	define('EINSTEINSIGNTOIT_URL_ROOT_RELATIVE', EINSTEINSIGN_URL_ROOT);
}

if (!defined('module'))
	define('module', 'EINSTEINSIGNTOIT');

$isForDolistore = true;
if ($isForDolistore)
	define('LIB_DOCUMENT_ROOT', EINSTEINSIGNTOIT_DOCUMENT_ROOT . '/lib');
else
	define('LIB_DOCUMENT_ROOT', DOL_DOCUMENT_ROOT . '/__lib');

// attention : $langs n'est pas défini dans master.inc.php
if (!defined('mytitle'))
	define('mytitle', 'EINSTEINSIGNTOIT');

// raccourci pour le MAIN_DB_PREFIX
if (!defined('LLX_'))
	define('LLX_', MAIN_DB_PREFIX);

include_once(__DIR__ . '/lib/einsteinsign.lib.php');
